// API utility functions for making requests to the backend
import { toast } from 'react-toastify';

// Base API URL from environment or default
const API_BASE_URL = process.env.REACT_APP_API_URL || 'http://localhost:5000/api/v1';

// Get the auth token from local storage
const getToken = () => {
  const user = localStorage.getItem('adminUser');
  if (user) {
    try {
      const parsedUser = JSON.parse(user);
      return parsedUser.token;
    } catch (error) {
      console.error('Error parsing user data:', error);
      return null;
    }
  }
  return null;
};

// Generic request function
const request = async (endpoint, options = {}) => {
  const token = getToken();
  
  const headers = {
    'Content-Type': 'application/json',
    ...(token && { 'Authorization': `Bearer ${token}` }),
    ...options.headers
  };
  
  const config = {
    ...options,
    headers
  };
  
  try {
    const response = await fetch(`${API_BASE_URL}${endpoint}`, config);
    
    // Handle JSON parsing
    const data = await response.json().catch(() => ({}));
    
    // Handle API errors
    if (!response.ok) {
      throw new Error(data.message || `API request failed with status ${response.status}`);
    }
    
    return data;
  } catch (error) {
    console.error(`API Error (${endpoint}):`, error.message);
    throw error;
  }
};

// Dashboard stats
export const fetchDashboardStats = async () => {
  try {
    return await request('/dashboard/stats');
  } catch (error) {
    toast.error('获取仪表盘数据失败');
    throw error;
  }
};

// Products
export const fetchProducts = async () => {
  return await request('/products');
};

export const getProduct = async (id) => {
  return await request(`/products/${id}`);
};

export const createProduct = async (productData) => {
  return await request('/products', {
    method: 'POST',
    body: JSON.stringify(productData)
  });
};

export const updateProduct = async (id, productData) => {
  return await request(`/products/${id}`, {
    method: 'PUT',
    body: JSON.stringify(productData)
  });
};

export const deleteProduct = async (id) => {
  return await request(`/products/${id}`, {
    method: 'DELETE'
  });
};

// Orders
export const fetchOrders = async () => {
  return await request('/orders');
};

export const getOrder = async (id) => {
  return await request(`/orders/${id}`);
};

export const updateOrderStatus = async (id, status) => {
  return await request(`/orders/${id}/status`, {
    method: 'PUT',
    body: JSON.stringify({ status })
  });
};

// Users
export const fetchUsers = async () => {
  return await request('/users');
};

export const getUser = async (id) => {
  return await request(`/users/${id}`);
};

export const createUser = async (userData) => {
  return await request('/users', {
    method: 'POST',
    body: JSON.stringify(userData)
  });
};

export const updateUser = async (id, userData) => {
  return await request(`/users/${id}`, {
    method: 'PUT',
    body: JSON.stringify(userData)
  });
};

export const toggleUserStatus = async (id, isActive) => {
  return await request(`/users/${id}/status`, {
    method: 'PUT',
    body: JSON.stringify({ isActive })
  });
};

// Upload file (multipart/form-data)
export const uploadFile = async (file) => {
  const formData = new FormData();
  formData.append('file', file);
  
  return await fetch(`${API_BASE_URL}/upload`, {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${getToken()}`
    },
    body: formData
  }).then(response => {
    if (!response.ok) {
      throw new Error('File upload failed');
    }
    return response.json();
  });
};

export default {
  fetchDashboardStats,
  fetchProducts,
  getProduct,
  createProduct,
  updateProduct,
  deleteProduct,
  fetchOrders,
  getOrder,
  updateOrderStatus,
  fetchUsers,
  getUser,
  createUser,
  updateUser,
  toggleUserStatus,
  uploadFile
};