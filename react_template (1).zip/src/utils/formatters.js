/**
 * Format date string based on user's language preference
 * @param {string|Date} dateString - Date string or Date object
 * @param {string} language - Language code ('en' for English, anything else for Chinese)
 * @param {object} options - Additional formatting options
 * @returns {string} Formatted date string
 */
export const formatDate = (dateString, language = 'en', options = {}) => {
  if (!dateString) return '';
  
  try {
    const date = dateString instanceof Date ? dateString : new Date(dateString);
    
    // Check if the date is valid
    if (isNaN(date.getTime())) {
      return '';
    }
    
    if (language === 'en') {
      // English format: Month Day, Year
      const defaultOptions = { 
        year: 'numeric', 
        month: 'short', 
        day: 'numeric',
        ...options
      };
      
      return date.toLocaleDateString('en-US', defaultOptions);
    } else {
      // Chinese format: Year-Month-Day
      const defaultOptions = {
        year: 'numeric',
        month: 'numeric',
        day: 'numeric',
        ...options
      };
      
      return date.toLocaleDateString('zh-CN', defaultOptions);
    }
  } catch (error) {
    console.error('Error formatting date:', error);
    return dateString?.toString() || '';
  }
};

/**
 * Format currency based on user's language preference and currency type
 * @param {number} amount - Amount to format
 * @param {string} currency - Currency code (default: 'CNY')
 * @param {string} language - Language code ('en' for English, anything else for Chinese)
 * @returns {string} Formatted currency string
 */
export const formatCurrency = (amount, currency = 'CNY', language = 'en') => {
  if (amount === undefined || amount === null) return '';
  
  try {
    const formatter = new Intl.NumberFormat(language === 'en' ? 'en-US' : 'zh-CN', {
      style: 'currency',
      currency: currency,
      minimumFractionDigits: 0,
      maximumFractionDigits: 2
    });
    
    return formatter.format(amount);
  } catch (error) {
    console.error('Error formatting currency:', error);
    return `${amount} ${currency}`;
  }
};

/**
 * Format number with thousands separators based on user's language preference
 * @param {number} number - Number to format
 * @param {string} language - Language code ('en' for English, anything else for Chinese)
 * @param {object} options - Additional formatting options
 * @returns {string} Formatted number string
 */
export const formatNumber = (number, language = 'en', options = {}) => {
  if (number === undefined || number === null) return '';
  
  try {
    const formatter = new Intl.NumberFormat(language === 'en' ? 'en-US' : 'zh-CN', options);
    return formatter.format(number);
  } catch (error) {
    console.error('Error formatting number:', error);
    return number.toString();
  }
};

/**
 * Format file size to human-readable format
 * @param {number} bytes - Size in bytes
 * @param {string} language - Language code ('en' for English, anything else for Chinese)
 * @returns {string} Formatted file size string
 */
export const formatFileSize = (bytes, language = 'en') => {
  if (bytes === 0) return language === 'en' ? '0 Bytes' : '0 字节';
  
  const sizes = language === 'en' 
    ? ['Bytes', 'KB', 'MB', 'GB', 'TB'] 
    : ['字节', 'KB', 'MB', 'GB', 'TB'];
    
  const i = Math.floor(Math.log(bytes) / Math.log(1024));
  
  return `${parseFloat((bytes / Math.pow(1024, i)).toFixed(2))} ${sizes[i]}`;
};

/**
 * Translate text based on current language
 * @param {string} text - Text to translate
 * @param {string} language - Language code ('en' for English, anything else for Chinese)
 * @returns {string} Translated text
 */
export const translateText = (text, language = 'en') => {
  if (!text) return '';
  
  // In a real application, this would connect to a translation service
  // For now, we're just returning the original text
  return text;
};