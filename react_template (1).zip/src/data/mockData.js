/**
 * 模拟数据用于开发和测试
 */

const mockData = {
  // 产品数据
  products: [
    {
      id: "p001",
      name: "高速扫描仪 X9000",
      nameEn: "High-Speed Scanner X9000",
      model: "X9000",
      categoryId: "scanning",
      imageUrls: [
        "https://images.unsplash.com/photo-1612815154858-60aa4c59eaa6?ixlib=rb-4.0.3&auto=format&fit=crop&w=500&q=60",
        "https://images.unsplash.com/photo-1587614382346-4ec70e388b28?ixlib=rb-4.0.3&auto=format&fit=crop&w=500&q=60"
      ],
      videoUrls: [],
      description: "高性能商用扫描仪，每分钟可扫描100页，自动双面扫描功能",
      descriptionEn: "High-performance commercial scanner, capable of scanning 100 pages per minute, automatic duplex scanning",
      parameters: [
        {
          name: "扫描速度",
          nameEn: "Scanning Speed",
          value: "100",
          valueEn: "100",
          unit: "ppm",
          groupName: "性能参数",
          isHighlight: true
        },
        {
          name: "分辨率",
          nameEn: "Resolution",
          value: "1200 x 1200",
          valueEn: "1200 x 1200",
          unit: "dpi",
          groupName: "性能参数",
          isHighlight: true
        },
        {
          name: "接口类型",
          nameEn: "Interface",
          value: "USB 3.0/网络/WiFi",
          valueEn: "USB 3.0/Network/WiFi",
          unit: "",
          groupName: "基本参数",
          isHighlight: false
        }
      ],
      isRecommended: true,
      tags: ["高速扫描", "双面扫描", "商用"],
      createdAt: "2023-08-15T10:00:00.000Z",
      updatedAt: "2023-09-20T14:30:00.000Z"
    },
    {
      id: "p002",
      name: "便携式扫描仪 M2000",
      nameEn: "Portable Scanner M2000",
      model: "M2000",
      categoryId: "scanning",
      imageUrls: [
        "https://images.unsplash.com/photo-1586810162909-8d28a9b180f4?ixlib=rb-4.0.3&auto=format&fit=crop&w=500&q=60"
      ],
      videoUrls: [],
      description: "轻巧便携的移动扫描仪，重量仅500克，适合外勤人员使用",
      descriptionEn: "Lightweight and portable mobile scanner, weighing only 500g, ideal for field staff",
      parameters: [
        {
          name: "扫描速度",
          nameEn: "Scanning Speed",
          value: "30",
          valueEn: "30",
          unit: "ppm",
          groupName: "性能参数",
          isHighlight: true
        },
        {
          name: "分辨率",
          nameEn: "Resolution",
          value: "600 x 600",
          valueEn: "600 x 600",
          unit: "dpi",
          groupName: "性能参数",
          isHighlight: false
        },
        {
          name: "重量",
          nameEn: "Weight",
          value: "500",
          valueEn: "500",
          unit: "g",
          groupName: "物理参数",
          isHighlight: true
        }
      ],
      isRecommended: true,
      tags: ["便携", "移动办公", "轻量级"],
      createdAt: "2023-07-20T08:00:00.000Z",
      updatedAt: "2023-09-15T11:20:00.000Z"
    }
  ],
  
  // 文章数据
  articles: [
    {
      id: "a001",
      title: "数字化转型中的文档管理策略",
      titleEn: "Document Management Strategies in Digital Transformation",
      content: "<p>文档管理在企业数字化转型中扮演着重要角色。</p><p>有效的策略包括明确目标、选择合适工具、确保安全性和推动文化变革。</p>",
      contentEn: "<p>Document management plays an important role in enterprise digital transformation.</p><p>Effective strategies include clarifying goals, choosing appropriate tools, ensuring security, and promoting cultural change.</p>",
      summary: "探讨企业数字化转型中的文档管理策略，包括目标设定、技术选型、安全保障和文化建设等方面。",
      summaryEn: "Discusses document management strategies in enterprise digital transformation, including goal setting, technology selection, security assurance, and cultural construction.",
      imageUrls: ["https://images.unsplash.com/photo-1553877522-43269d4ea984?ixlib=rb-4.0.3&auto=format&fit=crop&w=500&q=60"],
      tags: ["数字化转型", "文档管理", "企业信息化"],
      authorId: "user001",
      isPublished: true,
      viewCount: 1280,
      publishedAt: "2023-09-15T08:00:00.000Z",
      createdAt: "2023-09-10T14:30:00.000Z",
      updatedAt: "2023-09-15T08:00:00.000Z"
    },
    {
      id: "a002",
      title: "如何选择适合企业的扫描设备",
      titleEn: "How to Choose the Right Scanning Equipment for Your Business",
      content: "<p>选择合适的扫描设备对企业至关重要。</p><p>需考虑日常需求、扫描质量、连接兼容性和总拥有成本。</p>",
      contentEn: "<p>Choosing the right scanning equipment is crucial for businesses.</p><p>Consider daily needs, scanning quality, connectivity compatibility, and total cost of ownership.</p>",
      summary: "本文为企业提供扫描设备选型指南，从日常需求、扫描质量、连接兼容性和总拥有成本四个方面进行详细分析。",
      summaryEn: "This article provides a guide to selecting scanning equipment for businesses, with detailed analysis from four aspects: daily needs, scanning quality, connection compatibility, and total cost of ownership.",
      imageUrls: ["https://images.unsplash.com/photo-1563770557719-b3ff0eba0fa6?ixlib=rb-4.0.3&auto=format&fit=crop&w=500&q=60"],
      tags: ["扫描设备", "设备选型", "办公效率"],
      authorId: "user002",
      isPublished: true,
      viewCount: 856,
      publishedAt: "2023-08-28T10:15:00.000Z",
      createdAt: "2023-08-25T16:20:00.000Z",
      updatedAt: "2023-08-28T10:15:00.000Z"
    }
  ],
  
  // 案例数据
  cases: [
    {
      id: "c001",
      title: "某大型银行的文档数字化转型项目",
      titleEn: "Document Digitization Transformation Project for a Large Bank",
      client: "中国某大型银行",
      clientEn: "A Major Bank in China",
      industry: "金融行业",
      industryEn: "Financial Industry",
      content: "<p>该银行通过部署我们的高速扫描设备和文档管理系统，实现了全行文档的数字化管理。</p>",
      contentEn: "<p>The bank has achieved digital management of all documents through the deployment of our high-speed scanning equipment and document management system.</p>",
      summary: "通过部署扫描设备和文档管理系统，帮助银行实现了每日超过10万页文档的高效处理，优化了业务流程。",
      summaryEn: "By deploying scanning equipment and document management systems, we helped the bank achieve efficient processing of over 100,000 documents daily, optimizing business processes.",
      imageUrls: ["https://images.unsplash.com/photo-1556742049-0cfed4f6a45d?ixlib=rb-4.0.3&auto=format&fit=crop&w=500&q=60"],
      productIds: ["p001", "p005"],
      tags: ["银行", "文档数字化", "流程优化"],
      isPublished: true,
      viewCount: 1480,
      publishedAt: "2023-09-05T09:30:00.000Z",
      createdAt: "2023-09-01T15:20:00.000Z",
      updatedAt: "2023-09-05T09:30:00.000Z"
    },
    {
      id: "c002",
      title: "某医院医疗记录管理系统升级",
      titleEn: "Medical Record Management System Upgrade for a Hospital",
      client: "某三甲医院",
      clientEn: "A Top-tier Hospital",
      industry: "医疗行业",
      industryEn: "Healthcare Industry",
      content: "<p>通过整合扫描设备和专业医疗文档管理软件，帮助医院建立了高效的电子病历系统。</p>",
      contentEn: "<p>By integrating scanning devices and professional medical document management software, we helped the hospital establish an efficient electronic medical record system.</p>",
      summary: "为医院量身定制的解决方案，整合了高速扫描设备和医疗文档管理系统，大幅提升了患者记录的存储和检索效率。",
      summaryEn: "A customized solution for the hospital, integrating high-speed scanning equipment and medical document management systems, significantly improving the storage and retrieval efficiency of patient records.",
      imageUrls: ["https://images.unsplash.com/photo-1576091160550-2173dba999ef?ixlib=rb-4.0.3&auto=format&fit=crop&w=500&q=60"],
      productIds: ["p002", "p005", "p008"],
      tags: ["医疗", "电子病历", "数据管理"],
      isPublished: true,
      viewCount: 936,
      publishedAt: "2023-08-20T11:15:00.000Z",
      createdAt: "2023-08-15T14:30:00.000Z",
      updatedAt: "2023-08-20T11:15:00.000Z"
    }
  ]
};

export default mockData;