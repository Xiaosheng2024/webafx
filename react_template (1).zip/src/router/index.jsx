import React, { lazy, Suspense } from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';
import MainLayout from '../layout/MainLayout';

// Import GamePage directly to avoid dynamic import issues
import GamePage from '../pages/GamePage.jsx';
import TestPage from '../pages/TestPage.jsx'; // Import test page directly

// Lazy load other pages for better performance
const HomePage = lazy(() => import('../pages/HomePage.jsx'));
const ProductListPage = lazy(() => import('../pages/ProductListPage.jsx'));
const ProductDetailPage = lazy(() => import('../pages/ProductDetailPage.jsx'));
const ArticleListPage = lazy(() => import('../pages/ArticleListPage.jsx'));
const ArticleDetailPage = lazy(() => import('../pages/ArticleDetailPage.jsx'));
const CaseListPage = lazy(() => import('../pages/CaseListPage.jsx'));
const CaseDetailPage = lazy(() => import('../pages/CaseDetailPage.jsx'));
const SearchResultPage = lazy(() => import('../pages/SearchResultPage.jsx'));
const AboutPage = lazy(() => import('../pages/AboutPage.jsx'));
const ContactPage = lazy(() => import('../pages/ContactPage.jsx'));
const NotFoundPage = lazy(() => import('../pages/NotFoundPage.jsx'));

// Admin pages
const AdminLoginPage = lazy(() => import('../pages/AdminLoginPage.jsx'));
const TestLoginPage = lazy(() => import('../pages/admin/TestLoginPage.jsx'));
const DashboardPage = lazy(() => import('../pages/admin/DashboardPage.jsx'));
const ProductManagementPage = lazy(() => import('../pages/admin/ProductManagementPage.jsx'));
const OrderManagementPage = lazy(() => import('../pages/admin/OrderManagementPage.jsx'));
const UserManagementPage = lazy(() => import('../pages/admin/UserManagementPage.jsx'));

// Loading fallback
const LoadingFallback = () => (
  <div className="flex items-center justify-center h-screen">
    <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-600"></div>
  </div>
);

const AppRoutes = () => {
  return (
    <Routes>
      {/* Public routes */}
      <Route path="/" element={<MainLayout />}>
        <Route index element={
          <Suspense fallback={<LoadingFallback />}>
            <HomePage />
          </Suspense>
        } />
        
        <Route path="products">
          <Route index element={
            <Suspense fallback={<LoadingFallback />}>
              <ProductListPage />
            </Suspense>
          } />
          <Route path="category/:categoryId" element={
            <Suspense fallback={<LoadingFallback />}>
              <ProductListPage />
            </Suspense>
          } />
          <Route path=":productId" element={
            <Suspense fallback={<LoadingFallback />}>
              <ProductDetailPage />
            </Suspense>
          } />
        </Route>

        <Route path="articles">
          <Route index element={
            <Suspense fallback={<LoadingFallback />}>
              <ArticleListPage />
            </Suspense>
          } />
          <Route path="category/:categoryId" element={
            <Suspense fallback={<LoadingFallback />}>
              <ArticleListPage />
            </Suspense>
          } />
          <Route path=":articleId" element={
            <Suspense fallback={<LoadingFallback />}>
              <ArticleDetailPage />
            </Suspense>
          } />
        </Route>

        <Route path="cases">
          <Route index element={
            <Suspense fallback={<LoadingFallback />}>
              <CaseListPage />
            </Suspense>
          } />
          <Route path=":caseId" element={
            <Suspense fallback={<LoadingFallback />}>
              <CaseDetailPage />
            </Suspense>
          } />
        </Route>

        <Route path="search" element={
          <Suspense fallback={<LoadingFallback />}>
            <SearchResultPage />
          </Suspense>
        } />
        
        <Route path="about" element={
          <Suspense fallback={<LoadingFallback />}>
            <AboutPage />
          </Suspense>
        } />
        
        <Route path="contact" element={
          <Suspense fallback={<LoadingFallback />}>
            <ContactPage />
          </Suspense>
        } />
        
        <Route path="game" element={
          <Suspense fallback={<LoadingFallback />}>
            <GamePage />
          </Suspense>
        } />
        
        <Route path="404" element={
          <Suspense fallback={<LoadingFallback />}>
            <NotFoundPage />
          </Suspense>
        } />
        
        <Route path="*" element={<Navigate to="/404" replace />} />
      </Route>

      {/* Admin routes */}
      <Route path="/admin/login" element={
        <Suspense fallback={<LoadingFallback />}>
          <AdminLoginPage />
        </Suspense>
      } />
      
      <Route path="/admin/dashboard" element={
        <Suspense fallback={<LoadingFallback />}>
          <DashboardPage />
        </Suspense>
      } />
      
      <Route path="/admin/products" element={
        <Suspense fallback={<LoadingFallback />}>
          <ProductManagementPage />
        </Suspense>
      } />
      
      <Route path="/admin/orders" element={
        <Suspense fallback={<LoadingFallback />}>
          <OrderManagementPage />
        </Suspense>
      } />
      
      <Route path="/admin/users" element={
        <Suspense fallback={<LoadingFallback />}>
          <UserManagementPage />
        </Suspense>
      } />
      
      <Route path="/admin/test-login" element={
        <Suspense fallback={<LoadingFallback />}>
          <TestLoginPage />
        </Suspense>
      } />
      
      {/* Test route */}
      <Route path="/test" element={<TestPage />} />
    </Routes>
  );
};

export default AppRoutes;