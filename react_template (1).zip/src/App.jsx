import { Suspense, lazy } from 'react';
import { BrowserRouter as Router } from 'react-router-dom';
import AppRoutes from './router';
import { AppProvider } from './context/AppContext';
import { AuthProvider } from './contexts/AuthContext';

function App() {
  return (
    <AppProvider>
      <AuthProvider>
        <Router>
          <Suspense fallback={<div className="w-full h-screen flex items-center justify-center">
            <div className="animate-spin rounded-full h-16 w-16 border-t-2 border-b-2 border-blue-500"></div>
          </div>}>
            <AppRoutes />
          </Suspense>
        </Router>
      </AuthProvider>
    </AppProvider>
  );
}

export default App;