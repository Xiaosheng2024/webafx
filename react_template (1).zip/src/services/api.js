import axios from 'axios';

// Create an axios instance with default config
const api = axios.create({
  baseURL: '/api/v1',
  timeout: 10000,
  headers: {
    'Content-Type': 'application/json',
  },
});

// Request interceptor for API calls
api.interceptors.request.use(
  (config) => {
    // Get auth token from localStorage if it exists
    const token = localStorage.getItem('authToken');
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    
    // Get the current language from localStorage
    const language = localStorage.getItem('preferredLanguage') || 'zh';
    config.headers['Accept-Language'] = language;
    
    return config;
  },
  (error) => {
    return Promise.reject(error);
  }
);

// Response interceptor
api.interceptors.response.use(
  (response) => {
    // Any status code within the range of 2xx causes this function to trigger
    return response.data;
  },
  (error) => {
    // Handle errors based on status code
    if (error.response) {
      // The request was made and the server responded with a status code
      // that falls out of the range of 2xx
      const { status } = error.response;
      
      if (status === 401) {
        // Unauthorized - clear user data and redirect to login
        localStorage.removeItem('authToken');
        localStorage.removeItem('user');
        
        // If not already on the login page, redirect to login
        if (window.location.pathname !== '/login') {
          window.location.href = '/login';
        }
      }
      
      if (status === 403) {
        // Forbidden - redirect to 403 page
        window.location.href = '/forbidden';
      }
      
      if (status === 404) {
        // Not found - redirect to 404 page
        window.location.href = '/not-found';
      }
    }
    
    return Promise.reject(error);
  }
);

// For development/demo purposes, we'll use mock data
const useMockData = true;

// Helper function to simulate API delay for mock data
const mockDelay = (ms = 500) => new Promise(resolve => setTimeout(resolve, ms));

// Function to intercept API calls and return mock data if needed
export const apiRequest = async (method, url, data = null, config = {}) => {
  if (useMockData) {
    console.log(`Mock ${method} request to ${url}`, data);
    await mockDelay();
    
    // Import mock data dynamically based on the URL
    const mockData = await import('../data/mockData').then(module => {
      const urlParts = url.split('/');
      const resource = urlParts[1]; // Extract resource name from URL
      
      if (resource && module.default[resource]) {
        // Handle paginated responses
        if (url.includes('?') && url.includes('page=')) {
          // Extract query params
          const params = new URLSearchParams(url.split('?')[1]);
          const page = parseInt(params.get('page') || '1');
          const limit = parseInt(params.get('limit') || '10');
          
          const items = module.default[resource];
          const totalItems = items.length;
          const startIndex = (page - 1) * limit;
          const endIndex = startIndex + limit;
          
          return {
            data: items.slice(startIndex, endIndex),
            meta: {
              page,
              limit,
              totalItems,
              totalPages: Math.ceil(totalItems / limit),
            }
          };
        }
        
        // Handle detail view with ID
        if (urlParts.length > 2 && urlParts[2]) {
          const id = urlParts[2];
          return module.default[resource].find(item => item.id === id);
        }
        
        // Return the entire resource collection
        return module.default[resource];
      }
      
      return null;
    });
    
    if (mockData === null) {
      throw new Error(`No mock data available for ${url}`);
    }
    
    return mockData;
  }
  
  // Make actual API request if not using mock data
  switch (method.toLowerCase()) {
    case 'get':
      return api.get(url, config);
    case 'post':
      return api.post(url, data, config);
    case 'put':
      return api.put(url, data, config);
    case 'patch':
      return api.patch(url, data, config);
    case 'delete':
      return api.delete(url, config);
    default:
      throw new Error(`Unsupported method: ${method}`);
  }
};

export default api;