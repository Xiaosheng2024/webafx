import { apiRequest } from './api';

/**
 * Submit a new consultation/inquiry
 * @param {Object} consultationData - Consultation data
 * @param {string} consultationData.name - Customer name
 * @param {string} consultationData.company - Company name
 * @param {string} consultationData.email - Email address
 * @param {string} consultationData.phone - Phone number
 * @param {string} consultationData.content - Inquiry content
 * @param {string} [consultationData.productId] - Referenced product ID (optional)
 * @returns {Promise<Object>} - Created consultation
 */
export const submitConsultation = async (consultationData) => {
  // Basic validation
  const requiredFields = ['name', 'company', 'email', 'phone', 'content'];
  
  for (const field of requiredFields) {
    if (!consultationData[field] || !consultationData[field].trim()) {
      throw new Error(`${field} is required`);
    }
  }
  
  // Email validation
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!emailRegex.test(consultationData.email)) {
    throw new Error('Invalid email format');
  }
  
  // Phone validation (basic)
  const phoneRegex = /^[0-9+\-\s]{5,20}$/;
  if (!phoneRegex.test(consultationData.phone)) {
    throw new Error('Invalid phone number format');
  }
  
  return apiRequest('post', '/consultations', consultationData);
};

/**
 * Get consultation list (admin only)
 * @param {Object} params - Query parameters
 * @param {string} params.status - Filter by status
 * @param {number} params.limit - Limit number of results
 * @param {number} params.page - Page number for pagination
 * @returns {Promise<Array>} - List of consultations
 */
export const getConsultationList = async (params = {}) => {
  let queryString = '';
  
  if (params) {
    const queryParams = new URLSearchParams();
    
    if (params.status) {
      queryParams.append('status', params.status);
    }
    
    if (params.limit) {
      queryParams.append('limit', params.limit);
    }
    
    if (params.page) {
      queryParams.append('page', params.page);
    }
    
    queryString = queryParams.toString() ? `?${queryParams.toString()}` : '';
  }
  
  return apiRequest('get', `/admin/consultations${queryString}`);
};

/**
 * Get consultation details by ID (admin only)
 * @param {string} id - Consultation ID
 * @returns {Promise<Object>} - Consultation details
 */
export const getConsultationDetail = async (id) => {
  return apiRequest('get', `/admin/consultations/${id}`);
};

/**
 * Update consultation status (admin only)
 * @param {string} id - Consultation ID
 * @param {string} status - New status ('new', 'in_progress', 'completed', 'cancelled')
 * @returns {Promise<Object>} - Updated consultation
 */
export const updateConsultationStatus = async (id, status) => {
  return apiRequest('patch', `/admin/consultations/${id}/status`, { status });
};

/**
 * Handle a consultation (admin only)
 * @param {string} id - Consultation ID
 * @param {Object} data - Handling data
 * @param {string} data.result - Handling result
 * @param {string} data.handlerId - ID of the administrator who handled the consultation
 * @returns {Promise<Object>} - Handled consultation
 */
export const handleConsultation = async (id, data) => {
  return apiRequest('post', `/admin/consultations/${id}/handle`, data);
};