import { apiRequest } from './api';
import { translateText } from '../utils/formatters';

/**
 * Get product list with optional filtering
 * @param {Object} params - Query parameters
 * @param {string} params.categoryId - Filter by category ID
 * @param {number} params.limit - Limit number of results
 * @param {number} params.page - Page number for pagination
 * @param {string} params.searchQuery - Search query
 * @returns {Promise<Array>} - List of products
 */
export const getProductList = async (params = {}) => {
  let queryString = '';
  
  if (params) {
    const queryParams = new URLSearchParams();
    
    if (params.categoryId) {
      queryParams.append('categoryId', params.categoryId);
    }
    
    if (params.limit) {
      queryParams.append('limit', params.limit);
    }
    
    if (params.page) {
      queryParams.append('page', params.page);
    }
    
    if (params.searchQuery) {
      queryParams.append('q', params.searchQuery);
    }
    
    queryString = queryParams.toString() ? `?${queryParams.toString()}` : '';
  }
  
  return apiRequest('get', `/products${queryString}`);
};

/**
 * Get product details by ID
 * @param {string} id - Product ID
 * @returns {Promise<Object>} - Product details
 */
export const getProductDetail = async (id) => {
  const product = await apiRequest('get', `/products/${id}`);
  
  // If the English translation doesn't exist, generate it automatically
  // Note: In a real application, this would be handled on the server side
  if (!product.nameEn && product.name) {
    product.nameEn = await translateText(product.name, 'en');
  }
  
  if (!product.descriptionEn && product.description) {
    product.descriptionEn = await translateText(product.description, 'en');
  }
  
  // Translate parameters if needed
  if (product.parameters) {
    for (const param of product.parameters) {
      if (!param.nameEn && param.name) {
        param.nameEn = await translateText(param.name, 'en');
      }
      
      if (!param.valueEn && param.value) {
        param.valueEn = await translateText(param.value, 'en');
      }
    }
  }
  
  return product;
};

/**
 * Get related products for a given product
 * @param {string} productId - Product ID 
 * @param {number} limit - Maximum number of results
 * @returns {Promise<Array>} - List of related products
 */
export const getRelatedProducts = async (productId, limit = 4) => {
  return apiRequest('get', `/products/${productId}/related?limit=${limit}`);
};

/**
 * Compare products by IDs
 * @param {Array<string>} ids - Product IDs to compare 
 * @returns {Promise<Object>} - Comparison data
 */
export const compareProducts = async (ids) => {
  if (!Array.isArray(ids) || ids.length < 2) {
    throw new Error('At least two product IDs must be provided for comparison');
  }
  
  const queryString = ids.map(id => `id=${id}`).join('&');
  return apiRequest('get', `/products/compare?${queryString}`);
};

/**
 * Search products
 * @param {string} query - Search query
 * @param {Object} filters - Filter criteria
 * @returns {Promise<Array>} - Search results
 */
export const searchProducts = async (query, filters = {}) => {
  let queryString = `q=${encodeURIComponent(query)}`;
  
  if (filters) {
    for (const [key, value] of Object.entries(filters)) {
      if (value !== undefined && value !== null) {
        queryString += `&${key}=${encodeURIComponent(value)}`;
      }
    }
  }
  
  return apiRequest('get', `/products/search?${queryString}`);
};

/**
 * Create a new product (admin only)
 * @param {Object} productData - Product data
 * @returns {Promise<Object>} - Created product
 */
export const createProduct = async (productData) => {
  // If English translations are not provided, generate them automatically
  if (!productData.nameEn && productData.name) {
    productData.nameEn = await translateText(productData.name, 'en');
  }
  
  if (!productData.descriptionEn && productData.description) {
    productData.descriptionEn = await translateText(productData.description, 'en');
  }
  
  return apiRequest('post', '/admin/products', productData);
};

/**
 * Update an existing product (admin only)
 * @param {string} id - Product ID
 * @param {Object} productData - Updated product data
 * @returns {Promise<Object>} - Updated product
 */
export const updateProduct = async (id, productData) => {
  // If English translations are not provided, generate them automatically
  if (!productData.nameEn && productData.name) {
    productData.nameEn = await translateText(productData.name, 'en');
  }
  
  if (!productData.descriptionEn && productData.description) {
    productData.descriptionEn = await translateText(productData.description, 'en');
  }
  
  return apiRequest('put', `/admin/products/${id}`, productData);
};

/**
 * Delete a product (admin only)
 * @param {string} id - Product ID
 * @returns {Promise<Object>} - Deletion result
 */
export const deleteProduct = async (id) => {
  return apiRequest('delete', `/admin/products/${id}`);
};