import { apiRequest } from './api';
import { translateText } from '../utils/formatters';

/**
 * Get article list with optional filtering
 * @param {Object} params - Query parameters
 * @param {string} params.categoryId - Filter by category ID
 * @param {number} params.limit - Limit number of results
 * @param {number} params.page - Page number for pagination
 * @param {string} params.tag - Filter by tag
 * @returns {Promise<Array>} - List of articles
 */
export const getArticleList = async (params = {}) => {
  let queryString = '';
  
  if (params) {
    const queryParams = new URLSearchParams();
    
    if (params.categoryId) {
      queryParams.append('categoryId', params.categoryId);
    }
    
    if (params.limit) {
      queryParams.append('limit', params.limit);
    }
    
    if (params.page) {
      queryParams.append('page', params.page);
    }
    
    if (params.tag) {
      queryParams.append('tag', params.tag);
    }
    
    queryString = queryParams.toString() ? `?${queryParams.toString()}` : '';
  }
  
  return apiRequest('get', `/articles${queryString}`);
};

/**
 * Get article details by ID
 * @param {string} id - Article ID
 * @returns {Promise<Object>} - Article details
 */
export const getArticleDetail = async (id) => {
  const article = await apiRequest('get', `/articles/${id}`);
  
  // If the English translation doesn't exist, generate it automatically
  // Note: In a real application, this would be handled on the server side
  if (!article.titleEn && article.title) {
    article.titleEn = await translateText(article.title, 'en');
  }
  
  if (!article.summaryEn && article.summary) {
    article.summaryEn = await translateText(article.summary, 'en');
  }
  
  if (!article.contentEn && article.content) {
    article.contentEn = await translateText(article.content, 'en');
  }
  
  return article;
};

/**
 * Get related articles for a given product
 * @param {string} productId - Product ID 
 * @param {number} limit - Maximum number of results
 * @returns {Promise<Array>} - List of related articles
 */
export const getRelatedArticles = async (productId, limit = 4) => {
  return apiRequest('get', `/products/${productId}/articles?limit=${limit}`);
};

/**
 * Get related articles for a given article
 * @param {string} articleId - Article ID 
 * @param {number} limit - Maximum number of results
 * @returns {Promise<Array>} - List of related articles
 */
export const getSimilarArticles = async (articleId, limit = 4) => {
  return apiRequest('get', `/articles/${articleId}/related?limit=${limit}`);
};

/**
 * Search articles
 * @param {string} query - Search query
 * @param {Object} filters - Filter criteria
 * @returns {Promise<Array>} - Search results
 */
export const searchArticles = async (query, filters = {}) => {
  let queryString = `q=${encodeURIComponent(query)}`;
  
  if (filters) {
    for (const [key, value] of Object.entries(filters)) {
      if (value !== undefined && value !== null) {
        queryString += `&${key}=${encodeURIComponent(value)}`;
      }
    }
  }
  
  return apiRequest('get', `/articles/search?${queryString}`);
};

/**
 * Create a new article (admin only)
 * @param {Object} articleData - Article data
 * @returns {Promise<Object>} - Created article
 */
export const createArticle = async (articleData) => {
  // If English translations are not provided, generate them automatically
  if (!articleData.titleEn && articleData.title) {
    articleData.titleEn = await translateText(articleData.title, 'en');
  }
  
  if (!articleData.summaryEn && articleData.summary) {
    articleData.summaryEn = await translateText(articleData.summary, 'en');
  }
  
  if (!articleData.contentEn && articleData.content) {
    articleData.contentEn = await translateText(articleData.content, 'en');
  }
  
  return apiRequest('post', '/admin/articles', articleData);
};

/**
 * Update an existing article (admin only)
 * @param {string} id - Article ID
 * @param {Object} articleData - Updated article data
 * @returns {Promise<Object>} - Updated article
 */
export const updateArticle = async (id, articleData) => {
  // If English translations are not provided, generate them automatically
  if (!articleData.titleEn && articleData.title) {
    articleData.titleEn = await translateText(articleData.title, 'en');
  }
  
  if (!articleData.summaryEn && articleData.summary) {
    articleData.summaryEn = await translateText(articleData.summary, 'en');
  }
  
  if (!articleData.contentEn && articleData.content) {
    articleData.contentEn = await translateText(articleData.content, 'en');
  }
  
  return apiRequest('put', `/admin/articles/${id}`, articleData);
};

/**
 * Delete an article (admin only)
 * @param {string} id - Article ID
 * @returns {Promise<Object>} - Deletion result
 */
export const deleteArticle = async (id) => {
  return apiRequest('delete', `/admin/articles/${id}`);
};

/**
 * Publish an article (admin only)
 * @param {string} id - Article ID
 * @returns {Promise<Object>} - Published article
 */
export const publishArticle = async (id) => {
  return apiRequest('post', `/admin/articles/${id}/publish`);
};

/**
 * Unpublish an article (admin only)
 * @param {string} id - Article ID
 * @returns {Promise<Object>} - Unpublished article
 */
export const unpublishArticle = async (id) => {
  return apiRequest('post', `/admin/articles/${id}/unpublish`);
};