import React, { createContext, useEffect, useState } from 'react';
import { toast } from 'react-toastify';

// Create auth context
export const AuthContext = createContext();

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const [isAuthenticated, setIsAuthenticated] = useState(false);

  // Check if user is already logged in (from localStorage)
  useEffect(() => {
    const checkAuthStatus = () => {
      const storedUser = localStorage.getItem('adminUser');
      if (storedUser) {
        try {
          const parsedUser = JSON.parse(storedUser);
          setUser(parsedUser);
          setIsAuthenticated(true);
        } catch (error) {
          console.error('Error parsing stored user data:', error);
          // Clear invalid data
          localStorage.removeItem('adminUser');
        }
      }
      setLoading(false);
    };
    
    checkAuthStatus();
  }, []);

  // Login function
  const login = async (email, password) => {
    try {
      // In a real application, make API call to the backend
      // const response = await fetch('/api/v1/auth/login', {
      //   method: 'POST',
      //   headers: {
      //     'Content-Type': 'application/json',
      //   },
      //   body: JSON.stringify({ email, password }),
      // });
      
      // const data = await response.json();
      // if (!response.ok) {
      //   throw new Error(data.message || 'Login failed');
      // }
      
      // For demo purposes, we'll check against the default credentials
      if (email === 'admin@example.com' && password === 'admin123') {
        // Mock user data
        const userData = {
          id: 1,
          name: '管理员',
          email: 'admin@example.com',
          role: 'admin',
          token: 'mock-jwt-token',
        };
        
        // Store user data in localStorage
        localStorage.setItem('adminUser', JSON.stringify(userData));
        
        // Update context state
        setUser(userData);
        setIsAuthenticated(true);
        return userData;
      } else {
        throw new Error('邮箱或密码不正确');
      }
    } catch (error) {
      throw error;
    }
  };

  // Logout function
  const logout = () => {
    localStorage.removeItem('adminUser');
    setUser(null);
    setIsAuthenticated(false);
  };

  const contextValue = {
    user,
    isAuthenticated,
    loading,
    login,
    logout
  };

  return (
    <AuthContext.Provider value={contextValue}>
      {children}
    </AuthContext.Provider>
  );
};

export default AuthProvider;