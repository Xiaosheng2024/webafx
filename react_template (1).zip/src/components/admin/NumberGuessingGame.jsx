import React, { useState, useEffect, useRef } from 'react';

const NumberGuessingGame = () => {
  const [targetNumber, setTargetNumber] = useState(null);
  const [guess, setGuess] = useState('');
  const [message, setMessage] = useState('');
  const [attempts, setAttempts] = useState(0);
  const [gameActive, setGameActive] = useState(false);
  const [showHint, setShowHint] = useState(false);
  const [gameHistory, setGameHistory] = useState([]);
  const [bestScore, setBestScore] = useState(null);
  const inputRef = useRef(null);

  // Initialize the game
  const initGame = () => {
    const newNumber = Math.floor(Math.random() * 100) + 1;
    setTargetNumber(newNumber);
    setGuess('');
    setMessage('猜一个1-100之间的数字');
    setAttempts(0);
    setGameActive(true);
    setShowHint(false);
    if (inputRef.current) inputRef.current.focus();
  };

  // Check the user's guess
  const checkGuess = () => {
    if (!gameActive) return;
    
    const userGuess = parseInt(guess);
    if (isNaN(userGuess) || userGuess < 1 || userGuess > 100) {
      setMessage('请输入1-100之间的有效数字');
      return;
    }

    const newAttempts = attempts + 1;
    setAttempts(newAttempts);

    if (userGuess === targetNumber) {
      setMessage(`恭喜！您猜对了，答案是 ${targetNumber}。用了 ${newAttempts} 次尝试。`);
      setGameActive(false);
      setGameHistory(prev => [...prev, newAttempts]);
      if (bestScore === null || newAttempts < bestScore) {
        setBestScore(newAttempts);
      }
    } else if (userGuess < targetNumber) {
      setMessage('太小了！再试一次。');
    } else {
      setMessage('太大了！再试一次。');
    }
    
    setGuess('');
  };

  // Handle user input
  const handleChange = (e) => {
    setGuess(e.target.value);
  };

  // Handle form submission
  const handleSubmit = (e) => {
    e.preventDefault();
    checkGuess();
  };

  // Toggle hint
  const toggleHint = () => {
    setShowHint(!showHint);
  };

  // Generate a hint
  const getHint = () => {
    if (!targetNumber) return '';
    
    const lowerBound = Math.max(1, targetNumber - 10);
    const upperBound = Math.min(100, targetNumber + 10);
    
    return `提示：数字在 ${lowerBound} 到 ${upperBound} 之间`;
  };

  // Initialize the game when component mounts
  useEffect(() => {
    const storedBestScore = localStorage.getItem('numberGameBestScore');
    if (storedBestScore) {
      setBestScore(parseInt(storedBestScore));
    }
    
    const storedHistory = localStorage.getItem('numberGameHistory');
    if (storedHistory) {
      try {
        setGameHistory(JSON.parse(storedHistory));
      } catch (e) {
        console.error('Failed to parse game history', e);
      }
    }
    
    initGame();
  }, []);

  // Save best score and history to localStorage when they change
  useEffect(() => {
    if (bestScore !== null) {
      localStorage.setItem('numberGameBestScore', bestScore.toString());
    }
    
    localStorage.setItem('numberGameHistory', JSON.stringify(gameHistory));
  }, [bestScore, gameHistory]);

  return (
    <div className="flex flex-col">
      <h2 className="text-lg font-medium text-gray-900 mb-4">数字猜谜游戏</h2>
      <p className="mb-4 text-sm text-gray-500">
        有点累了？休息一下，玩个小游戏吧！
      </p>
      
      <div className="bg-gray-50 p-4 rounded-md mb-4">
        <p className="font-medium text-gray-700">{message}</p>
        {showHint && gameActive && (
          <p className="text-sm text-blue-600 mt-1">{getHint()}</p>
        )}
      </div>
      
      {gameActive ? (
        <form onSubmit={handleSubmit} className="mb-4">
          <div className="flex space-x-2">
            <input
              type="number"
              value={guess}
              onChange={handleChange}
              placeholder="输入您的猜测"
              className="block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 text-sm"
              min="1"
              max="100"
              ref={inputRef}
            />
            <button
              type="submit"
              className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
            >
              猜测
            </button>
          </div>
        </form>
      ) : (
        <button
          onClick={initGame}
          className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-green-600 hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500 mb-4"
        >
          再来一局
        </button>
      )}
      
      <div className="flex justify-between items-center mb-2">
        <div>
          {gameActive && (
            <button
              onClick={toggleHint}
              className="text-sm text-blue-600 hover:text-blue-800"
            >
              {showHint ? '隐藏提示' : '显示提示'}
            </button>
          )}
        </div>
        <div className="text-sm text-gray-500">
          {attempts > 0 && `已尝试: ${attempts} 次`}
        </div>
      </div>
      
      {bestScore !== null && (
        <div className="text-sm text-gray-700 mt-2">
          <p>最佳记录: {bestScore} 次尝试</p>
        </div>
      )}
      
      {gameHistory.length > 0 && (
        <div className="mt-4">
          <h3 className="text-sm font-medium text-gray-700 mb-2">游戏历史</h3>
          <div className="text-xs text-gray-500">
            {gameHistory.slice(-5).map((score, idx) => (
              <div key={idx} className="flex justify-between">
                <span>游戏 {gameHistory.length - (gameHistory.slice(-5).length - 1) + idx}:</span>
                <span>{score} 次尝试</span>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

export default NumberGuessingGame;