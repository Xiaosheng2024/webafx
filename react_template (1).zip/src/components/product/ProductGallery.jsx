import React, { useState } from 'react';
import { useAppContext } from '../../context/AppContext';

const ProductGallery = ({ images = [], videos = [] }) => {
  const [selectedMediaIndex, setSelectedMediaIndex] = useState(0);
  const [mediaType, setMediaType] = useState(images.length > 0 ? 'image' : videos.length > 0 ? 'video' : null);
  const [showLightbox, setShowLightbox] = useState(false);
  const { state } = useAppContext();
  const { language } = state;

  // Combine images and videos for display
  const allMedia = [
    ...images.map(url => ({ type: 'image', url })),
    ...videos.map(url => ({ type: 'video', url }))
  ];

  const handleThumbnailClick = (index, type) => {
    setSelectedMediaIndex(index);
    setMediaType(type);
  };

  const handleMainMediaClick = () => {
    if (mediaType === 'image') {
      setShowLightbox(true);
    }
  };

  const handlePrevious = () => {
    setSelectedMediaIndex((prev) => (prev === 0 ? allMedia.length - 1 : prev - 1));
    setMediaType(allMedia[(selectedMediaIndex === 0 ? allMedia.length - 1 : selectedMediaIndex - 1)].type);
  };

  const handleNext = () => {
    setSelectedMediaIndex((prev) => (prev === allMedia.length - 1 ? 0 : prev + 1));
    setMediaType(allMedia[(selectedMediaIndex === allMedia.length - 1 ? 0 : selectedMediaIndex + 1)].type);
  };

  if (allMedia.length === 0) {
    return (
      <div className="bg-gray-100 rounded-lg flex items-center justify-center h-64">
        <p className="text-gray-500">
          {language === 'en' ? 'No media available' : '暂无媒体资源'}
        </p>
      </div>
    );
  }

  return (
    <div>
      {/* Main Media Display */}
      <div className="relative aspect-square overflow-hidden rounded-lg mb-4 bg-gray-100 cursor-pointer">
        {mediaType === 'image' ? (
          <img
            src={allMedia[selectedMediaIndex]?.url}
            alt={`Product preview ${selectedMediaIndex + 1}`}
            className="w-full h-full object-contain"
            onClick={handleMainMediaClick}
          />
        ) : (
          <video 
            controls
            className="w-full h-full object-contain"
            src={allMedia[selectedMediaIndex]?.url}
          >
            {language === 'en' ? 'Your browser does not support the video tag.' : '您的浏览器不支持视频标签。'}
          </video>
        )}
        
        {/* Navigation arrows */}
        {allMedia.length > 1 && (
          <>
            <button
              className="absolute left-2 top-1/2 transform -translate-y-1/2 bg-white bg-opacity-70 hover:bg-opacity-100 rounded-full p-2 shadow-md text-gray-800"
              onClick={handlePrevious}
            >
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
              </svg>
            </button>
            <button
              className="absolute right-2 top-1/2 transform -translate-y-1/2 bg-white bg-opacity-70 hover:bg-opacity-100 rounded-full p-2 shadow-md text-gray-800"
              onClick={handleNext}
            >
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
              </svg>
            </button>
          </>
        )}
      </div>
      
      {/* Thumbnails */}
      {allMedia.length > 1 && (
        <div className="flex overflow-x-auto space-x-2 pb-2">
          {allMedia.map((media, index) => (
            <div
              key={index}
              onClick={() => handleThumbnailClick(index, media.type)}
              className={`relative cursor-pointer border-2 rounded-md overflow-hidden w-16 h-16 flex-shrink-0 ${
                selectedMediaIndex === index ? 'border-blue-500' : 'border-transparent'
              }`}
            >
              {media.type === 'image' ? (
                <img
                  src={media.url}
                  alt={`Thumbnail ${index + 1}`}
                  className="w-full h-full object-cover"
                />
              ) : (
                <div className="bg-gray-100 w-full h-full flex items-center justify-center">
                  <svg className="w-6 h-6 text-gray-500" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M14.752 11.168l-3.197-2.132A1 1 0 0010 9.87v4.263a1 1 0 001.555.832l3.197-2.132a1 1 0 000-1.664z" />
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                  </svg>
                </div>
              )}
            </div>
          ))}
        </div>
      )}
      
      {/* Lightbox */}
      {showLightbox && mediaType === 'image' && (
        <div className="fixed inset-0 bg-black bg-opacity-90 z-50 flex items-center justify-center p-4" onClick={() => setShowLightbox(false)}>
          <div className="relative max-w-4xl max-h-full">
            <img
              src={allMedia[selectedMediaIndex].url}
              alt={`Product lightbox ${selectedMediaIndex + 1}`}
              className="max-w-full max-h-[80vh] object-contain"
            />
            <button
              className="absolute top-2 right-2 bg-white rounded-full p-1"
              onClick={(e) => {
                e.stopPropagation();
                setShowLightbox(false);
              }}
            >
              <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
              </svg>
            </button>
            <div className="absolute bottom-2 left-1/2 transform -translate-x-1/2 text-white text-sm">
              {selectedMediaIndex + 1} / {images.length}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default ProductGallery;