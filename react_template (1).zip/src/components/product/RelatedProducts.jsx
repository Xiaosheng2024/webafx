import React, { useState, useEffect } from 'react';
import ProductCard from '../common/ProductCard';
import { useAppContext } from '../../context/AppContext';
import { getRelatedProducts } from '../../services/productService';

const RelatedProducts = ({ productId, limit = 4 }) => {
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const { state } = useAppContext();
  const { language } = state;

  useEffect(() => {
    const fetchRelatedProducts = async () => {
      try {
        setLoading(true);
        const data = await getRelatedProducts(productId, limit);
        setProducts(data);
      } catch (err) {
        console.error('Error fetching related products:', err);
        setProducts([]);
      } finally {
        setLoading(false);
      }
    };

    if (productId) {
      fetchRelatedProducts();
    }
  }, [productId, limit, language]);

  if (loading) {
    return (
      <div className="flex justify-center items-center py-8">
        <div className="animate-spin rounded-full h-8 w-8 border-t-2 border-b-2 border-blue-500"></div>
      </div>
    );
  }

  if (products.length === 0) {
    return null;
  }

  return (
    <div className="mt-12">
      <h2 className="text-2xl font-bold mb-6">
        {language === 'en' ? 'Related Products' : '相关产品'}
      </h2>
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
        {products.map(product => (
          <ProductCard key={product.id} product={product} />
        ))}
      </div>
    </div>
  );
};

export default RelatedProducts;