import React, { useState, useEffect } from 'react';
import { useAppContext } from '../../context/AppContext';
import ProductGallery from './ProductGallery';
import ProductParameters from './ProductParameters';
import { getProductDetail } from '../../services/productService';

const ProductDetail = ({ productId }) => {
  const [product, setProduct] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [activeTab, setActiveTab] = useState('details');
  const { state } = useAppContext();
  const { language } = state;

  useEffect(() => {
    const fetchProductDetail = async () => {
      try {
        setLoading(true);
        const data = await getProductDetail(productId);
        setProduct(data);
        setError(null);
      } catch (err) {
        console.error('Error fetching product details:', err);
        setError(language === 'en' 
          ? 'Failed to load product details. Please try again later.'
          : '加载产品详情失败，请稍后再试。');
      } finally {
        setLoading(false);
      }
    };

    if (productId) {
      fetchProductDetail();
    }
  }, [productId, language]);

  if (loading) {
    return (
      <div className="flex justify-center items-center py-12">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-500"></div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="text-center py-12">
        <div className="text-red-500 mb-4">{error}</div>
        <button 
          onClick={() => window.location.reload()}
          className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors"
        >
          {language === 'en' ? 'Try Again' : '重试'}
        </button>
      </div>
    );
  }

  if (!product) {
    return (
      <div className="text-center py-12 text-gray-500">
        {language === 'en' ? 'Product not found.' : '未找到该产品。'}
      </div>
    );
  }

  // Display name and description based on selected language
  const displayName = language === 'en' ? product.nameEn || product.name : product.name;
  const displayDescription = language === 'en' ? product.descriptionEn || product.description : product.description;

  const tabs = [
    { id: 'details', label: language === 'en' ? 'Product Details' : '产品详情' },
    { id: 'parameters', label: language === 'en' ? 'Parameters' : '参数规格' },
    { id: 'documents', label: language === 'en' ? 'Documents' : '资料下载' },
  ];

  return (
    <div className="bg-white rounded-lg shadow-md overflow-hidden">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8 p-6">
        {/* Product Gallery */}
        <div>
          <ProductGallery 
            images={product.imageUrls} 
            videos={product.videoUrls} 
          />
        </div>
        
        {/* Product Info */}
        <div>
          <h1 className="text-3xl font-bold text-gray-800 mb-2">{displayName}</h1>
          <p className="text-gray-600 mb-4">
            {language === 'en' ? 'Model:' : '型号:'} <span className="font-medium">{product.model}</span>
          </p>
          
          <div className="border-t border-gray-200 my-4 pt-4">
            <p className="text-gray-700 mb-6">{displayDescription}</p>
          </div>
          
          <div className="flex flex-wrap gap-2 mb-6">
            {product.tags && product.tags.map((tag, index) => (
              <span 
                key={index}
                className="text-sm px-3 py-1 bg-gray-100 text-gray-700 rounded-full"
              >
                {tag}
              </span>
            ))}
          </div>
          
          <div className="flex flex-wrap gap-4">
            <button className="px-6 py-3 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors">
              {language === 'en' ? 'Request Quote' : '获取报价'}
            </button>
            <button className="px-6 py-3 border border-blue-600 text-blue-600 rounded-md hover:bg-blue-50 transition-colors">
              {language === 'en' ? 'Product Consultation' : '产品咨询'}
            </button>
          </div>
        </div>
      </div>
      
      {/* Tabs Navigation */}
      <div className="border-t border-gray-200">
        <div className="flex overflow-x-auto">
          {tabs.map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`px-6 py-4 font-medium transition-colors whitespace-nowrap ${
                activeTab === tab.id
                  ? 'text-blue-600 border-b-2 border-blue-600'
                  : 'text-gray-500 hover:text-gray-700'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>
        
        {/* Tab Content */}
        <div className="p-6">
          {activeTab === 'details' && (
            <div className="prose max-w-none" dangerouslySetInnerHTML={{ __html: language === 'en' ? (product.contentEn || product.content) : product.content }} />
          )}
          
          {activeTab === 'parameters' && (
            <ProductParameters parameters={product.parameters} />
          )}
          
          {activeTab === 'documents' && (
            <div>
              {product.documents && product.documents.length > 0 ? (
                <ul className="divide-y divide-gray-200">
                  {product.documents.map((doc, index) => (
                    <li key={index} className="py-3 flex justify-between items-center">
                      <div className="flex items-center">
                        <svg className="w-5 h-5 mr-2 text-gray-500" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                          <path fillRule="evenodd" d="M4 4a2 2 0 012-2h4.586A2 2 0 0112 2.586L15.414 6A2 2 0 0116 7.414V16a2 2 0 01-2 2H6a2 2 0 01-2-2V4z" clipRule="evenodd" />
                        </svg>
                        <span>{language === 'en' ? (doc.nameEn || doc.name) : doc.name}</span>
                      </div>
                      <a 
                        href={doc.fileUrl}
                        download
                        className="text-blue-600 hover:text-blue-800"
                      >
                        {language === 'en' ? 'Download' : '下载'}
                      </a>
                    </li>
                  ))}
                </ul>
              ) : (
                <div className="text-center py-8 text-gray-500">
                  {language === 'en' ? 'No documents available.' : '暂无相关文档。'}
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default ProductDetail;