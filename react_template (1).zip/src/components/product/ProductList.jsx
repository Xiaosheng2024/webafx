import React, { useState, useEffect } from 'react';
import ProductCard from '../common/ProductCard';
import { useAppContext } from '../../context/AppContext';
import { getProductList } from '../../services/productService';

const ProductList = ({ categoryId = null, limit = null, searchQuery = null }) => {
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const { state } = useAppContext();
  const { language } = state;

  useEffect(() => {
    const fetchProducts = async () => {
      try {
        setLoading(true);
        const params = { 
          categoryId, 
          limit, 
          searchQuery
        };
        const data = await getProductList(params);
        setProducts(data);
        setError(null);
      } catch (err) {
        console.error('Error fetching products:', err);
        setError(language === 'en' 
          ? 'Failed to load products. Please try again later.'
          : '加载产品失败，请稍后再试。');
      } finally {
        setLoading(false);
      }
    };

    fetchProducts();
  }, [categoryId, limit, searchQuery, language]);

  if (loading) {
    return (
      <div className="flex justify-center items-center py-12">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-500"></div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="text-center py-12">
        <div className="text-red-500 mb-4">{error}</div>
        <button 
          onClick={() => window.location.reload()}
          className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors"
        >
          {language === 'en' ? 'Try Again' : '重试'}
        </button>
      </div>
    );
  }

  if (products.length === 0) {
    return (
      <div className="text-center py-12 text-gray-500">
        {language === 'en' ? 'No products found.' : '未找到相关产品。'}
      </div>
    );
  }

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
      {products.map(product => (
        <ProductCard key={product.id} product={product} />
      ))}
    </div>
  );
};

export default ProductList;