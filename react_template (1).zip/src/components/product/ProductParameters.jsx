import React from 'react';
import { useAppContext } from '../../context/AppContext';

const ProductParameters = ({ parameters }) => {
  const { state } = useAppContext();
  const { language } = state;
  
  if (!parameters || parameters.length === 0) {
    return (
      <div className="text-center py-8 text-gray-500">
        {language === 'en' ? 'No parameter information available.' : '暂无参数信息。'}
      </div>
    );
  }

  // Group parameters by groupName
  const groupedParameters = parameters.reduce((groups, param) => {
    const groupName = param.groupName || (language === 'en' ? 'General' : '基本参数');
    if (!groups[groupName]) {
      groups[groupName] = [];
    }
    groups[groupName].push(param);
    return groups;
  }, {});

  const renderParameterValue = (param) => {
    const value = language === 'en' ? (param.valueEn || param.value) : param.value;
    const unit = param.unit ? ` ${param.unit}` : '';
    return `${value}${unit}`;
  };

  return (
    <div className="space-y-6">
      {Object.entries(groupedParameters).map(([groupName, params]) => (
        <div key={groupName} className="overflow-hidden">
          <h3 className="font-semibold text-lg mb-3">{groupName}</h3>
          <div className="overflow-x-auto">
            <table className="w-full min-w-full divide-y divide-gray-200">
              <thead className="bg-gray-50">
                <tr>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider w-1/3">
                    {language === 'en' ? 'Parameter' : '参数名称'}
                  </th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider w-2/3">
                    {language === 'en' ? 'Value' : '参数值'}
                  </th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {params.map((param, index) => (
                  <tr key={index} className={param.isHighlight ? 'bg-blue-50' : ''}>
                    <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                      {language === 'en' ? (param.nameEn || param.name) : param.name}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      {renderParameterValue(param)}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      ))}
    </div>
  );
};

export default ProductParameters;