import React, { useState, useEffect, useRef } from 'react';
import { useAppContext } from '../../context/AppContext';

const Carousel = ({ items, autoplaySpeed = 5000, showIndicators = true, showArrows = true }) => {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isAutoPlaying, setIsAutoPlaying] = useState(true);
  const autoPlayRef = useRef(null);
  const { state } = useAppContext();
  const { language } = state;

  // Stop autoplay when user interacts with carousel
  const pauseAutoPlay = () => {
    setIsAutoPlaying(false);
    if (autoPlayRef.current) {
      clearTimeout(autoPlayRef.current);
    }
  };

  // Resume autoplay after a delay
  const resumeAutoPlay = () => {
    setIsAutoPlaying(true);
  };

  useEffect(() => {
    if (isAutoPlaying) {
      autoPlayRef.current = setTimeout(() => {
        goToNext();
      }, autoplaySpeed);
    }
    return () => {
      if (autoPlayRef.current) {
        clearTimeout(autoPlayRef.current);
      }
    };
  }, [currentIndex, isAutoPlaying]);

  const goToPrevious = () => {
    pauseAutoPlay();
    const isFirstSlide = currentIndex === 0;
    const newIndex = isFirstSlide ? items.length - 1 : currentIndex - 1;
    setCurrentIndex(newIndex);
    setTimeout(resumeAutoPlay, 5000);
  };

  const goToNext = () => {
    pauseAutoPlay();
    const isLastSlide = currentIndex === items.length - 1;
    const newIndex = isLastSlide ? 0 : currentIndex + 1;
    setCurrentIndex(newIndex);
    setTimeout(resumeAutoPlay, 5000);
  };

  const goToSlide = (index) => {
    pauseAutoPlay();
    setCurrentIndex(index);
    setTimeout(resumeAutoPlay, 5000);
  };

  if (!items || items.length === 0) {
    return null;
  }

  return (
    <div className="relative w-full h-full group">
      <div 
        className="w-full h-full bg-cover bg-center transition-all duration-500 ease-in-out"
        style={{ backgroundImage: `url(${items[currentIndex].imageUrl})` }}
      >
        <div className="absolute inset-0 bg-black bg-opacity-40 flex flex-col items-center justify-center text-center px-6">
          <h2 className="text-white text-3xl md:text-4xl lg:text-5xl font-bold mb-4">
            {language === 'en' ? 
              (items[currentIndex].titleEn || items[currentIndex].title) : 
              items[currentIndex].title}
          </h2>
          <p className="text-white text-lg md:text-xl max-w-3xl">
            {language === 'en' ? 
              (items[currentIndex].descriptionEn || items[currentIndex].description) : 
              items[currentIndex].description}
          </p>
          {items[currentIndex].buttonText && (
            <a 
              href={items[currentIndex].buttonLink} 
              className="mt-6 px-6 py-3 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors"
            >
              {language === 'en' ? 
                (items[currentIndex].buttonTextEn || items[currentIndex].buttonText) : 
                items[currentIndex].buttonText}
            </a>
          )}
        </div>
      </div>

      {/* Left Arrow */}
      {showArrows && (
        <div 
          className="absolute top-1/2 left-4 -translate-y-1/2 cursor-pointer bg-white bg-opacity-30 hover:bg-opacity-50 rounded-full p-2 opacity-70 hover:opacity-100 transition-opacity"
          onClick={goToPrevious}
        >
          <svg className="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
          </svg>
        </div>
      )}

      {/* Right Arrow */}
      {showArrows && (
        <div 
          className="absolute top-1/2 right-4 -translate-y-1/2 cursor-pointer bg-white bg-opacity-30 hover:bg-opacity-50 rounded-full p-2 opacity-70 hover:opacity-100 transition-opacity"
          onClick={goToNext}
        >
          <svg className="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
          </svg>
        </div>
      )}

      {/* Indicators */}
      {showIndicators && (
        <div className="absolute bottom-4 left-0 right-0 flex justify-center">
          {items.map((_, index) => (
            <div
              key={index}
              className={`w-3 h-3 mx-1 rounded-full cursor-pointer transition-all ${
                index === currentIndex ? 'bg-white' : 'bg-white bg-opacity-50'
              }`}
              onClick={() => goToSlide(index)}
            />
          ))}
        </div>
      )}
    </div>
  );
};

export default Carousel;