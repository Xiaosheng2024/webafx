import React from 'react';
import { Link } from 'react-router-dom';
import { useAppContext } from '../../context/AppContext';

const CaseCard = ({ caseItem }) => {
  const { state } = useAppContext();
  const { language } = state;
  
  // Display title and summary based on selected language
  const displayTitle = language === 'en' ? (caseItem.titleEn || caseItem.title) : caseItem.title;
  const displaySummary = language === 'en' ? (caseItem.summaryEn || caseItem.summary) : caseItem.summary;
  const displayClient = language === 'en' ? (caseItem.clientEn || caseItem.client) : caseItem.client;
  const displayIndustry = language === 'en' 
    ? (caseItem.industry === '金融行业' ? 'Finance' : 
       caseItem.industry === '医疗行业' ? 'Healthcare' : 
       caseItem.industry === '政府机构' ? 'Government' : 
       caseItem.industry === '教育行业' ? 'Education' : 
       caseItem.industry === '物流行业' ? 'Logistics' : 
       caseItem.industry === '零售行业' ? 'Retail' : caseItem.industry)
    : caseItem.industry;

  return (
    <Link 
      to={`/cases/${caseItem.id}`} 
      className="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-lg transition-shadow flex flex-col h-full"
    >
      {caseItem.imageUrl ? (
        <div className="h-48 overflow-hidden">
          <img 
            src={caseItem.imageUrl} 
            alt={displayTitle}
            className="w-full h-full object-cover transition-transform hover:scale-105"
          />
        </div>
      ) : (
        <div className="h-48 bg-gray-200 flex items-center justify-center">
          <svg className="w-12 h-12 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4" />
          </svg>
        </div>
      )}
      
      <div className="p-4 flex flex-col flex-grow">
        <div className="flex items-center justify-between mb-2">
          <span className="text-sm px-2 py-1 bg-blue-100 text-blue-800 rounded">{displayIndustry}</span>
        </div>
        <h3 className="text-lg font-semibold mb-2 line-clamp-2">{displayTitle}</h3>
        
        {displayClient && (
          <p className="text-sm text-gray-700 font-medium mb-2">
            {language === 'en' ? 'Client: ' : '客户: '}{displayClient}
          </p>
        )}
        
        <p className="text-gray-600 text-sm mb-4 line-clamp-3">{displaySummary}</p>
        
        <div className="mt-auto">
          <span className="text-blue-600 flex items-center text-sm">
            {language === 'en' ? 'View Case Study' : '查看案例'}
            <svg className="w-4 h-4 ml-1" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
            </svg>
          </span>
        </div>
      </div>
    </Link>
  );
};

export default CaseCard;