import React from 'react';
import { Link, useLocation } from 'react-router-dom';

const Navigation = ({ mobile = false }) => {
  const location = useLocation();
  
  const navigationItems = [
    {
      title: '首页',
      path: '/',
    },
    {
      title: '产品中心',
      path: '/products',
      submenu: [
        { title: '扫描设备', path: '/products/category/scanning' },
        { title: '打印设备', path: '/products/category/printing' },
        { title: '软件服务器', path: '/products/category/software' },
        { title: '集成方案', path: '/products/category/solutions' },
      ],
    },
    {
      title: '解决方案',
      path: '/solutions',
      submenu: [
        { title: '金融行业', path: '/solutions/finance' },
        { title: '医疗行业', path: '/solutions/healthcare' },
        { title: '物流行业', path: '/solutions/logistics' },
        { title: '零售行业', path: '/solutions/retail' },
      ],
    },
    {
      title: '资讯中心',
      path: '/articles',
      submenu: [
        { title: '行业动态', path: '/articles/category/industry' },
        { title: '技术文章', path: '/articles/category/technical' },
        { title: '常见问题', path: '/articles/category/faq' },
      ],
    },
    {
      title: '案例展示',
      path: '/cases',
    },
    {
      title: '记忆卡游戏',
      path: '/game',
    },
    {
      title: '关于我们',
      path: '/about',
    },
  ];

  // Handle submenu state for mobile
  const [openSubmenu, setOpenSubmenu] = React.useState(null);

  const toggleSubmenu = (index) => {
    if (openSubmenu === index) {
      setOpenSubmenu(null);
    } else {
      setOpenSubmenu(index);
    }
  };

  const isActiveLink = (path) => {
    if (path === '/') {
      return location.pathname === path;
    }
    return location.pathname.startsWith(path);
  };

  // Render for desktop navigation
  if (!mobile) {
    return (
      <nav className="flex items-center space-x-6">
        {navigationItems.map((item, index) => (
          <div key={index} className="relative group">
            <Link 
              to={item.path} 
              className={`font-medium transition-colors hover:text-blue-600 ${
                isActiveLink(item.path) ? 'text-blue-600' : 'text-gray-700'
              }`}
            >
              {item.title}
              {item.submenu && (
                <svg 
                  className="w-4 h-4 ml-1 inline-block" 
                  fill="none" 
                  stroke="currentColor" 
                  viewBox="0 0 24 24" 
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                </svg>
              )}
            </Link>

            {/* Submenu */}
            {item.submenu && (
              <div className="absolute left-0 mt-2 w-48 rounded-md shadow-lg bg-white ring-1 ring-black ring-opacity-5 opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all duration-300">
                <div className="py-1">
                  {item.submenu.map((subitem, subindex) => (
                    <Link
                      key={subindex}
                      to={subitem.path}
                      className="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100 hover:text-blue-600"
                    >
                      {subitem.title}
                    </Link>
                  ))}
                </div>
              </div>
            )}
          </div>
        ))}
      </nav>
    );
  }

  // Render for mobile navigation
  return (
    <nav className="flex flex-col space-y-4">
      {navigationItems.map((item, index) => (
        <div key={index}>
          <div 
            className="flex justify-between items-center"
            onClick={() => item.submenu && toggleSubmenu(index)}
          >
            <Link 
              to={item.submenu ? '#' : item.path} 
              className={`font-medium ${
                isActiveLink(item.path) ? 'text-blue-600' : 'text-gray-700'
              }`}
            >
              {item.title}
            </Link>
            {item.submenu && (
              <button className="focus:outline-none">
                <svg 
                  className={`w-4 h-4 transition-transform ${openSubmenu === index ? 'transform rotate-180' : ''}`}
                  fill="none" 
                  stroke="currentColor" 
                  viewBox="0 0 24 24" 
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                </svg>
              </button>
            )}
          </div>

          {/* Mobile Submenu */}
          {item.submenu && openSubmenu === index && (
            <div className="ml-4 mt-2 space-y-2">
              {item.submenu.map((subitem, subindex) => (
                <Link
                  key={subindex}
                  to={subitem.path}
                  className="block py-1 text-gray-600 hover:text-blue-600"
                >
                  {subitem.title}
                </Link>
              ))}
            </div>
          )}
        </div>
      ))}
    </nav>
  );
};

export default Navigation;