import React from 'react';
import { Link } from 'react-router-dom';
import { useAppContext } from '../../context/AppContext';

const ProductCard = ({ product }) => {
  const { state } = useAppContext();
  const { language } = state;
  
  // Display name based on selected language
  const displayName = language === 'en' ? product.nameEn || product.name : product.name;
  const displayDescription = language === 'en' ? product.descriptionEn || product.description : product.description;
  
  return (
    <div className="bg-white rounded-lg overflow-hidden shadow-md hover:shadow-lg transition-shadow duration-300">
      <div className="relative pb-[60%] overflow-hidden">
        <Link to={`/products/${product.id}`}>
          <img 
            src={product.imageUrls[0] || '/placeholder-product.jpg'} 
            alt={displayName}
            className="absolute top-0 left-0 w-full h-full object-cover transition-transform duration-300 hover:scale-105"
          />
        </Link>
      </div>
      <div className="p-4">
        <Link to={`/products/${product.id}`}>
          <h3 className="text-lg font-semibold text-gray-800 mb-2 hover:text-blue-600 transition-colors">
            {displayName}
          </h3>
        </Link>
        <p className="text-gray-600 text-sm mb-3 line-clamp-2">
          {displayDescription}
        </p>
        <div className="flex justify-between items-center">
          <span className="text-sm text-gray-500">
            {language === 'en' ? 'Model' : '型号'}: {product.model}
          </span>
          <Link 
            to={`/products/${product.id}`}
            className="text-blue-600 text-sm font-medium hover:text-blue-800 flex items-center"
          >
            {language === 'en' ? 'Details' : '查看详情'}
            <svg className="w-4 h-4 ml-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
            </svg>
          </Link>
        </div>
      </div>
    </div>
  );
};

export default ProductCard;