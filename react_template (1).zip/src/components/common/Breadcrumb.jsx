import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { useAppContext } from '../../context/AppContext';

const Breadcrumb = ({ additionalItems = [] }) => {
  const location = useLocation();
  const { state } = useAppContext();
  const { language } = state;

  // Default home item
  const defaultItems = [
    {
      name: language === 'en' ? 'Home' : '首页',
      path: '/'
    }
  ];

  // Combine default items with additional items
  const items = [...defaultItems, ...additionalItems];

  return (
    <nav className="flex mb-6 text-sm">
      <ol className="flex flex-wrap items-center">
        {items.map((item, index) => {
          const isLast = index === items.length - 1;
          
          return (
            <li key={item.path} className="flex items-center">
              {index > 0 && (
                <span className="mx-2 text-gray-500">/</span>
              )}
              
              {isLast ? (
                <span className="text-blue-600">{item.name}</span>
              ) : (
                <Link 
                  to={item.path}
                  className="text-gray-500 hover:text-blue-600 transition-colors"
                >
                  {item.name}
                </Link>
              )}
            </li>
          );
        })}
      </ol>
    </nav>
  );
};

export default Breadcrumb;