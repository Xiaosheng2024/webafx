import React, { useState, useEffect } from 'react';
import PropTypes from 'prop-types';

const Card = ({ id, value, isFlipped, isMatched, onClick, disabled }) => {
  const [showFlipAnimation, setShowFlipAnimation] = useState(false);

  useEffect(() => {
    if (isFlipped || isMatched) {
      setShowFlipAnimation(true);
    } else {
      setShowFlipAnimation(false);
    }
  }, [isFlipped, isMatched]);

  // Card emojis for matching pairs
  const emojis = [
    '🎮', '🎯', '🎲', '🎪', '🎭', 
    '🎨', '🎬', '🎤', '🎸', '🎺',
    '🎻', '🎹', '🏆', '🎯', '🎪',
    '⚾', '🏀', '🏈', '⚽', '🎾'
  ];

  // Get emoji based on card value
  const emoji = emojis[value % emojis.length];

  const handleCardClick = () => {
    if (!disabled && !isFlipped && !isMatched) {
      onClick(id);
    }
  };

  return (
    <div 
      className={`relative w-full aspect-square cursor-pointer`}
      onClick={handleCardClick}
    >
      <div 
        className={`
          w-full h-full relative transition-transform duration-500 transform-gpu
          ${showFlipAnimation ? 'rotate-y-180' : ''} 
          preserve-3d
        `}
      >
        {/* Front of card (hidden) */}
        <div className={`
          absolute w-full h-full backface-hidden
          ${showFlipAnimation ? 'rotate-y-180' : ''} 
          bg-gradient-to-br from-indigo-500 to-purple-600
          border-2 ${isMatched ? 'border-green-400' : 'border-white'}
          rounded-lg flex items-center justify-center text-white
          text-5xl shadow-lg
        `}>
          {emoji}
        </div>

        {/* Back of card (shown when not flipped) */}
        <div className={`
          absolute w-full h-full backface-hidden
          ${!showFlipAnimation ? '' : 'rotate-y-180'} 
          bg-gradient-to-br from-blue-900 to-purple-900
          border-2 border-blue-300 rounded-lg shadow-lg
          flex items-center justify-center
        `}>
          <div className="text-3xl font-bold text-blue-300">?</div>
        </div>
      </div>
    </div>
  );
};

Card.propTypes = {
  id: PropTypes.number.isRequired,
  value: PropTypes.number.isRequired,
  isFlipped: PropTypes.bool.isRequired,
  isMatched: PropTypes.bool.isRequired,
  onClick: PropTypes.func.isRequired,
  disabled: PropTypes.bool.isRequired
};

export default Card;