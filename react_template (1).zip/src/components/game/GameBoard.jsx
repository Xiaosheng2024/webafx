import React, { useState, useEffect, useCallback } from 'react';
import PropTypes from 'prop-types';
import Card from './Card';

const GameBoard = ({ onMove, onGameStart, onGameComplete, gameCompleted }) => {
  const [cards, setCards] = useState([]);
  const [flippedCards, setFlippedCards] = useState([]);
  const [matchedPairs, setMatchedPairs] = useState([]);
  const [disableBoard, setDisableBoard] = useState(false);

  const gridSizes = {
    sm: { cols: 4, rows: 3 }, // 12 cards (6 pairs)
    md: { cols: 4, rows: 4 }, // 16 cards (8 pairs)
    lg: { cols: 6, rows: 4 }, // 24 cards (12 pairs)
  };

  const difficulty = 'md'; // Set difficulty (sm, md, lg)
  const numPairs = (gridSizes[difficulty].cols * gridSizes[difficulty].rows) / 2;

  // Initialize cards
  const initializeGame = useCallback(() => {
    // Create pairs of cards with matching values
    const cardValues = [];
    for (let i = 0; i < numPairs; i++) {
      cardValues.push(i, i); // Add two cards with same value for a pair
    }

    // Shuffle cards
    const shuffledCards = cardValues
      .sort(() => Math.random() - 0.5)
      .map((value, index) => ({
        id: index,
        value,
        isFlipped: false,
        isMatched: false,
      }));

    setCards(shuffledCards);
    setFlippedCards([]);
    setMatchedPairs([]);
    setDisableBoard(false);
  }, [numPairs]);

  // Initialize game on mount
  useEffect(() => {
    initializeGame();
  }, [initializeGame, gameCompleted]);

  // Reset game when gameCompleted changes to false
  useEffect(() => {
    if (gameCompleted === false) {
      initializeGame();
    }
  }, [gameCompleted, initializeGame]);

  // Check if game is complete (all pairs matched)
  useEffect(() => {
    if (matchedPairs.length === numPairs && matchedPairs.length > 0) {
      onGameComplete();
    }
  }, [matchedPairs, numPairs, onGameComplete]);

  // Handle card click
  const handleCardClick = (id) => {
    // Don't allow flipping more than 2 cards at once or clicking the same card
    if (flippedCards.length >= 2 || flippedCards.includes(id)) return;

    onGameStart();
    onMove();

    // Flip clicked card
    const newCards = cards.map(card => 
      card.id === id ? { ...card, isFlipped: true } : card
    );
    
    setCards(newCards);
    setFlippedCards(prev => [...prev, id]);
    
    // If two cards are flipped, check for match
    if (flippedCards.length === 1) {
      setDisableBoard(true);
      const firstCard = cards.find(card => card.id === flippedCards[0]);
      const secondCard = cards.find(card => card.id === id);
      
      // If we have a match
      if (firstCard.value === secondCard.value) {
        // Mark cards as matched
        setTimeout(() => {
          setCards(prevCards => 
            prevCards.map(card => 
              card.id === firstCard.id || card.id === secondCard.id
                ? { ...card, isMatched: true }
                : card
            )
          );
          setMatchedPairs(prev => [...prev, firstCard.value]);
          setFlippedCards([]);
          setDisableBoard(false);
        }, 1000);
      } 
      // If no match, flip cards back
      else {
        setTimeout(() => {
          setCards(prevCards => 
            prevCards.map(card => 
              card.id === firstCard.id || card.id === secondCard.id
                ? { ...card, isFlipped: false }
                : card
            )
          );
          setFlippedCards([]);
          setDisableBoard(false);
        }, 1500);
      }
    }
  };

  // Determine grid columns based on difficulty
  const gridTemplate = {
    gridTemplateColumns: `repeat(${gridSizes[difficulty].cols}, minmax(0, 1fr))`,
    gridTemplateRows: `repeat(${gridSizes[difficulty].rows}, minmax(0, 1fr))`,
  };

  return (
    <div 
      className="grid gap-3 md:gap-4"
      style={gridTemplate}
    >
      {cards.map((card) => (
        <Card
          key={card.id}
          id={card.id}
          value={card.value}
          isFlipped={card.isFlipped}
          isMatched={card.isMatched}
          onClick={handleCardClick}
          disabled={disableBoard || card.isMatched || gameCompleted}
        />
      ))}
    </div>
  );
};

GameBoard.propTypes = {
  onMove: PropTypes.func.isRequired,
  onGameStart: PropTypes.func.isRequired,
  onGameComplete: PropTypes.func.isRequired,
  gameCompleted: PropTypes.bool.isRequired
};

export default GameBoard;