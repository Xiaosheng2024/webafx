import React, { useState, useEffect } from 'react';
import { Outlet, useLocation } from 'react-router-dom';
import Header from '../components/common/Header';
import Footer from '../components/common/Footer';
import LanguageSwitcher from '../components/common/LanguageSwitcher';
import { useAppContext } from '../context/AppContext';

const MainLayout = () => {
  const location = useLocation();
  const [showLanguageSwitcher, setShowLanguageSwitcher] = useState(false);
  const { state } = useAppContext();
  const { language } = state;
  
  // Control when to show the language switcher (after a delay)
  useEffect(() => {
    const timer = setTimeout(() => {
      setShowLanguageSwitcher(true);
    }, 1000);
    
    return () => clearTimeout(timer);
  }, []);
  
  // Scroll to top on route change
  useEffect(() => {
    window.scrollTo(0, 0);
  }, [location.pathname]);
  
  return (
    <div className={`flex flex-col min-h-screen ${language === 'en' ? 'font-sans' : 'font-sans'}`}>
      <Header />
      
      {/* Fixed language switcher */}
      {showLanguageSwitcher && (
        <div className="fixed bottom-8 right-8 z-50">
          <div className="bg-white shadow-lg rounded-lg p-1 flex items-center">
            <LanguageSwitcher className="bg-white" />
          </div>
        </div>
      )}
      
      {/* Main content */}
      <main className="flex-grow pt-20">
        <Outlet />
      </main>
      
      <Footer />
    </div>
  );
};

export default MainLayout;