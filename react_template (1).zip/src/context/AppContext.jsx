import React from 'react';
import { createContext, useContext, useReducer, useEffect } from 'react';

// Initial state
const initialState = {
  language: 'zh', // Default language is Chinese
  theme: 'light',
  user: null,
  cart: [],
  favorites: [],
  notifications: [],
};

// Actions
const reducer = (state, action) => {
  switch (action.type) {
    case 'SET_LANGUAGE':
      return { ...state, language: action.payload };
    case 'SET_THEME':
      return { ...state, theme: action.payload };
    case 'SET_USER':
      return { ...state, user: action.payload };
    case 'ADD_TO_CART':
      return { 
        ...state, 
        cart: [...state.cart, action.payload] 
      };
    case 'REMOVE_FROM_CART':
      return { 
        ...state, 
        cart: state.cart.filter(item => item.id !== action.payload) 
      };
    case 'TOGGLE_FAVORITE':
      const isFavorite = state.favorites.some(id => id === action.payload);
      return { 
        ...state, 
        favorites: isFavorite 
          ? state.favorites.filter(id => id !== action.payload) 
          : [...state.favorites, action.payload]
      };
    case 'ADD_NOTIFICATION':
      return { 
        ...state, 
        notifications: [...state.notifications, action.payload] 
      };
    case 'REMOVE_NOTIFICATION':
      return { 
        ...state, 
        notifications: state.notifications.filter(notification => notification.id !== action.payload) 
      };
    default:
      return state;
  }
};

// Create context
const AppContext = createContext();

// Provider component
export const AppProvider = ({ children }) => {
  // Initialize state from localStorage if available
  const loadInitialState = () => {
    try {
      const savedLanguage = localStorage.getItem('preferredLanguage');
      const savedFavorites = JSON.parse(localStorage.getItem('favorites')) || [];
      const savedCart = JSON.parse(localStorage.getItem('cart')) || [];
      
      return {
        ...initialState,
        language: savedLanguage || initialState.language,
        favorites: savedFavorites,
        cart: savedCart,
      };
    } catch (error) {
      console.error('Error loading state from localStorage', error);
      return initialState;
    }
  };

  const [state, dispatch] = useReducer(reducer, loadInitialState());

  // Save certain state elements to localStorage when they change
  useEffect(() => {
    localStorage.setItem('preferredLanguage', state.language);
  }, [state.language]);

  useEffect(() => {
    localStorage.setItem('favorites', JSON.stringify(state.favorites));
  }, [state.favorites]);

  useEffect(() => {
    localStorage.setItem('cart', JSON.stringify(state.cart));
  }, [state.cart]);

  return (
    <AppContext.Provider value={{ state, dispatch }}>
      {children}
    </AppContext.Provider>
  );
};

// Custom hook for using the context
export const useAppContext = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useAppContext must be used within an AppProvider');
  }
  return context;
};

export default AppContext;