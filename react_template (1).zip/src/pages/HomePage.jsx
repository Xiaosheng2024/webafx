import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { useAppContext } from '../context/AppContext';

// Dummy data for development - in production, these would come from API calls
const bannerData = [
  {
    id: 1,
    title: '高效扫描解决方案',
    description: '适用于各行业的专业扫描设备，精准高效',
    image: '/images/banner1.jpg',
    link: '/products/category/scanning'
  },
  {
    id: 2,
    title: '企业级打印系统',
    description: '稳定可靠的打印设备，满足企业各类打印需求',
    image: '/images/banner2.jpg',
    link: '/products/category/printing'
  },
  {
    id: 3,
    title: '软件与服务器解决方案',
    description: '专业软件服务，提升企业运营效率',
    image: '/images/banner3.jpg',
    link: '/products/category/software'
  }
];

const productCategories = [
  { id: 1, title: '扫描设备', icon: '📷', path: '/products/category/scanning' },
  { id: 2, title: '打印设备', icon: '🖨️', path: '/products/category/printing' },
  { id: 3, title: '软件服务器', icon: '💻', path: '/products/category/software' },
  { id: 4, title: '解决方案', icon: '🔧', path: '/products/category/solutions' }
];

const featuredProducts = [
  {
    id: 1,
    name: 'X9000高速扫描仪',
    image: '/images/product1.jpg',
    description: '企业级高速文档扫描仪，每分钟可扫描200页',
    path: '/products/1'
  },
  {
    id: 2,
    name: 'P5000彩色激光打印机',
    image: '/images/product2.jpg',
    description: '高品质商用彩色激光打印机，支持双面打印',
    path: '/products/2'
  },
  {
    id: 3,
    name: '文档管理系统专业版',
    image: '/images/product3.jpg',
    description: '企业文档全生命周期管理系统，支持云存储',
    path: '/products/3'
  },
  {
    id: 4,
    name: '医疗行业扫描存储方案',
    image: '/images/product4.jpg',
    description: '专为医疗行业设计的扫描及文档存储整体解决方案',
    path: '/products/4'
  }
];

const latestArticles = [
  {
    id: 1,
    title: '数字化转型中的文档管理挑战与解决方案',
    summary: '探讨企业在数字化过程中面临的文档管理问题，并提供切实可行的解决思路...',
    date: '2025-02-25',
    tags: ['数字化转型', '文档管理'],
    image: '/images/article1.jpg',
    path: '/articles/1'
  },
  {
    id: 2,
    title: '如何选择适合企业的扫描设备',
    summary: '针对不同规模企业的需求，分析各类扫描设备的优缺点及适用场景...',
    date: '2025-02-20',
    tags: ['扫描设备', '设备选购'],
    image: '/images/article2.jpg',
    path: '/articles/2'
  }
];

const caseStudies = [
  {
    id: 1,
    title: '某大型银行的文档数字化转型案例',
    client: '中国XX银行',
    image: '/images/case1.jpg',
    summary: '为大型银行提供全面的文档扫描及管理解决方案，实现无纸化办公...',
    path: '/cases/1'
  },
  {
    id: 2,
    title: '医疗机构病历电子化存储项目',
    client: 'XX省人民医院',
    image: '/images/case2.jpg',
    summary: '为医院提供专业的病历扫描及电子化管理系统，提升工作效率...',
    path: '/cases/2'
  },
  {
    id: 3,
    title: '物流企业条码扫描系统升级项目',
    client: 'XX物流集团',
    image: '/images/case3.jpg',
    summary: '为物流企业提供高效的条码扫描系统，优化仓储和配送流程...',
    path: '/cases/3'
  }
];

const HomePage = () => {
  const [currentBanner, setCurrentBanner] = useState(0);
  const { state } = useAppContext();
  const { language } = state;

  // Auto rotate banner
  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentBanner((prev) => (prev + 1) % bannerData.length);
    }, 5000);
    
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="flex flex-col">
      {/* Hero Section with Banner */}
      <section className="relative h-[500px] md:h-[600px] overflow-hidden">
        <div className="absolute inset-0 w-full h-full">
          {bannerData.map((banner, index) => (
            <div 
              key={banner.id}
              className={`absolute inset-0 w-full h-full transition-opacity duration-1000 
                ${currentBanner === index ? 'opacity-100' : 'opacity-0'}`}
              style={{
                backgroundImage: `linear-gradient(rgba(0, 0, 0, 0.5), rgba(0, 0, 0, 0.5)), url(${banner.image})`,
                backgroundSize: 'cover',
                backgroundPosition: 'center'
              }}
            >
              <div className="container mx-auto h-full flex flex-col justify-center px-4 md:px-0">
                <h1 className="text-3xl md:text-5xl text-white font-bold mb-4">{banner.title}</h1>
                <p className="text-lg md:text-xl text-white mb-8 max-w-xl">{banner.description}</p>
                <Link 
                  to={banner.link} 
                  className="bg-blue-600 text-white px-6 py-3 rounded-md hover:bg-blue-700 transition-colors inline-block w-max"
                >
                  了解更多
                </Link>
              </div>
            </div>
          ))}
        </div>

        {/* Banner Navigation Dots */}
        <div className="absolute bottom-8 left-0 right-0 flex justify-center">
          {bannerData.map((_, index) => (
            <button
              key={index}
              onClick={() => setCurrentBanner(index)}
              className={`w-3 h-3 mx-2 rounded-full ${
                currentBanner === index ? 'bg-white' : 'bg-gray-400'
              }`}
              aria-label={`Slide ${index + 1}`}
            />
          ))}
        </div>
      </section>

      {/* Product Categories Navigation */}
      <section className="py-12 bg-gray-50">
        <div className="container mx-auto px-4">
          <h2 className="text-2xl md:text-3xl font-bold text-center mb-10">产品分类</h2>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
            {productCategories.map(category => (
              <Link 
                key={category.id} 
                to={category.path}
                className="flex flex-col items-center justify-center p-6 bg-white rounded-lg shadow-md hover:shadow-lg transition-shadow"
              >
                <div className="text-4xl mb-4">{category.icon}</div>
                <h3 className="text-lg font-semibold text-center">{category.title}</h3>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* Featured Products */}
      <section className="py-12">
        <div className="container mx-auto px-4">
          <div className="flex justify-between items-center mb-10">
            <h2 className="text-2xl md:text-3xl font-bold">推荐产品</h2>
            <Link to="/products" className="text-blue-600 hover:text-blue-800">
              查看全部 &rarr;
            </Link>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {featuredProducts.map(product => (
              <div key={product.id} className="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-lg transition-shadow">
                <Link to={product.path}>
                  <div className="h-48 overflow-hidden">
                    <img 
                      src={product.image} 
                      alt={product.name} 
                      className="w-full h-full object-cover transition-transform hover:scale-105"
                    />
                  </div>
                  <div className="p-5">
                    <h3 className="text-xl font-semibold mb-2">{product.name}</h3>
                    <p className="text-gray-600 line-clamp-2">{product.description}</p>
                  </div>
                </Link>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Latest Articles */}
      <section className="py-12 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="flex justify-between items-center mb-10">
            <h2 className="text-2xl md:text-3xl font-bold">最新资讯</h2>
            <Link to="/articles" className="text-blue-600 hover:text-blue-800">
              查看全部 &rarr;
            </Link>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {latestArticles.map(article => (
              <Link key={article.id} to={article.path} className="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-lg transition-shadow">
                <div className="flex flex-col md:flex-row">
                  <div className="md:w-1/3 h-48 md:h-auto overflow-hidden">
                    <img 
                      src={article.image} 
                      alt={article.title} 
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <div className="md:w-2/3 p-5">
                    <h3 className="text-xl font-semibold mb-2">{article.title}</h3>
                    <p className="text-gray-600 mb-4 line-clamp-2">{article.summary}</p>
                    <div className="flex items-center justify-between">
                      <p className="text-sm text-gray-500">{article.date}</p>
                      <div className="flex space-x-2">
                        {article.tags.map((tag, index) => (
                          <span key={index} className="text-xs bg-blue-100 text-blue-600 px-2 py-1 rounded">
                            {tag}
                          </span>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* Case Studies */}
      <section className="py-12">
        <div className="container mx-auto px-4">
          <div className="flex justify-between items-center mb-10">
            <h2 className="text-2xl md:text-3xl font-bold">客户案例</h2>
            <Link to="/cases" className="text-blue-600 hover:text-blue-800">
              查看全部 &rarr;
            </Link>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {caseStudies.map(caseItem => (
              <Link key={caseItem.id} to={caseItem.path} className="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-lg transition-shadow">
                <div className="h-48 overflow-hidden">
                  <img 
                    src={caseItem.image} 
                    alt={caseItem.title} 
                    className="w-full h-full object-cover transition-transform hover:scale-105"
                  />
                </div>
                <div className="p-5">
                  <h3 className="text-xl font-semibold mb-2">{caseItem.title}</h3>
                  <p className="text-gray-700 font-medium mb-2">客户: {caseItem.client}</p>
                  <p className="text-gray-600 line-clamp-2">{caseItem.summary}</p>
                </div>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* Call to Action */}
      <section className="py-16 bg-blue-600 text-white">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-6">寻找适合您企业的解决方案</h2>
          <p className="text-xl max-w-2xl mx-auto mb-8">我们的专业团队随时为您提供定制化的产品咨询和技术支持</p>
          <Link 
            to="/contact" 
            className="inline-block bg-white text-blue-600 font-bold px-8 py-3 rounded-md hover:bg-gray-100 transition-colors"
          >
            立即咨询
          </Link>
        </div>
      </section>
    </div>
  );
};

export default HomePage;