import React from 'react';
import { Link } from 'react-router-dom';
import { useAppContext } from '../context/AppContext';

const NotFoundPage = () => {
  const { state } = useAppContext();
  const { language } = state;

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-50 py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-md w-full text-center">
        <div className="mb-8">
          <h1 className="inline-block text-9xl font-extrabold text-blue-600">
            404
          </h1>
        </div>
        <div className="mb-8">
          <h2 className="text-2xl font-bold text-gray-900 mb-2">
            {language === 'en' ? 'Page Not Found' : '页面未找到'}
          </h2>
          <p className="text-gray-600">
            {language === 'en' 
              ? 'The page you are looking for might have been removed, had its name changed, or is temporarily unavailable.'
              : '您查找的页面可能已被删除、更名或暂时不可用。'}
          </p>
        </div>
        <div className="flex flex-col sm:flex-row justify-center space-y-4 sm:space-y-0 sm:space-x-4">
          <Link
            to="/"
            className="px-5 py-3 border border-transparent text-base font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700"
          >
            {language === 'en' ? 'Back to Home' : '返回首页'}
          </Link>
          <Link
            to="/contact"
            className="px-5 py-3 border border-transparent text-base font-medium rounded-md text-blue-700 bg-blue-100 hover:bg-blue-200"
          >
            {language === 'en' ? 'Contact Support' : '联系客服'}
          </Link>
        </div>
        
        <div className="mt-16">
          <p className="text-sm text-gray-500">
            {language === 'en' 
              ? 'Looking for something specific? Try using the search function at the top of the page.'
              : '在寻找特定内容？请尝试使用页面顶部的搜索功能。'}
          </p>
        </div>
      </div>
    </div>
  );
};

export default NotFoundPage;