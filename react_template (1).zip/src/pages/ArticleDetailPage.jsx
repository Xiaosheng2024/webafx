import React, { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import Breadcrumb from '../components/common/Breadcrumb';
import { useAppContext } from '../context/AppContext';
import { getArticleDetail, getSimilarArticles } from '../services/articleService';
import { formatDate } from '../utils/formatters';
import ArticleCard from '../components/common/ArticleCard';
import ConsultationForm from '../components/common/ConsultationForm';

const ArticleDetailPage = () => {
  const { articleId } = useParams();
  const { state } = useAppContext();
  const { language } = state;
  
  const [article, setArticle] = useState(null);
  const [similarArticles, setSimilarArticles] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  
  // Fetch article detail
  useEffect(() => {
    const fetchArticleDetail = async () => {
      try {
        setLoading(true);
        const data = await getArticleDetail(articleId);
        setArticle(data);
        setError(null);
      } catch (err) {
        console.error('Error fetching article details:', err);
        setError(language === 'en' 
          ? 'Failed to load article. Please try again later.'
          : '加载文章失败，请稍后再试。');
      } finally {
        setLoading(false);
      }
    };
    
    if (articleId) {
      fetchArticleDetail();
    }
  }, [articleId, language]);
  
  // Fetch similar articles
  useEffect(() => {
    const fetchSimilarArticles = async () => {
      try {
        if (article) {
          const data = await getSimilarArticles(articleId, 3);
          setSimilarArticles(data);
        }
      } catch (err) {
        console.error('Error fetching similar articles:', err);
        setSimilarArticles([]);
      }
    };
    
    if (article) {
      fetchSimilarArticles();
    }
  }, [article, articleId, language]);
  
  // Prepare breadcrumb items
  const breadcrumbItems = article ? [
    {
      name: language === 'en' ? 'Articles' : '文章',
      path: '/articles'
    },
    {
      name: language === 'en' ? (article.titleEn || article.title) : article.title,
      path: `/articles/${articleId}`
    }
  ] : [];
  
  if (loading) {
    return (
      <div className="container mx-auto px-4 py-8">
        <Breadcrumb />
        <div className="flex justify-center py-12">
          <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-500"></div>
        </div>
      </div>
    );
  }
  
  if (error || !article) {
    return (
      <div className="container mx-auto px-4 py-8">
        <Breadcrumb />
        <div className="text-center py-12">
          <div className="text-red-500 mb-4">
            {error || (language === 'en' ? 'Article not found.' : '未找到该文章。')}
          </div>
          <Link 
            to="/articles" 
            className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors"
          >
            {language === 'en' ? 'Return to Articles' : '返回文章列表'}
          </Link>
        </div>
      </div>
    );
  }

  // Display title and content based on selected language
  const displayTitle = language === 'en' ? article.titleEn || article.title : article.title;
  const displayContent = language === 'en' ? article.contentEn || article.content : article.content;
  
  return (
    <div className="container mx-auto px-4 py-8">
      {/* Breadcrumb */}
      <Breadcrumb additionalItems={breadcrumbItems} />
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2">
          {/* Article Content */}
          <article className="bg-white rounded-lg shadow-md overflow-hidden">
            {article.imageUrls && article.imageUrls.length > 0 && (
              <div className="w-full h-96 relative overflow-hidden">
                <img 
                  src={article.imageUrls[0]} 
                  alt={displayTitle}
                  className="w-full h-full object-cover"
                />
              </div>
            )}
            
            <div className="p-6">
              <h1 className="text-3xl font-bold mb-4">{displayTitle}</h1>
              
              <div className="flex items-center text-gray-500 mb-6">
                <span>{formatDate(article.publishedAt, language)}</span>
                <span className="mx-2">•</span>
                <span>
                  {language === 'en' ? 'Views' : '浏览'}: {article.viewCount || 0}
                </span>
                
                <div className="ml-auto flex flex-wrap gap-2">
                  {article.tags && article.tags.map((tag, index) => (
                    <Link 
                      key={index}
                      to={`/articles?tag=${tag}`}
                      className="text-xs px-2 py-1 bg-gray-100 text-gray-600 rounded-md hover:bg-gray-200 transition-colors"
                    >
                      {tag}
                    </Link>
                  ))}
                </div>
              </div>
              
              <div 
                className="prose max-w-none"
                dangerouslySetInnerHTML={{ __html: displayContent }}
              />
              
              {/* Social Sharing */}
              <div className="border-t border-gray-200 mt-8 pt-6">
                <div className="flex items-center">
                  <span className="text-gray-700 mr-4">
                    {language === 'en' ? 'Share this article:' : '分享文章:'}
                  </span>
                  <div className="flex space-x-2">
                    <a href="#" className="text-gray-400 hover:text-blue-600">
                      <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                        <path d="M22.675 0h-21.35c-.732 0-1.325.593-1.325 1.325v21.351c0 .731.593 1.324 1.325 1.324h11.495v-9.294h-3.128v-3.622h3.128v-2.671c0-3.1 1.893-4.788 4.659-4.788 1.325 0 2.463.099 2.795.143v3.24l-1.918.001c-1.504 0-1.795.715-1.795 1.763v2.313h3.587l-.467 3.622h-3.12v9.293h6.116c.73 0 1.323-.593 1.323-1.325v-21.35c0-.732-.593-1.325-1.325-1.325z" />
                      </svg>
                    </a>
                    <a href="#" className="text-gray-400 hover:text-blue-400">
                      <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                        <path d="M23.953 4.57a10 10 0 01-2.825.775 4.958 4.958 0 002.163-2.723c-.951.555-2.005.959-3.127 1.184a4.92 4.92 0 00-8.384 4.482C7.69 8.095 4.067 6.13 1.64 3.162a4.822 4.822 0 00-.666 2.475c0 1.71.87 3.213 2.188 4.096a4.904 4.904 0 01-2.228-.616v.06a4.923 4.923 0 003.946 4.827 4.996 4.996 0 01-2.212.085 4.936 4.936 0 004.604 3.417 9.867 9.867 0 01-6.102 2.105c-.39 0-.779-.023-1.17-.067a13.995 13.995 0 007.557 2.209c9.053 0 13.998-7.496 13.998-13.985 0-.21 0-.42-.015-.63A9.935 9.935 0 0024 4.59z" />
                      </svg>
                    </a>
                    <a href="#" className="text-gray-400 hover:text-green-600">
                      <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                        <path d="M7.8,2H16.2C19.4,2 22,4.6 22,7.8V16.2A5.8,5.8 0 0,1 16.2,22H7.8C4.6,22 2,19.4 2,16.2V7.8A5.8,5.8 0 0,1 7.8,2M7.6,4A3.6,3.6 0 0,0 4,7.6V16.4C4,18.39 5.61,20 7.6,20H16.4A3.6,3.6 0 0,0 20,16.4V7.6C20,5.61 18.39,4 16.4,4H7.6M17.25,5.5A1.25,1.25 0 0,1 18.5,6.75A1.25,1.25 0 0,1 17.25,8A1.25,1.25 0 0,1 16,6.75A1.25,1.25 0 0,1 17.25,5.5M12,7A5,5 0 0,1 17,12A5,5 0 0,1 12,17A5,5 0 0,1 7,12A5,5 0 0,1 12,7M12,9A3,3 0 0,0 9,12A3,3 0 0,0 12,15A3,3 0 0,0 15,12A3,3 0 0,0 12,9Z" />
                      </svg>
                    </a>
                    <a href="#" className="text-gray-400 hover:text-blue-800">
                      <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                        <path d="M0 1.146C0 .513.526 0 1.175 0h13.65C15.474 0 16 .513 16 1.146v13.708c0 .633-.526 1.146-1.175 1.146H1.175C.526 16 0 15.487 0 14.854V1.146zm4.943 12.248V6.169H2.542v7.225h2.401zm-1.2-8.212c.837 0 1.358-.554 1.358-1.248-.015-.709-.52-1.248-1.342-1.248-.822 0-1.359.54-1.359 1.248 0 .694.521 1.248 1.327 1.248h.016zm4.908 8.212V9.359c0-.216.016-.432.08-.586.173-.431.568-.878 1.232-.878.869 0 1.216.662 1.216 1.634v3.865h2.401V9.25c0-2.22-1.184-3.252-2.764-3.252-1.274 0-1.845.7-2.165 1.193v.025h-.016a5.54 5.54 0 0 1 .016-.025V6.169h-2.4c.03.678 0 7.225 0 7.225h2.4z" />
                      </svg>
                    </a>
                  </div>
                </div>
              </div>
            </div>
          </article>
          
          {/* Similar Articles */}
          {similarArticles.length > 0 && (
            <div className="mt-12">
              <h2 className="text-2xl font-bold mb-6">
                {language === 'en' ? 'You Might Also Like' : '你可能也喜欢'}
              </h2>
              
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {similarArticles.map(article => (
                  <ArticleCard key={article.id} article={article} />
                ))}
              </div>
            </div>
          )}
        </div>
        
        {/* Sidebar */}
        <div className="lg:col-span-1">
          {/* Consultation Form */}
          <div className="sticky top-24">
            <ConsultationForm />
            
            {/* Popular Tags */}
            <div className="bg-white rounded-lg shadow-md p-6 mt-6">
              <h3 className="text-xl font-semibold mb-4">
                {language === 'en' ? 'Popular Tags' : '热门标签'}
              </h3>
              <div className="flex flex-wrap gap-2">
                {['数字化转型', '文档管理', '扫描设备', '打印设备', '高效办公', '解决方案', '技术趋势', '行业应用'].map((tag) => (
                  <Link 
                    key={tag}
                    to={`/articles?tag=${encodeURIComponent(tag)}`}
                    className="px-3 py-1 bg-gray-100 text-gray-700 rounded-full hover:bg-gray-200 transition-colors"
                  >
                    {tag}
                  </Link>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ArticleDetailPage;