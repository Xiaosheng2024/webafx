import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import Breadcrumb from '../components/common/Breadcrumb';
import CaseCard from '../components/common/CaseCard';
import { useAppContext } from '../context/AppContext';

const CaseListPage = () => {
  const { state } = useAppContext();
  const { language } = state;
  
  const [cases, setCases] = useState([]);
  const [industries, setIndustries] = useState([]);
  const [selectedIndustry, setSelectedIndustry] = useState('all');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  
  useEffect(() => {
    const fetchCases = async () => {
      try {
        setLoading(true);
        
        // In a real application, this would call an API
        // For now, we'll use mock data
        const mockData = await import('../data/mockData');
        const caseData = mockData.default.cases || [];
        setCases(caseData);
        
        // Extract unique industries
        const uniqueIndustries = [...new Set(caseData.map(item => item.industry))];
        setIndustries(uniqueIndustries);
        
        setError(null);
      } catch (err) {
        console.error('Error fetching cases:', err);
        setError(language === 'en' 
          ? 'Failed to load case studies. Please try again later.'
          : '加载案例失败，请稍后再试。');
        setCases([]);
      } finally {
        setLoading(false);
      }
    };
    
    fetchCases();
  }, [language]);
  
  // Filter cases by industry
  const filteredCases = selectedIndustry === 'all' 
    ? cases 
    : cases.filter(caseItem => caseItem.industry === selectedIndustry);
  
  return (
    <div className="container mx-auto px-4 py-8">
      {/* Breadcrumb */}
      <Breadcrumb additionalItems={[{ name: language === 'en' ? 'Case Studies' : '案例展示', path: '/cases' }]} />
      
      {/* Page Header */}
      <div className="mb-8">
        <h1 className="text-3xl font-bold mb-4">
          {language === 'en' ? 'Customer Success Stories' : '客户成功案例'}
        </h1>
        <p className="text-gray-600">
          {language === 'en' 
            ? 'Discover how our solutions have helped businesses across various industries achieve their goals.'
            : '了解我们的解决方案如何帮助各行业的企业实现其目标。'}
        </p>
      </div>
      
      {/* Industry Filter */}
      <div className="mb-8">
        <div className="flex flex-wrap items-center gap-3">
          <span className="font-medium">
            {language === 'en' ? 'Filter by Industry:' : '按行业筛选:'}
          </span>
          <button
            onClick={() => setSelectedIndustry('all')}
            className={`px-4 py-2 rounded-md ${
              selectedIndustry === 'all' 
                ? 'bg-blue-600 text-white' 
                : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
            } transition-colors`}
          >
            {language === 'en' ? 'All Industries' : '所有行业'}
          </button>
          
          {industries.map((industry, index) => (
            <button
              key={index}
              onClick={() => setSelectedIndustry(industry)}
              className={`px-4 py-2 rounded-md ${
                selectedIndustry === industry 
                  ? 'bg-blue-600 text-white' 
                  : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
              } transition-colors`}
            >
              {language === 'en' ? (industry === '金融行业' ? 'Finance' : industry === '医疗行业' ? 'Healthcare' : industry) : industry}
            </button>
          ))}
        </div>
      </div>
      
      {/* Case Studies */}
      {loading ? (
        <div className="flex justify-center py-12">
          <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-500"></div>
        </div>
      ) : error ? (
        <div className="text-center py-12">
          <div className="text-red-500 mb-4">{error}</div>
          <button 
            onClick={() => window.location.reload()}
            className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors"
          >
            {language === 'en' ? 'Try Again' : '重试'}
          </button>
        </div>
      ) : (
        <>
          {filteredCases.length === 0 ? (
            <div className="text-center py-12 text-gray-500">
              {language === 'en' ? 'No case studies found.' : '未找到相关案例。'}
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {filteredCases.map(caseItem => (
                <CaseCard key={caseItem.id} caseItem={caseItem} />
              ))}
            </div>
          )}
        </>
      )}
      
      {/* Call to Action */}
      <div className="mt-16 bg-blue-50 rounded-lg p-8 text-center">
        <h2 className="text-2xl font-bold mb-4">
          {language === 'en' ? 'Looking for a Solution for Your Business?' : '寻找适合您企业的解决方案？'}
        </h2>
        <p className="text-gray-600 mb-6 max-w-2xl mx-auto">
          {language === 'en' 
            ? 'Our expert team is ready to analyze your requirements and design a tailored solution that meets your specific needs.'
            : '我们的专家团队随时准备分析您的需求，设计满足您特定需求的定制解决方案。'}
        </p>
        <div className="flex justify-center gap-4">
          <Link 
            to="/contact" 
            className="px-6 py-3 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors"
          >
            {language === 'en' ? 'Contact Us' : '联系我们'}
          </Link>
          <Link 
            to="/products" 
            className="px-6 py-3 border border-blue-600 text-blue-600 rounded-md hover:bg-blue-50 transition-colors"
          >
            {language === 'en' ? 'View Our Products' : '查看我们的产品'}
          </Link>
        </div>
      </div>
    </div>
  );
};

export default CaseListPage;