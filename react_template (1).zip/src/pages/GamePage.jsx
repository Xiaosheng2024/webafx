import React, { useState, useEffect } from 'react';
import { Helmet } from 'react-helmet';
import GameBoard from '../components/game/GameBoard';

const GamePage = () => {
  const [moves, setMoves] = useState(0);
  const [timeElapsed, setTimeElapsed] = useState(0);
  const [gameStarted, setGameStarted] = useState(false);
  const [gameCompleted, setGameCompleted] = useState(false);
  const [timerInterval, setTimerInterval] = useState(null);

  // Start timer when game starts
  useEffect(() => {
    if (gameStarted && !gameCompleted) {
      const interval = setInterval(() => {
        setTimeElapsed(prevTime => prevTime + 1);
      }, 1000);
      setTimerInterval(interval);
      
      return () => clearInterval(interval);
    }
  }, [gameStarted, gameCompleted]);

  // Stop timer when game completes
  useEffect(() => {
    if (gameCompleted && timerInterval) {
      clearInterval(timerInterval);
    }
  }, [gameCompleted, timerInterval]);

  const handleGameStart = () => {
    setGameStarted(true);
  };

  const handleMove = () => {
    if (!gameStarted) setGameStarted(true);
    setMoves(prevMoves => prevMoves + 1);
  };

  const handleGameComplete = () => {
    setGameCompleted(true);
  };

  const handleRestart = () => {
    setMoves(0);
    setTimeElapsed(0);
    setGameCompleted(false);
    setGameStarted(false);
  };

  const formatTime = (seconds) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  return (
    <div className="min-h-screen flex flex-col bg-gradient-to-b from-indigo-900 to-blue-600 text-white">
      <Helmet>
        <title>Memory Match Game</title>
      </Helmet>
      
      <header className="py-6 text-center">
        <h1 className="text-4xl font-bold mb-2">Memory Match Game</h1>
        <p className="text-lg">Find all matching pairs to win!</p>
      </header>

      <div className="flex-grow container mx-auto px-4 py-8">
        <div className="bg-blue-800 bg-opacity-50 rounded-lg shadow-lg p-6 max-w-4xl mx-auto">
          <div className="flex flex-wrap justify-between mb-6">
            <div className="mb-4 md:mb-0">
              <div className="bg-blue-900 rounded-lg p-3 inline-block mr-4">
                <span className="text-xl font-bold">Moves: {moves}</span>
              </div>
              <div className="bg-blue-900 rounded-lg p-3 inline-block">
                <span className="text-xl font-bold">Time: {formatTime(timeElapsed)}</span>
              </div>
            </div>
            <button 
              onClick={handleRestart}
              className="bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-3 px-6 rounded-lg transition-colors duration-200"
            >
              Restart Game
            </button>
          </div>

          <GameBoard 
            onMove={handleMove} 
            onGameStart={handleGameStart}
            onGameComplete={handleGameComplete}
            gameCompleted={gameCompleted}
          />

          {gameCompleted && (
            <div className="mt-8 bg-green-600 bg-opacity-80 rounded-lg p-6 text-center">
              <h2 className="text-3xl font-bold mb-2">Congratulations!</h2>
              <p className="text-xl mb-4">You completed the game in {moves} moves and {formatTime(timeElapsed)}!</p>
              <button 
                onClick={handleRestart}
                className="bg-yellow-500 hover:bg-yellow-600 text-black font-bold py-2 px-6 rounded-lg transition-colors duration-200"
              >
                Play Again
              </button>
            </div>
          )}
        </div>
      </div>

      <footer className="py-4 text-center text-sm opacity-70">
        <p>Memory Match Game &copy; {new Date().getFullYear()}</p>
      </footer>
    </div>
  );
};

export default GamePage;