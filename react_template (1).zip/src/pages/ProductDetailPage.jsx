import React, { useState, useEffect } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { useAppContext } from '../context/AppContext';

// Dummy product data - in a real application, this would come from an API
// This is the same product data structure from ProductListPage
const allProducts = [
  // Scanning Equipment
  {
    id: 1,
    name: 'X9000高速扫描仪',
    category: 'scanning',
    categoryName: '扫描设备',
    image: '/images/product1.jpg',
    images: [
      '/images/product1.jpg',
      '/images/product1_2.jpg',
      '/images/product1_3.jpg',
      '/images/product1_4.jpg',
    ],
    description: '企业级高速文档扫描仪，每分钟可扫描200页，双面扫描，自动进纸器可容纳500张纸',
    longDescription: `
      <h3>产品介绍</h3>
      <p>X9000高速扫描仪是一款面向企业的高性能文档扫描解决方案。采用最新的扫描技术，能够满足大批量文档数字化的需求。</p>
      <p>该扫描仪配备了高精度图像传感器，可以捕捉文档的每一个细节，确保扫描结果清晰准确。同时，其高速扫描能力可以显著提升工作效率，适合银行、政府、医疗等行业的大规模文档处理需求。</p>
      
      <h3>核心优势</h3>
      <ul>
        <li>超高速扫描：每分钟可扫描200页（100张双面）</li>
        <li>大容量进纸器：标配500张容量，可扩展至1000张</li>
        <li>智能纸张处理：可自动检测并处理不同尺寸、厚度的文档</li>
        <li>多种扫描模式：支持彩色、灰度、黑白多种模式</li>
        <li>高级图像处理：自动裁剪、偏斜校正、空白页删除等功能</li>
      </ul>
    `,
    price: '¥29,999',
    tags: ['高速', '双面扫描', '大容量'],
    parameters: [
      { name: '扫描速度', value: '200页/分钟（双面100页/分钟）' },
      { name: '光学分辨率', value: '600 dpi' },
      { name: '最大扫描幅面', value: 'A3' },
      { name: '进纸器容量', value: '500张（80g/m²）' },
      { name: '接口类型', value: 'USB 3.0, 以太网' },
      { name: '文件格式', value: 'PDF, TIFF, JPEG, BMP, PNG, Word, Excel' },
      { name: '日扫描量', value: '最高50,000页' },
      { name: '尺寸（长x宽x高）', value: '530 x 350 x 280 mm' },
      { name: '重量', value: '25 kg' },
      { name: '电源要求', value: 'AC 100-240V, 50/60Hz' },
      { name: '功耗', value: '操作时: <90W, 休眠时: <2.0W' },
      { name: '系统要求', value: 'Windows 7/8/10/11, macOS 10.14或以上' },
    ],
    downloads: [
      { name: '产品说明书', type: 'PDF', size: '5.2MB', url: '/downloads/X9000_manual.pdf' },
      { name: '驱动程序 (Windows)', type: '可执行文件', size: '45MB', url: '/downloads/X9000_driver_win.exe' },
      { name: '驱动程序 (Mac)', type: 'DMG', size: '42MB', url: '/downloads/X9000_driver_mac.dmg' },
      { name: '技术规格表', type: 'PDF', size: '2.1MB', url: '/downloads/X9000_specs.pdf' },
      { name: '认证文件', type: 'PDF', size: '1.8MB', url: '/downloads/X9000_certification.pdf' },
    ]
  },
  // Other product data would follow...
];

// Dummy article data
const relatedArticles = [
  {
    id: 1,
    title: '高速扫描仪如何提升企业办公效率',
    summary: '探讨企业引入高速扫描设备后的效率变化及投资回报...',
    date: '2025-02-15',
    image: '/images/article1.jpg',
    path: '/articles/1'
  },
  {
    id: 2,
    title: '文档数字化最佳实践',
    summary: '分享大型企业文档数字化转型的经验与技巧...',
    date: '2025-02-10',
    image: '/images/article2.jpg',
    path: '/articles/2'
  },
  {
    id: 3,
    title: '如何选择适合企业的扫描设备',
    summary: '根据不同的业务需求，如何选择合适的扫描设备...',
    date: '2025-01-28',
    image: '/images/article3.jpg',
    path: '/articles/3'
  }
];

// Dummy case studies
const relatedCases = [
  {
    id: 1,
    title: '某大型银行的文档数字化转型案例',
    summary: '该银行通过部署X9000高速扫描仪，成功实现了每日10万页文档的数字化处理...',
    client: '中国XX银行',
    image: '/images/case1.jpg',
    path: '/cases/1'
  },
  {
    id: 2,
    title: '政府机构档案电子化项目',
    summary: '某市政府使用我们的扫描解决方案，完成了历史档案的数字化保存工作...',
    client: 'XX市政府',
    image: '/images/case2.jpg',
    path: '/cases/2'
  }
];

const ProductDetailPage = () => {
  const { productId } = useParams();
  const navigate = useNavigate();
  const { state } = useAppContext();
  const { language } = state;
  
  // State variables
  const [product, setProduct] = useState(null);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState('parameters');
  const [currentImage, setCurrentImage] = useState(0);
  const [relatedProducts, setRelatedProducts] = useState([]);
  
  // Fetch product data
  useEffect(() => {
    // Simulate API call delay
    setLoading(true);
    const timer = setTimeout(() => {
      const foundProduct = allProducts.find(p => p.id === parseInt(productId));
      if (foundProduct) {
        setProduct(foundProduct);
        
        // Find related products (same category or shared tags)
        const related = allProducts
          .filter(p => p.id !== foundProduct.id && 
                      (p.category === foundProduct.category || 
                       p.tags.some(tag => foundProduct.tags.includes(tag))))
          .slice(0, 4);
        
        setRelatedProducts(related);
      } else {
        // Product not found, redirect to 404
        navigate('/404');
      }
      setLoading(false);
    }, 500);
    
    return () => clearTimeout(timer);
  }, [productId, navigate]);
  
  // Handle image navigation
  const nextImage = () => {
    if (product && product.images) {
      setCurrentImage((prev) => (prev + 1) % product.images.length);
    }
  };
  
  const prevImage = () => {
    if (product && product.images) {
      setCurrentImage((prev) => (prev - 1 + product.images.length) % product.images.length);
    }
  };
  
  // Change main image on thumbnail click
  const handleThumbnailClick = (index) => {
    setCurrentImage(index);
  };
  
  // Loading state
  if (loading) {
    return (
      <div className="container mx-auto px-4 py-8 flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-600"></div>
      </div>
    );
  }
  
  // 404 state (though we redirect, this is a fallback)
  if (!product) {
    return (
      <div className="container mx-auto px-4 py-8">
        <div className="text-center">
          <h2 className="text-2xl font-bold text-gray-700">产品未找到</h2>
          <p className="mt-4 text-gray-600">抱歉，您查找的产品不存在。</p>
          <Link to="/products" className="mt-6 inline-block bg-blue-600 text-white px-4 py-2 rounded-md">
            返回产品列表
          </Link>
        </div>
      </div>
    );
  }
  
  return (
    <div className="container mx-auto px-4 py-8">
      {/* Breadcrumbs */}
      <nav className="text-sm mb-6 flex items-center">
        <Link to="/" className="text-gray-500 hover:text-blue-600">首页</Link>
        <span className="mx-2 text-gray-500">/</span>
        <Link to="/products" className="text-gray-500 hover:text-blue-600">产品中心</Link>
        <span className="mx-2 text-gray-500">/</span>
        <Link to={`/products/category/${product.category}`} className="text-gray-500 hover:text-blue-600">{product.categoryName}</Link>
        <span className="mx-2 text-gray-500">/</span>
        <span className="text-blue-600">{product.name}</span>
      </nav>
      
      {/* Product Main Section */}
      <div className="flex flex-col lg:flex-row gap-8 mb-12">
        {/* Product Images */}
        <div className="lg:w-1/2">
          <div className="relative bg-gray-100 rounded-lg overflow-hidden h-[400px] mb-4">
            {/* Main Image */}
            <img 
              src={product.images ? product.images[currentImage] : product.image} 
              alt={product.name}
              className="w-full h-full object-contain"
            />
            
            {/* Navigation Arrows */}
            {product.images && product.images.length > 1 && (
              <>
                <button 
                  onClick={prevImage}
                  className="absolute left-2 top-1/2 -translate-y-1/2 bg-white rounded-full p-2 shadow-md hover:bg-gray-100"
                  aria-label="Previous image"
                >
                  <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
                  </svg>
                </button>
                <button 
                  onClick={nextImage}
                  className="absolute right-2 top-1/2 -translate-y-1/2 bg-white rounded-full p-2 shadow-md hover:bg-gray-100"
                  aria-label="Next image"
                >
                  <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                  </svg>
                </button>
              </>
            )}
          </div>
          
          {/* Thumbnails */}
          {product.images && product.images.length > 1 && (
            <div className="flex gap-2 overflow-x-auto">
              {product.images.map((image, index) => (
                <button 
                  key={index} 
                  onClick={() => handleThumbnailClick(index)}
                  className={`border-2 rounded overflow-hidden h-20 w-20 flex-shrink-0 
                    ${currentImage === index ? 'border-blue-600' : 'border-transparent'}`}
                >
                  <img 
                    src={image} 
                    alt={`${product.name} - 图片 ${index + 1}`}
                    className="w-full h-full object-cover"
                  />
                </button>
              ))}
            </div>
          )}
        </div>
        
        {/* Product Details */}
        <div className="lg:w-1/2">
          <h1 className="text-3xl font-bold mb-2">{product.name}</h1>
          <div className="text-sm text-gray-500 mb-4">型号: XX-{product.id}00</div>
          <p className="text-lg mb-6">{product.description}</p>
          
          {/* Price and Tags */}
          <div className="mb-6">
            <div className="text-2xl text-blue-700 font-bold mb-2">{product.price}</div>
            <div className="flex flex-wrap gap-2">
              {product.tags.map((tag, index) => (
                <span key={index} className="bg-blue-100 text-blue-800 text-sm px-3 py-1 rounded-full">
                  {tag}
                </span>
              ))}
            </div>
          </div>
          
          {/* Actions */}
          <div className="flex flex-col sm:flex-row gap-4 mb-8">
            <Link to="/contact" className="bg-blue-600 text-white text-center px-6 py-3 rounded-md hover:bg-blue-700 transition-colors">
              在线咨询
            </Link>
            <button 
              type="button"
              onClick={() => {
                // In a real app, this would add to favorites using Context
                alert('产品已添加到收藏夹！');
              }}
              className="border border-blue-600 text-blue-600 px-6 py-3 rounded-md hover:bg-blue-50 transition-colors flex items-center justify-center"
            >
              <svg className="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z" />
              </svg>
              收藏产品
            </button>
          </div>
          
          {/* Quick Highlights */}
          <div className="bg-gray-50 rounded-lg p-4 mb-6">
            <h3 className="font-bold mb-2">产品亮点</h3>
            <ul className="list-disc list-inside space-y-1">
              <li>高速扫描，每分钟200页</li>
              <li>大容量进纸器，可容纳500张</li>
              <li>支持双面同时扫描</li>
              <li>多种接口，易于集成</li>
              <li>高级图像处理功能</li>
            </ul>
          </div>
        </div>
      </div>
      
      {/* Tabs Section */}
      <div className="mb-12">
        {/* Tab Navigation */}
        <div className="border-b border-gray-200 mb-6">
          <div className="flex overflow-x-auto">
            <button 
              onClick={() => setActiveTab('parameters')}
              className={`py-3 px-6 font-medium whitespace-nowrap border-b-2 ${
                activeTab === 'parameters' ? 'border-blue-600 text-blue-600' : 'border-transparent text-gray-500'
              }`}
            >
              详细参数
            </button>
            <button 
              onClick={() => setActiveTab('description')}
              className={`py-3 px-6 font-medium whitespace-nowrap border-b-2 ${
                activeTab === 'description' ? 'border-blue-600 text-blue-600' : 'border-transparent text-gray-500'
              }`}
            >
              产品介绍
            </button>
            <button 
              onClick={() => setActiveTab('downloads')}
              className={`py-3 px-6 font-medium whitespace-nowrap border-b-2 ${
                activeTab === 'downloads' ? 'border-blue-600 text-blue-600' : 'border-transparent text-gray-500'
              }`}
            >
              下载资料
            </button>
            <button 
              onClick={() => setActiveTab('cases')}
              className={`py-3 px-6 font-medium whitespace-nowrap border-b-2 ${
                activeTab === 'cases' ? 'border-blue-600 text-blue-600' : 'border-transparent text-gray-500'
              }`}
            >
              相关案例
            </button>
          </div>
        </div>
        
        {/* Tab Content */}
        <div className="bg-white rounded-lg">
          {/* Parameters Tab */}
          {activeTab === 'parameters' && (
            <div>
              <h2 className="text-xl font-bold mb-4">技术规格参数</h2>
              <div className="overflow-x-auto">
                <table className="w-full">
                  <tbody>
                    {product.parameters && product.parameters.map((param, index) => (
                      <tr key={index} className={index % 2 === 0 ? 'bg-gray-50' : 'bg-white'}>
                        <td className="py-3 px-4 font-medium w-1/3">{param.name}</td>
                        <td className="py-3 px-4">{param.value}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}
          
          {/* Description Tab */}
          {activeTab === 'description' && (
            <div>
              <div 
                className="prose max-w-none"
                dangerouslySetInnerHTML={{ __html: product.longDescription || '<p>暂无详细介绍</p>' }}
              />
            </div>
          )}
          
          {/* Downloads Tab */}
          {activeTab === 'downloads' && (
            <div>
              <h2 className="text-xl font-bold mb-4">相关资料下载</h2>
              {product.downloads && product.downloads.length > 0 ? (
                <div className="space-y-4">
                  {product.downloads.map((item, index) => (
                    <div key={index} className="flex items-center justify-between p-4 border border-gray-200 rounded-lg hover:bg-gray-50">
                      <div className="flex items-center">
                        <div className="mr-4">
                          <svg className="w-10 h-10 text-blue-600" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                            <path fillRule="evenodd" d="M4 4a2 2 0 012-2h4.586A2 2 0 0112 2.586L15.414 6A2 2 0 0116 7.414V16a2 2 0 01-2 2H6a2 2 0 01-2-2V4z" clipRule="evenodd" />
                          </svg>
                        </div>
                        <div>
                          <div className="font-medium">{item.name}</div>
                          <div className="text-sm text-gray-500">
                            {item.type} · {item.size}
                          </div>
                        </div>
                      </div>
                      <a 
                        href={item.url}
                        download
                        className="flex items-center text-blue-600 hover:text-blue-800"
                      >
                        <span className="mr-1">下载</span>
                        <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" />
                        </svg>
                      </a>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-gray-500">暂无可下载资料</p>
              )}
            </div>
          )}
          
          {/* Cases Tab */}
          {activeTab === 'cases' && (
            <div>
              <h2 className="text-xl font-bold mb-4">相关案例</h2>
              {relatedCases.length > 0 ? (
                <div className="grid md:grid-cols-2 gap-6">
                  {relatedCases.map(caseItem => (
                    <Link key={caseItem.id} to={caseItem.path} className="flex flex-col bg-white border border-gray-200 rounded-lg overflow-hidden hover:shadow-md transition-shadow">
                      <div className="h-48 overflow-hidden">
                        <img 
                          src={caseItem.image} 
                          alt={caseItem.title} 
                          className="w-full h-full object-cover transition-transform hover:scale-105"
                        />
                      </div>
                      <div className="p-5">
                        <h3 className="text-xl font-semibold mb-2">{caseItem.title}</h3>
                        <p className="text-gray-700 font-medium mb-2">客户: {caseItem.client}</p>
                        <p className="text-gray-600 line-clamp-2">{caseItem.summary}</p>
                        <div className="mt-4 text-blue-600">查看详情 →</div>
                      </div>
                    </Link>
                  ))}
                </div>
              ) : (
                <p className="text-gray-500">暂无相关案例</p>
              )}
            </div>
          )}
        </div>
      </div>
      
      {/* Related Products */}
      {relatedProducts.length > 0 && (
        <div className="mb-12">
          <div className="flex justify-between items-center mb-6">
            <h2 className="text-2xl font-bold">相关产品</h2>
            <Link to="/products" className="text-blue-600 hover:text-blue-800">
              查看全部 &rarr;
            </Link>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {relatedProducts.map(relatedProduct => (
              <Link key={relatedProduct.id} to={`/products/${relatedProduct.id}`} className="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-lg transition-shadow">
                <div className="h-48 overflow-hidden">
                  <img 
                    src={relatedProduct.image} 
                    alt={relatedProduct.name} 
                    className="w-full h-full object-cover transition-transform hover:scale-105"
                  />
                </div>
                <div className="p-5">
                  <h3 className="text-lg font-semibold mb-2">{relatedProduct.name}</h3>
                  <div className="flex items-center justify-between mb-3">
                    <span className="text-sm text-gray-500">{relatedProduct.categoryName}</span>
                    <span className="font-semibold text-blue-600">{relatedProduct.price}</span>
                  </div>
                </div>
              </Link>
            ))}
          </div>
        </div>
      )}
      
      {/* Related Articles */}
      <div>
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-2xl font-bold">相关文章</h2>
          <Link to="/articles" className="text-blue-600 hover:text-blue-800">
            查看全部 &rarr;
          </Link>
        </div>
        <div className="grid md:grid-cols-3 gap-6">
          {relatedArticles.map(article => (
            <Link key={article.id} to={article.path} className="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-lg transition-shadow">
              <div className="h-48 overflow-hidden">
                <img 
                  src={article.image} 
                  alt={article.title} 
                  className="w-full h-full object-cover transition-transform hover:scale-105"
                />
              </div>
              <div className="p-5">
                <h3 className="text-lg font-semibold mb-2">{article.title}</h3>
                <p className="text-gray-600 mb-4 line-clamp-2">{article.summary}</p>
                <p className="text-sm text-gray-500">{article.date}</p>
              </div>
            </Link>
          ))}
        </div>
      </div>
    </div>
  );
};

export default ProductDetailPage;