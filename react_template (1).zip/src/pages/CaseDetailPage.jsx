import React, { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { FaArrowLeft, FaClock, FaBuilding, FaTag } from 'react-icons/fa';

const CaseDetailPage = () => {
  const { caseId } = useParams();
  const [caseDetail, setCaseDetail] = useState(null);
  const [loading, setLoading] = useState(true);

  // Static case data since there's no backend
  const staticCaseData = {
    '1': {
      id: '1',
      title: 'Enterprise Digital Transformation Project',
      company: 'XYZ Corporation',
      date: '2023-10-15',
      summary: 'A comprehensive digital transformation project for XYZ Corporation that revolutionized their business processes.',
      challenge: 'XYZ Corporation was facing challenges with outdated systems, manual processes, and difficulty scaling their operations to meet growing demand.',
      solution: 'We implemented a tailored enterprise solution that digitized core processes, integrated disparate systems, and enabled data-driven decision making.',
      results: 'The solution resulted in a 45% increase in operational efficiency, 30% reduction in costs, and enabled the client to scale operations by 200% without additional staffing.',
      tags: ['Digital Transformation', 'Enterprise Solutions', 'Process Automation'],
      image: '/images/case-study-1.jpg',
      testimonial: {
        quote: "The transformation has been remarkable. We're now able to serve more customers with fewer resources while improving quality.",
        author: "Jane Smith",
        position: "CIO, XYZ Corporation"
      }
    },
    '2': {
      id: '2',
      title: 'Smart Manufacturing Implementation',
      company: 'ABC Industries',
      date: '2023-08-22',
      summary: 'Implementation of IoT and AI solutions in manufacturing to optimize production processes.',
      challenge: 'ABC Industries struggled with production inefficiencies, quality control issues, and high operational costs in their manufacturing plants.',
      solution: 'We deployed IoT sensors throughout the production line and implemented AI-powered analytics to optimize processes and predict maintenance needs.',
      results: 'Manufacturing efficiency improved by 35%, defect rates decreased by 58%, and predictive maintenance reduced downtime by 72%.',
      tags: ['IoT', 'AI', 'Manufacturing', 'Industry 4.0'],
      image: '/images/case-study-2.jpg',
      testimonial: {
        quote: "This technology revolution has transformed our manufacturing processes and significantly improved our bottom line.",
        author: "John Brown",
        position: "COO, ABC Industries"
      }
    },
    '3': {
      id: '3',
      title: 'Cloud Migration & Security Enhancement',
      company: 'Global Financial Services',
      date: '2023-07-10',
      summary: 'Successful migration to cloud infrastructure with enhanced security protocols for a financial institution.',
      challenge: 'The client needed to modernize their infrastructure while ensuring compliance with strict financial regulations and enhancing security.',
      solution: 'We implemented a hybrid cloud solution with advanced security measures, identity management, and compliance monitoring tools.',
      results: 'Achieved 99.99% system availability, reduced infrastructure costs by 40%, and successfully passed all security audits with zero findings.',
      tags: ['Cloud Migration', 'Cybersecurity', 'Financial Services'],
      image: '/images/case-study-3.jpg',
      testimonial: {
        quote: "The migration was seamless and the enhanced security gives us peace of mind in an increasingly threatening cyber landscape.",
        author: "Sarah Wilson",
        position: "CISO, Global Financial Services"
      }
    }
  };

  useEffect(() => {
    // Simulate API call with setTimeout
    setLoading(true);
    setTimeout(() => {
      setCaseDetail(staticCaseData[caseId] || null);
      setLoading(false);
    }, 500);
  }, [caseId]);

  if (loading) {
    return (
      <div className="flex items-center justify-center h-screen">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  if (!caseDetail) {
    return (
      <div className="container mx-auto px-4 py-12">
        <div className="text-center">
          <h1 className="text-3xl font-bold text-red-600 mb-4">Case Study Not Found</h1>
          <p className="mb-6">The case study you're looking for doesn't exist or has been removed.</p>
          <Link to="/cases" className="inline-flex items-center text-blue-600 hover:text-blue-800">
            <FaArrowLeft className="mr-2" /> Return to Case Studies
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-10">
      {/* Breadcrumb */}
      <div className="mb-6">
        <Link to="/cases" className="inline-flex items-center text-blue-600 hover:underline">
          <FaArrowLeft className="mr-2" /> Back to Case Studies
        </Link>
      </div>
      
      {/* Case Header */}
      <div className="mb-8">
        <h1 className="text-3xl md:text-4xl font-bold mb-4">{caseDetail.title}</h1>
        <div className="flex flex-wrap items-center text-gray-600 gap-4 mb-4">
          <div className="flex items-center">
            <FaBuilding className="mr-1" />
            <span>{caseDetail.company}</span>
          </div>
          <div className="flex items-center">
            <FaClock className="mr-1" />
            <span>{new Date(caseDetail.date).toLocaleDateString()}</span>
          </div>
        </div>
        <div className="flex flex-wrap gap-2 mb-4">
          {caseDetail.tags.map(tag => (
            <span key={tag} className="bg-blue-100 text-blue-800 text-sm px-3 py-1 rounded-full flex items-center">
              <FaTag className="mr-1 text-xs" /> {tag}
            </span>
          ))}
        </div>
      </div>

      {/* Hero Image */}
      <div className="mb-10 rounded-xl overflow-hidden shadow-lg">
        <img 
          src={caseDetail.image || "https://via.placeholder.com/1200x600?text=Case+Study+Image"} 
          alt={caseDetail.title}
          className="w-full object-cover h-[400px]"
        />
      </div>

      {/* Summary */}
      <div className="mb-10 bg-blue-50 p-6 rounded-lg border-l-4 border-blue-600">
        <h2 className="text-xl font-semibold mb-2">Summary</h2>
        <p className="text-gray-700">{caseDetail.summary}</p>
      </div>

      {/* Main Content */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-12">
        <div className="lg:col-span-2 space-y-8">
          <section>
            <h2 className="text-2xl font-bold mb-4">Challenge</h2>
            <p className="text-gray-700">{caseDetail.challenge}</p>
          </section>
          
          <section>
            <h2 className="text-2xl font-bold mb-4">Solution</h2>
            <p className="text-gray-700">{caseDetail.solution}</p>
          </section>
          
          <section>
            <h2 className="text-2xl font-bold mb-4">Results</h2>
            <p className="text-gray-700">{caseDetail.results}</p>
          </section>
        </div>
        
        <div>
          {/* Testimonial Sidebar */}
          {caseDetail.testimonial && (
            <div className="bg-gray-50 p-6 rounded-lg shadow-md">
              <blockquote className="italic text-lg mb-4">"{caseDetail.testimonial.quote}"</blockquote>
              <div className="flex items-center">
                <div className="h-12 w-12 rounded-full bg-gray-300 flex items-center justify-center text-gray-600 font-bold text-xl mr-4">
                  {caseDetail.testimonial.author.charAt(0)}
                </div>
                <div>
                  <p className="font-medium">{caseDetail.testimonial.author}</p>
                  <p className="text-gray-600 text-sm">{caseDetail.testimonial.position}</p>
                </div>
              </div>
            </div>
          )}
          
          {/* Related Case Studies */}
          <div className="mt-8">
            <h3 className="text-xl font-bold mb-4">Related Case Studies</h3>
            <div className="space-y-4">
              {Object.values(staticCaseData)
                .filter(item => item.id !== caseDetail.id)
                .slice(0, 2)
                .map(item => (
                  <Link key={item.id} to={`/cases/${item.id}`} className="block p-4 border border-gray-200 rounded-lg hover:bg-gray-50">
                    <h4 className="font-medium mb-1">{item.title}</h4>
                    <p className="text-sm text-gray-600">{item.company}</p>
                  </Link>
                ))
              }
            </div>
          </div>
        </div>
      </div>

      {/* Call to Action */}
      <div className="bg-blue-600 text-white p-8 rounded-lg text-center">
        <h2 className="text-2xl font-bold mb-4">Ready to achieve similar results?</h2>
        <p className="mb-6">Contact us today to discuss how we can help transform your business.</p>
        <Link 
          to="/contact" 
          className="inline-block bg-white text-blue-600 px-6 py-3 rounded-md font-medium hover:bg-gray-100 transition-colors"
        >
          Contact Us
        </Link>
      </div>
    </div>
  );
};

export default CaseDetailPage;