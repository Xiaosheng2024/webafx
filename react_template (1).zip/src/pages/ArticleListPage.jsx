import React, { useState, useEffect } from 'react';
import { useParams, Link, useLocation, useNavigate } from 'react-router-dom';
import { useAppContext } from '../context/AppContext';

// Dummy article data - in a real application, this would come from an API
const allArticles = [
  // Industry News - 行业动态
  {
    id: 1,
    title: '数字化转型中的文档管理挑战与解决方案',
    category: 'industry',
    categoryName: '行业动态',
    image: '/images/article1.jpg',
    summary: '探讨企业在数字化过程中面临的文档管理问题，并提供切实可行的解决思路。随着企业数字化转型的深入，文档管理面临的挑战日益凸显，高效的解决方案成为关键。',
    content: '文章正文内容...',
    author: '李明',
    date: '2025-02-25',
    tags: ['数字化转型', '文档管理', '企业效率'],
    viewCount: 1250
  },
  {
    id: 2,
    title: '2025年打印设备行业发展趋势分析',
    category: 'industry',
    categoryName: '行业动态',
    image: '/images/article2.jpg',
    summary: '基于市场数据分析当前打印设备行业的发展方向，探讨智能化、环保化、集成化等趋势对行业的影响和未来发展前景。',
    content: '文章正文内容...',
    author: '王强',
    date: '2025-02-20',
    tags: ['行业趋势', '打印设备', '市场分析'],
    viewCount: 980
  },
  {
    id: 3,
    title: '全球文档扫描市场季度报告解读',
    category: 'industry',
    categoryName: '行业动态',
    image: '/images/article3.jpg',
    summary: '解读最新一季度全球文档扫描设备市场报告，分析市场份额变化、区域发展差异以及主要厂商的战略调整。',
    content: '文章正文内容...',
    author: '张海',
    date: '2025-02-15',
    tags: ['市场报告', '扫描设备', '全球市场'],
    viewCount: 845
  },
  {
    id: 4,
    title: '政府部门文档管理的数字化转型案例',
    category: 'industry',
    categoryName: '行业动态',
    image: '/images/article4.jpg',
    summary: '分享多个政府部门成功实施文档数字化管理的案例，总结其中的经验和挑战，为其他机构提供参考。',
    content: '文章正文内容...',
    author: '刘悦',
    date: '2025-02-10',
    tags: ['政府机构', '数字化转型', '案例分析'],
    viewCount: 1120
  },
  // Technical Articles - 技术文章
  {
    id: 5,
    title: '如何选择适合企业的扫描设备',
    category: 'technical',
    categoryName: '技术文章',
    image: '/images/article5.jpg',
    summary: '针对不同规模企业的需求，分析各类扫描设备的优缺点及适用场景，帮助企业做出明智的设备选购决策。',
    content: '文章正文内容...',
    author: '赵明',
    date: '2025-02-08',
    tags: ['扫描设备', '设备选购', '企业应用'],
    viewCount: 1580
  },
  {
    id: 6,
    title: 'OCR技术在文档管理中的应用进展',
    category: 'technical',
    categoryName: '技术文章',
    image: '/images/article6.jpg',
    summary: '介绍OCR技术的最新发展及其在企业文档管理中的实际应用，包括多语言识别、表格识别等特定场景的技术突破。',
    content: '文章正文内容...',
    author: '陈学',
    date: '2025-02-05',
    tags: ['OCR技术', 'AI识别', '技术应用'],
    viewCount: 1350
  },
  {
    id: 7,
    title: '企业打印管理系统的安全防护策略',
    category: 'technical',
    categoryName: '技术文章',
    image: '/images/article7.jpg',
    summary: '探讨企业打印环境中的安全风险及防护措施，包括权限管理、数据加密、审计跟踪等方面的最佳实践。',
    content: '文章正文内容...',
    author: '郭安',
    date: '2025-02-01',
    tags: ['打印安全', '数据保护', '安全策略'],
    viewCount: 920
  },
  {
    id: 8,
    title: '高速扫描仪光学系统原理与维护',
    category: 'technical',
    categoryName: '技术文章',
    image: '/images/article8.jpg',
    summary: '详解高速扫描仪的光学系统工作原理，以及日常使用中的维护要点，帮助用户延长设备使用寿命。',
    content: '文章正文内容...',
    author: '孙技',
    date: '2025-01-28',
    tags: ['扫描原理', '设备维护', '技术知识'],
    viewCount: 760
  },
  // FAQs - 常见问题
  {
    id: 9,
    title: '扫描仪无法正常进纸的常见原因及解决方法',
    category: 'faq',
    categoryName: '常见问题',
    image: '/images/article9.jpg',
    summary: '总结扫描仪使用中常见的进纸问题，分析可能的原因并提供针对性的排查和解决步骤。',
    content: '文章正文内容...',
    author: '技术支持部',
    date: '2025-01-25',
    tags: ['常见故障', '故障排除', '用户指南'],
    viewCount: 2100
  },
  {
    id: 10,
    title: '如何提高OCR识别的准确率',
    category: 'faq',
    categoryName: '常见问题',
    image: '/images/article10.jpg',
    summary: '提供一系列实用技巧，帮助用户在使用OCR功能时获得更高的文字识别准确率，包括图像预处理、参数设置等方面的建议。',
    content: '文章正文内容...',
    author: '技术支持部',
    date: '2025-01-20',
    tags: ['OCR识别', '使用技巧', '问题解答'],
    viewCount: 1870
  },
  {
    id: 11,
    title: '企业常见的打印成本控制方法',
    category: 'faq',
    categoryName: '常见问题',
    image: '/images/article11.jpg',
    summary: '介绍企业中常用的打印成本控制策略，包括设备选择、耗材管理、权限设置和使用习惯培养等多个方面。',
    content: '文章正文内容...',
    author: '解决方案部',
    date: '2025-01-15',
    tags: ['成本控制', '打印管理', '企业经验'],
    viewCount: 1420
  },
  {
    id: 12,
    title: '文档管理软件常见问题解答集锦',
    category: 'faq',
    categoryName: '常见问题',
    image: '/images/article12.jpg',
    summary: '汇总用户在使用文档管理软件过程中常见的问题及解答，涵盖安装配置、日常使用和故障处理等多个方面。',
    content: '文章正文内容...',
    author: '客户服务部',
    date: '2025-01-10',
    tags: ['软件使用', '问题解答', '用户指南'],
    viewCount: 1650
  }
];

// Article categories
const categories = [
  { id: 'all', name: '全部文章' },
  { id: 'industry', name: '行业动态' },
  { id: 'technical', name: '技术文章' },
  { id: 'faq', name: '常见问题' }
];

// All tags for filtering
const allTags = [
  '数字化转型', '文档管理', '企业效率', '行业趋势', '打印设备', '市场分析',
  '市场报告', '扫描设备', '全球市场', '政府机构', '案例分析', '设备选购',
  '企业应用', 'OCR技术', 'AI识别', '技术应用', '打印安全', '数据保护',
  '安全策略', '扫描原理', '设备维护', '技术知识', '常见故障', '故障排除',
  '用户指南', 'OCR识别', '使用技巧', '问题解答', '成本控制', '打印管理',
  '企业经验', '软件使用'
];

const ArticleListPage = () => {
  const { categoryId } = useParams();
  const location = useLocation();
  const navigate = useNavigate();
  const queryParams = new URLSearchParams(location.search);
  const { state } = useAppContext();
  const { language } = state;

  // State variables
  const [articles, setArticles] = useState([]);
  const [selectedCategory, setSelectedCategory] = useState(categoryId || 'all');
  const [selectedTags, setSelectedTags] = useState([]);
  const [searchQuery, setSearchQuery] = useState(queryParams.get('query') || '');
  const [sortBy, setSortBy] = useState('date'); // 'date', 'viewCount'
  const [currentPage, setCurrentPage] = useState(1);
  const [articlesPerPage] = useState(6);
  const [isMobileFilterOpen, setIsMobileFilterOpen] = useState(false);

  // Filter articles based on selections
  useEffect(() => {
    let filteredArticles = [...allArticles];
    
    // Filter by category
    if (selectedCategory !== 'all') {
      filteredArticles = filteredArticles.filter(article => article.category === selectedCategory);
    }
    
    // Filter by tags
    if (selectedTags.length > 0) {
      filteredArticles = filteredArticles.filter(article => 
        selectedTags.some(tag => article.tags.includes(tag))
      );
    }
    
    // Filter by search query
    if (searchQuery) {
      const query = searchQuery.toLowerCase();
      filteredArticles = filteredArticles.filter(article => 
        article.title.toLowerCase().includes(query) || 
        article.summary.toLowerCase().includes(query) ||
        article.tags.some(tag => tag.toLowerCase().includes(query))
      );
    }
    
    // Sort articles
    if (sortBy === 'date') {
      filteredArticles.sort((a, b) => new Date(b.date) - new Date(a.date));
    } else if (sortBy === 'viewCount') {
      filteredArticles.sort((a, b) => b.viewCount - a.viewCount);
    }
    
    setArticles(filteredArticles);
    setCurrentPage(1);
    
    // Update URL with filters
    const params = new URLSearchParams();
    if (selectedCategory !== 'all') params.set('category', selectedCategory);
    if (selectedTags.length > 0) params.set('tags', selectedTags.join(','));
    if (searchQuery) params.set('query', searchQuery);
    if (sortBy !== 'date') params.set('sort', sortBy);
    
    const newUrl = `${location.pathname}${params.toString() ? `?${params.toString()}` : ''}`;
    navigate(newUrl, { replace: true });
    
  }, [selectedCategory, selectedTags, searchQuery, sortBy, navigate, location.pathname]);
  
  // Update selected category when URL param changes
  useEffect(() => {
    if (categoryId) {
      setSelectedCategory(categoryId);
    } else {
      setSelectedCategory('all');
    }
  }, [categoryId]);
  
  // Handle category selection
  const handleCategoryChange = (category) => {
    setSelectedCategory(category);
    if (category === 'all') {
      navigate('/articles');
    } else {
      navigate(`/articles/category/${category}`);
    }
  };
  
  // Handle tag selection
  const handleTagToggle = (tag) => {
    setSelectedTags(prevTags => 
      prevTags.includes(tag)
        ? prevTags.filter(t => t !== tag)
        : [...prevTags, tag]
    );
  };
  
  // Handle search input
  const handleSearchChange = (e) => {
    setSearchQuery(e.target.value);
  };

  // Handle sort change
  const handleSortChange = (e) => {
    setSortBy(e.target.value);
  };
  
  // Pagination logic
  const indexOfLastArticle = currentPage * articlesPerPage;
  const indexOfFirstArticle = indexOfLastArticle - articlesPerPage;
  const currentArticles = articles.slice(indexOfFirstArticle, indexOfLastArticle);
  const totalPages = Math.ceil(articles.length / articlesPerPage);
  
  // Get category name for display
  const getCategoryName = (categoryId) => {
    if (categoryId === 'all') return '全部文章';
    const category = categories.find(cat => cat.id === categoryId);
    return category ? category.name : '资讯中心';
  };
  
  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex flex-col md:flex-row justify-between items-start">
        {/* Mobile Filter Toggle */}
        <button 
          className="md:hidden bg-blue-600 text-white px-4 py-2 rounded-md mb-4 flex items-center"
          onClick={() => setIsMobileFilterOpen(!isMobileFilterOpen)}
        >
          <svg className="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6V4m0 2a2 2 0 100 4m0-4a2 2 0 110 4m-6 8a2 2 0 100-4m0 4a2 2 0 110-4m0 4v2m0-6V4m6 6v10m6-2a2 2 0 100-4m0 4a2 2 0 110-4m0 4v2m0-6V4" />
          </svg>
          筛选选项
        </button>
        
        {/* Left Sidebar - Filters */}
        <aside className={`w-full md:w-1/4 md:pr-6 ${isMobileFilterOpen ? 'block' : 'hidden md:block'}`}>
          <div className="bg-white rounded-lg shadow-md p-6 mb-6">
            <h3 className="text-lg font-semibold mb-4">分类浏览</h3>
            <ul className="space-y-2">
              {categories.map(category => (
                <li key={category.id}>
                  <button 
                    onClick={() => handleCategoryChange(category.id)}
                    className={`w-full text-left px-3 py-2 rounded-md ${selectedCategory === category.id ? 'bg-blue-500 text-white' : 'hover:bg-gray-100'}`}
                  >
                    {category.name}
                  </button>
                </li>
              ))}
            </ul>
          </div>
          
          <div className="bg-white rounded-lg shadow-md p-6 mb-6">
            <h3 className="text-lg font-semibold mb-4">搜索文章</h3>
            <div className="relative">
              <input 
                type="text" 
                value={searchQuery}
                onChange={handleSearchChange}
                placeholder="搜索文章..."
                className="w-full border border-gray-300 rounded-md px-4 py-2 pl-10"
              />
              <svg className="w-5 h-5 absolute left-3 top-3 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
              </svg>
            </div>
          </div>
          
          <div className="bg-white rounded-lg shadow-md p-6">
            <h3 className="text-lg font-semibold mb-4">热门标签</h3>
            <div className="flex flex-wrap gap-2">
              {allTags.map(tag => (
                <button
                  key={tag}
                  onClick={() => handleTagToggle(tag)}
                  className={`px-3 py-1 rounded-full text-sm ${
                    selectedTags.includes(tag) 
                      ? 'bg-blue-500 text-white' 
                      : 'bg-gray-100 hover:bg-gray-200'
                  }`}
                >
                  {tag}
                </button>
              ))}
            </div>
          </div>
        </aside>
        
        {/* Main Content */}
        <main className="w-full md:w-3/4">
          {/* Breadcrumbs */}
          <nav className="text-sm mb-6 flex items-center">
            <Link to="/" className="text-gray-500 hover:text-blue-600">首页</Link>
            <span className="mx-2 text-gray-500">/</span>
            <Link to="/articles" className="text-gray-500 hover:text-blue-600">资讯中心</Link>
            {selectedCategory !== 'all' && (
              <>
                <span className="mx-2 text-gray-500">/</span>
                <span className="text-blue-600">{getCategoryName(selectedCategory)}</span>
              </>
            )}
          </nav>
          
          {/* Page Header */}
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-6">
            <h1 className="text-2xl md:text-3xl font-bold mb-3 sm:mb-0">{getCategoryName(selectedCategory)}</h1>
            <div className="flex items-center">
              <label htmlFor="sortSelect" className="mr-2 text-gray-600">排序方式:</label>
              <select 
                id="sortSelect"
                value={sortBy} 
                onChange={handleSortChange}
                className="border border-gray-300 rounded-md px-3 py-1"
              >
                <option value="date">最新发布</option>
                <option value="viewCount">最多阅读</option>
              </select>
            </div>
          </div>
          
          {/* Applied Filters */}
          {(selectedTags.length > 0 || searchQuery) && (
            <div className="bg-gray-50 p-3 rounded-md mb-6">
              <div className="flex flex-wrap gap-2 items-center">
                <span className="text-sm text-gray-500">已选条件:</span>
                {searchQuery && (
                  <span className="inline-flex items-center bg-blue-100 text-blue-800 text-xs px-2 py-1 rounded-full">
                    搜索: {searchQuery}
                    <button 
                      onClick={() => setSearchQuery('')}
                      className="ml-1 focus:outline-none"
                    >
                      <svg className="w-3 h-3" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                        <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" clipRule="evenodd" />
                      </svg>
                    </button>
                  </span>
                )}
                {selectedTags.map(tag => (
                  <span key={tag} className="inline-flex items-center bg-blue-100 text-blue-800 text-xs px-2 py-1 rounded-full">
                    {tag}
                    <button 
                      onClick={() => handleTagToggle(tag)}
                      className="ml-1 focus:outline-none"
                    >
                      <svg className="w-3 h-3" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                        <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" clipRule="evenodd" />
                      </svg>
                    </button>
                  </span>
                ))}
                {(selectedTags.length > 0 || searchQuery) && (
                  <button 
                    onClick={() => {
                      setSelectedTags([]);
                      setSearchQuery('');
                    }}
                    className="text-sm text-blue-600 hover:text-blue-800"
                  >
                    清除全部条件
                  </button>
                )}
              </div>
            </div>
          )}
          
          {/* Articles Grid */}
          {articles.length > 0 ? (
            <>
              <div className="grid grid-cols-1 gap-8">
                {currentArticles.map(article => (
                  <Link key={article.id} to={`/articles/${article.id}`} className="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-lg transition-shadow">
                    <div className="flex flex-col md:flex-row">
                      <div className="md:w-1/3 h-60 md:h-auto overflow-hidden">
                        <img 
                          src={article.image} 
                          alt={article.title} 
                          className="w-full h-full object-cover transition-transform hover:scale-105"
                        />
                      </div>
                      <div className="md:w-2/3 p-6">
                        <div className="flex flex-col h-full">
                          <div>
                            <span className="inline-block bg-blue-100 text-blue-800 text-xs px-2 py-1 rounded mb-2">
                              {article.categoryName}
                            </span>
                            <h3 className="text-xl font-bold mb-3 hover:text-blue-600 transition-colors">{article.title}</h3>
                            <p className="text-gray-600 mb-4 line-clamp-2">{article.summary}</p>
                          </div>
                          <div className="mt-auto">
                            <div className="flex flex-wrap gap-2 mb-3">
                              {article.tags.map((tag, idx) => (
                                <span key={idx} className="text-xs bg-gray-100 px-2 py-1 rounded">
                                  {tag}
                                </span>
                              ))}
                            </div>
                            <div className="flex items-center justify-between text-sm text-gray-500">
                              <div className="flex items-center">
                                <span className="mr-1">by {article.author}</span>
                              </div>
                              <div className="flex items-center space-x-4">
                                <span>{article.date}</span>
                                <div className="flex items-center">
                                  <svg className="w-4 h-4 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
                                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" />
                                  </svg>
                                  {article.viewCount}
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </Link>
                ))}
              </div>
              
              {/* Pagination */}
              {totalPages > 1 && (
                <div className="mt-8 flex justify-center">
                  <nav className="flex items-center space-x-2">
                    <button
                      onClick={() => setCurrentPage(prev => Math.max(prev - 1, 1))}
                      disabled={currentPage === 1}
                      className={`px-3 py-2 rounded-md ${
                        currentPage === 1 
                          ? 'text-gray-400 cursor-not-allowed' 
                          : 'text-gray-700 hover:bg-gray-100'
                      }`}
                    >
                      上一页
                    </button>
                    
                    {[...Array(totalPages)].map((_, idx) => (
                      <button
                        key={idx}
                        onClick={() => setCurrentPage(idx + 1)}
                        className={`px-3 py-2 rounded-md ${
                          currentPage === idx + 1
                            ? 'bg-blue-600 text-white'
                            : 'text-gray-700 hover:bg-gray-100'
                        }`}
                      >
                        {idx + 1}
                      </button>
                    ))}
                    
                    <button
                      onClick={() => setCurrentPage(prev => Math.min(prev + 1, totalPages))}
                      disabled={currentPage === totalPages}
                      className={`px-3 py-2 rounded-md ${
                        currentPage === totalPages
                          ? 'text-gray-400 cursor-not-allowed'
                          : 'text-gray-700 hover:bg-gray-100'
                      }`}
                    >
                      下一页
                    </button>
                  </nav>
                </div>
              )}
            </>
          ) : (
            <div className="bg-gray-50 p-10 rounded-lg text-center">
              <svg className="w-16 h-16 text-gray-400 mx-auto mb-4" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9.172 16.172a4 4 0 015.656 0M9 10h.01M15 10h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
              </svg>
              <h3 className="text-xl font-semibold mb-2">未找到文章</h3>
              <p className="text-gray-600 mb-4">抱歉，没有找到符合当前筛选条件的文章。</p>
              <button 
                onClick={() => {
                  setSelectedTags([]);
                  setSearchQuery('');
                }}
                className="inline-flex items-center bg-blue-600 text-white px-4 py-2 rounded-md hover:bg-blue-700"
              >
                <svg className="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
                </svg>
                重置筛选条件
              </button>
            </div>
          )}
        </main>
      </div>
    </div>
  );
};

export default ArticleListPage;