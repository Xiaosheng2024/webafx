import React, { useState, useEffect } from 'react';
import { toast } from 'react-toastify';
import Layout from '../../components/admin/Layout';

const UserManagementPage = () => {
  const [users, setUsers] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [currentUser, setCurrentUser] = useState(null);
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    role: 'user',
    isActive: true
  });
  const [filterRole, setFilterRole] = useState('all');
  
  // Mock data for demonstration
  const mockUsers = [
    {
      id: 101,
      name: '管理员',
      email: 'admin@example.com',
      role: 'admin',
      registeredAt: '2023-01-10 09:00:00',
      lastLogin: '2023-02-28 08:35:42',
      isActive: true,
      orders: 0,
      totalSpent: 0
    },
    {
      id: 102,
      name: '张三',
      email: 'zhangsan@example.com',
      role: 'user',
      registeredAt: '2023-01-15 14:22:31',
      lastLogin: '2023-02-25 10:15:22',
      isActive: true,
      orders: 1,
      totalSpent: 12800
    },
    {
      id: 103,
      name: '李四',
      email: 'lisi@example.com',
      role: 'user',
      registeredAt: '2023-01-18 09:45:12',
      lastLogin: '2023-02-24 16:30:45',
      isActive: true,
      orders: 1,
      totalSpent: 9600
    },
    {
      id: 104,
      name: '王五',
      email: 'wangwu@example.com',
      role: 'user',
      registeredAt: '2023-01-20 11:32:54',
      lastLogin: '2023-02-23 14:22:18',
      isActive: true,
      orders: 1,
      totalSpent: 25000
    },
    {
      id: 105,
      name: '赵六',
      email: 'zhaoliu@example.com',
      role: 'user',
      registeredAt: '2023-01-22 15:18:36',
      lastLogin: '2023-02-22 17:45:30',
      isActive: true,
      orders: 1,
      totalSpent: 18500
    },
    {
      id: 106,
      name: '钱七',
      email: 'qianqi@example.com',
      role: 'user',
      registeredAt: '2023-02-10 10:05:19',
      lastLogin: '2023-02-21 13:20:11',
      isActive: true,
      orders: 1,
      totalSpent: 35000
    },
    {
      id: 107,
      name: '孙八',
      email: 'sunba@example.com',
      role: 'user',
      registeredAt: '2023-02-15 14:40:27',
      lastLogin: '2023-02-15 14:42:33',
      isActive: false,
      orders: 0,
      totalSpent: 0
    }
  ];
  
  useEffect(() => {
    const fetchUsers = async () => {
      setIsLoading(true);
      try {
        // In a real application, fetch users from API
        // const response = await fetch('/api/v1/users');
        // const data = await response.json();
        // setUsers(data);
        
        // Using mock data for demonstration
        setTimeout(() => {
          setUsers(mockUsers);
          setIsLoading(false);
        }, 500);
      } catch (error) {
        console.error('Error fetching users:', error);
        toast.error('获取用户列表失败');
        setIsLoading(false);
      }
    };
    
    fetchUsers();
  }, []);
  
  const handleInputChange = (e) => {
    const { name, value, type, checked } = e.target;
    setFormData({
      ...formData,
      [name]: type === 'checkbox' ? checked : value
    });
  };
  
  const handleAddNew = () => {
    setCurrentUser(null);
    setFormData({
      name: '',
      email: '',
      role: 'user',
      isActive: true
    });
    setIsModalOpen(true);
  };
  
  const handleEdit = (user) => {
    setCurrentUser(user);
    setFormData({
      name: user.name,
      email: user.email,
      role: user.role,
      isActive: user.isActive
    });
    setIsModalOpen(true);
  };
  
  const toggleUserStatus = async (userId, currentStatus) => {
    try {
      // In a real application, update via API
      // await fetch(`/api/v1/users/${userId}/status`, {
      //   method: 'PUT',
      //   headers: {
      //     'Content-Type': 'application/json',
      //   },
      //   body: JSON.stringify({ isActive: !currentStatus }),
      // });
      
      // Update local state
      setUsers(users.map(user => 
        user.id === userId 
          ? { ...user, isActive: !currentStatus } 
          : user
      ));
      
      toast.success(`用户状态已${!currentStatus ? '激活' : '停用'}`);
    } catch (error) {
      console.error('Error toggling user status:', error);
      toast.error('更新用户状态失败');
    }
  };
  
  const handleSubmit = async (e) => {
    e.preventDefault();
    
    try {
      // Validate form
      if (!formData.name || !formData.email || !formData.role) {
        toast.error('请填写必要的用户信息');
        return;
      }
      
      // Email validation
      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (!emailRegex.test(formData.email)) {
        toast.error('请输入有效的邮箱地址');
        return;
      }
      
      const userData = {
        ...formData
      };
      
      if (currentUser) {
        // Edit existing user
        // In a real application, update via API
        // await fetch(`/api/v1/users/${currentUser.id}`, {
        //   method: 'PUT',
        //   headers: {
        //     'Content-Type': 'application/json',
        //   },
        //   body: JSON.stringify(userData),
        // });
        
        // Update local state
        setUsers(users.map(user => 
          user.id === currentUser.id 
            ? { ...user, ...userData } 
            : user
        ));
        toast.success('用户信息更新成功');
      } else {
        // Add new user
        // In a real application, create via API
        // const response = await fetch('/api/v1/users', {
        //   method: 'POST',
        //   headers: {
        //     'Content-Type': 'application/json',
        //   },
        //   body: JSON.stringify(userData),
        // });
        // const newUser = await response.json();
        
        // Mock creating a new user with ID
        const newUser = {
          ...userData,
          id: Math.max(...users.map(u => u.id), 0) + 1,
          registeredAt: new Date().toISOString().slice(0, 19).replace('T', ' '),
          lastLogin: null,
          orders: 0,
          totalSpent: 0
        };
        
        setUsers([...users, newUser]);
        toast.success('用户添加成功');
      }
      
      setIsModalOpen(false);
    } catch (error) {
      console.error('Error saving user:', error);
      toast.error('保存用户失败');
    }
  };
  
  const filteredUsers = filterRole === 'all' 
    ? users 
    : users.filter(user => user.role === filterRole);
  
  const formatCurrency = (amount) => {
    return new Intl.NumberFormat('zh-CN', {
      style: 'currency',
      currency: 'CNY',
      minimumFractionDigits: 0
    }).format(amount);
  };
  
  return (
    <Layout>
      <div className="px-4 sm:px-6 lg:px-8 py-8">
        <div className="sm:flex sm:items-center sm:justify-between">
          <h1 className="text-2xl font-bold text-gray-900">用户管理</h1>
          <div className="mt-4 sm:mt-0">
            <button
              onClick={handleAddNew}
              className="inline-flex items-center justify-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
            >
              添加用户
            </button>
          </div>
        </div>
        
        <div className="mt-8">
          <div className="mb-6">
            <label htmlFor="role-filter" className="mr-2 font-medium text-gray-700">角色筛选：</label>
            <select
              id="role-filter"
              value={filterRole}
              onChange={(e) => setFilterRole(e.target.value)}
              className="shadow-sm focus:ring-blue-500 focus:border-blue-500 sm:text-sm border-gray-300 rounded-md"
            >
              <option value="all">所有角色</option>
              <option value="admin">管理员</option>
              <option value="user">普通用户</option>
            </select>
          </div>
          
          {isLoading ? (
            <div className="flex justify-center items-center h-64">
              <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
            </div>
          ) : (
            <div className="flex flex-col">
              <div className="-my-2 overflow-x-auto sm:-mx-6 lg:-mx-8">
                <div className="py-2 align-middle inline-block min-w-full sm:px-6 lg:px-8">
                  <div className="shadow overflow-hidden border-b border-gray-200 sm:rounded-lg">
                    <table className="min-w-full divide-y divide-gray-200">
                      <thead className="bg-gray-50">
                        <tr>
                          <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            用户
                          </th>
                          <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            角色
                          </th>
                          <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            注册日期
                          </th>
                          <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            订单/消费
                          </th>
                          <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            状态
                          </th>
                          <th scope="col" className="relative px-6 py-3">
                            <span className="sr-only">操作</span>
                          </th>
                        </tr>
                      </thead>
                      <tbody className="bg-white divide-y divide-gray-200">
                        {filteredUsers.map((user) => (
                          <tr key={user.id}>
                            <td className="px-6 py-4 whitespace-nowrap">
                              <div className="flex items-center">
                                <div className="flex-shrink-0 h-10 w-10">
                                  <div className="h-10 w-10 rounded-full bg-gray-200 flex items-center justify-center">
                                    <span className="text-gray-500 font-medium">
                                      {user.name.charAt(0).toUpperCase()}
                                    </span>
                                  </div>
                                </div>
                                <div className="ml-4">
                                  <div className="text-sm font-medium text-gray-900">{user.name}</div>
                                  <div className="text-sm text-gray-500">{user.email}</div>
                                </div>
                              </div>
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap">
                              <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${
                                user.role === 'admin' ? 'bg-purple-100 text-purple-800' : 'bg-blue-100 text-blue-800'
                              }`}>
                                {user.role === 'admin' ? '管理员' : '普通用户'}
                              </span>
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                              <div>{user.registeredAt.split(' ')[0]}</div>
                              <div className="text-xs text-gray-400">上次登录: {user.lastLogin ? user.lastLogin.split(' ')[0] : '从未登录'}</div>
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap">
                              <div className="text-sm text-gray-900">{user.orders} 笔订单</div>
                              <div className="text-sm text-gray-500">{formatCurrency(user.totalSpent)}</div>
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap">
                              <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${
                                user.isActive ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'
                              }`}>
                                {user.isActive ? '已启用' : '已停用'}
                              </span>
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                              <button 
                                onClick={() => handleEdit(user)}
                                className="text-indigo-600 hover:text-indigo-900 mr-4"
                              >
                                编辑
                              </button>
                              <button 
                                onClick={() => toggleUserStatus(user.id, user.isActive)}
                                className={user.isActive ? 'text-red-600 hover:text-red-900' : 'text-green-600 hover:text-green-900'}
                              >
                                {user.isActive ? '停用' : '启用'}
                              </button>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
      
      {/* Add/Edit User Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 overflow-y-auto z-50">
          <div className="flex items-end justify-center min-h-screen pt-4 px-4 pb-20 text-center sm:block sm:p-0">
            <div className="fixed inset-0 transition-opacity" aria-hidden="true">
              <div className="absolute inset-0 bg-gray-500 opacity-75"></div>
            </div>
            
            <span className="hidden sm:inline-block sm:align-middle sm:h-screen" aria-hidden="true">&#8203;</span>
            
            <div className="inline-block align-bottom bg-white rounded-lg text-left overflow-hidden shadow-xl transform transition-all sm:my-8 sm:align-middle sm:max-w-lg sm:w-full">
              <form onSubmit={handleSubmit}>
                <div className="bg-white px-4 pt-5 pb-4 sm:p-6 sm:pb-4">
                  <div className="sm:flex sm:items-start">
                    <div className="mt-3 text-center sm:mt-0 sm:ml-4 sm:text-left w-full">
                      <h3 className="text-lg leading-6 font-medium text-gray-900">
                        {currentUser ? '编辑用户' : '添加用户'}
                      </h3>
                      <div className="mt-6 grid grid-cols-1 gap-y-6 gap-x-4 sm:grid-cols-6">
                        <div className="sm:col-span-6">
                          <label htmlFor="name" className="block text-sm font-medium text-gray-700">
                            姓名
                          </label>
                          <div className="mt-1">
                            <input
                              type="text"
                              name="name"
                              id="name"
                              value={formData.name}
                              onChange={handleInputChange}
                              className="shadow-sm focus:ring-blue-500 focus:border-blue-500 block w-full sm:text-sm border-gray-300 rounded-md"
                              required
                            />
                          </div>
                        </div>
                        
                        <div className="sm:col-span-6">
                          <label htmlFor="email" className="block text-sm font-medium text-gray-700">
                            邮箱
                          </label>
                          <div className="mt-1">
                            <input
                              type="email"
                              name="email"
                              id="email"
                              value={formData.email}
                              onChange={handleInputChange}
                              className="shadow-sm focus:ring-blue-500 focus:border-blue-500 block w-full sm:text-sm border-gray-300 rounded-md"
                              required
                            />
                          </div>
                        </div>
                        
                        <div className="sm:col-span-3">
                          <label htmlFor="role" className="block text-sm font-medium text-gray-700">
                            角色
                          </label>
                          <div className="mt-1">
                            <select
                              id="role"
                              name="role"
                              value={formData.role}
                              onChange={handleInputChange}
                              className="shadow-sm focus:ring-blue-500 focus:border-blue-500 block w-full sm:text-sm border-gray-300 rounded-md"
                            >
                              <option value="user">普通用户</option>
                              <option value="admin">管理员</option>
                            </select>
                          </div>
                        </div>
                        
                        <div className="sm:col-span-3">
                          <div className="flex items-center h-full">
                            <div className="flex items-start mt-6">
                              <div className="flex items-center h-5">
                                <input
                                  id="isActive"
                                  name="isActive"
                                  type="checkbox"
                                  checked={formData.isActive}
                                  onChange={handleInputChange}
                                  className="focus:ring-blue-500 h-4 w-4 text-blue-600 border-gray-300 rounded"
                                />
                              </div>
                              <div className="ml-3 text-sm">
                                <label htmlFor="isActive" className="font-medium text-gray-700">启用用户</label>
                              </div>
                            </div>
                          </div>
                        </div>
                        
                        {!currentUser && (
                          <div className="sm:col-span-6 pt-4 border-t border-gray-200">
                            <p className="text-sm text-gray-500">
                              用户将会收到一封包含临时密码的邮件，首次登录后需要修改密码。
                            </p>
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                </div>
                <div className="bg-gray-50 px-4 py-3 sm:px-6 sm:flex sm:flex-row-reverse">
                  <button
                    type="submit"
                    className="w-full inline-flex justify-center rounded-md border border-transparent shadow-sm px-4 py-2 bg-blue-600 text-base font-medium text-white hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 sm:ml-3 sm:w-auto sm:text-sm"
                  >
                    保存
                  </button>
                  <button
                    type="button"
                    onClick={() => setIsModalOpen(false)}
                    className="mt-3 w-full inline-flex justify-center rounded-md border border-gray-300 shadow-sm px-4 py-2 bg-white text-base font-medium text-gray-700 hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 sm:mt-0 sm:ml-3 sm:w-auto sm:text-sm"
                  >
                    取消
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      )}
    </Layout>
  );
};

export default UserManagementPage;