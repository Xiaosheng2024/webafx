import React, { useState, useEffect } from 'react';
import { toast } from 'react-toastify';
import Layout from '../../components/admin/Layout';

const ProductManagementPage = () => {
  const [products, setProducts] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [currentProduct, setCurrentProduct] = useState(null);
  const [formData, setFormData] = useState({
    name: '',
    category: '',
    price: '',
    stock: '',
    description: '',
    imageUrl: '',
  });
  
  // Mock data for demonstration
  const mockProducts = [
    {
      id: 1,
      name: '高速扫描仪 A3000',
      category: '扫描设备',
      price: 12800,
      stock: 24,
      description: '高速双面扫描，每分钟可扫描60页，支持A3幅面',
      imageUrl: '/images/products/scanner-a3000.jpg',
    },
    {
      id: 2,
      name: '彩色激光打印机 X5100',
      category: '打印设备',
      price: 9600,
      stock: 18,
      description: '高品质彩色激光打印，每分钟30页，自动双面打印',
      imageUrl: '/images/products/printer-x5100.jpg',
    },
    {
      id: 3,
      name: '文档管理服务器 S2000',
      category: '软件服务器',
      price: 25000,
      stock: 5,
      description: '企业级文档管理解决方案，支持OCR识别和云存储',
      imageUrl: '/images/products/server-s2000.jpg',
    },
    {
      id: 4,
      name: '办公自动化套件',
      category: '集成打包方案',
      price: 35000,
      stock: 10,
      description: '包含扫描仪、打印机和文档管理软件的完整解决方案',
      imageUrl: '/images/products/office-suite.jpg',
    },
  ];
  
  useEffect(() => {
    const fetchProducts = async () => {
      setIsLoading(true);
      try {
        // In a real application, fetch products from API
        // const response = await fetch('/api/v1/products');
        // const data = await response.json();
        // setProducts(data);
        
        // Using mock data for demonstration
        setTimeout(() => {
          setProducts(mockProducts);
          setIsLoading(false);
        }, 500);
      } catch (error) {
        console.error('Error fetching products:', error);
        toast.error('获取产品列表失败');
        setIsLoading(false);
      }
    };
    
    fetchProducts();
  }, []);
  
  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value,
    });
  };
  
  const handleAddNew = () => {
    setCurrentProduct(null);
    setFormData({
      name: '',
      category: '',
      price: '',
      stock: '',
      description: '',
      imageUrl: '',
    });
    setIsModalOpen(true);
  };
  
  const handleEdit = (product) => {
    setCurrentProduct(product);
    setFormData({
      name: product.name,
      category: product.category,
      price: product.price,
      stock: product.stock,
      description: product.description,
      imageUrl: product.imageUrl,
    });
    setIsModalOpen(true);
  };
  
  const handleDelete = async (id) => {
    if (!window.confirm('确定要删除这个产品吗？')) return;
    
    try {
      // In a real application, delete product via API
      // await fetch(`/api/v1/products/${id}`, {
      //   method: 'DELETE',
      // });
      
      // Update UI optimistically
      setProducts(products.filter(product => product.id !== id));
      toast.success('产品删除成功');
    } catch (error) {
      console.error('Error deleting product:', error);
      toast.error('删除产品失败');
    }
  };
  
  const handleSubmit = async (e) => {
    e.preventDefault();
    
    try {
      // Validate form
      if (!formData.name || !formData.category || !formData.price) {
        toast.error('请填写必要的产品信息');
        return;
      }
      
      const productData = {
        ...formData,
        price: parseFloat(formData.price),
        stock: parseInt(formData.stock, 10),
      };
      
      if (currentProduct) {
        // Edit existing product
        // In a real application, update via API
        // await fetch(`/api/v1/products/${currentProduct.id}`, {
        //   method: 'PUT',
        //   headers: {
        //     'Content-Type': 'application/json',
        //   },
        //   body: JSON.stringify(productData),
        // });
        
        // Update local state
        setProducts(products.map(product => 
          product.id === currentProduct.id 
            ? { ...product, ...productData } 
            : product
        ));
        toast.success('产品更新成功');
      } else {
        // Add new product
        // In a real application, create via API
        // const response = await fetch('/api/v1/products', {
        //   method: 'POST',
        //   headers: {
        //     'Content-Type': 'application/json',
        //   },
        //   body: JSON.stringify(productData),
        // });
        // const newProduct = await response.json();
        
        // Mock creating a new product with ID
        const newProduct = {
          ...productData,
          id: Math.max(...products.map(p => p.id), 0) + 1,
        };
        
        setProducts([...products, newProduct]);
        toast.success('产品添加成功');
      }
      
      setIsModalOpen(false);
    } catch (error) {
      console.error('Error saving product:', error);
      toast.error('保存产品失败');
    }
  };
  
  const categories = ['扫描设备', '打印设备', '软件服务器', '集成打包方案'];
  
  return (
    <Layout>
      <div className="px-4 sm:px-6 lg:px-8 py-8">
        <div className="sm:flex sm:items-center sm:justify-between">
          <h1 className="text-2xl font-bold text-gray-900">产品管理</h1>
          <div className="mt-4 sm:mt-0">
            <button
              onClick={handleAddNew}
              className="inline-flex items-center justify-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
            >
              添加产品
            </button>
          </div>
        </div>
        
        <div className="mt-8">
          {isLoading ? (
            <div className="flex justify-center items-center h-64">
              <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
            </div>
          ) : (
            <div className="flex flex-col">
              <div className="-my-2 overflow-x-auto sm:-mx-6 lg:-mx-8">
                <div className="py-2 align-middle inline-block min-w-full sm:px-6 lg:px-8">
                  <div className="shadow overflow-hidden border-b border-gray-200 sm:rounded-lg">
                    <table className="min-w-full divide-y divide-gray-200">
                      <thead className="bg-gray-50">
                        <tr>
                          <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            产品
                          </th>
                          <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            类别
                          </th>
                          <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            价格
                          </th>
                          <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            库存
                          </th>
                          <th scope="col" className="relative px-6 py-3">
                            <span className="sr-only">编辑</span>
                          </th>
                        </tr>
                      </thead>
                      <tbody className="bg-white divide-y divide-gray-200">
                        {products.map((product) => (
                          <tr key={product.id}>
                            <td className="px-6 py-4 whitespace-nowrap">
                              <div className="flex items-center">
                                <div className="flex-shrink-0 h-10 w-10">
                                  <img className="h-10 w-10 rounded-md object-cover" src={product.imageUrl || '/placeholder.png'} alt={product.name} />
                                </div>
                                <div className="ml-4">
                                  <div className="text-sm font-medium text-gray-900">{product.name}</div>
                                </div>
                              </div>
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap">
                              <span className="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-blue-100 text-blue-800">
                                {product.category}
                              </span>
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap">
                              <div className="text-sm text-gray-900">¥{product.price.toLocaleString()}</div>
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap">
                              <div className="text-sm text-gray-900">{product.stock}</div>
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                              <button 
                                onClick={() => handleEdit(product)}
                                className="text-indigo-600 hover:text-indigo-900 mr-4"
                              >
                                编辑
                              </button>
                              <button 
                                onClick={() => handleDelete(product.id)}
                                className="text-red-600 hover:text-red-900"
                              >
                                删除
                              </button>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
      
      {/* Add/Edit Product Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 overflow-y-auto z-50">
          <div className="flex items-end justify-center min-h-screen pt-4 px-4 pb-20 text-center sm:block sm:p-0">
            <div className="fixed inset-0 transition-opacity" aria-hidden="true">
              <div className="absolute inset-0 bg-gray-500 opacity-75"></div>
            </div>
            
            <span className="hidden sm:inline-block sm:align-middle sm:h-screen" aria-hidden="true">&#8203;</span>
            
            <div className="inline-block align-bottom bg-white rounded-lg text-left overflow-hidden shadow-xl transform transition-all sm:my-8 sm:align-middle sm:max-w-lg sm:w-full">
              <form onSubmit={handleSubmit}>
                <div className="bg-white px-4 pt-5 pb-4 sm:p-6 sm:pb-4">
                  <div className="sm:flex sm:items-start">
                    <div className="mt-3 text-center sm:mt-0 sm:ml-4 sm:text-left w-full">
                      <h3 className="text-lg leading-6 font-medium text-gray-900">
                        {currentProduct ? '编辑产品' : '添加产品'}
                      </h3>
                      <div className="mt-6 grid grid-cols-1 gap-y-6 gap-x-4 sm:grid-cols-6">
                        <div className="sm:col-span-6">
                          <label htmlFor="name" className="block text-sm font-medium text-gray-700">
                            产品名称
                          </label>
                          <div className="mt-1">
                            <input
                              type="text"
                              name="name"
                              id="name"
                              value={formData.name}
                              onChange={handleInputChange}
                              className="shadow-sm focus:ring-blue-500 focus:border-blue-500 block w-full sm:text-sm border-gray-300 rounded-md"
                              required
                            />
                          </div>
                        </div>
                        
                        <div className="sm:col-span-3">
                          <label htmlFor="category" className="block text-sm font-medium text-gray-700">
                            类别
                          </label>
                          <div className="mt-1">
                            <select
                              id="category"
                              name="category"
                              value={formData.category}
                              onChange={handleInputChange}
                              className="shadow-sm focus:ring-blue-500 focus:border-blue-500 block w-full sm:text-sm border-gray-300 rounded-md"
                              required
                            >
                              <option value="">选择类别</option>
                              {categories.map(category => (
                                <option key={category} value={category}>
                                  {category}
                                </option>
                              ))}
                            </select>
                          </div>
                        </div>
                        
                        <div className="sm:col-span-3">
                          <label htmlFor="price" className="block text-sm font-medium text-gray-700">
                            价格 (¥)
                          </label>
                          <div className="mt-1">
                            <input
                              type="number"
                              name="price"
                              id="price"
                              min="0"
                              step="0.01"
                              value={formData.price}
                              onChange={handleInputChange}
                              className="shadow-sm focus:ring-blue-500 focus:border-blue-500 block w-full sm:text-sm border-gray-300 rounded-md"
                              required
                            />
                          </div>
                        </div>
                        
                        <div className="sm:col-span-3">
                          <label htmlFor="stock" className="block text-sm font-medium text-gray-700">
                            库存
                          </label>
                          <div className="mt-1">
                            <input
                              type="number"
                              name="stock"
                              id="stock"
                              min="0"
                              value={formData.stock}
                              onChange={handleInputChange}
                              className="shadow-sm focus:ring-blue-500 focus:border-blue-500 block w-full sm:text-sm border-gray-300 rounded-md"
                              required
                            />
                          </div>
                        </div>
                        
                        <div className="sm:col-span-3">
                          <label htmlFor="imageUrl" className="block text-sm font-medium text-gray-700">
                            图片URL
                          </label>
                          <div className="mt-1">
                            <input
                              type="text"
                              name="imageUrl"
                              id="imageUrl"
                              value={formData.imageUrl}
                              onChange={handleInputChange}
                              className="shadow-sm focus:ring-blue-500 focus:border-blue-500 block w-full sm:text-sm border-gray-300 rounded-md"
                            />
                          </div>
                        </div>
                        
                        <div className="sm:col-span-6">
                          <label htmlFor="description" className="block text-sm font-medium text-gray-700">
                            产品描述
                          </label>
                          <div className="mt-1">
                            <textarea
                              id="description"
                              name="description"
                              rows={3}
                              value={formData.description}
                              onChange={handleInputChange}
                              className="shadow-sm focus:ring-blue-500 focus:border-blue-500 block w-full sm:text-sm border-gray-300 rounded-md"
                            />
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div className="bg-gray-50 px-4 py-3 sm:px-6 sm:flex sm:flex-row-reverse">
                  <button
                    type="submit"
                    className="w-full inline-flex justify-center rounded-md border border-transparent shadow-sm px-4 py-2 bg-blue-600 text-base font-medium text-white hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 sm:ml-3 sm:w-auto sm:text-sm"
                  >
                    保存
                  </button>
                  <button
                    type="button"
                    onClick={() => setIsModalOpen(false)}
                    className="mt-3 w-full inline-flex justify-center rounded-md border border-gray-300 shadow-sm px-4 py-2 bg-white text-base font-medium text-gray-700 hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 sm:mt-0 sm:ml-3 sm:w-auto sm:text-sm"
                  >
                    取消
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      )}
    </Layout>
  );
};

export default ProductManagementPage;