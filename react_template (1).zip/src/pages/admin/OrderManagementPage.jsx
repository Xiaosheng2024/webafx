import React, { useState, useEffect } from 'react';
import { toast } from 'react-toastify';
import Layout from '../../components/admin/Layout';

const OrderManagementPage = () => {
  const [orders, setOrders] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [currentOrder, setCurrentOrder] = useState(null);
  const [isDetailsModalOpen, setIsDetailsModalOpen] = useState(false);
  const [statusFilter, setStatusFilter] = useState('all');
  
  // Mock data for demonstration
  const mockOrders = [
    {
      id: 1001,
      customer: {
        id: 102,
        name: '张三',
        email: 'zhangsan@example.com',
        phone: '138****1234',
      },
      products: [
        { id: 1, name: '高速扫描仪 A3000', quantity: 1, price: 12800 },
      ],
      totalAmount: 12800,
      status: '已完成',
      paymentMethod: '微信支付',
      shippingAddress: '北京市海淀区中关村南大街5号',
      createdAt: '2023-02-25 09:35:21',
      updatedAt: '2023-02-26 14:22:10',
      notes: '',
    },
    {
      id: 1002,
      customer: {
        id: 103,
        name: '李四',
        email: 'lisi@example.com',
        phone: '139****5678',
      },
      products: [
        { id: 2, name: '彩色激光打印机 X5100', quantity: 1, price: 9600 },
      ],
      totalAmount: 9600,
      status: '处理中',
      paymentMethod: '支付宝',
      shippingAddress: '上海市徐汇区漕河泾开发区',
      createdAt: '2023-02-24 15:12:33',
      updatedAt: '2023-02-24 15:12:33',
      notes: '客户要求周末送货',
    },
    {
      id: 1003,
      customer: {
        id: 104,
        name: '王五',
        email: 'wangwu@example.com',
        phone: '137****9012',
      },
      products: [
        { id: 3, name: '文档管理服务器 S2000', quantity: 1, price: 25000 },
      ],
      totalAmount: 25000,
      status: '已完成',
      paymentMethod: '银行转账',
      shippingAddress: '广州市天河区珠江新城',
      createdAt: '2023-02-23 10:45:19',
      updatedAt: '2023-02-25 09:30:00',
      notes: '',
    },
    {
      id: 1004,
      customer: {
        id: 105,
        name: '赵六',
        email: 'zhaoliu@example.com',
        phone: '136****3456',
      },
      products: [
        { id: 4, name: '扫描仪 A4500', quantity: 1, price: 15000 },
        { id: 5, name: '软件许可证', quantity: 1, price: 3500 },
      ],
      totalAmount: 18500,
      status: '已发货',
      paymentMethod: '微信支付',
      shippingAddress: '深圳市南山区科技园',
      createdAt: '2023-02-22 14:28:45',
      updatedAt: '2023-02-23 11:15:32',
      notes: '需要提供安装服务',
    },
    {
      id: 1005,
      customer: {
        id: 106,
        name: '钱七',
        email: 'qianqi@example.com',
        phone: '135****7890',
      },
      products: [
        { id: 6, name: '办公自动化套件', quantity: 1, price: 35000 },
      ],
      totalAmount: 35000,
      status: '待付款',
      paymentMethod: '待支付',
      shippingAddress: '成都市高新区天府大道',
      createdAt: '2023-02-21 09:10:05',
      updatedAt: '2023-02-21 09:10:05',
      notes: '大客户优先处理',
    },
  ];
  
  useEffect(() => {
    const fetchOrders = async () => {
      setIsLoading(true);
      try {
        // In a real application, fetch orders from API
        // const response = await fetch('/api/v1/orders');
        // const data = await response.json();
        // setOrders(data);
        
        // Using mock data for demonstration
        setTimeout(() => {
          setOrders(mockOrders);
          setIsLoading(false);
        }, 500);
      } catch (error) {
        console.error('Error fetching orders:', error);
        toast.error('获取订单列表失败');
        setIsLoading(false);
      }
    };
    
    fetchOrders();
  }, []);
  
  const handleViewDetails = (order) => {
    setCurrentOrder(order);
    setIsDetailsModalOpen(true);
  };
  
  const handleUpdateStatus = async (orderId, newStatus) => {
    try {
      // In a real application, update via API
      // await fetch(`/api/v1/orders/${orderId}/status`, {
      //   method: 'PUT',
      //   headers: {
      //     'Content-Type': 'application/json',
      //   },
      //   body: JSON.stringify({ status: newStatus }),
      // });
      
      // Update local state
      setOrders(orders.map(order => 
        order.id === orderId 
          ? { ...order, status: newStatus, updatedAt: new Date().toISOString().slice(0, 19).replace('T', ' ') } 
          : order
      ));
      
      toast.success(`订单 #${orderId} 状态已更新为 "${newStatus}"`);
      
      // If the order details modal is open for this order, update it too
      if (currentOrder && currentOrder.id === orderId) {
        setCurrentOrder({
          ...currentOrder,
          status: newStatus,
          updatedAt: new Date().toISOString().slice(0, 19).replace('T', ' ')
        });
      }
    } catch (error) {
      console.error('Error updating order status:', error);
      toast.error('更新订单状态失败');
    }
  };
  
  const filteredOrders = statusFilter === 'all' 
    ? orders 
    : orders.filter(order => order.status === statusFilter);
  
  const statusOptions = [
    { value: 'all', label: '所有状态' },
    { value: '待付款', label: '待付款' },
    { value: '处理中', label: '处理中' },
    { value: '已发货', label: '已发货' },
    { value: '已完成', label: '已完成' },
    { value: '已取消', label: '已取消' }
  ];
  
  const statusChangeOptions = ['待付款', '处理中', '已发货', '已完成', '已取消'];
  
  const getStatusClass = (status) => {
    switch (status) {
      case '已完成':
        return 'bg-green-100 text-green-800';
      case '处理中':
        return 'bg-blue-100 text-blue-800';
      case '已发货':
        return 'bg-purple-100 text-purple-800';
      case '待付款':
        return 'bg-yellow-100 text-yellow-800';
      case '已取消':
        return 'bg-red-100 text-red-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };
  
  const formatCurrency = (amount) => {
    return new Intl.NumberFormat('zh-CN', {
      style: 'currency',
      currency: 'CNY',
      minimumFractionDigits: 0
    }).format(amount);
  };
  
  return (
    <Layout>
      <div className="px-4 sm:px-6 lg:px-8 py-8">
        <h1 className="text-2xl font-bold text-gray-900 mb-6">订单管理</h1>
        
        <div className="mb-6">
          <label htmlFor="status-filter" className="mr-2 font-medium text-gray-700">状态筛选：</label>
          <select
            id="status-filter"
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="shadow-sm focus:ring-blue-500 focus:border-blue-500 sm:text-sm border-gray-300 rounded-md"
          >
            {statusOptions.map((option) => (
              <option key={option.value} value={option.value}>
                {option.label}
              </option>
            ))}
          </select>
        </div>
        
        {isLoading ? (
          <div className="flex justify-center items-center h-64">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
          </div>
        ) : (
          <div className="flex flex-col">
            <div className="-my-2 overflow-x-auto sm:-mx-6 lg:-mx-8">
              <div className="py-2 align-middle inline-block min-w-full sm:px-6 lg:px-8">
                <div className="shadow overflow-hidden border-b border-gray-200 sm:rounded-lg">
                  <table className="min-w-full divide-y divide-gray-200">
                    <thead className="bg-gray-50">
                      <tr>
                        <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          订单ID
                        </th>
                        <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          客户
                        </th>
                        <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          金额
                        </th>
                        <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          状态
                        </th>
                        <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          日期
                        </th>
                        <th scope="col" className="relative px-6 py-3">
                          <span className="sr-only">操作</span>
                        </th>
                      </tr>
                    </thead>
                    <tbody className="bg-white divide-y divide-gray-200">
                      {filteredOrders.length > 0 ? (
                        filteredOrders.map((order) => (
                          <tr key={order.id}>
                            <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                              #{order.id}
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap">
                              <div className="text-sm font-medium text-gray-900">{order.customer.name}</div>
                              <div className="text-sm text-gray-500">{order.customer.email}</div>
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                              {formatCurrency(order.totalAmount)}
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap">
                              <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${getStatusClass(order.status)}`}>
                                {order.status}
                              </span>
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                              {order.createdAt.split(' ')[0]}
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                              <button
                                onClick={() => handleViewDetails(order)}
                                className="text-indigo-600 hover:text-indigo-900"
                              >
                                查看详情
                              </button>
                              <select
                                className="ml-2 text-sm border-gray-300 rounded-md"
                                value=""
                                onChange={(e) => {
                                  if (e.target.value) {
                                    handleUpdateStatus(order.id, e.target.value);
                                    e.target.value = "";
                                  }
                                }}
                              >
                                <option value="">更改状态</option>
                                {statusChangeOptions.map((status) => (
                                  <option key={status} value={status} disabled={order.status === status}>
                                    {status}
                                  </option>
                                ))}
                              </select>
                            </td>
                          </tr>
                        ))
                      ) : (
                        <tr>
                          <td colSpan="6" className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 text-center">
                            没有找到订单
                          </td>
                        </tr>
                      )}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
      
      {/* Order Details Modal */}
      {isDetailsModalOpen && currentOrder && (
        <div className="fixed inset-0 overflow-y-auto z-50">
          <div className="flex items-end justify-center min-h-screen pt-4 px-4 pb-20 text-center sm:block sm:p-0">
            <div className="fixed inset-0 transition-opacity" aria-hidden="true">
              <div className="absolute inset-0 bg-gray-500 opacity-75"></div>
            </div>
            
            <span className="hidden sm:inline-block sm:align-middle sm:h-screen" aria-hidden="true">&#8203;</span>
            
            <div className="inline-block align-bottom bg-white rounded-lg text-left overflow-hidden shadow-xl transform transition-all sm:my-8 sm:align-middle sm:max-w-lg sm:w-full">
              <div className="bg-white px-4 pt-5 pb-4 sm:p-6 sm:pb-4">
                <div className="sm:flex sm:items-start">
                  <div className="mt-3 text-center sm:mt-0 sm:ml-4 sm:text-left w-full">
                    <h3 className="text-lg leading-6 font-medium text-gray-900 mb-4">
                      订单 #{currentOrder.id} 详情
                    </h3>
                    
                    <div className="border-t border-gray-200 py-3">
                      <h4 className="font-medium text-gray-900">客户信息</h4>
                      <p className="mt-1 text-sm text-gray-500">姓名: {currentOrder.customer.name}</p>
                      <p className="mt-1 text-sm text-gray-500">邮箱: {currentOrder.customer.email}</p>
                      <p className="mt-1 text-sm text-gray-500">电话: {currentOrder.customer.phone}</p>
                      <p className="mt-1 text-sm text-gray-500">地址: {currentOrder.shippingAddress}</p>
                    </div>
                    
                    <div className="border-t border-gray-200 py-3">
                      <h4 className="font-medium text-gray-900">订单信息</h4>
                      <p className="mt-1 text-sm text-gray-500">创建时间: {currentOrder.createdAt}</p>
                      <p className="mt-1 text-sm text-gray-500">最后更新: {currentOrder.updatedAt}</p>
                      <p className="mt-1 text-sm text-gray-500">支付方式: {currentOrder.paymentMethod}</p>
                      <p className="mt-2 text-sm text-gray-500">
                        状态: 
                        <span className={`inline-flex items-center ml-2 px-2.5 py-0.5 rounded-full text-xs font-medium ${getStatusClass(currentOrder.status)}`}>
                          {currentOrder.status}
                        </span>
                      </p>
                      {currentOrder.notes && (
                        <p className="mt-2 text-sm text-gray-500">备注: {currentOrder.notes}</p>
                      )}
                    </div>
                    
                    <div className="border-t border-gray-200 py-3">
                      <h4 className="font-medium text-gray-900">产品详情</h4>
                      {currentOrder.products.map((product) => (
                        <div key={product.id} className="flex justify-between items-center mt-2">
                          <div className="text-sm text-gray-900">
                            {product.name} × {product.quantity}
                          </div>
                          <div className="text-sm font-medium text-gray-900">
                            {formatCurrency(product.price * product.quantity)}
                          </div>
                        </div>
                      ))}
                      <div className="flex justify-between items-center mt-4 pt-4 border-t border-gray-200">
                        <div className="text-base font-medium text-gray-900">总计</div>
                        <div className="text-base font-medium text-gray-900">
                          {formatCurrency(currentOrder.totalAmount)}
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div className="bg-gray-50 px-4 py-3 sm:px-6 sm:flex sm:flex-row-reverse">
                <button
                  type="button"
                  className="mt-3 w-full inline-flex justify-center rounded-md border border-gray-300 shadow-sm px-4 py-2 bg-white text-base font-medium text-gray-700 hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 sm:mt-0 sm:ml-3 sm:w-auto sm:text-sm"
                  onClick={() => setIsDetailsModalOpen(false)}
                >
                  关闭
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </Layout>
  );
};

export default OrderManagementPage;