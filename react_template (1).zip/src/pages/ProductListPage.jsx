import React, { useState, useEffect } from 'react';
import { useParams, Link, useLocation, useNavigate } from 'react-router-dom';
import { useAppContext } from '../context/AppContext';

// Dummy product data - in a real application, this would come from an API
const allProducts = [
  // Scanning Equipment
  {
    id: 1,
    name: 'X9000高速扫描仪',
    category: 'scanning',
    categoryName: '扫描设备',
    image: '/images/product1.jpg',
    description: '企业级高速文档扫描仪，每分钟可扫描200页，双面扫描，自动进纸器可容纳500张纸',
    price: '¥29,999',
    tags: ['高速', '双面扫描', '大容量']
  },
  {
    id: 2,
    name: 'S5000桌面型扫描仪',
    category: 'scanning',
    categoryName: '扫描设备',
    image: '/images/product2.jpg',
    description: '紧凑型桌面扫描仪，每分钟可扫描60页，适合小型办公室或个人工作站使用',
    price: '¥5,999',
    tags: ['桌面型', '小型', '便携']
  },
  {
    id: 3,
    name: 'M3000移动扫描仪',
    category: 'scanning',
    categoryName: '扫描设备',
    image: '/images/product3.jpg',
    description: '便携式移动扫描仪，无需电源，USB供电，重量仅500g，随时随地扫描文档',
    price: '¥1,999',
    tags: ['便携', '移动', 'USB供电']
  },
  {
    id: 4,
    name: 'F2000平板扫描仪',
    category: 'scanning',
    categoryName: '扫描设备',
    image: '/images/product4.jpg',
    description: '专业平板扫描仪，支持A3幅面，适合图纸、书籍等大尺寸文档的扫描',
    price: '¥8,999',
    tags: ['平板', 'A3', '大幅面']
  },
  // Printing Equipment
  {
    id: 5,
    name: 'P5000彩色激光打印机',
    category: 'printing',
    categoryName: '打印设备',
    image: '/images/product5.jpg',
    description: '高品质商用彩色激光打印机，支持双面打印，每分钟可打印35页彩色文档',
    price: '¥12,999',
    tags: ['彩色', '激光', '双面打印']
  },
  {
    id: 6,
    name: 'P3000黑白激光打印机',
    category: 'printing',
    categoryName: '打印设备',
    image: '/images/product6.jpg',
    description: '经济实惠的黑白激光打印机，适合日常办公文档打印，每分钟可打印40页',
    price: '¥3,999',
    tags: ['黑白', '激光', '高速']
  },
  {
    id: 7,
    name: 'L8000标签打印机',
    category: 'printing',
    categoryName: '打印设备',
    image: '/images/product7.jpg',
    description: '专业标签打印机，支持多种材质标签，精准定位，适合仓储、物流等行业使用',
    price: '¥6,999',
    tags: ['标签', '高精度', '工业级']
  },
  {
    id: 8,
    name: 'T6000图形绘图仪',
    category: 'printing',
    categoryName: '打印设备',
    image: '/images/product8.jpg',
    description: '大幅面绘图仪，最大支持A0幅面，适合CAD图纸、海报等专业打印需求',
    price: '¥39,999',
    tags: ['绘图仪', '大幅面', '高精度']
  },
  // Software Servers
  {
    id: 9,
    name: '文档管理系统专业版',
    category: 'software',
    categoryName: '软件服务器',
    image: '/images/product9.jpg',
    description: '企业文档全生命周期管理系统，支持云存储，多用户协同编辑，版本控制等功能',
    price: '¥49,999/年',
    tags: ['文档管理', '协同办公', '云存储']
  },
  {
    id: 10,
    name: '智能OCR识别系统',
    category: 'software',
    categoryName: '软件服务器',
    image: '/images/product10.jpg',
    description: '基于AI技术的光学字符识别系统，支持多语言识别，表格识别，版面分析等功能',
    price: '¥29,999/年',
    tags: ['OCR', 'AI识别', '多语言']
  },
  {
    id: 11,
    name: '打印管理服务器',
    category: 'software',
    categoryName: '软件服务器',
    image: '/images/product11.jpg',
    description: '企业级打印管理服务器，集中管理所有打印设备，支持权限控制，统计分析等功能',
    price: '¥19,999/年',
    tags: ['打印管理', '权限控制', '统计分析']
  },
  {
    id: 12,
    name: '文档安全加密系统',
    category: 'software',
    categoryName: '软件服务器',
    image: '/images/product12.jpg',
    description: '企业级文档安全解决方案，支持文档加密，水印，权限控制，操作审计等功能',
    price: '¥35,999/年',
    tags: ['安全加密', '文档保护', '操作审计']
  },
  // Solutions
  {
    id: 13,
    name: '医疗行业扫描存储方案',
    category: 'solutions',
    categoryName: '解决方案',
    image: '/images/product13.jpg',
    description: '专为医疗行业设计的病历扫描及电子化存储方案，符合医疗数据安全规范',
    price: '定制报价',
    tags: ['医疗', '电子病历', '数据安全']
  },
  {
    id: 14,
    name: '金融行业文档管理方案',
    category: 'solutions',
    categoryName: '解决方案',
    image: '/images/product14.jpg',
    description: '面向银行、保险等金融机构的文档扫描、存储、检索一体化方案',
    price: '定制报价',
    tags: ['金融', '合规存储', '快速检索']
  },
  {
    id: 15,
    name: '政府档案数字化方案',
    category: 'solutions',
    categoryName: '解决方案',
    image: '/images/product15.jpg',
    description: '针对政府部门档案数字化需求，提供全流程电子化转型解决方案',
    price: '定制报价',
    tags: ['政府', '档案数字化', '长期保存']
  },
  {
    id: 16,
    name: '教育机构信息化方案',
    category: 'solutions',
    categoryName: '解决方案',
    image: '/images/product16.jpg',
    description: '为学校、培训机构提供教材、试卷、学生档案等文档的数字化管理方案',
    price: '定制报价',
    tags: ['教育', '资源共享', '数字化校园']
  }
];

// Product tags for filtering
const allTags = [
  '高速', '双面扫描', '大容量', '桌面型', '小型', '便携', '移动', 'USB供电', '平板',
  'A3', '大幅面', '彩色', '激光', '高速', '黑白', '标签', '高精度', '工业级', '绘图仪',
  '文档管理', '协同办公', '云存储', 'OCR', 'AI识别', '多语言', '打印管理', '权限控制',
  '统计分析', '安全加密', '文档保护', '操作审计', '医疗', '电子病历', '数据安全',
  '金融', '合规存储', '快速检索', '政府', '档案数字化', '长期保存', '教育', '资源共享', '数字化校园'
];

// Categories
const categories = [
  { id: 'scanning', name: '扫描设备' },
  { id: 'printing', name: '打印设备' },
  { id: 'software', name: '软件服务器' },
  { id: 'solutions', name: '解决方案' }
];

const ProductListPage = () => {
  const { categoryId } = useParams();
  const location = useLocation();
  const navigate = useNavigate();
  const queryParams = new URLSearchParams(location.search);
  const { state } = useAppContext();
  
  // State variables
  const [products, setProducts] = useState([]);
  const [selectedCategory, setSelectedCategory] = useState(categoryId || 'all');
  const [selectedTags, setSelectedTags] = useState([]);
  const [searchQuery, setSearchQuery] = useState(queryParams.get('query') || '');
  const [currentPage, setCurrentPage] = useState(1);
  const [productsPerPage] = useState(8);
  const [isMobileFilterOpen, setIsMobileFilterOpen] = useState(false);
  
  // Filter products based on selections
  useEffect(() => {
    let filteredProducts = [...allProducts];
    
    // Filter by category
    if (selectedCategory !== 'all') {
      filteredProducts = filteredProducts.filter(product => product.category === selectedCategory);
    }
    
    // Filter by tags
    if (selectedTags.length > 0) {
      filteredProducts = filteredProducts.filter(product => 
        selectedTags.some(tag => product.tags.includes(tag))
      );
    }
    
    // Filter by search query
    if (searchQuery) {
      const query = searchQuery.toLowerCase();
      filteredProducts = filteredProducts.filter(product => 
        product.name.toLowerCase().includes(query) || 
        product.description.toLowerCase().includes(query) ||
        product.tags.some(tag => tag.toLowerCase().includes(query))
      );
    }
    
    setProducts(filteredProducts);
    setCurrentPage(1);
    
    // Update URL with filters
    const params = new URLSearchParams();
    if (selectedCategory !== 'all') params.set('category', selectedCategory);
    if (selectedTags.length > 0) params.set('tags', selectedTags.join(','));
    if (searchQuery) params.set('query', searchQuery);
    
    const newUrl = `${location.pathname}${params.toString() ? `?${params.toString()}` : ''}`;
    navigate(newUrl, { replace: true });
    
  }, [selectedCategory, selectedTags, searchQuery, navigate, location.pathname]);
  
  // Update selected category when URL param changes
  useEffect(() => {
    if (categoryId) {
      setSelectedCategory(categoryId);
    } else {
      setSelectedCategory('all');
    }
  }, [categoryId]);
  
  // Handle category selection
  const handleCategoryChange = (category) => {
    setSelectedCategory(category);
    if (category === 'all') {
      navigate('/products');
    } else {
      navigate(`/products/category/${category}`);
    }
  };
  
  // Handle tag selection
  const handleTagToggle = (tag) => {
    setSelectedTags(prevTags => 
      prevTags.includes(tag)
        ? prevTags.filter(t => t !== tag)
        : [...prevTags, tag]
    );
  };
  
  // Handle search input
  const handleSearchChange = (e) => {
    setSearchQuery(e.target.value);
  };
  
  // Pagination logic
  const indexOfLastProduct = currentPage * productsPerPage;
  const indexOfFirstProduct = indexOfLastProduct - productsPerPage;
  const currentProducts = products.slice(indexOfFirstProduct, indexOfLastProduct);
  const totalPages = Math.ceil(products.length / productsPerPage);
  
  // Get category name for display
  const getCategoryName = (categoryId) => {
    if (categoryId === 'all') return '所有产品';
    const category = categories.find(cat => cat.id === categoryId);
    return category ? category.name : '产品列表';
  };
  
  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex flex-col md:flex-row justify-between items-start">
        {/* Mobile Filter Toggle */}
        <button 
          className="md:hidden bg-blue-600 text-white px-4 py-2 rounded-md mb-4 flex items-center"
          onClick={() => setIsMobileFilterOpen(!isMobileFilterOpen)}
        >
          <svg className="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6V4m0 2a2 2 0 100 4m0-4a2 2 0 110 4m-6 8a2 2 0 100-4m0 4a2 2 0 110-4m0 4v2m0-6V4m6 6v10m6-2a2 2 0 100-4m0 4a2 2 0 110-4m0 4v2m0-6V4" />
          </svg>
          筛选选项
        </button>
        
        {/* Left Sidebar - Filters */}
        <aside className={`w-full md:w-1/4 md:pr-6 ${isMobileFilterOpen ? 'block' : 'hidden md:block'}`}>
          <div className="bg-white rounded-lg shadow-md p-6 mb-6">
            <h3 className="text-lg font-semibold mb-4">产品分类</h3>
            <ul className="space-y-2">
              <li>
                <button 
                  onClick={() => handleCategoryChange('all')}
                  className={`w-full text-left px-3 py-2 rounded-md ${selectedCategory === 'all' ? 'bg-blue-500 text-white' : 'hover:bg-gray-100'}`}
                >
                  所有产品
                </button>
              </li>
              {categories.map(category => (
                <li key={category.id}>
                  <button 
                    onClick={() => handleCategoryChange(category.id)}
                    className={`w-full text-left px-3 py-2 rounded-md ${selectedCategory === category.id ? 'bg-blue-500 text-white' : 'hover:bg-gray-100'}`}
                  >
                    {category.name}
                  </button>
                </li>
              ))}
            </ul>
          </div>
          
          <div className="bg-white rounded-lg shadow-md p-6 mb-6">
            <h3 className="text-lg font-semibold mb-4">搜索</h3>
            <div className="relative">
              <input 
                type="text" 
                value={searchQuery}
                onChange={handleSearchChange}
                placeholder="搜索产品..."
                className="w-full border border-gray-300 rounded-md px-4 py-2 pl-10"
              />
              <svg className="w-5 h-5 absolute left-3 top-3 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
              </svg>
            </div>
          </div>
          
          <div className="bg-white rounded-lg shadow-md p-6">
            <h3 className="text-lg font-semibold mb-4">产品特性</h3>
            <div className="flex flex-wrap gap-2">
              {allTags.map(tag => (
                <button
                  key={tag}
                  onClick={() => handleTagToggle(tag)}
                  className={`px-3 py-1 rounded-full text-sm ${
                    selectedTags.includes(tag) 
                      ? 'bg-blue-500 text-white' 
                      : 'bg-gray-100 hover:bg-gray-200'
                  }`}
                >
                  {tag}
                </button>
              ))}
            </div>
          </div>
        </aside>
        
        {/* Main Content */}
        <main className="w-full md:w-3/4">
          {/* Breadcrumbs */}
          <nav className="text-sm mb-6 flex items-center">
            <Link to="/" className="text-gray-500 hover:text-blue-600">首页</Link>
            <span className="mx-2 text-gray-500">/</span>
            <Link to="/products" className="text-gray-500 hover:text-blue-600">产品中心</Link>
            {selectedCategory !== 'all' && (
              <>
                <span className="mx-2 text-gray-500">/</span>
                <span className="text-blue-600">{getCategoryName(selectedCategory)}</span>
              </>
            )}
          </nav>
          
          {/* Page Header */}
          <div className="flex justify-between items-center mb-6">
            <h1 className="text-2xl md:text-3xl font-bold">{getCategoryName(selectedCategory)}</h1>
            <span className="text-gray-600">显示 {products.length} 个产品</span>
          </div>
          
          {/* Applied Filters */}
          {(selectedTags.length > 0 || searchQuery) && (
            <div className="bg-gray-50 p-3 rounded-md mb-6">
              <div className="flex flex-wrap gap-2 items-center">
                <span className="text-sm text-gray-500">已选筛选条件:</span>
                {searchQuery && (
                  <span className="inline-flex items-center bg-blue-100 text-blue-800 text-xs px-2 py-1 rounded-full">
                    搜索: {searchQuery}
                    <button 
                      onClick={() => setSearchQuery('')}
                      className="ml-1 focus:outline-none"
                    >
                      <svg className="w-3 h-3" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                        <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" clipRule="evenodd" />
                      </svg>
                    </button>
                  </span>
                )}
                {selectedTags.map(tag => (
                  <span key={tag} className="inline-flex items-center bg-blue-100 text-blue-800 text-xs px-2 py-1 rounded-full">
                    {tag}
                    <button 
                      onClick={() => handleTagToggle(tag)}
                      className="ml-1 focus:outline-none"
                    >
                      <svg className="w-3 h-3" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                        <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" clipRule="evenodd" />
                      </svg>
                    </button>
                  </span>
                ))}
                {(selectedTags.length > 0 || searchQuery) && (
                  <button 
                    onClick={() => {
                      setSelectedTags([]);
                      setSearchQuery('');
                    }}
                    className="text-sm text-blue-600 hover:text-blue-800"
                  >
                    清除全部筛选条件
                  </button>
                )}
              </div>
            </div>
          )}
          
          {/* Products Grid */}
          {products.length > 0 ? (
            <>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                {currentProducts.map(product => (
                  <div key={product.id} className="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-lg transition-shadow">
                    <Link to={`/products/${product.id}`}>
                      <div className="h-48 overflow-hidden">
                        <img 
                          src={product.image} 
                          alt={product.name} 
                          className="w-full h-full object-cover transition-transform hover:scale-105"
                        />
                      </div>
                      <div className="p-5">
                        <h3 className="text-lg font-semibold mb-2">{product.name}</h3>
                        <div className="flex items-center justify-between mb-3">
                          <span className="text-sm text-gray-500">{product.categoryName}</span>
                          <span className="font-semibold text-blue-600">{product.price}</span>
                        </div>
                        <p className="text-gray-600 text-sm line-clamp-3">{product.description}</p>
                        <div className="mt-3 flex flex-wrap gap-1">
                          {product.tags.slice(0, 3).map((tag, idx) => (
                            <span key={idx} className="text-xs bg-gray-100 px-2 py-1 rounded">
                              {tag}
                            </span>
                          ))}
                        </div>
                      </div>
                    </Link>
                  </div>
                ))}
              </div>
              
              {/* Pagination */}
              {totalPages > 1 && (
                <div className="mt-8 flex justify-center">
                  <nav className="flex items-center space-x-2">
                    <button
                      onClick={() => setCurrentPage(prev => Math.max(prev - 1, 1))}
                      disabled={currentPage === 1}
                      className={`px-3 py-2 rounded-md ${
                        currentPage === 1 
                          ? 'text-gray-400 cursor-not-allowed' 
                          : 'text-gray-700 hover:bg-gray-100'
                      }`}
                    >
                      上一页
                    </button>
                    
                    {[...Array(totalPages)].map((_, idx) => (
                      <button
                        key={idx}
                        onClick={() => setCurrentPage(idx + 1)}
                        className={`px-3 py-2 rounded-md ${
                          currentPage === idx + 1
                            ? 'bg-blue-600 text-white'
                            : 'text-gray-700 hover:bg-gray-100'
                        }`}
                      >
                        {idx + 1}
                      </button>
                    ))}
                    
                    <button
                      onClick={() => setCurrentPage(prev => Math.min(prev + 1, totalPages))}
                      disabled={currentPage === totalPages}
                      className={`px-3 py-2 rounded-md ${
                        currentPage === totalPages
                          ? 'text-gray-400 cursor-not-allowed'
                          : 'text-gray-700 hover:bg-gray-100'
                      }`}
                    >
                      下一页
                    </button>
                  </nav>
                </div>
              )}
            </>
          ) : (
            <div className="bg-gray-50 p-10 rounded-lg text-center">
              <svg className="w-16 h-16 text-gray-400 mx-auto mb-4" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9.172 16.172a4 4 0 015.656 0M9 10h.01M15 10h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
              </svg>
              <h3 className="text-xl font-semibold mb-2">未找到产品</h3>
              <p className="text-gray-600 mb-4">抱歉，没有找到符合当前筛选条件的产品。</p>
              <button 
                onClick={() => {
                  setSelectedTags([]);
                  setSearchQuery('');
                }}
                className="inline-flex items-center bg-blue-600 text-white px-4 py-2 rounded-md hover:bg-blue-700"
              >
                <svg className="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
                </svg>
                重置筛选条件
              </button>
            </div>
          )}
        </main>
      </div>
    </div>
  );
};

export default ProductListPage;