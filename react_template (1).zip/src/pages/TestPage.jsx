import React from 'react';

function TestPage() {
  return (
    <div className="flex items-center justify-center h-screen bg-gray-100">
      <div className="bg-white p-8 rounded-lg shadow-md w-full max-w-md">
        <h1 className="text-2xl font-bold text-center mb-6">Test Page Works!</h1>
        <p className="text-center text-gray-600 mb-4">
          This is a simple test page to verify routing is working correctly.
        </p>
        <div className="flex justify-center">
          <a 
            href="/admin/test-login" 
            className="px-4 py-2 bg-blue-500 text-white rounded hover:bg-blue-600 transition-colors"
          >
            Go to Test Login Page
          </a>
        </div>
      </div>
    </div>
  );
}

export default TestPage;