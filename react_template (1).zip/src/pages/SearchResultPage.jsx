import React, { useState, useEffect } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { FaSearch, FaTimes, FaFilter, FaSortAmountDown } from 'react-icons/fa';

const SearchResultPage = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const queryParams = new URLSearchParams(location.search);
  const searchQuery = queryParams.get('q') || '';
  const category = queryParams.get('category') || 'all';
  
  const [searchResults, setSearchResults] = useState([]);
  const [loading, setLoading] = useState(true);
  const [filters, setFilters] = useState({
    category: category,
    sort: 'relevance',
  });
  const [showFilters, setShowFilters] = useState(false);

  // Static data for search results since there's no backend
  const allData = {
    products: [
      { id: '1', type: 'product', title: 'Enterprise Cloud Solution', category: 'cloud', description: 'Secure and scalable cloud solution for enterprise businesses.', image: '/images/product-1.jpg' },
      { id: '2', type: 'product', title: 'Cybersecurity Suite', category: 'security', description: 'Comprehensive security tools for protecting your business data.', image: '/images/product-2.jpg' },
      { id: '3', type: 'product', title: 'Data Analytics Platform', category: 'analytics', description: 'Powerful insights from your business data with advanced analytics.', image: '/images/product-3.jpg' },
      { id: '4', type: 'product', title: 'IoT Management System', category: 'iot', description: 'Connect and manage all your IoT devices from a single platform.', image: '/images/product-4.jpg' },
    ],
    articles: [
      { id: '1', type: 'article', title: 'Digital Transformation Strategies', category: 'strategy', date: '2023-09-15', description: 'Learn about effective strategies for digital transformation.', image: '/images/article-1.jpg' },
      { id: '2', type: 'article', title: 'The Future of AI in Business', category: 'technology', date: '2023-10-02', description: 'Exploring how artificial intelligence will reshape business operations.', image: '/images/article-2.jpg' },
      { id: '3', type: 'article', title: 'Cybersecurity Best Practices', category: 'security', date: '2023-08-28', description: 'Essential security practices every business should implement.', image: '/images/article-3.jpg' },
    ],
    cases: [
      { id: '1', type: 'case', title: 'Enterprise Digital Transformation Project', category: 'transformation', client: 'XYZ Corporation', description: 'How we helped XYZ Corporation digitize their operations.', image: '/images/case-1.jpg' },
      { id: '2', type: 'case', title: 'Smart Manufacturing Implementation', category: 'manufacturing', client: 'ABC Industries', description: 'Implementing IoT and AI in manufacturing processes.', image: '/images/case-2.jpg' },
      { id: '3', type: 'case', title: 'Cloud Migration & Security Enhancement', category: 'cloud', client: 'Global Financial Services', description: 'Secure cloud migration for a financial institution.', image: '/images/case-3.jpg' },
    ],
  };

  // Perform search on static data
  useEffect(() => {
    setLoading(true);
    
    // Simulate API delay
    setTimeout(() => {
      if (!searchQuery) {
        setSearchResults([]);
        setLoading(false);
        return;
      }
      
      // Filter results based on search query and selected category
      let results = [];
      const query = searchQuery.toLowerCase();
      
      const searchInData = (items, type) => {
        return items.filter(item => {
          const matchesQuery = 
            item.title.toLowerCase().includes(query) || 
            item.description.toLowerCase().includes(query);
          
          const matchesCategory = 
            filters.category === 'all' || 
            item.category === filters.category;
          
          return matchesQuery && matchesCategory;
        }).map(item => ({ ...item, type }));
      };
      
      if (filters.category === 'all' || filters.category === 'products') {
        results = [...results, ...searchInData(allData.products, 'product')];
      }
      
      if (filters.category === 'all' || filters.category === 'articles') {
        results = [...results, ...searchInData(allData.articles, 'article')];
      }
      
      if (filters.category === 'all' || filters.category === 'cases') {
        results = [...results, ...searchInData(allData.cases, 'case')];
      }
      
      // Apply sorting
      if (filters.sort === 'newest') {
        // For demo purposes, just randomize the order
        results.sort(() => Math.random() - 0.5);
      } else if (filters.sort === 'a-z') {
        results.sort((a, b) => a.title.localeCompare(b.title));
      }
      
      setSearchResults(results);
      setLoading(false);
    }, 800);
    
  }, [searchQuery, filters]);

  // Update URL when filters change
  useEffect(() => {
    const params = new URLSearchParams();
    if (searchQuery) params.set('q', searchQuery);
    if (filters.category !== 'all') params.set('category', filters.category);
    
    navigate({ search: params.toString() }, { replace: true });
  }, [filters, searchQuery, navigate]);

  const handleSearch = (e) => {
    e.preventDefault();
    const formData = new FormData(e.target);
    const newQuery = formData.get('search');
    
    const params = new URLSearchParams(location.search);
    params.set('q', newQuery);
    navigate({ search: params.toString() });
  };

  const handleFilterChange = (name, value) => {
    setFilters(prev => ({ ...prev, [name]: value }));
  };

  return (
    <div className="container mx-auto px-4 py-8">
      {/* Search Form */}
      <div className="mb-8">
        <form onSubmit={handleSearch} className="flex max-w-3xl mx-auto">
          <div className="relative flex-grow">
            <input
              type="text"
              name="search"
              defaultValue={searchQuery}
              placeholder="Search for products, articles, or case studies..."
              className="w-full pl-12 pr-4 py-3 border border-gray-300 rounded-l-lg focus:ring focus:ring-blue-200 focus:border-blue-500 outline-none"
            />
            <FaSearch className="absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-400" />
            {searchQuery && (
              <button 
                type="button"
                onClick={() => navigate('/search')}
                className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-gray-600"
              >
                <FaTimes />
              </button>
            )}
          </div>
          <button 
            type="submit"
            className="bg-blue-600 hover:bg-blue-700 text-white px-6 py-3 rounded-r-lg font-medium"
          >
            Search
          </button>
        </form>
      </div>

      {/* Search Results Summary */}
      {searchQuery && (
        <div className="mb-6">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
            <h2 className="text-2xl font-bold">
              Search results for "{searchQuery}" 
              <span className="ml-2 text-sm font-normal text-gray-500">
                ({searchResults.length} results found)
              </span>
            </h2>
            
            <div className="flex items-center space-x-4">
              <button 
                onClick={() => setShowFilters(!showFilters)}
                className="flex items-center text-gray-700 hover:text-blue-600"
              >
                <FaFilter className="mr-2" />
                <span className="font-medium">Filters</span>
              </button>
              
              <div className="relative">
                <select
                  value={filters.sort}
                  onChange={(e) => handleFilterChange('sort', e.target.value)}
                  className="appearance-none pl-8 pr-8 py-2 border border-gray-300 rounded-md focus:outline-none"
                >
                  <option value="relevance">Most Relevant</option>
                  <option value="newest">Newest First</option>
                  <option value="a-z">A-Z</option>
                </select>
                <FaSortAmountDown className="absolute left-2 top-1/2 transform -translate-y-1/2 text-gray-400" />
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Filters */}
      {showFilters && (
        <div className="bg-gray-50 p-4 rounded-lg mb-6">
          <h3 className="font-medium mb-3">Filter by category:</h3>
          <div className="flex flex-wrap gap-2">
            {['all', 'products', 'articles', 'cases', 'cloud', 'security', 'analytics'].map(cat => (
              <button
                key={cat}
                onClick={() => handleFilterChange('category', cat)}
                className={`px-4 py-2 rounded-full text-sm ${
                  filters.category === cat
                    ? 'bg-blue-600 text-white'
                    : 'bg-white border border-gray-300 hover:bg-gray-100'
                }`}
              >
                {cat.charAt(0).toUpperCase() + cat.slice(1)}
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Loading State */}
      {loading && searchQuery && (
        <div className="flex justify-center py-12">
          <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-600"></div>
        </div>
      )}

      {/* No Results */}
      {!loading && searchQuery && searchResults.length === 0 && (
        <div className="text-center py-16">
          <h3 className="text-xl font-semibold mb-2">No results found</h3>
          <p className="text-gray-600 mb-4">We couldn't find any matches for "{searchQuery}"</p>
          <p>Try adjusting your search or filters to find what you're looking for.</p>
        </div>
      )}

      {/* Search Results */}
      {!loading && searchResults.length > 0 && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {searchResults.map((result) => (
            <div key={`${result.type}-${result.id}`} className="border border-gray-200 rounded-lg overflow-hidden hover:shadow-md transition-shadow">
              <Link 
                to={
                  result.type === 'product' ? `/products/${result.id}` :
                  result.type === 'article' ? `/articles/${result.id}` :
                  `/cases/${result.id}`
                }
              >
                <div className="h-48 overflow-hidden">
                  <img 
                    src={result.image || `https://via.placeholder.com/400x300?text=${result.title}`} 
                    alt={result.title}
                    className="w-full h-full object-cover"
                  />
                </div>
                <div className="p-4">
                  <div className="mb-2">
                    <span className="inline-block px-2 py-1 text-xs font-medium rounded bg-gray-100 text-gray-800">
                      {result.type.charAt(0).toUpperCase() + result.type.slice(1)}
                    </span>
                    {result.category && (
                      <span className="inline-block ml-2 px-2 py-1 text-xs font-medium rounded bg-blue-100 text-blue-800">
                        {result.category.charAt(0).toUpperCase() + result.category.slice(1)}
                      </span>
                    )}
                  </div>
                  <h3 className="font-bold text-lg mb-2">{result.title}</h3>
                  {result.client && <p className="text-sm text-gray-600 mb-1">Client: {result.client}</p>}
                  {result.date && <p className="text-sm text-gray-600 mb-1">Published: {new Date(result.date).toLocaleDateString()}</p>}
                  <p className="text-gray-600 line-clamp-2">{result.description}</p>
                </div>
              </Link>
            </div>
          ))}
        </div>
      )}
      
      {/* Empty Initial State */}
      {!searchQuery && !loading && (
        <div className="text-center py-16">
          <h3 className="text-xl font-semibold mb-2">Search our website</h3>
          <p className="text-gray-600">Enter your search term above to find products, articles, and case studies.</p>
        </div>
      )}

      {/* Pagination - For Demo Purposes */}
      {searchResults.length > 0 && (
        <div className="flex justify-center mt-10">
          <div className="inline-flex items-center">
            <button className="px-4 py-2 border border-gray-300 rounded-l-md bg-white text-gray-500 hover:bg-gray-50" disabled>
              Previous
            </button>
            <button className="px-4 py-2 border border-gray-300 bg-blue-600 text-white">
              1
            </button>
            <button className="px-4 py-2 border border-gray-300 bg-white text-gray-700 hover:bg-gray-50">
              2
            </button>
            <button className="px-4 py-2 border border-gray-300 bg-white text-gray-700 hover:bg-gray-50">
              3
            </button>
            <button className="px-4 py-2 border border-gray-300 rounded-r-md bg-white text-gray-700 hover:bg-gray-50">
              Next
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

export default SearchResultPage;