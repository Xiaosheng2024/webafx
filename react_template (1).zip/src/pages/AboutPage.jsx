import React from 'react';
import Breadcrumb from '../components/common/Breadcrumb';
import { useAppContext } from '../context/AppContext';

const AboutPage = () => {
  const { state } = useAppContext();
  const { language } = state;

  // Company history milestones
  const milestones = [
    {
      year: '2010',
      title: {
        zh: '公司成立',
        en: 'Company Founded'
      },
      description: {
        zh: '我们的创始团队怀揣梦想，成立了专注于扫描设备和文档管理解决方案的公司。',
        en: 'Our founding team established the company with a vision focused on scanning equipment and document management solutions.'
      }
    },
    {
      year: '2013',
      title: {
        zh: '首款高速扫描仪发布',
        en: 'First High-Speed Scanner Released'
      },
      description: {
        zh: '成功研发并推出了首款高速扫描设备，标志着我们在技术创新领域迈出了重要一步。',
        en: 'Successfully developed and launched our first high-speed scanning device, marking a significant step in technological innovation.'
      }
    },
    {
      year: '2016',
      title: {
        zh: '国际市场扩展',
        en: 'International Market Expansion'
      },
      description: {
        zh: '产品开始进入国际市场，建立了覆盖亚太地区的销售和服务网络。',
        en: 'Our products entered the international market, establishing a sales and service network covering the Asia-Pacific region.'
      }
    },
    {
      year: '2019',
      title: {
        zh: '软件业务拓展',
        en: 'Software Business Expansion'
      },
      description: {
        zh: '推出了全新的文档管理软件系列，形成了硬件与软件结合的完整解决方案。',
        en: 'Launched a new document management software series, forming complete solutions that combine hardware and software.'
      }
    },
    {
      year: '2022',
      title: {
        zh: '智能化升级',
        en: 'Intelligence Upgrade'
      },
      description: {
        zh: '全线产品实现智能化升级，融入AI技术，提升用户体验和工作效率。',
        en: 'All product lines achieved intelligence upgrades, incorporating AI technology to enhance user experience and work efficiency.'
      }
    },
    {
      year: '2024',
      title: {
        zh: '可持续发展战略',
        en: 'Sustainable Development Strategy'
      },
      description: {
        zh: '推出绿色环保产品线，致力于减少碳排放并促进可持续发展。',
        en: 'Launched an eco-friendly product line, committed to reducing carbon emissions and promoting sustainable development.'
      }
    }
  ];

  // Team members
  const team = [
    {
      name: '张明',
      nameEn: 'Zhang Ming',
      position: {
        zh: '创始人兼首席执行官',
        en: 'Founder & CEO'
      },
      bio: {
        zh: '拥有20年科技行业经验，曾在多家知名企业担任高管职位。带领团队不断创新，致力于提供最优质的产品和服务。',
        en: 'With 20 years of experience in the technology industry, he has held executive positions at several renowned companies. He leads the team in continuous innovation, dedicated to providing the highest quality products and services.'
      },
      image: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-4.0.3&auto=format&fit=crop&w=200&h=200&q=80'
    },
    {
      name: '李婷',
      nameEn: 'Li Ting',
      position: {
        zh: '技术总监',
        en: 'CTO'
      },
      bio: {
        zh: '计算机科学博士，专注于图像处理和机器学习领域。领导公司核心技术研发，持有多项国际专利。',
        en: 'Ph.D. in Computer Science, focusing on image processing and machine learning. She leads the company\'s core technology R&D and holds multiple international patents.'
      },
      image: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?ixlib=rb-4.0.3&auto=format&fit=crop&w=200&h=200&q=80'
    },
    {
      name: '王强',
      nameEn: 'Wang Qiang',
      position: {
        zh: '产品总监',
        en: 'Product Director'
      },
      bio: {
        zh: '资深产品专家，擅长用户体验设计和产品策略制定。致力于打造符合客户需求的创新产品。',
        en: 'Senior product expert, specializing in user experience design and product strategy development. Committed to creating innovative products that meet customer needs.'
      },
      image: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&auto=format&fit=crop&w=200&h=200&q=80'
    },
    {
      name: '陈梅',
      nameEn: 'Chen Mei',
      position: {
        zh: '市场营销总监',
        en: 'Marketing Director'
      },
      bio: {
        zh: '拥有丰富的B2B市场营销经验，精通国内外市场策略。曾成功带领团队开拓多个新兴市场。',
        en: 'With extensive B2B marketing experience, she is proficient in domestic and international market strategies. She has successfully led teams to develop multiple emerging markets.'
      },
      image: 'https://images.unsplash.com/photo-1573497019940-1c28c88b4f3e?ixlib=rb-4.0.3&auto=format&fit=crop&w=200&h=200&q=80'
    }
  ];

  return (
    <div className="container mx-auto px-4 py-8">
      {/* Breadcrumb */}
      <Breadcrumb additionalItems={[
        { name: language === 'en' ? 'About Us' : '关于我们', path: '/about' }
      ]} />
      
      {/* Hero Section */}
      <div className="bg-blue-50 rounded-lg overflow-hidden mb-16">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <div className="p-8 md:p-12 flex flex-col justify-center">
            <h1 className="text-3xl md:text-4xl font-bold mb-6">
              {language === 'en' ? 'About Our Company' : '关于我们的公司'}
            </h1>
            <p className="text-lg text-gray-700 mb-6">
              {language === 'en' 
                ? 'We are a leading provider of scanning equipment, printing solutions, and document management systems. With over a decade of experience, we are committed to delivering high-quality products and services to our clients worldwide.'
                : '我们是扫描设备、打印解决方案和文档管理系统的领先提供商。凭借十多年的经验，我们致力于为全球客户提供高质量的产品和服务。'}
            </p>
            <div className="flex flex-wrap gap-4">
              <div className="bg-white p-4 rounded-lg shadow flex items-center w-40">
                <div className="mr-3 text-blue-600">
                  <svg className="w-10 h-10" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                    <path fillRule="evenodd" d="M6 2a1 1 0 00-1 1v1H4a2 2 0 00-2 2v10a2 2 0 002 2h12a2 2 0 002-2V6a2 2 0 00-2-2h-1V3a1 1 0 10-2 0v1H7V3a1 1 0 00-1-1zm0 5a1 1 0 000 2h8a1 1 0 100-2H6z" clipRule="evenodd" />
                  </svg>
                </div>
                <div>
                  <div className="text-xs text-gray-500">{language === 'en' ? 'Founded in' : '成立于'}</div>
                  <div className="font-bold">2010</div>
                </div>
              </div>
              
              <div className="bg-white p-4 rounded-lg shadow flex items-center w-40">
                <div className="mr-3 text-blue-600">
                  <svg className="w-10 h-10" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                    <path fillRule="evenodd" d="M10 9a3 3 0 100-6 3 3 0 000 6zm-7 9a7 7 0 1114 0H3z" clipRule="evenodd" />
                  </svg>
                </div>
                <div>
                  <div className="text-xs text-gray-500">{language === 'en' ? 'Employees' : '员工数'}</div>
                  <div className="font-bold">200+</div>
                </div>
              </div>
              
              <div className="bg-white p-4 rounded-lg shadow flex items-center w-40">
                <div className="mr-3 text-blue-600">
                  <svg className="w-10 h-10" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                    <path fillRule="evenodd" d="M5 2a2 2 0 00-2 2v14l3.5-2 3.5 2 3.5-2 3.5 2V4a2 2 0 00-2-2H5zm4.5 14L6 18l-3-2V4a1 1 0 011-1h12a1 1 0 011 1v12l-3 2-3.5-2z" clipRule="evenodd" />
                  </svg>
                </div>
                <div>
                  <div className="text-xs text-gray-500">{language === 'en' ? 'Countries' : '覆盖国家'}</div>
                  <div className="font-bold">30+</div>
                </div>
              </div>
            </div>
          </div>
          <div className="relative h-80 lg:h-auto">
            <img 
              src="https://images.unsplash.com/photo-1541746972996-4e0b0f43e02a?ixlib=rb-4.0.3&auto=format&fit=crop&w=1000&q=80" 
              alt={language === 'en' ? 'Company Office' : '公司办公室'}
              className="absolute inset-0 w-full h-full object-cover"
            />
          </div>
        </div>
      </div>
      
      {/* Our Mission & Vision */}
      <div className="mb-16">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold mb-4">
            {language === 'en' ? 'Our Mission & Vision' : '我们的使命与愿景'}
          </h2>
          <div className="w-24 h-1 bg-blue-600 mx-auto"></div>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          <div className="bg-white rounded-lg shadow-md p-8">
            <div className="rounded-full bg-blue-100 w-16 h-16 flex items-center justify-center mb-6">
              <svg className="w-8 h-8 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
              </svg>
            </div>
            <h3 className="text-xl font-bold mb-4">
              {language === 'en' ? 'Our Mission' : '我们的使命'}
            </h3>
            <p className="text-gray-700">
              {language === 'en' 
                ? 'To empower businesses with innovative document management solutions that enhance efficiency, reduce costs, and promote sustainability in the digital transformation journey.'
                : '通过创新的文档管理解决方案赋能企业，提升效率，降低成本，促进数字化转型过程中的可持续发展。'}
            </p>
          </div>
          
          <div className="bg-white rounded-lg shadow-md p-8">
            <div className="rounded-full bg-blue-100 w-16 h-16 flex items-center justify-center mb-6">
              <svg className="w-8 h-8 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" />
              </svg>
            </div>
            <h3 className="text-xl font-bold mb-4">
              {language === 'en' ? 'Our Vision' : '我们的愿景'}
            </h3>
            <p className="text-gray-700">
              {language === 'en' 
                ? 'To be the global leader in innovative document management and imaging solutions, recognized for excellence in technology, service, and sustainability.'
                : '成为全球创新文档管理和成像解决方案的领导者，以技术、服务和可持续性方面的卓越表现而闻名。'}
            </p>
          </div>
        </div>
      </div>
      
      {/* Company History */}
      <div className="mb-16">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold mb-4">
            {language === 'en' ? 'Our Journey' : '我们的发展历程'}
          </h2>
          <div className="w-24 h-1 bg-blue-600 mx-auto"></div>
        </div>
        
        <div className="relative">
          {/* Timeline line */}
          <div className="hidden md:block absolute left-1/2 transform -translate-x-1/2 h-full w-0.5 bg-blue-200"></div>
          
          {/* Timeline content */}
          <div className="space-y-12">
            {milestones.map((milestone, index) => (
              <div key={index} className={`flex flex-col ${index % 2 === 0 ? 'md:flex-row' : 'md:flex-row-reverse'} items-center`}>
                <div className="md:w-1/2 mb-4 md:mb-0 md:px-8">
                  <div className="bg-white rounded-lg shadow-md p-6 relative">
                    <div className={`absolute top-1/2 transform -translate-y-1/2 ${index % 2 === 0 ? 'right-0 translate-x-1/2' : 'left-0 -translate-x-1/2'} hidden md:block`}>
                      <div className="w-4 h-4 rounded-full bg-blue-600 border-4 border-blue-100"></div>
                    </div>
                    <h3 className="text-xl font-bold mb-2 flex items-center">
                      <span className="inline-block mr-2 md:hidden bg-blue-600 text-white w-6 h-6 rounded-full text-xs flex items-center justify-center">
                        <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                        </svg>
                      </span>
                      {language === 'en' ? milestone.title.en : milestone.title.zh}
                    </h3>
                    <p className="text-gray-700">{language === 'en' ? milestone.description.en : milestone.description.zh}</p>
                  </div>
                </div>
                <div className="md:w-1/2 text-center md:px-8">
                  <div className="bg-blue-600 text-white text-xl font-bold py-2 px-6 rounded-full inline-block">
                    {milestone.year}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
      
      {/* Leadership Team */}
      <div className="mb-16">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold mb-4">
            {language === 'en' ? 'Our Leadership Team' : '我们的领导团队'}
          </h2>
          <div className="w-24 h-1 bg-blue-600 mx-auto"></div>
          <p className="max-w-2xl mx-auto mt-4 text-gray-600">
            {language === 'en' 
              ? 'Meet the team of professionals who lead our company towards innovation and excellence.'
              : '了解引领我们公司走向创新和卓越的专业团队。'}
          </p>
        </div>
        
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
          {team.map((member, index) => (
            <div key={index} className="bg-white rounded-lg shadow-md overflow-hidden">
              <div className="aspect-square overflow-hidden">
                <img 
                  src={member.image} 
                  alt={language === 'en' ? member.nameEn : member.name} 
                  className="w-full h-full object-cover transition-transform duration-300 hover:scale-110"
                />
              </div>
              <div className="p-6">
                <h3 className="text-xl font-bold mb-1">
                  {language === 'en' ? member.nameEn : member.name}
                </h3>
                <p className="text-blue-600 mb-4">
                  {language === 'en' ? member.position.en : member.position.zh}
                </p>
                <p className="text-gray-600 text-sm">
                  {language === 'en' ? member.bio.en : member.bio.zh}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>
      
      {/* Values */}
      <div className="mb-16">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold mb-4">
            {language === 'en' ? 'Our Core Values' : '我们的核心价值观'}
          </h2>
          <div className="w-24 h-1 bg-blue-600 mx-auto"></div>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div className="bg-white rounded-lg shadow-md p-8 text-center">
            <div className="w-20 h-20 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-6">
              <svg className="w-10 h-10 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" />
              </svg>
            </div>
            <h3 className="text-xl font-bold mb-4">
              {language === 'en' ? 'Innovation' : '创新'}
            </h3>
            <p className="text-gray-600">
              {language === 'en' 
                ? 'We constantly push boundaries to develop cutting-edge solutions that address evolving customer needs.'
                : '我们不断突破界限，开发前沿解决方案，满足不断变化的客户需求。'}
            </p>
          </div>
          
          <div className="bg-white rounded-lg shadow-md p-8 text-center">
            <div className="w-20 h-20 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-6">
              <svg className="w-10 h-10 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z" />
              </svg>
            </div>
            <h3 className="text-xl font-bold mb-4">
              {language === 'en' ? 'Collaboration' : '协作'}
            </h3>
            <p className="text-gray-600">
              {language === 'en' 
                ? 'We believe in the power of teamwork, both internally and with our clients, to achieve extraordinary results.'
                : '我们相信团队合作的力量，无论是内部团队还是与客户合作，都能取得非凡的成果。'}
            </p>
          </div>
          
          <div className="bg-white rounded-lg shadow-md p-8 text-center">
            <div className="w-20 h-20 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-6">
              <svg className="w-10 h-10 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 12a9 9 0 01-9 9m9-9a9 9 0 00-9-9m9 9H3m9 9a9 9 0 01-9-9m9 9c1.657 0 3-4.03 3-9s-1.343-9-3-9m0 18c-1.657 0-3-4.03-3-9s1.343-9 3-9m-9 9a9 9 0 019-9" />
              </svg>
            </div>
            <h3 className="text-xl font-bold mb-4">
              {language === 'en' ? 'Sustainability' : '可持续性'}
            </h3>
            <p className="text-gray-600">
              {language === 'en' 
                ? 'We are committed to environmentally responsible practices in our operations and product development.'
                : '我们致力于在运营和产品开发中实行环保责任实践。'}
            </p>
          </div>
        </div>
      </div>
      
      {/* CTA Section */}
      <div className="bg-blue-600 rounded-lg p-8 md:p-12 text-white text-center">
        <h2 className="text-3xl font-bold mb-4">
          {language === 'en' ? 'Ready to Work With Us?' : '准备与我们合作？'}
        </h2>
        <p className="text-blue-100 mb-8 max-w-2xl mx-auto">
          {language === 'en' 
            ? 'Contact our team today to discuss how our products and solutions can help your business succeed.'
            : '立即联系我们的团队，了解我们的产品和解决方案如何帮助您的企业取得成功。'}
        </p>
        <div className="flex flex-wrap justify-center gap-4">
          <a 
            href="/contact"
            className="px-8 py-3 bg-white text-blue-600 font-medium rounded-md hover:bg-blue-50 transition-colors"
          >
            {language === 'en' ? 'Contact Us' : '联系我们'}
          </a>
          <a 
            href="/products"
            className="px-8 py-3 border border-white text-white font-medium rounded-md hover:bg-blue-700 transition-colors"
          >
            {language === 'en' ? 'View Our Products' : '查看我们的产品'}
          </a>
        </div>
      </div>
    </div>
  );
};

export default AboutPage;