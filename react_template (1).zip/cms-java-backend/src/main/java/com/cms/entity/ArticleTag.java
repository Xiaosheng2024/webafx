package com.cms.entity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Article-Tag relation entity
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ArticleTag {
    
    /**
     * ID
     */
    private Long id;
    
    /**
     * Article ID
     */
    private Long articleId;
    
    /**
     * Tag ID
     */
    private Long tagId;
    
    /**
     * Tag name (denormalized for convenience)
     */
    private String tagName;
}