package com.cms.entity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Role-Permission relation entity
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class RolePermission {
    
    /**
     * ID
     */
    private Long id;
    
    /**
     * Role ID
     */
    private Long roleId;
    
    /**
     * Permission ID
     */
    private Long permissionId;
}