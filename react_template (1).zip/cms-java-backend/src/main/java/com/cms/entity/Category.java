package com.cms.entity;

import java.util.Date;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Category entity
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Category {
    
    /**
     * Category ID
     */
    private Long id;
    
    /**
     * Category name
     */
    private String name;
    
    /**
     * Category description
     */
    private String description;
    
    /**
     * Parent category ID
     */
    private Long parentId;
    
    /**
     * Category sort order
     */
    private Integer sortOrder;
    
    /**
     * Category icon
     */
    private String icon;
    
    /**
     * Category status (active/inactive)
     */
    private String status;
    
    /**
     * Article count in this category
     */
    private Integer articleCount;
    
    /**
     * Creation time
     */
    private Date createTime;
    
    /**
     * Last update time
     */
    private Date updateTime;
    
    /**
     * Creator ID
     */
    private Long createBy;
    
    /**
     * Last updater ID
     */
    private Long updateBy;
    
    /**
     * Remarks
     */
    private String remark;
}