package com.cms.entity;

import java.util.Date;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Article entity
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Article {
    
    /**
     * Article ID
     */
    private Long id;
    
    /**
     * Article title
     */
    private String title;
    
    /**
     * Article content
     */
    private String content;
    
    /**
     * Article summary
     */
    private String summary;
    
    /**
     * Article cover image
     */
    private String coverImage;
    
    /**
     * Category ID
     */
    private Long categoryId;
    
    /**
     * Category name (denormalized for convenience)
     */
    private String categoryName;
    
    /**
     * Article status (published/draft/archived)
     */
    private String status;
    
    /**
     * Article views count
     */
    private Long viewCount;
    
    /**
     * Is this article featured?
     */
    private Boolean featured;
    
    /**
     * Article author ID
     */
    private Long authorId;
    
    /**
     * Article author name (denormalized for convenience)
     */
    private String authorName;
    
    /**
     * Article publish time
     */
    private Date publishTime;
    
    /**
     * Creation time
     */
    private Date createTime;
    
    /**
     * Last update time
     */
    private Date updateTime;
    
    /**
     * Creator ID
     */
    private Long createBy;
    
    /**
     * Last updater ID
     */
    private Long updateBy;
    
    /**
     * Search keywords
     */
    private String keywords;
    
    /**
     * SEO description
     */
    private String seoDescription;
    
    /**
     * Custom URL alias
     */
    private String urlAlias;
    
    /**
     * Sort order
     */
    private Integer sortOrder;
}