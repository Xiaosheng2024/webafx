package com.cms.entity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * User-Role relation entity
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class UserRole {
    
    /**
     * ID
     */
    private Long id;
    
    /**
     * User ID
     */
    private Long userId;
    
    /**
     * Role ID
     */
    private Long roleId;
    
    /**
     * Role name (denormalized for convenience)
     */
    private String roleName;
}