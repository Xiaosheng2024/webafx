package com.cms.entity;

import java.util.Date;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Permission entity
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Permission {
    
    /**
     * Permission ID
     */
    private Long id;
    
    /**
     * Permission name
     */
    private String name;
    
    /**
     * Permission code
     */
    private String code;
    
    /**
     * Permission type (menu, button, api, etc.)
     */
    private String type;
    
    /**
     * Parent permission ID
     */
    private Long parentId;
    
    /**
     * Permission path for menu
     */
    private String path;
    
    /**
     * Component path for menu
     */
    private String component;
    
    /**
     * Permission icon
     */
    private String icon;
    
    /**
     * Permission sort order
     */
    private Integer sortOrder;
    
    /**
     * Is this a hidden menu item?
     */
    private Boolean hidden;
    
    /**
     * Creation time
     */
    private Date createTime;
    
    /**
     * Last update time
     */
    private Date updateTime;
    
    /**
     * Creator ID
     */
    private Long createBy;
    
    /**
     * Last updater ID
     */
    private Long updateBy;
    
    /**
     * Remarks
     */
    private String remark;
}