package com.cms.entity;

import java.util.Date;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * User entity
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class User {
    
    /**
     * User ID
     */
    private Long id;
    
    /**
     * Username
     */
    private String username;
    
    /**
     * Password
     */
    private String password;
    
    /**
     * Full name
     */
    private String name;
    
    /**
     * Email address
     */
    private String email;
    
    /**
     * Phone number
     */
    private String phone;
    
    /**
     * Avatar URL
     */
    private String avatar;
    
    /**
     * User status (active/inactive)
     */
    private String status;
    
    /**
     * Last login time
     */
    private Date lastLoginTime;
    
    /**
     * Creation time
     */
    private Date createTime;
    
    /**
     * Last update time
     */
    private Date updateTime;
    
    /**
     * Creator ID
     */
    private Long createBy;
    
    /**
     * Last updater ID
     */
    private Long updateBy;
    
    /**
     * Remarks
     */
    private String remark;
}