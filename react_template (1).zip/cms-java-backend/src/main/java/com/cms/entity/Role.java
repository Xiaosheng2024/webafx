package com.cms.entity;

import java.util.Date;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Role entity
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Role {
    
    /**
     * Role ID
     */
    private Long id;
    
    /**
     * Role name
     */
    private String name;
    
    /**
     * Role code
     */
    private String code;
    
    /**
     * Role description
     */
    private String description;
    
    /**
     * Role sort order
     */
    private Integer sortOrder;
    
    /**
     * Role status (active/inactive)
     */
    private String status;
    
    /**
     * Creation time
     */
    private Date createTime;
    
    /**
     * Last update time
     */
    private Date updateTime;
    
    /**
     * Creator ID
     */
    private Long createBy;
    
    /**
     * Last updater ID
     */
    private Long updateBy;
    
    /**
     * Remarks
     */
    private String remark;
}