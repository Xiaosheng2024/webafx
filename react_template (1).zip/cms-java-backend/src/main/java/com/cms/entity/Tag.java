package com.cms.entity;

import java.util.Date;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Tag entity
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Tag {
    
    /**
     * Tag ID
     */
    private Long id;
    
    /**
     * Tag name
     */
    private String name;
    
    /**
     * Tag description
     */
    private String description;
    
    /**
     * Tag color
     */
    private String color;
    
    /**
     * Article count with this tag
     */
    private Integer articleCount;
    
    /**
     * Creation time
     */
    private Date createTime;
    
    /**
     * Last update time
     */
    private Date updateTime;
    
    /**
     * Creator ID
     */
    private Long createBy;
    
    /**
     * Last updater ID
     */
    private Long updateBy;
}