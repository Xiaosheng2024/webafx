package com.cms.mapper;

import com.cms.entity.Category;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import java.util.List;

/**
 * Category Mapper Interface
 */
@Mapper
public interface CategoryMapper {

    /**
     * Find category by ID
     * @param id Category ID
     * @return Category object
     */
    Category findById(Long id);

    /**
     * Get all categories
     * @return List of categories
     */
    List<Category> findAll();

    /**
     * Get all categories with pagination
     * @param offset Offset
     * @param limit Limit
     * @return List of categories
     */
    List<Category> findAllWithPagination(@Param("offset") int offset, @Param("limit") int limit);

    /**
     * Get categories by parent ID
     * @param parentId Parent category ID
     * @return List of child categories
     */
    List<Category> findByParentId(Long parentId);

    /**
     * Get categories by status
     * @param status Category status
     * @return List of categories
     */
    List<Category> findByStatus(String status);

    /**
     * Count total number of categories
     * @return Count of categories
     */
    int count();

    /**
     * Insert a new category
     * @param category Category object
     * @return Number of rows affected
     */
    int insert(Category category);

    /**
     * Update category
     * @param category Category object
     * @return Number of rows affected
     */
    int update(Category category);

    /**
     * Update category status
     * @param id Category ID
     * @param status New status
     * @return Number of rows affected
     */
    int updateStatus(@Param("id") Long id, @Param("status") String status);

    /**
     * Update article count for a category
     * @param id Category ID
     * @param count New count
     * @return Number of rows affected
     */
    int updateArticleCount(@Param("id") Long id, @Param("count") int count);

    /**
     * Delete category by ID
     * @param id Category ID
     * @return Number of rows affected
     */
    int deleteById(Long id);
}