package com.cms.mapper;

import com.cms.entity.ArticleTag;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import java.util.List;

/**
 * Article-Tag Mapper Interface
 */
@Mapper
public interface ArticleTagMapper {

    /**
     * Find by ID
     * @param id ID
     * @return ArticleTag object
     */
    ArticleTag findById(Long id);

    /**
     * Find article tags by article ID
     * @param articleId Article ID
     * @return List of article tags
     */
    List<ArticleTag> findByArticleId(Long articleId);

    /**
     * Find articles by tag ID
     * @param tagId Tag ID
     * @return List of article tags
     */
    List<ArticleTag> findByTagId(Long tagId);

    /**
     * Check if an article has a specific tag
     * @param articleId Article ID
     * @param tagId Tag ID
     * @return ArticleTag object if exists, null otherwise
     */
    ArticleTag findByArticleIdAndTagId(@Param("articleId") Long articleId, @Param("tagId") Long tagId);

    /**
     * Insert a new article-tag relationship
     * @param articleTag ArticleTag object
     * @return Number of rows affected
     */
    int insert(ArticleTag articleTag);

    /**
     * Batch insert article-tag relationships
     * @param articleTags List of ArticleTag objects
     * @return Number of rows affected
     */
    int batchInsert(List<ArticleTag> articleTags);

    /**
     * Delete article-tag relationship by ID
     * @param id ID
     * @return Number of rows affected
     */
    int deleteById(Long id);

    /**
     * Delete article-tag relationships by article ID
     * @param articleId Article ID
     * @return Number of rows affected
     */
    int deleteByArticleId(Long articleId);

    /**
     * Delete article-tag relationships by tag ID
     * @param tagId Tag ID
     * @return Number of rows affected
     */
    int deleteByTagId(Long tagId);

    /**
     * Delete a specific article-tag relationship
     * @param articleId Article ID
     * @param tagId Tag ID
     * @return Number of rows affected
     */
    int deleteByArticleIdAndTagId(@Param("articleId") Long articleId, @Param("tagId") Long tagId);
}