package com.cms.mapper;

import com.cms.entity.Tag;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import java.util.List;

/**
 * Tag Mapper Interface
 */
@Mapper
public interface TagMapper {

    /**
     * Find tag by ID
     * @param id Tag ID
     * @return Tag object
     */
    Tag findById(Long id);

    /**
     * Find tag by name
     * @param name Tag name
     * @return Tag object
     */
    Tag findByName(String name);

    /**
     * Get all tags
     * @return List of tags
     */
    List<Tag> findAll();

    /**
     * Get all tags with pagination
     * @param offset Offset
     * @param limit Limit
     * @return List of tags
     */
    List<Tag> findAllWithPagination(@Param("offset") int offset, @Param("limit") int limit);

    /**
     * Get tags by article ID
     * @param articleId Article ID
     * @return List of tags
     */
    List<Tag> findByArticleId(Long articleId);

    /**
     * Get popular tags
     * @param limit Limit number of results
     * @return List of popular tags
     */
    List<Tag> findPopular(int limit);

    /**
     * Count total number of tags
     * @return Count of tags
     */
    int count();

    /**
     * Insert a new tag
     * @param tag Tag object
     * @return Number of rows affected
     */
    int insert(Tag tag);

    /**
     * Update tag
     * @param tag Tag object
     * @return Number of rows affected
     */
    int update(Tag tag);

    /**
     * Update article count for a tag
     * @param id Tag ID
     * @param count New count
     * @return Number of rows affected
     */
    int updateArticleCount(@Param("id") Long id, @Param("count") int count);

    /**
     * Delete tag by ID
     * @param id Tag ID
     * @return Number of rows affected
     */
    int deleteById(Long id);
}