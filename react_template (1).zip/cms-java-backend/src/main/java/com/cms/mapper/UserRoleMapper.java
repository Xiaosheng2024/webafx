package com.cms.mapper;

import com.cms.entity.UserRole;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import java.util.List;

/**
 * User-Role Mapper Interface
 */
@Mapper
public interface UserRoleMapper {

    /**
     * Find by ID
     * @param id ID
     * @return UserRole object
     */
    UserRole findById(Long id);

    /**
     * Find user roles by user ID
     * @param userId User ID
     * @return List of user roles
     */
    List<UserRole> findByUserId(Long userId);

    /**
     * Find users by role ID
     * @param roleId Role ID
     * @return List of user roles
     */
    List<UserRole> findByRoleId(Long roleId);

    /**
     * Check if a user has a specific role
     * @param userId User ID
     * @param roleId Role ID
     * @return UserRole object if exists, null otherwise
     */
    UserRole findByUserIdAndRoleId(@Param("userId") Long userId, @Param("roleId") Long roleId);

    /**
     * Insert a new user-role relationship
     * @param userRole UserRole object
     * @return Number of rows affected
     */
    int insert(UserRole userRole);

    /**
     * Batch insert user-role relationships
     * @param userRoles List of UserRole objects
     * @return Number of rows affected
     */
    int batchInsert(List<UserRole> userRoles);

    /**
     * Delete user-role relationship by ID
     * @param id ID
     * @return Number of rows affected
     */
    int deleteById(Long id);

    /**
     * Delete user-role relationships by user ID
     * @param userId User ID
     * @return Number of rows affected
     */
    int deleteByUserId(Long userId);

    /**
     * Delete user-role relationships by role ID
     * @param roleId Role ID
     * @return Number of rows affected
     */
    int deleteByRoleId(Long roleId);

    /**
     * Delete a specific user-role relationship
     * @param userId User ID
     * @param roleId Role ID
     * @return Number of rows affected
     */
    int deleteByUserIdAndRoleId(@Param("userId") Long userId, @Param("roleId") Long roleId);
}