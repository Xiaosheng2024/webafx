package com.cms.mapper;

import com.cms.entity.Permission;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import java.util.List;

/**
 * Permission Mapper Interface
 */
@Mapper
public interface PermissionMapper {

    /**
     * Find permission by ID
     * @param id Permission ID
     * @return Permission object
     */
    Permission findById(Long id);

    /**
     * Find permission by code
     * @param code Permission code
     * @return Permission object
     */
    Permission findByCode(String code);

    /**
     * Get all permissions
     * @return List of permissions
     */
    List<Permission> findAll();

    /**
     * Get all permissions with pagination
     * @param offset Offset
     * @param limit Limit
     * @return List of permissions
     */
    List<Permission> findAllWithPagination(@Param("offset") int offset, @Param("limit") int limit);

    /**
     * Get permissions by type
     * @param type Permission type
     * @return List of permissions
     */
    List<Permission> findByType(String type);

    /**
     * Get permissions by parent ID
     * @param parentId Parent permission ID
     * @return List of child permissions
     */
    List<Permission> findByParentId(Long parentId);

    /**
     * Count total number of permissions
     * @return Count of permissions
     */
    int count();

    /**
     * Insert a new permission
     * @param permission Permission object
     * @return Number of rows affected
     */
    int insert(Permission permission);

    /**
     * Update permission
     * @param permission Permission object
     * @return Number of rows affected
     */
    int update(Permission permission);

    /**
     * Delete permission by ID
     * @param id Permission ID
     * @return Number of rows affected
     */
    int deleteById(Long id);

    /**
     * Find permissions by role ID
     * @param roleId Role ID
     * @return List of permissions
     */
    List<Permission> findByRoleId(Long roleId);

    /**
     * Find permissions by user ID
     * @param userId User ID
     * @return List of permissions
     */
    List<Permission> findByUserId(Long userId);
}