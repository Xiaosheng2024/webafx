package com.cms.mapper;

import com.cms.entity.User;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import java.util.List;

/**
 * User Mapper Interface
 */
@Mapper
public interface UserMapper {

    /**
     * Find user by ID
     * @param id User ID
     * @return User object
     */
    User findById(Long id);

    /**
     * Find user by username
     * @param username Username
     * @return User object
     */
    User findByUsername(String username);

    /**
     * Find user by email
     * @param email Email
     * @return User object
     */
    User findByEmail(String email);

    /**
     * Get all users
     * @return List of users
     */
    List<User> findAll();

    /**
     * Get all users with pagination
     * @param offset Offset
     * @param limit Limit
     * @return List of users
     */
    List<User> findAllWithPagination(@Param("offset") int offset, @Param("limit") int limit);

    /**
     * Count total number of users
     * @return Count of users
     */
    int count();

    /**
     * Search users by criteria
     * @param username Username (can be partial)
     * @param name Full name (can be partial)
     * @param email Email (can be partial)
     * @param status Status
     * @return List of matching users
     */
    List<User> search(@Param("username") String username, 
                      @Param("name") String name, 
                      @Param("email") String email,
                      @Param("status") String status);

    /**
     * Insert a new user
     * @param user User object
     * @return Number of rows affected
     */
    int insert(User user);

    /**
     * Update user
     * @param user User object
     * @return Number of rows affected
     */
    int update(User user);

    /**
     * Update user's status
     * @param id User ID
     * @param status New status
     * @return Number of rows affected
     */
    int updateStatus(@Param("id") Long id, @Param("status") String status);

    /**
     * Update user's password
     * @param id User ID
     * @param password New password (should be already encoded)
     * @return Number of rows affected
     */
    int updatePassword(@Param("id") Long id, @Param("password") String password);

    /**
     * Delete user by ID
     * @param id User ID
     * @return Number of rows affected
     */
    int deleteById(Long id);
}