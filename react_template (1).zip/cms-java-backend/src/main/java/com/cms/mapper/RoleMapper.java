package com.cms.mapper;

import com.cms.entity.Role;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import java.util.List;

/**
 * Role Mapper Interface
 */
@Mapper
public interface RoleMapper {

    /**
     * Find role by ID
     * @param id Role ID
     * @return Role object
     */
    Role findById(Long id);

    /**
     * Find role by code
     * @param code Role code
     * @return Role object
     */
    Role findByCode(String code);

    /**
     * Get all roles
     * @return List of roles
     */
    List<Role> findAll();

    /**
     * Get all roles with pagination
     * @param offset Offset
     * @param limit Limit
     * @return List of roles
     */
    List<Role> findAllWithPagination(@Param("offset") int offset, @Param("limit") int limit);

    /**
     * Count total number of roles
     * @return Count of roles
     */
    int count();

    /**
     * Search roles by criteria
     * @param name Role name (can be partial)
     * @param code Role code (can be partial)
     * @param status Status
     * @return List of matching roles
     */
    List<Role> search(@Param("name") String name,
                      @Param("code") String code,
                      @Param("status") String status);

    /**
     * Insert a new role
     * @param role Role object
     * @return Number of rows affected
     */
    int insert(Role role);

    /**
     * Update role
     * @param role Role object
     * @return Number of rows affected
     */
    int update(Role role);

    /**
     * Update role's status
     * @param id Role ID
     * @param status New status
     * @return Number of rows affected
     */
    int updateStatus(@Param("id") Long id, @Param("status") String status);

    /**
     * Delete role by ID
     * @param id Role ID
     * @return Number of rows affected
     */
    int deleteById(Long id);
    
    /**
     * Find roles by user ID
     * @param userId User ID
     * @return List of roles
     */
    List<Role> findRolesByUserId(Long userId);
}