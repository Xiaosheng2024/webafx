package com.cms.mapper;

import com.cms.entity.RolePermission;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import java.util.List;

/**
 * Role-Permission Mapper Interface
 */
@Mapper
public interface RolePermissionMapper {

    /**
     * Find by ID
     * @param id ID
     * @return RolePermission object
     */
    RolePermission findById(Long id);

    /**
     * Find role permissions by role ID
     * @param roleId Role ID
     * @return List of role permissions
     */
    List<RolePermission> findByRoleId(Long roleId);

    /**
     * Find roles by permission ID
     * @param permissionId Permission ID
     * @return List of role permissions
     */
    List<RolePermission> findByPermissionId(Long permissionId);

    /**
     * Check if a role has a specific permission
     * @param roleId Role ID
     * @param permissionId Permission ID
     * @return RolePermission object if exists, null otherwise
     */
    RolePermission findByRoleIdAndPermissionId(@Param("roleId") Long roleId, @Param("permissionId") Long permissionId);

    /**
     * Insert a new role-permission relationship
     * @param rolePermission RolePermission object
     * @return Number of rows affected
     */
    int insert(RolePermission rolePermission);

    /**
     * Batch insert role-permission relationships
     * @param rolePermissions List of RolePermission objects
     * @return Number of rows affected
     */
    int batchInsert(List<RolePermission> rolePermissions);

    /**
     * Delete role-permission relationship by ID
     * @param id ID
     * @return Number of rows affected
     */
    int deleteById(Long id);

    /**
     * Delete role-permission relationships by role ID
     * @param roleId Role ID
     * @return Number of rows affected
     */
    int deleteByRoleId(Long roleId);

    /**
     * Delete role-permission relationships by permission ID
     * @param permissionId Permission ID
     * @return Number of rows affected
     */
    int deleteByPermissionId(Long permissionId);

    /**
     * Delete a specific role-permission relationship
     * @param roleId Role ID
     * @param permissionId Permission ID
     * @return Number of rows affected
     */
    int deleteByRoleIdAndPermissionId(@Param("roleId") Long roleId, @Param("permissionId") Long permissionId);
}