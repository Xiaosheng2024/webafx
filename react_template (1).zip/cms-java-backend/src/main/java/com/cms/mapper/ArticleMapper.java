package com.cms.mapper;

import com.cms.entity.Article;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import java.util.List;

/**
 * Article Mapper Interface
 */
@Mapper
public interface ArticleMapper {

    /**
     * Find article by ID
     * @param id Article ID
     * @return Article object
     */
    Article findById(Long id);

    /**
     * Find article by URL alias
     * @param urlAlias URL alias
     * @return Article object
     */
    Article findByUrlAlias(String urlAlias);

    /**
     * Get all articles
     * @return List of articles
     */
    List<Article> findAll();

    /**
     * Get all articles with pagination
     * @param offset Offset
     * @param limit Limit
     * @return List of articles
     */
    List<Article> findAllWithPagination(@Param("offset") int offset, @Param("limit") int limit);

    /**
     * Get articles by category ID
     * @param categoryId Category ID
     * @return List of articles
     */
    List<Article> findByCategoryId(Long categoryId);

    /**
     * Get articles by category ID with pagination
     * @param categoryId Category ID
     * @param offset Offset
     * @param limit Limit
     * @return List of articles
     */
    List<Article> findByCategoryIdWithPagination(
            @Param("categoryId") Long categoryId,
            @Param("offset") int offset,
            @Param("limit") int limit);

    /**
     * Get articles by author ID
     * @param authorId Author ID
     * @return List of articles
     */
    List<Article> findByAuthorId(Long authorId);

    /**
     * Get articles by status
     * @param status Article status
     * @return List of articles
     */
    List<Article> findByStatus(String status);

    /**
     * Get featured articles
     * @param limit Limit number of results
     * @return List of featured articles
     */
    List<Article> findFeatured(@Param("limit") int limit);

    /**
     * Search articles by keywords
     * @param keyword Search keyword
     * @return List of matching articles
     */
    List<Article> search(String keyword);

    /**
     * Advanced search of articles
     * @param title Title (can be partial)
     * @param categoryId Category ID
     * @param status Status
     * @param featured Featured flag
     * @param authorId Author ID
     * @return List of matching articles
     */
    List<Article> advancedSearch(
            @Param("title") String title,
            @Param("categoryId") Long categoryId,
            @Param("status") String status,
            @Param("featured") Boolean featured,
            @Param("authorId") Long authorId);

    /**
     * Count total number of articles
     * @return Count of articles
     */
    int count();

    /**
     * Count articles by category ID
     * @param categoryId Category ID
     * @return Count of articles
     */
    int countByCategoryId(Long categoryId);

    /**
     * Insert a new article
     * @param article Article object
     * @return Number of rows affected
     */
    int insert(Article article);

    /**
     * Update article
     * @param article Article object
     * @return Number of rows affected
     */
    int update(Article article);

    /**
     * Update article status
     * @param id Article ID
     * @param status New status
     * @return Number of rows affected
     */
    int updateStatus(@Param("id") Long id, @Param("status") String status);

    /**
     * Increment view count
     * @param id Article ID
     * @return Number of rows affected
     */
    int incrementViewCount(Long id);

    /**
     * Delete article by ID
     * @param id Article ID
     * @return Number of rows affected
     */
    int deleteById(Long id);
}