package com.cms.service.impl;

import com.cms.entity.User;
import com.cms.entity.UserRole;
import com.cms.mapper.UserMapper;
import com.cms.mapper.UserRoleMapper;
import com.cms.security.UserPrincipal;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

/**
 * UserDetailsService implementation for authentication
 */
@Service
public class UserDetailsServiceImpl implements UserDetailsService {

    @Autowired
    private UserMapper userMapper;

    @Autowired
    private UserRoleMapper userRoleMapper;

    /**
     * Load user by username for authentication
     * @param username Username
     * @return UserDetails object
     * @throws UsernameNotFoundException if user not found
     */
    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        User user = userMapper.findByUsername(username);
        if (user == null) {
            throw new UsernameNotFoundException("User not found with username: " + username);
        }

        // Get user roles
        List<String> roles = getUserRoles(user.getId());

        return UserPrincipal.create(
                user.getId(),
                user.getUsername(),
                user.getName(),
                user.getEmail(),
                user.getPassword(),
                roles,
                "active".equals(user.getStatus())
        );
    }

    /**
     * Load user by ID
     * @param id User ID
     * @return UserDetails object
     * @throws UsernameNotFoundException if user not found
     */
    public UserDetails loadUserById(Long id) throws UsernameNotFoundException {
        User user = userMapper.findById(id);
        if (user == null) {
            throw new UsernameNotFoundException("User not found with id: " + id);
        }

        // Get user roles
        List<String> roles = getUserRoles(user.getId());

        return UserPrincipal.create(
                user.getId(),
                user.getUsername(),
                user.getName(),
                user.getEmail(),
                user.getPassword(),
                roles,
                "active".equals(user.getStatus())
        );
    }

    /**
     * Get user roles by user ID
     * @param userId User ID
     * @return List of role names
     */
    private List<String> getUserRoles(Long userId) {
        List<UserRole> userRoles = userRoleMapper.findByUserId(userId);
        if (userRoles != null && !userRoles.isEmpty()) {
            return userRoles.stream()
                    .map(UserRole::getRoleName)
                    .collect(Collectors.toList());
        }
        return new ArrayList<>();
    }
}