-- CMS Database Schema SQL Script

-- Drop tables if they exist to ensure clean initialization
DROP TABLE IF EXISTS cms_article_tag;
DROP TABLE IF EXISTS cms_tag;
DROP TABLE IF EXISTS cms_article;
DROP TABLE IF EXISTS cms_category;
DROP TABLE IF EXISTS sys_role_permission;
DROP TABLE IF EXISTS sys_user_role;
DROP TABLE IF EXISTS sys_permission;
DROP TABLE IF EXISTS sys_role;
DROP TABLE IF EXISTS sys_user;

-- User table
CREATE TABLE sys_user (
    id BIGINT AUTO_INCREMENT PRIMARY KEY COMMENT 'User ID',
    username VARCHAR(50) NOT NULL COMMENT 'Username',
    password VARCHAR(100) NOT NULL COMMENT 'Password',
    name VARCHAR(50) COMMENT 'Full name',
    email VARCHAR(100) COMMENT 'Email address',
    phone VARCHAR(20) COMMENT 'Phone number',
    avatar VARCHAR(255) COMMENT 'Avatar URL',
    status VARCHAR(20) DEFAULT 'active' COMMENT 'User status (active/inactive)',
    last_login_time DATETIME COMMENT 'Last login time',
    create_time DATETIME NOT NULL COMMENT 'Creation time',
    update_time DATETIME NOT NULL COMMENT 'Last update time',
    create_by BIGINT COMMENT 'Creator ID',
    update_by BIGINT COMMENT 'Last updater ID',
    remark VARCHAR(500) COMMENT 'Remarks',
    UNIQUE KEY uk_username (username),
    UNIQUE KEY uk_email (email)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='User table';

-- Role table
CREATE TABLE sys_role (
    id BIGINT AUTO_INCREMENT PRIMARY KEY COMMENT 'Role ID',
    name VARCHAR(50) NOT NULL COMMENT 'Role name',
    code VARCHAR(50) NOT NULL COMMENT 'Role code',
    description VARCHAR(500) COMMENT 'Role description',
    sort_order INT DEFAULT 0 COMMENT 'Sort order',
    status VARCHAR(20) DEFAULT 'active' COMMENT 'Role status (active/inactive)',
    create_time DATETIME NOT NULL COMMENT 'Creation time',
    update_time DATETIME NOT NULL COMMENT 'Last update time',
    create_by BIGINT COMMENT 'Creator ID',
    update_by BIGINT COMMENT 'Last updater ID',
    remark VARCHAR(500) COMMENT 'Remarks',
    UNIQUE KEY uk_code (code)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='Role table';

-- Permission table
CREATE TABLE sys_permission (
    id BIGINT AUTO_INCREMENT PRIMARY KEY COMMENT 'Permission ID',
    name VARCHAR(50) NOT NULL COMMENT 'Permission name',
    code VARCHAR(100) NOT NULL COMMENT 'Permission code',
    type VARCHAR(20) COMMENT 'Permission type (menu, button, api, etc.)',
    parent_id BIGINT DEFAULT 0 COMMENT 'Parent permission ID',
    path VARCHAR(255) COMMENT 'Permission path for menu',
    component VARCHAR(255) COMMENT 'Component path for menu',
    icon VARCHAR(100) COMMENT 'Permission icon',
    sort_order INT DEFAULT 0 COMMENT 'Sort order',
    hidden BOOLEAN DEFAULT FALSE COMMENT 'Is this a hidden menu item?',
    create_time DATETIME NOT NULL COMMENT 'Creation time',
    update_time DATETIME NOT NULL COMMENT 'Last update time',
    create_by BIGINT COMMENT 'Creator ID',
    update_by BIGINT COMMENT 'Last updater ID',
    remark VARCHAR(500) COMMENT 'Remarks',
    UNIQUE KEY uk_code (code)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='Permission table';

-- User-Role relation table
CREATE TABLE sys_user_role (
    id BIGINT AUTO_INCREMENT PRIMARY KEY COMMENT 'ID',
    user_id BIGINT NOT NULL COMMENT 'User ID',
    role_id BIGINT NOT NULL COMMENT 'Role ID',
    role_name VARCHAR(50) COMMENT 'Role name (denormalized)',
    KEY idx_user_id (user_id),
    KEY idx_role_id (role_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='User-Role relation table';

-- Role-Permission relation table
CREATE TABLE sys_role_permission (
    id BIGINT AUTO_INCREMENT PRIMARY KEY COMMENT 'ID',
    role_id BIGINT NOT NULL COMMENT 'Role ID',
    permission_id BIGINT NOT NULL COMMENT 'Permission ID',
    KEY idx_role_id (role_id),
    KEY idx_permission_id (permission_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='Role-Permission relation table';

-- Category table
CREATE TABLE cms_category (
    id BIGINT AUTO_INCREMENT PRIMARY KEY COMMENT 'Category ID',
    name VARCHAR(50) NOT NULL COMMENT 'Category name',
    description VARCHAR(500) COMMENT 'Category description',
    parent_id BIGINT DEFAULT 0 COMMENT 'Parent category ID',
    sort_order INT DEFAULT 0 COMMENT 'Category sort order',
    icon VARCHAR(100) COMMENT 'Category icon',
    status VARCHAR(20) DEFAULT 'active' COMMENT 'Category status (active/inactive)',
    article_count INT DEFAULT 0 COMMENT 'Article count in this category',
    create_time DATETIME NOT NULL COMMENT 'Creation time',
    update_time DATETIME NOT NULL COMMENT 'Last update time',
    create_by BIGINT COMMENT 'Creator ID',
    update_by BIGINT COMMENT 'Last updater ID',
    remark VARCHAR(500) COMMENT 'Remarks'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='Category table';

-- Article table
CREATE TABLE cms_article (
    id BIGINT AUTO_INCREMENT PRIMARY KEY COMMENT 'Article ID',
    title VARCHAR(255) NOT NULL COMMENT 'Article title',
    content LONGTEXT COMMENT 'Article content',
    summary VARCHAR(500) COMMENT 'Article summary',
    cover_image VARCHAR(255) COMMENT 'Article cover image',
    category_id BIGINT COMMENT 'Category ID',
    category_name VARCHAR(50) COMMENT 'Category name (denormalized)',
    status VARCHAR(20) DEFAULT 'draft' COMMENT 'Article status (published/draft/archived)',
    view_count BIGINT DEFAULT 0 COMMENT 'Article views count',
    featured BOOLEAN DEFAULT FALSE COMMENT 'Is this article featured?',
    author_id BIGINT COMMENT 'Article author ID',
    author_name VARCHAR(50) COMMENT 'Article author name (denormalized)',
    publish_time DATETIME COMMENT 'Article publish time',
    create_time DATETIME NOT NULL COMMENT 'Creation time',
    update_time DATETIME NOT NULL COMMENT 'Last update time',
    create_by BIGINT COMMENT 'Creator ID',
    update_by BIGINT COMMENT 'Last updater ID',
    keywords VARCHAR(255) COMMENT 'Search keywords',
    seo_description VARCHAR(255) COMMENT 'SEO description',
    url_alias VARCHAR(255) COMMENT 'Custom URL alias',
    sort_order INT DEFAULT 0 COMMENT 'Sort order',
    KEY idx_category_id (category_id),
    KEY idx_status (status),
    KEY idx_author_id (author_id),
    UNIQUE KEY uk_url_alias (url_alias)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='Article table';

-- Tag table
CREATE TABLE cms_tag (
    id BIGINT AUTO_INCREMENT PRIMARY KEY COMMENT 'Tag ID',
    name VARCHAR(50) NOT NULL COMMENT 'Tag name',
    description VARCHAR(255) COMMENT 'Tag description',
    color VARCHAR(20) COMMENT 'Tag color',
    article_count INT DEFAULT 0 COMMENT 'Article count with this tag',
    create_time DATETIME NOT NULL COMMENT 'Creation time',
    update_time DATETIME NOT NULL COMMENT 'Last update time',
    create_by BIGINT COMMENT 'Creator ID',
    update_by BIGINT COMMENT 'Last updater ID',
    UNIQUE KEY uk_name (name)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='Tag table';

-- Article-Tag relation table
CREATE TABLE cms_article_tag (
    id BIGINT AUTO_INCREMENT PRIMARY KEY COMMENT 'ID',
    article_id BIGINT NOT NULL COMMENT 'Article ID',
    tag_id BIGINT NOT NULL COMMENT 'Tag ID',
    tag_name VARCHAR(50) COMMENT 'Tag name (denormalized)',
    KEY idx_article_id (article_id),
    KEY idx_tag_id (tag_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='Article-Tag relation table';

-- Insert initial admin user (password: admin123)
INSERT INTO sys_user 
(username, password, name, email, status, create_time, update_time) 
VALUES 
('admin', '$2a$10$CcmLhwHvnuHfF1orVY/UHuaGGpFwmZ0N3dPycpvWgcGrEkvx2Joze', 'Admin User', 'admin@example.com', 'active', NOW(), NOW());

-- Insert initial roles
INSERT INTO sys_role 
(name, code, description, sort_order, status, create_time, update_time) 
VALUES 
('Administrator', 'ADMIN', 'System administrator with all permissions', 1, 'active', NOW(), NOW()),
('Content Manager', 'CONTENT_MANAGER', 'User who can manage content', 2, 'active', NOW(), NOW()),
('Editor', 'EDITOR', 'User who can edit content', 3, 'active', NOW(), NOW()),
('Viewer', 'VIEWER', 'User who can only view content', 4, 'active', NOW(), NOW());

-- Assign admin role to admin user
INSERT INTO sys_user_role 
(user_id, role_id, role_name) 
VALUES 
(1, 1, 'Administrator');

-- Insert base permissions
INSERT INTO sys_permission 
(name, code, type, parent_id, path, icon, sort_order, create_time, update_time) 
VALUES 
-- Dashboard
('Dashboard', 'dashboard', 'menu', 0, '/dashboard', 'el-icon-s-home', 1, NOW(), NOW()),

-- Content Management
('Content Management', 'content', 'menu', 0, '/content', 'el-icon-document', 2, NOW(), NOW()),
('Article List', 'content:article:list', 'menu', 2, '/content/article', 'el-icon-tickets', 1, NOW(), NOW()),
('Add Article', 'content:article:add', 'button', 3, NULL, NULL, 1, NOW(), NOW()),
('Edit Article', 'content:article:edit', 'button', 3, NULL, NULL, 2, NOW(), NOW()),
('Delete Article', 'content:article:delete', 'button', 3, NULL, NULL, 3, NOW(), NOW()),
('Category Management', 'content:category', 'menu', 2, '/content/category', 'el-icon-collection', 2, NOW(), NOW()),
('Add Category', 'content:category:add', 'button', 7, NULL, NULL, 1, NOW(), NOW()),
('Edit Category', 'content:category:edit', 'button', 7, NULL, NULL, 2, NOW(), NOW()),
('Delete Category', 'content:category:delete', 'button', 7, NULL, NULL, 3, NOW(), NOW()),
('Tag Management', 'content:tag', 'menu', 2, '/content/tag', 'el-icon-collection-tag', 3, NOW(), NOW()),
('Add Tag', 'content:tag:add', 'button', 11, NULL, NULL, 1, NOW(), NOW()),
('Edit Tag', 'content:tag:edit', 'button', 11, NULL, NULL, 2, NOW(), NOW()),
('Delete Tag', 'content:tag:delete', 'button', 11, NULL, NULL, 3, NOW(), NOW()),

-- System Management
('System Management', 'system', 'menu', 0, '/system', 'el-icon-setting', 3, NOW(), NOW()),
('User Management', 'system:user', 'menu', 15, '/system/user', 'el-icon-user', 1, NOW(), NOW()),
('Add User', 'system:user:add', 'button', 16, NULL, NULL, 1, NOW(), NOW()),
('Edit User', 'system:user:edit', 'button', 16, NULL, NULL, 2, NOW(), NOW()),
('Delete User', 'system:user:delete', 'button', 16, NULL, NULL, 3, NOW(), NOW()),
('Role Management', 'system:role', 'menu', 15, '/system/role', 'el-icon-s-custom', 2, NOW(), NOW()),
('Add Role', 'system:role:add', 'button', 20, NULL, NULL, 1, NOW(), NOW()),
('Edit Role', 'system:role:edit', 'button', 20, NULL, NULL, 2, NOW(), NOW()),
('Delete Role', 'system:role:delete', 'button', 20, NULL, NULL, 3, NOW(), NOW()),
('Permission Management', 'system:permission', 'menu', 15, '/system/permission', 'el-icon-lock', 3, NOW(), NOW()),
('Add Permission', 'system:permission:add', 'button', 24, NULL, NULL, 1, NOW(), NOW()),
('Edit Permission', 'system:permission:edit', 'button', 24, NULL, NULL, 2, NOW(), NOW()),
('Delete Permission', 'system:permission:delete', 'button', 24, NULL, NULL, 3, NOW(), NOW());

-- Assign permissions to roles
-- Admin gets all permissions
INSERT INTO sys_role_permission 
(role_id, permission_id) 
VALUES 
-- Admin permissions (all)
(1, 1), (1, 2), (1, 3), (1, 4), (1, 5), (1, 6), (1, 7), (1, 8), (1, 9), (1, 10),
(1, 11), (1, 12), (1, 13), (1, 14), (1, 15), (1, 16), (1, 17), (1, 18), (1, 19),
(1, 20), (1, 21), (1, 22), (1, 23), (1, 24), (1, 25), (1, 26), (1, 27),

-- Content Manager permissions
(2, 1), (2, 2), (2, 3), (2, 4), (2, 5), (2, 6), (2, 7), (2, 8), (2, 9), (2, 10),
(2, 11), (2, 12), (2, 13), (2, 14),

-- Editor permissions
(3, 1), (3, 2), (3, 3), (3, 4), (3, 5), (3, 7), (3, 9), (3, 11), (3, 13),

-- Viewer permissions
(4, 1), (4, 2), (4, 3), (4, 7), (4, 11);

-- Insert sample categories
INSERT INTO cms_category 
(name, description, parent_id, sort_order, icon, status, create_time, update_time, create_by) 
VALUES 
('Products', 'Product information', 0, 1, 'el-icon-goods', 'active', NOW(), NOW(), 1),
('Solutions', 'Solutions we offer', 0, 2, 'el-icon-magic-stick', 'active', NOW(), NOW(), 1),
('News', 'Latest news and updates', 0, 3, 'el-icon-news', 'active', NOW(), NOW(), 1),
('Case Studies', 'Customer case studies', 0, 4, 'el-icon-s-management', 'active', NOW(), NOW(), 1),
('About Us', 'Company information', 0, 5, 'el-icon-office-building', 'active', NOW(), NOW(), 1),
('Contact', 'Contact information', 0, 6, 'el-icon-phone', 'active', NOW(), NOW(), 1);

-- Insert sample tags
INSERT INTO cms_tag 
(name, description, color, create_time, update_time, create_by) 
VALUES 
('New', 'New content tag', '#67C23A', NOW(), NOW(), 1),
('Featured', 'Featured content tag', '#409EFF', NOW(), NOW(), 1),
('Technology', 'Technology related content', '#E6A23C', NOW(), NOW(), 1),
('Business', 'Business related content', '#F56C6C', NOW(), NOW(), 1),
('Updates', 'Content updates', '#909399', NOW(), NOW(), 1);

-- Insert sample articles
INSERT INTO cms_article 
(title, content, summary, cover_image, category_id, category_name, status, featured, author_id, author_name, publish_time, create_time, update_time, create_by, keywords, seo_description, url_alias) 
VALUES 
(
    'Welcome to Our New Website', 
    '<p>Welcome to our newly redesigned website! We are excited to introduce a more user-friendly design and improved features.</p><p>Our new website offers:</p><ul><li>Better navigation</li><li>Improved search functionality</li><li>Mobile-friendly design</li><li>Faster loading times</li></ul><p>We hope you enjoy the new experience!</p>', 
    'Welcome to our newly redesigned website with improved features and user experience', 
    '/uploads/images/welcome.jpg', 
    3, 'News', 'published', true, 1, 'Admin User', NOW(), NOW(), NOW(), 1, 
    'welcome, new website, redesign', 
    'Welcome to our newly redesigned website with improved features and user experience', 
    'welcome-new-website'
),
(
    'Our Latest Product Innovation', 
    '<p>We are proud to announce our latest product innovation that will revolutionize the industry.</p><p>Key features include:</p><ul><li>Advanced AI technology</li><li>Seamless integration</li><li>Enhanced security</li><li>User-friendly interface</li></ul><p>Contact us today to learn more about how this product can benefit your business!</p>', 
    'Introducing our revolutionary new product with advanced AI technology', 
    '/uploads/images/product.jpg', 
    1, 'Products', 'published', true, 1, 'Admin User', NOW(), NOW(), NOW(), 1, 
    'product, innovation, AI, technology', 
    'Learn about our latest product innovation featuring advanced AI technology', 
    'latest-product-innovation'
),
(
    'Industry Solutions for Modern Challenges', 
    '<p>Our comprehensive solutions address the most pressing challenges facing the industry today.</p><p>We offer tailored solutions for:</p><ul><li>Digital transformation</li><li>Cloud migration</li><li>Security enhancement</li><li>Process optimization</li></ul><p>Contact our solutions team to discuss your specific needs.</p>', 
    'Comprehensive industry solutions for digital transformation, cloud migration, and more', 
    '/uploads/images/solutions.jpg', 
    2, 'Solutions', 'published', false, 1, 'Admin User', NOW(), NOW(), NOW(), 1, 
    'solutions, digital transformation, cloud, security', 
    'Our comprehensive industry solutions address modern business challenges', 
    'industry-solutions'
),
(
    'Customer Success Story: Global Enterprises', 
    '<p>Global Enterprises achieved a 40% increase in productivity after implementing our solutions.</p><p>The challenges they faced included:</p><ul><li>Legacy systems integration</li><li>Data security concerns</li><li>Scaling operations</li></ul><p>Our approach delivered measurable results within three months of implementation.</p>', 
    'How Global Enterprises achieved a 40% productivity increase with our solutions', 
    '/uploads/images/case-study.jpg', 
    4, 'Case Studies', 'published', true, 1, 'Admin User', NOW(), NOW(), NOW(), 1, 
    'case study, success story, Global Enterprises', 
    'Learn how Global Enterprises achieved a 40% productivity increase with our solutions', 
    'global-enterprises-success'
);

-- Connect articles with tags
INSERT INTO cms_article_tag 
(article_id, tag_id, tag_name) 
VALUES 
(1, 2, 'Featured'),
(1, 5, 'Updates'),
(2, 1, 'New'),
(2, 2, 'Featured'),
(2, 3, 'Technology'),
(3, 3, 'Technology'),
(3, 4, 'Business'),
(4, 2, 'Featured'),
(4, 4, 'Business');

-- Update tag counts
UPDATE cms_tag SET article_count = (SELECT COUNT(*) FROM cms_article_tag WHERE tag_id = 1) WHERE id = 1;
UPDATE cms_tag SET article_count = (SELECT COUNT(*) FROM cms_article_tag WHERE tag_id = 2) WHERE id = 2;
UPDATE cms_tag SET article_count = (SELECT COUNT(*) FROM cms_article_tag WHERE tag_id = 3) WHERE id = 3;
UPDATE cms_tag SET article_count = (SELECT COUNT(*) FROM cms_article_tag WHERE tag_id = 4) WHERE id = 4;
UPDATE cms_tag SET article_count = (SELECT COUNT(*) FROM cms_article_tag WHERE tag_id = 5) WHERE id = 5;

-- Update category counts
UPDATE cms_category SET article_count = (SELECT COUNT(*) FROM cms_article WHERE category_id = 1) WHERE id = 1;
UPDATE cms_category SET article_count = (SELECT COUNT(*) FROM cms_article WHERE category_id = 2) WHERE id = 2;
UPDATE cms_category SET article_count = (SELECT COUNT(*) FROM cms_article WHERE category_id = 3) WHERE id = 3;
UPDATE cms_category SET article_count = (SELECT COUNT(*) FROM cms_article WHERE category_id = 4) WHERE id = 4;
UPDATE cms_category SET article_count = (SELECT COUNT(*) FROM cms_article WHERE category_id = 5) WHERE id = 5;
UPDATE cms_category SET article_count = (SELECT COUNT(*) FROM cms_article WHERE category_id = 6) WHERE id = 6;