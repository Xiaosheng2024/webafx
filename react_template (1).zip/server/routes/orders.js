const express = require('express');
const { body } = require('express-validator');
const orderController = require('../controllers/orderController');
const { validateToken, isAdmin } = require('../middleware/authMiddleware');

const router = express.Router();

// All routes require authentication
router.use(validateToken);

// GET /api/v1/orders - Get all orders with pagination
router.get('/', orderController.getAllOrders);

// GET /api/v1/orders/:id - Get order by ID
router.get('/:id', orderController.getOrderById);

// POST /api/v1/orders - Create new order
router.post(
  '/',
  [
    body('customerName').notEmpty().withMessage('Customer name is required'),
    body('customerEmail').isEmail().withMessage('Valid customer email is required'),
    body('status').isIn(['pending', 'processing', 'shipped', 'delivered', 'cancelled']).withMessage('Invalid status'),
    body('paymentStatus').isIn(['pending', 'paid', 'refunded', 'failed']).withMessage('Invalid payment status'),
    body('totalAmount').isFloat({ min: 0 }).withMessage('Total amount must be a positive number'),
    body('items').isArray().withMessage('Items must be an array'),
    body('items.*.productName').notEmpty().withMessage('Product name is required'),
    body('items.*.quantity').isInt({ min: 1 }).withMessage('Quantity must be at least 1'),
    body('items.*.unitPrice').isFloat({ min: 0 }).withMessage('Unit price must be a positive number'),
  ],
  orderController.createOrder
);

// PUT /api/v1/orders/:id - Update order
router.put(
  '/:id',
  [
    body('status').optional().isIn(['pending', 'processing', 'shipped', 'delivered', 'cancelled']).withMessage('Invalid status'),
    body('paymentStatus').optional().isIn(['pending', 'paid', 'refunded', 'failed']).withMessage('Invalid payment status'),
    body('notes').optional().isString(),
    body('shippingAddress').optional().isString(),
  ],
  orderController.updateOrder
);

// PUT /api/v1/orders/:id/status - Update order status
router.put(
  '/:id/status',
  body('status').isIn(['pending', 'processing', 'shipped', 'delivered', 'cancelled']).withMessage('Invalid status'),
  orderController.updateOrderStatus
);

// PUT /api/v1/orders/:id/payment - Update payment status
router.put(
  '/:id/payment',
  body('paymentStatus').isIn(['pending', 'paid', 'refunded', 'failed']).withMessage('Invalid payment status'),
  orderController.updatePaymentStatus
);

// GET /api/v1/orders/analytics/summary - Get orders summary statistics
router.get('/analytics/summary', orderController.getOrdersSummary);

// DELETE /api/v1/orders/:id - Delete order (admin only)
router.delete('/:id', isAdmin, orderController.deleteOrder);

module.exports = router;