const express = require('express');
const { body } = require('express-validator');
const productController = require('../controllers/productController');
const { validateToken, isEditor } = require('../middleware/authMiddleware');

const router = express.Router();

// All routes require authentication
router.use(validateToken);

// GET /api/v1/products - Get all products
router.get('/', productController.getAllProducts);

// GET /api/v1/products/:id - Get product by ID
router.get('/:id', productController.getProductById);

// POST /api/v1/products - Create new product (editor/admin only)
router.post(
  '/',
  isEditor,
  [
    body('name').notEmpty().withMessage('Name is required'),
    body('slug').notEmpty().withMessage('Slug is required'),
    body('categoryId').isInt().withMessage('Valid category ID is required'),
    body('price').isFloat({ min: 0 }).withMessage('Price must be a positive number'),
  ],
  productController.createProduct
);

// PUT /api/v1/products/:id - Update product (editor/admin only)
router.put(
  '/:id',
  isEditor,
  [
    body('name').optional().notEmpty().withMessage('Name cannot be empty'),
    body('slug').optional().notEmpty().withMessage('Slug cannot be empty'),
    body('categoryId').optional().isInt().withMessage('Category ID must be an integer'),
    body('price').optional().isFloat({ min: 0 }).withMessage('Price must be a positive number'),
  ],
  productController.updateProduct
);

// DELETE /api/v1/products/:id - Delete product (editor/admin only)
router.delete('/:id', isEditor, productController.deleteProduct);

// GET /api/v1/products/categories - Get all product categories
router.get('/categories/all', productController.getAllCategories);

// POST /api/v1/products/:id/images - Add images to product (editor/admin only)
router.post(
  '/:id/images',
  isEditor,
  [
    body('images').isArray().withMessage('Images must be an array'),
    body('images.*.imageUrl').notEmpty().withMessage('Image URL is required'),
  ],
  productController.addProductImages
);

// DELETE /api/v1/products/images/:imageId - Delete product image (editor/admin only)
router.delete('/images/:imageId', isEditor, productController.deleteProductImage);

// POST /api/v1/products/:id/specifications - Add specifications to product (editor/admin only)
router.post(
  '/:id/specifications',
  isEditor,
  [
    body('specifications').isArray().withMessage('Specifications must be an array'),
    body('specifications.*.name').notEmpty().withMessage('Specification name is required'),
    body('specifications.*.value').notEmpty().withMessage('Specification value is required'),
  ],
  productController.addProductSpecifications
);

// PUT /api/v1/products/:id/publish - Toggle product publish status (editor/admin only)
router.put(
  '/:id/publish',
  isEditor,
  body('isPublished').isBoolean().withMessage('isPublished must be a boolean'),
  productController.toggleProductPublishStatus
);

module.exports = router;