const express = require('express');
const { isAdmin } = require('../middleware/authMiddleware');
const dashboardController = require('../controllers/dashboardController');

const router = express.Router();

// GET /api/v1/dashboard/stats - Get dashboard statistics
router.get('/stats', dashboardController.getDashboardStats);

// GET /api/v1/dashboard/recent-activity - Get recent admin activity
router.get('/recent-activity', dashboardController.getRecentActivity);

// GET /api/v1/dashboard/sales - Get sales statistics
router.get('/sales', dashboardController.getSalesStats);

module.exports = router;