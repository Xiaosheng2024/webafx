const express = require('express');
const { body } = require('express-validator');
const userController = require('../controllers/userController');
const { validateToken, isAdmin } = require('../middleware/authMiddleware');

const router = express.Router();

// All routes require authentication
router.use(validateToken);

// GET /api/v1/users - Get all users
router.get('/', userController.getAllUsers);

// GET /api/v1/users/:id - Get user by ID
router.get('/:id', userController.getUserById);

// POST /api/v1/users - Create new user (admin only)
router.post(
  '/',
  isAdmin,
  [
    body('email').isEmail().withMessage('Please provide a valid email'),
    body('name').notEmpty().withMessage('Name is required'),
    body('password')
      .isLength({ min: 6 })
      .withMessage('Password must be at least 6 characters'),
    body('role').isIn(['USER', 'ADMIN', 'EDITOR']).withMessage('Invalid role'),
  ],
  userController.createUser
);

// PUT /api/v1/users/:id - Update user (admin only)
router.put(
  '/:id',
  isAdmin,
  [
    body('email').optional().isEmail().withMessage('Please provide a valid email'),
    body('name').optional().notEmpty().withMessage('Name cannot be empty'),
    body('role').optional().isIn(['USER', 'ADMIN', 'EDITOR']).withMessage('Invalid role'),
  ],
  userController.updateUser
);

// PUT /api/v1/users/:id/status - Toggle user active status (admin only)
router.put(
  '/:id/status',
  isAdmin,
  body('isActive').isBoolean().withMessage('isActive must be a boolean'),
  userController.toggleUserStatus
);

// DELETE /api/v1/users/:id - Delete user (admin only)
router.delete('/:id', isAdmin, userController.deleteUser);

module.exports = router;