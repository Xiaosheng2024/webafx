const express = require('express');
const multer = require('multer');
const path = require('path');
const fs = require('fs');
const uploadController = require('../controllers/uploadController');
const { validateToken } = require('../middleware/authMiddleware');
const config = require('../config/config');

const router = express.Router();

// Ensure uploads directory exists
const uploadsDir = path.join(__dirname, '..', config.uploadDir);
if (!fs.existsSync(uploadsDir)) {
  fs.mkdirSync(uploadsDir, { recursive: true });
}

// Configure multer for file uploads
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    // Determine subfolder based on file type
    let subFolder = 'misc';
    
    if (file.mimetype.startsWith('image/')) {
      subFolder = 'images';
    } else if (file.mimetype === 'application/pdf') {
      subFolder = 'documents';
    } else if (file.mimetype.startsWith('video/')) {
      subFolder = 'videos';
    }
    
    const destination = path.join(uploadsDir, subFolder);
    if (!fs.existsSync(destination)) {
      fs.mkdirSync(destination, { recursive: true });
    }
    
    req.uploadSubFolder = subFolder;
    cb(null, destination);
  },
  filename: (req, file, cb) => {
    // Create unique filename with timestamp and random string
    const timestamp = Date.now();
    const randomString = Math.random().toString(36).substring(2, 10);
    const fileExt = path.extname(file.originalname);
    const newFilename = `${timestamp}-${randomString}${fileExt}`;
    cb(null, newFilename);
  }
});

// File filter to restrict file types
const fileFilter = (req, file, cb) => {
  // Allowed extensions
  const allowedTypes = [
    'image/jpeg', 'image/png', 'image/gif', 'image/webp',
    'application/pdf',
    'video/mp4', 'video/mpeg', 'video/quicktime',
    'application/vnd.openxmlformats-officedocument.wordprocessingml.document', // .docx
    'application/msword', // .doc
    'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', // .xlsx
    'application/vnd.ms-excel', // .xls
    'text/csv'
  ];
  
  if (allowedTypes.includes(file.mimetype)) {
    cb(null, true);
  } else {
    cb(new Error('Invalid file type. Only images, PDFs, videos, and office documents are allowed.'), false);
  }
};

// Configure upload middleware
const upload = multer({
  storage: storage,
  fileFilter: fileFilter,
  limits: {
    fileSize: config.maxFileSize // e.g., 10MB
  }
});

// All routes require authentication
router.use(validateToken);

// POST /api/v1/upload - Upload single file
router.post('/', upload.single('file'), uploadController.uploadFile);

// POST /api/v1/upload/multiple - Upload multiple files
router.post('/multiple', upload.array('files', 10), uploadController.uploadMultipleFiles);

// DELETE /api/v1/upload - Delete file
router.delete('/', uploadController.deleteFile);

module.exports = router;