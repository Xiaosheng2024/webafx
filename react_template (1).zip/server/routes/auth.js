// routes/auth.js
const express = require('express');
const router = express.Router();

// Import controller methods
const {
  login,
  getMe,
  logout
} = require('../controllers/authController');

// Mock middleware
const protect = (req, res, next) => {
  // In a real app, this would verify the JWT token
  // For our mock, we'll just let all requests through
  next();
};

// Routes
router.post('/login', login);
router.get('/me', protect, getMe);
router.get('/logout', protect, logout);

module.exports = router;