const { PrismaClient } = require('@prisma/client');
const logger = require('../utils/logger');

const prisma = new PrismaClient();

// Connect to database
const connectDB = async () => {
  try {
    // Test the connection
    await prisma.$connect();
    logger.info('Database connected successfully');
    return prisma;
  } catch (error) {
    logger.error(`Error connecting to database: ${error.message}`);
    // Exit process with failure
    process.exit(1);
  }
};

// Disconnect from database
const disconnectDB = async () => {
  try {
    await prisma.$disconnect();
    logger.info('Database disconnected successfully');
  } catch (error) {
    logger.error(`Error disconnecting from database: ${error.message}`);
  }
};

module.exports = { prisma, connectDB, disconnectDB };