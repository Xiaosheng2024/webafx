/**
 * Utilities for formatting consistent API responses
 */

/**
 * Format a success response
 * @param {Object|Array} data - Response data
 * @param {String} message - Optional success message
 * @param {Object} meta - Optional metadata (pagination, etc)
 * @returns {Object} Formatted success response
 */
exports.formatSuccessResponse = (data, message = null, meta = null) => {
  const response = {
    success: true,
    data: data || null
  };
  
  if (message) {
    response.message = message;
  }
  
  if (meta) {
    response.meta = meta;
  }
  
  return response;
};

/**
 * Format an error response
 * @param {String} message - Error message
 * @param {String} stack - Optional error stack trace (for dev environment only)
 * @param {Object} errors - Optional validation errors object
 * @returns {Object} Formatted error response
 */
exports.formatErrorResponse = (message, stack = null, errors = null) => {
  const response = {
    success: false,
    error: {
      message: message || 'An error occurred'
    }
  };
  
  if (errors) {
    response.error.errors = errors;
  }
  
  // Include stack trace only in development environment
  if (stack && process.env.NODE_ENV === 'development') {
    response.error.stack = stack;
  }
  
  return response;
};

/**
 * Format pagination metadata
 * @param {Number} total - Total count of records
 * @param {Number} page - Current page number
 * @param {Number} limit - Records per page
 * @returns {Object} Pagination metadata
 */
exports.formatPaginationMeta = (total, page, limit) => {
  const totalPages = Math.ceil(total / limit);
  
  return {
    total,
    page,
    limit,
    totalPages,
    hasNextPage: page < totalPages,
    hasPrevPage: page > 1
  };
};