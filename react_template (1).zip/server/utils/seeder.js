const { PrismaClient } = require('@prisma/client');
const bcrypt = require('bcryptjs');
const path = require('path');
const fs = require('fs');
const logger = require('./logger');

// Initialize Prisma client
const prisma = new PrismaClient();

/**
 * Main seed function
 */
async function seedDatabase() {
  try {
    logger.info('Starting database seeding...');
    
    // Create default admin user
    const adminUser = await createAdminUser();
    logger.info(`Created admin user: ${adminUser.email}`);
    
    // Create product categories
    const categories = await createProductCategories();
    logger.info(`Created ${categories.length} product categories`);
    
    // Create tags
    const tags = await createTags();
    logger.info(`Created ${tags.length} tags`);
    
    // Create products
    const products = await createSampleProducts(categories, tags);
    logger.info(`Created ${products.length} sample products`);
    
    // Create sample orders
    const orders = await createSampleOrders(products);
    logger.info(`Created ${orders.length} sample orders`);
    
    // Create site settings
    await createSiteSettings();
    logger.info('Created site settings');
    
    logger.info('Database seeding completed successfully!');
  } catch (error) {
    logger.error(`Error seeding database: ${error.message}`);
    console.error(error);
  } finally {
    await prisma.$disconnect();
  }
}

/**
 * Create default admin user
 */
async function createAdminUser() {
  // Hash password
  const hashedPassword = await bcrypt.hash('admin123', 10);
  
  // Check if admin already exists
  const existingAdmin = await prisma.user.findUnique({
    where: { email: 'admin@example.com' }
  });
  
  if (existingAdmin) {
    return existingAdmin;
  }
  
  // Create admin user
  return await prisma.user.create({
    data: {
      email: 'admin@example.com',
      name: '管理员',
      password: hashedPassword,
      role: 'ADMIN',
      isActive: true
    }
  });
}

/**
 * Create product categories
 */
async function createProductCategories() {
  const categories = [
    {
      name: '扫描设备',
      slug: 'scanning-equipment',
      description: '高级扫描解决方案，适用于各种行业应用',
      imageUrl: '/uploads/images/category-scanning.jpg'
    },
    {
      name: '打印设备',
      slug: 'printing-equipment',
      description: '专业环境下的高质量打印解决方案',
      imageUrl: '/uploads/images/category-printing.jpg'
    },
    {
      name: '软件与服务器',
      slug: 'software-servers',
      description: '数据管理的软件解决方案和服务器系统',
      imageUrl: '/uploads/images/category-software.jpg'
    },
    {
      name: '集成解决方案',
      slug: 'integrated-solutions',
      description: '全面的综合包装和处理解决方案',
      imageUrl: '/uploads/images/category-solutions.jpg'
    }
  ];
  
  const createdCategories = [];
  
  for (const category of categories) {
    // Check if category already exists
    const existingCategory = await prisma.productCategory.findUnique({
      where: { slug: category.slug }
    });
    
    if (existingCategory) {
      createdCategories.push(existingCategory);
      continue;
    }
    
    // Create category
    const createdCategory = await prisma.productCategory.create({
      data: category
    });
    
    createdCategories.push(createdCategory);
    
    // Create subcategories for Scanning Equipment
    if (category.slug === 'scanning-equipment') {
      const scanningSubcategories = [
        {
          name: '条码扫描器',
          slug: 'barcode-scanners',
          description: '1D和2D条码扫描设备',
          parentId: createdCategory.id
        },
        {
          name: '文档扫描器',
          slug: 'document-scanners',
          description: '用于文档数字化的高分辨率扫描仪',
          parentId: createdCategory.id
        }
      ];
      
      for (const subCategory of scanningSubcategories) {
        const existingSubCategory = await prisma.productCategory.findUnique({
          where: { slug: subCategory.slug }
        });
        
        if (!existingSubCategory) {
          const createdSubCategory = await prisma.productCategory.create({
            data: subCategory
          });
          createdCategories.push(createdSubCategory);
        }
      }
    }
    
    // Create subcategories for Printing Equipment
    if (category.slug === 'printing-equipment') {
      const printingSubcategories = [
        {
          name: '标签打印机',
          slug: 'label-printers',
          description: '工业和商业标签打印解决方案',
          parentId: createdCategory.id
        },
        {
          name: '收据打印机',
          slug: 'receipt-printers',
          description: '销售点收据打印设备',
          parentId: createdCategory.id
        }
      ];
      
      for (const subCategory of printingSubcategories) {
        const existingSubCategory = await prisma.productCategory.findUnique({
          where: { slug: subCategory.slug }
        });
        
        if (!existingSubCategory) {
          const createdSubCategory = await prisma.productCategory.create({
            data: subCategory
          });
          createdCategories.push(createdSubCategory);
        }
      }
    }
  }
  
  return createdCategories;
}

/**
 * Create tags
 */
async function createTags() {
  const tagNames = [
    { name: '条码', slug: 'barcode' },
    { name: 'QR码', slug: 'qr-code' },
    { name: 'RFID', slug: 'rfid' },
    { name: '移动扫描', slug: 'mobile-scanning' },
    { name: '标签打印', slug: 'label-printing' },
    { name: '工业', slug: 'industrial' },
    { name: '零售', slug: 'retail' },
    { name: '仓库', slug: 'warehouse' },
    { name: '医疗', slug: 'healthcare' },
    { name: '物流', slug: 'logistics' }
  ];
  
  const createdTags = [];
  
  for (const tag of tagNames) {
    // Check if tag already exists
    const existingTag = await prisma.tag.findUnique({
      where: { slug: tag.slug }
    });
    
    if (existingTag) {
      createdTags.push(existingTag);
      continue;
    }
    
    // Create tag
    const createdTag = await prisma.tag.create({
      data: tag
    });
    
    createdTags.push(createdTag);
  }
  
  return createdTags;
}

/**
 * Create sample products
 */
async function createSampleProducts(categories, tags) {
  // Find barcode scanners category
  const barcodeScannerCategory = categories.find(c => c.slug === 'barcode-scanners') || 
    (await prisma.productCategory.findFirst({ where: { slug: 'barcode-scanners' } }));
  
  // Find label printers category
  const labelPrinterCategory = categories.find(c => c.slug === 'label-printers') || 
    (await prisma.productCategory.findFirst({ where: { slug: 'label-printers' } }));
    
  // Find relevant tags
  const barcodeTag = tags.find(t => t.slug === 'barcode') || (await prisma.tag.findUnique({ where: { slug: 'barcode' } }));
  const retailTag = tags.find(t => t.slug === 'retail') || (await prisma.tag.findUnique({ where: { slug: 'retail' } }));
  const warehouseTag = tags.find(t => t.slug === 'warehouse') || (await prisma.tag.findUnique({ where: { slug: 'warehouse' } }));
  const labelTag = tags.find(t => t.slug === 'label-printing') || (await prisma.tag.findUnique({ where: { slug: 'label-printing' } }));
  
  const sampleProducts = [
    {
      name: 'ProScan X1 手持扫描器',
      slug: 'proscan-x1-handheld-scanner',
      description: '专业手持条码扫描器，具有先进的扫描功能。适用于零售和仓库环境。',
      categoryId: barcodeScannerCategory?.id || categories[0].id,
      price: 1299.99,
      sku: 'SCN-X1-001',
      stockQuantity: 50,
      isPublished: true,
      images: [
        {
          imageUrl: '/uploads/images/proscan-x1-1.jpg',
          altText: 'ProScan X1 正面视图'
        },
        {
          imageUrl: '/uploads/images/proscan-x1-2.jpg',
          altText: 'ProScan X1 侧面视图'
        }
      ],
      specifications: [
        {
          group: '物理特性',
          name: '尺寸',
          value: '16 x 7 x 4',
          unit: 'cm'
        },
        {
          group: '物理特性',
          name: '重量',
          value: '235',
          unit: 'g'
        },
        {
          group: '性能',
          name: '扫描速率',
          value: '100',
          unit: '扫描/秒'
        },
        {
          group: '性能',
          name: '读取距离',
          value: '0.5-30',
          unit: 'cm'
        },
        {
          group: '连接',
          name: '接口',
          value: 'USB, 蓝牙 5.0',
          unit: ''
        }
      ],
      tags: [barcodeTag?.id, retailTag?.id, warehouseTag?.id].filter(Boolean)
    },
    {
      name: 'LabelPro 320 标签打印机',
      slug: 'labelpro-320-printer',
      description: '高速工业级标签打印机，适用于仓库和物流环境。打印清晰、耐用的标签，支持多种标签尺寸。',
      categoryId: labelPrinterCategory?.id || categories[1].id,
      price: 3499.99,
      sku: 'LBP-320',
      stockQuantity: 25,
      isPublished: true,
      images: [
        {
          imageUrl: '/uploads/images/labelpro-320-1.jpg',
          altText: 'LabelPro 320 正面视图'
        }
      ],
      specifications: [
        {
          group: '打印特性',
          name: '打印分辨率',
          value: '300',
          unit: 'DPI'
        },
        {
          group: '打印特性',
          name: '打印速度',
          value: '最高 8',
          unit: '英寸/秒'
        },
        {
          group: '物理特性',
          name: '尺寸',
          value: '28 x 21 x 18',
          unit: 'cm'
        },
        {
          group: '连接',
          name: '接口',
          value: 'USB, 以太网, 蓝牙',
          unit: ''
        }
      ],
      tags: [labelTag?.id, warehouseTag?.id].filter(Boolean)
    }
  ];
  
  const createdProducts = [];
  
  for (const productData of sampleProducts) {
    // Extract tags and images before creating product
    const { images, specifications, tags: productTags, ...productBasicData } = productData;
    
    // Check if product already exists
    const existingProduct = await prisma.product.findUnique({
      where: { slug: productBasicData.slug }
    });
    
    if (existingProduct) {
      createdProducts.push(existingProduct);
      continue;
    }
    
    // Add timestamp for publishDate if published
    if (productBasicData.isPublished) {
      productBasicData.publishDate = new Date();
    }
    
    // Create product
    const createdProduct = await prisma.product.create({
      data: productBasicData
    });
    
    // Add images
    if (images && images.length > 0) {
      await prisma.productImage.createMany({
        data: images.map((image, index) => ({
          productId: createdProduct.id,
          imageUrl: image.imageUrl,
          altText: image.altText || productBasicData.name,
          displayOrder: index + 1
        }))
      });
      
      // Set the first image as featured image if not already set
      if (!createdProduct.featuredImageUrl) {
        await prisma.product.update({
          where: { id: createdProduct.id },
          data: { featuredImageUrl: images[0].imageUrl }
        });
      }
    }
    
    // Add specifications
    if (specifications && specifications.length > 0) {
      await prisma.specification.createMany({
        data: specifications.map((spec, index) => ({
          productId: createdProduct.id,
          group: spec.group,
          name: spec.name,
          value: spec.value,
          unit: spec.unit,
          displayOrder: index + 1
        }))
      });
    }
    
    // Add tags
    if (productTags && productTags.length > 0) {
      for (const tagId of productTags) {
        await prisma.tagsOnProducts.create({
          data: {
            productId: createdProduct.id,
            tagId: tagId
          }
        });
      }
    }
    
    createdProducts.push(createdProduct);
  }
  
  return createdProducts;
}

/**
 * Create sample orders
 */
async function createSampleOrders(products) {
  const orderStatuses = ['pending', 'processing', 'shipped', 'delivered', 'cancelled'];
  const paymentStatuses = ['pending', 'paid', 'refunded', 'failed'];
  
  const sampleOrders = [
    {
      customerName: '张三',
      customerEmail: 'zhangsan@example.com',
      customerPhone: '13800138000',
      company: '未来科技有限公司',
      status: 'delivered',
      totalAmount: 1299.99,
      paymentStatus: 'paid',
      shippingAddress: '上海市浦东新区陆家嘴金融中心88号',
      notes: '周一至周五上班时间送货',
      items: [
        {
          productName: 'ProScan X1 手持扫描器',
          sku: 'SCN-X1-001',
          quantity: 1,
          unitPrice: 1299.99
        }
      ]
    },
    {
      customerName: '李四',
      customerEmail: 'lisi@example.com',
      customerPhone: '13900139000',
      company: '创新科技公司',
      status: 'processing',
      totalAmount: 3499.99,
      paymentStatus: 'paid',
      shippingAddress: '北京市朝阳区建国门外大街甲6号',
      notes: '',
      items: [
        {
          productName: 'LabelPro 320 标签打印机',
          sku: 'LBP-320',
          quantity: 1,
          unitPrice: 3499.99
        }
      ]
    },
    {
      customerName: '王五',
      customerEmail: 'wangwu@example.com',
      customerPhone: '13700137000',
      company: '星辰物流有限公司',
      status: 'pending',
      totalAmount: 5199.96,
      paymentStatus: 'pending',
      shippingAddress: '广州市天河区天河路385号',
      notes: '需要提前预约送货',
      items: [
        {
          productName: 'ProScan X1 手持扫描器',
          sku: 'SCN-X1-001',
          quantity: 4,
          unitPrice: 1299.99
        }
      ]
    }
  ];
  
  const createdOrders = [];
  
  for (const orderData of sampleOrders) {
    const { items, ...orderBasicData } = orderData;
    
    // Generate order number
    const timestamp = new Date().getTime().toString().substring(6);
    const random = Math.floor(Math.random() * 1000).toString().padStart(3, '0');
    const orderNumber = `ORD${timestamp}${random}`;
    
    // Create order
    const createdOrder = await prisma.order.create({
      data: {
        ...orderBasicData,
        orderNumber,
        orderDate: new Date(Date.now() - Math.floor(Math.random() * 30) * 24 * 60 * 60 * 1000) // Random date within last 30 days
      }
    });
    
    // Add order items
    if (items && items.length > 0) {
      await prisma.orderItem.createMany({
        data: items.map(item => ({
          orderId: createdOrder.id,
          productName: item.productName,
          sku: item.sku,
          quantity: item.quantity,
          unitPrice: item.unitPrice,
          totalPrice: item.quantity * item.unitPrice
        }))
      });
    }
    
    createdOrders.push(createdOrder);
  }
  
  return createdOrders;
}

/**
 * Create site settings
 */
async function createSiteSettings() {
  const settings = [
    {
      key: 'site_name',
      value: '企业技术解决方案',
      group: 'general',
      description: '网站名称，显示在浏览器标题和页头'
    },
    {
      key: 'site_description',
      value: '专业扫描设备、打印解决方案和集成系统，适用于企业应用',
      group: 'general',
      description: '网站描述，用于SEO'
    },
    {
      key: 'contact_email',
      value: 'info@example.com',
      group: 'contact',
      description: '主要联系邮箱'
    },
    {
      key: 'contact_phone',
      value: '400-123-4567',
      group: 'contact',
      description: '主要联系电话'
    },
    {
      key: 'social_wechat',
      value: 'company_wechat',
      group: 'social',
      description: '公司微信账号'
    },
    {
      key: 'social_weibo',
      value: 'https://weibo.com/company',
      group: 'social',
      description: '微博链接'
    }
  ];
  
  for (const setting of settings) {
    // Check if setting already exists
    const existingSetting = await prisma.siteSetting.findUnique({
      where: { key: setting.key }
    });
    
    if (existingSetting) {
      // Update existing setting
      await prisma.siteSetting.update({
        where: { key: setting.key },
        data: setting
      });
    } else {
      // Create new setting
      await prisma.siteSetting.create({
        data: setting
      });
    }
  }
}

// Create uploads directory structure if it doesn't exist
function createUploadDirs() {
  const baseDir = path.join(__dirname, '..', 'uploads');
  const subDirs = ['images', 'documents', 'videos', 'misc'];
  
  if (!fs.existsSync(baseDir)) {
    fs.mkdirSync(baseDir, { recursive: true });
  }
  
  for (const dir of subDirs) {
    const dirPath = path.join(baseDir, dir);
    if (!fs.existsSync(dirPath)) {
      fs.mkdirSync(dirPath, { recursive: true });
    }
  }
}

// Run the seeder if this script is executed directly
if (require.main === module) {
  createUploadDirs();
  seedDatabase()
    .then(() => {
      console.log('Database seeding completed successfully!');
      process.exit(0);
    })
    .catch(error => {
      console.error('Error seeding database:', error);
      process.exit(1);
    });
}

module.exports = seedDatabase;