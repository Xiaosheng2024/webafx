// Authentication middleware for protecting routes
const jwt = require('jsonwebtoken');
const { prisma } = require('../config/db');
const config = require('../config/config');
const { formatErrorResponse } = require('../utils/responseFormatter');

/**
 * Middleware to validate JWT token
 * @param {Object} req - Express request object
 * @param {Object} res - Express response object
 * @param {Function} next - Express next function
 */
exports.validateToken = async (req, res, next) => {
  try {
    // Get token from header
    const authHeader = req.header('Authorization');
    
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return res.status(401).json(formatErrorResponse('Access denied. No token provided'));
    }

    const token = authHeader.replace('Bearer ', '');

    try {
      // Verify token
      const decoded = jwt.verify(token, config.jwtSecret);
      
      // Add user to request
      const user = await prisma.user.findUnique({
        where: { id: decoded.id },
        select: { 
          id: true, 
          name: true, 
          email: true, 
          role: true, 
          isActive: true 
        }
      });

      if (!user) {
        return res.status(401).json(formatErrorResponse('Invalid token. User not found'));
      }

      if (!user.isActive) {
        return res.status(401).json(formatErrorResponse('User account is deactivated'));
      }

      req.user = user;
      next();
    } catch (error) {
      return res.status(401).json(formatErrorResponse('Invalid token'));
    }
  } catch (error) {
    return res.status(500).json(formatErrorResponse('Server error in auth middleware'));
  }
};

/**
 * Middleware to check if user has admin role
 * @param {Object} req - Express request object
 * @param {Object} res - Express response object
 * @param {Function} next - Express next function
 */
exports.isAdmin = (req, res, next) => {
  if (req.user && req.user.role === 'ADMIN') {
    next();
  } else {
    return res.status(403).json(formatErrorResponse('Access denied. Admin privileges required'));
  }
};

/**
 * Middleware to check if user has editor role (or higher)
 * @param {Object} req - Express request object
 * @param {Object} res - Express response object
 * @param {Function} next - Express next function
 */
exports.isEditor = (req, res, next) => {
  if (req.user && (req.user.role === 'EDITOR' || req.user.role === 'ADMIN')) {
    next();
  } else {
    return res.status(403).json(formatErrorResponse('Access denied. Editor privileges required'));
  }
};