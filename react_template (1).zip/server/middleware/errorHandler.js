// Error handler middleware for consistent error responses
const logger = require('../utils/logger');
const { formatErrorResponse } = require('../utils/responseFormatter');

/**
 * Custom error handler middleware
 * @param {Error} err - Error object
 * @param {Object} req - Express request object
 * @param {Object} res - Express response object
 * @param {Function} next - Express next function
 */
exports.errorHandler = (err, req, res, next) => {
  // Log the error for server-side debugging
  logger.error(`${err.name}: ${err.message}`);
  logger.debug(err.stack);

  // Determine status code based on error type
  let statusCode = 500;
  let errorMessage = 'Server error';
  
  // Handle specific error types
  if (err.name === 'ValidationError') {
    statusCode = 400;
    errorMessage = err.message || 'Validation error';
  } else if (err.name === 'UnauthorizedError') {
    statusCode = 401;
    errorMessage = 'Unauthorized access';
  } else if (err.name === 'ForbiddenError') {
    statusCode = 403;
    errorMessage = 'Forbidden access';
  } else if (err.name === 'NotFoundError') {
    statusCode = 404;
    errorMessage = err.message || 'Resource not found';
  } else if (err.code === 'P2002') {
    // Prisma unique constraint violation
    statusCode = 409;
    errorMessage = 'Resource already exists';
  } else if (err.code === 'P2025') {
    // Prisma record not found
    statusCode = 404;
    errorMessage = 'Resource not found';
  }

  // Format the error response
  const errorResponse = formatErrorResponse(
    errorMessage,
    process.env.NODE_ENV === 'development' ? err.stack : undefined
  );

  // Send response
  res.status(statusCode).json(errorResponse);
};

/**
 * Not found handler for undefined routes
 * @param {Object} req - Express request object
 * @param {Object} res - Express response object
 */
exports.notFound = (req, res) => {
  res.status(404).json(formatErrorResponse(`Endpoint not found: ${req.originalUrl}`));
};