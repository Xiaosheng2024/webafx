// controllers/authController.js
/**
 * @desc    Login user and get token (MOCK VERSION)
 * @route   POST /api/v1/auth/login
 * @access  Public
 */
exports.login = (req, res, next) => {
  try {
    // Mock credentials for testing
    const { email, password } = req.body;
    
    // Check if email and password are provided
    if (!email || !password) {
      return res.status(400).json({
        success: false,
        message: 'Please provide email and password'
      });
    }
    
    // Mock validation (in real app, would check against database)
    if (email === 'admin@example.com' && password === 'admin123') {
      // Create token
      const token = 'mock-jwt-token-for-testing-xyz123';
      
      return res.status(200).json({
        success: true,
        message: 'Login successful',
        token,
        user: {
          id: 1,
          name: 'Admin User',
          email: 'admin@example.com',
          role: 'ADMIN'
        }
      });
    }
    
    // Invalid credentials
    return res.status(401).json({
      success: false,
      message: 'Invalid credentials'
    });
  } catch (error) {
    next(error);
  }
};

/**
 * @desc    Get current logged in user
 * @route   GET /api/v1/auth/me
 * @access  Private
 */
exports.getMe = (req, res, next) => {
  try {
    // Mock user data (in real app, would fetch from database using authenticated user ID)
    const user = {
      id: 1,
      name: 'Admin User',
      email: 'admin@example.com',
      role: 'ADMIN'
    };
    
    res.status(200).json({
      success: true,
      data: user
    });
  } catch (error) {
    next(error);
  }
};

/**
 * @desc    Logout user / clear cookie
 * @route   GET /api/v1/auth/logout
 * @access  Private
 */
exports.logout = (req, res, next) => {
  try {
    res.status(200).json({
      success: true,
      message: 'User logged out successfully'
    });
  } catch (error) {
    next(error);
  }
};