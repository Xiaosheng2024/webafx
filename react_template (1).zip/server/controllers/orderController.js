const { validationResult } = require('express-validator');
const { prisma } = require('../config/db');
const { formatSuccessResponse, formatErrorResponse, formatPaginationMeta } = require('../utils/responseFormatter');
const logger = require('../utils/logger');

/**
 * Generate a unique order number
 */
const generateOrderNumber = async () => {
  const prefix = 'ORD';
  const date = new Date().toISOString().slice(2, 10).replace(/-/g, '');
  const randomPart = Math.floor(Math.random() * 10000).toString().padStart(4, '0');
  const orderNumber = `${prefix}-${date}-${randomPart}`;
  
  // Check if the order number already exists
  const existingOrder = await prisma.order.findUnique({
    where: { orderNumber }
  });
  
  if (existingOrder) {
    // If exists, recursively try to generate a new one
    return generateOrderNumber();
  }
  
  return orderNumber;
};

/**
 * Get all orders with pagination and filtering
 * @route GET /api/v1/orders
 */
exports.getAllOrders = async (req, res) => {
  try {
    // Pagination parameters
    const page = parseInt(req.query.page) || 1;
    const limit = parseInt(req.query.limit) || 10;
    const skip = (page - 1) * limit;
    
    // Filter parameters
    const search = req.query.search;
    const status = req.query.status;
    const paymentStatus = req.query.paymentStatus;
    const fromDate = req.query.fromDate ? new Date(req.query.fromDate) : null;
    const toDate = req.query.toDate ? new Date(req.query.toDate) : null;
    const minAmount = req.query.minAmount ? parseFloat(req.query.minAmount) : null;
    const maxAmount = req.query.maxAmount ? parseFloat(req.query.maxAmount) : null;
    
    // Build filter conditions
    const where = {};
    
    if (search) {
      where.OR = [
        { orderNumber: { contains: search, mode: 'insensitive' } },
        { customerName: { contains: search, mode: 'insensitive' } },
        { customerEmail: { contains: search, mode: 'insensitive' } },
      ];
    }
    
    if (status) {
      where.status = status;
    }
    
    if (paymentStatus) {
      where.paymentStatus = paymentStatus;
    }
    
    if (fromDate || toDate) {
      where.orderDate = {};
      if (fromDate) where.orderDate.gte = fromDate;
      if (toDate) {
        // Set the end of the day for toDate
        const endOfDay = new Date(toDate);
        endOfDay.setHours(23, 59, 59, 999);
        where.orderDate.lte = endOfDay;
      }
    }
    
    if (minAmount !== null || maxAmount !== null) {
      where.totalAmount = {};
      if (minAmount !== null) where.totalAmount.gte = minAmount;
      if (maxAmount !== null) where.totalAmount.lte = maxAmount;
    }
    
    // Get total count for pagination
    const totalOrders = await prisma.order.count({ where });
    
    // Get orders with items
    const orders = await prisma.order.findMany({
      where,
      include: {
        items: true,
        _count: {
          select: {
            items: true
          }
        }
      },
      skip,
      take: limit,
      orderBy: { orderDate: 'desc' }
    });
    
    // Create pagination metadata
    const meta = formatPaginationMeta(totalOrders, page, limit);
    
    res.json(formatSuccessResponse(orders, 'Orders retrieved successfully', meta));
  } catch (error) {
    logger.error(`Error fetching orders: ${error.message}`);
    res.status(500).json(formatErrorResponse('Failed to fetch orders'));
  }
};

/**
 * Get order by ID
 * @route GET /api/v1/orders/:id
 */
exports.getOrderById = async (req, res) => {
  try {
    const orderId = parseInt(req.params.id);
    
    const order = await prisma.order.findUnique({
      where: { id: orderId },
      include: {
        items: true
      }
    });
    
    if (!order) {
      return res.status(404).json(formatErrorResponse('Order not found'));
    }
    
    res.json(formatSuccessResponse(order, 'Order retrieved successfully'));
  } catch (error) {
    logger.error(`Error fetching order: ${error.message}`);
    res.status(500).json(formatErrorResponse('Failed to fetch order'));
  }
};

/**
 * Create new order
 * @route POST /api/v1/orders
 */
exports.createOrder = async (req, res) => {
  try {
    // Validate request body
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json(formatErrorResponse('Validation error', null, errors.array()));
    }
    
    const {
      customerName,
      customerEmail,
      customerPhone,
      company,
      status,
      totalAmount,
      paymentStatus,
      shippingAddress,
      notes,
      items
    } = req.body;
    
    // Generate unique order number
    const orderNumber = await generateOrderNumber();
    
    // Create order
    const order = await prisma.order.create({
      data: {
        orderNumber,
        customerName,
        customerEmail,
        customerPhone,
        company,
        status,
        totalAmount,
        paymentStatus,
        shippingAddress,
        notes,
        items: {
          create: items.map(item => ({
            productName: item.productName,
            sku: item.sku,
            quantity: item.quantity,
            unitPrice: item.unitPrice,
            totalPrice: item.quantity * item.unitPrice,
            notes: item.notes
          }))
        }
      },
      include: {
        items: true
      }
    });
    
    // Log admin activity
    await prisma.adminActivity.create({
      data: {
        userId: req.user.id,
        action: 'created',
        entityType: 'order',
        entityId: order.id,
        details: `Created new order: ${orderNumber} for customer: ${customerName}`
      }
    });
    
    res.status(201).json(formatSuccessResponse(order, 'Order created successfully'));
  } catch (error) {
    logger.error(`Error creating order: ${error.message}`);
    res.status(500).json(formatErrorResponse('Failed to create order'));
  }
};

/**
 * Update order
 * @route PUT /api/v1/orders/:id
 */
exports.updateOrder = async (req, res) => {
  try {
    // Validate request body
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json(formatErrorResponse('Validation error', null, errors.array()));
    }
    
    const orderId = parseInt(req.params.id);
    const {
      status,
      paymentStatus,
      shippingAddress,
      notes,
    } = req.body;
    
    // Check if order exists
    const order = await prisma.order.findUnique({
      where: { id: orderId }
    });
    
    if (!order) {
      return res.status(404).json(formatErrorResponse('Order not found'));
    }
    
    // Build update data
    const updateData = {};
    if (status) updateData.status = status;
    if (paymentStatus) updateData.paymentStatus = paymentStatus;
    if (shippingAddress !== undefined) updateData.shippingAddress = shippingAddress;
    if (notes !== undefined) updateData.notes = notes;
    
    // Update order
    const updatedOrder = await prisma.order.update({
      where: { id: orderId },
      data: updateData,
      include: {
        items: true
      }
    });
    
    // Log admin activity
    await prisma.adminActivity.create({
      data: {
        userId: req.user.id,
        action: 'updated',
        entityType: 'order',
        entityId: orderId,
        details: `Updated order: ${order.orderNumber}`
      }
    });
    
    res.json(formatSuccessResponse(updatedOrder, 'Order updated successfully'));
  } catch (error) {
    logger.error(`Error updating order: ${error.message}`);
    res.status(500).json(formatErrorResponse('Failed to update order'));
  }
};

/**
 * Update order status
 * @route PUT /api/v1/orders/:id/status
 */
exports.updateOrderStatus = async (req, res) => {
  try {
    // Validate request body
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json(formatErrorResponse('Validation error', null, errors.array()));
    }
    
    const orderId = parseInt(req.params.id);
    const { status } = req.body;
    
    // Check if order exists
    const order = await prisma.order.findUnique({
      where: { id: orderId }
    });
    
    if (!order) {
      return res.status(404).json(formatErrorResponse('Order not found'));
    }
    
    // Update order status
    const updatedOrder = await prisma.order.update({
      where: { id: orderId },
      data: { status }
    });
    
    // Log admin activity
    await prisma.adminActivity.create({
      data: {
        userId: req.user.id,
        action: 'updated',
        entityType: 'order',
        entityId: orderId,
        details: `Updated order status for ${order.orderNumber} to: ${status}`
      }
    });
    
    res.json(formatSuccessResponse({
      id: updatedOrder.id,
      status: updatedOrder.status
    }, 'Order status updated successfully'));
  } catch (error) {
    logger.error(`Error updating order status: ${error.message}`);
    res.status(500).json(formatErrorResponse('Failed to update order status'));
  }
};

/**
 * Update payment status
 * @route PUT /api/v1/orders/:id/payment
 */
exports.updatePaymentStatus = async (req, res) => {
  try {
    // Validate request body
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json(formatErrorResponse('Validation error', null, errors.array()));
    }
    
    const orderId = parseInt(req.params.id);
    const { paymentStatus } = req.body;
    
    // Check if order exists
    const order = await prisma.order.findUnique({
      where: { id: orderId }
    });
    
    if (!order) {
      return res.status(404).json(formatErrorResponse('Order not found'));
    }
    
    // Update payment status
    const updatedOrder = await prisma.order.update({
      where: { id: orderId },
      data: { paymentStatus }
    });
    
    // Log admin activity
    await prisma.adminActivity.create({
      data: {
        userId: req.user.id,
        action: 'updated',
        entityType: 'order',
        entityId: orderId,
        details: `Updated payment status for ${order.orderNumber} to: ${paymentStatus}`
      }
    });
    
    res.json(formatSuccessResponse({
      id: updatedOrder.id,
      paymentStatus: updatedOrder.paymentStatus
    }, 'Payment status updated successfully'));
  } catch (error) {
    logger.error(`Error updating payment status: ${error.message}`);
    res.status(500).json(formatErrorResponse('Failed to update payment status'));
  }
};

/**
 * Get orders summary statistics
 * @route GET /api/v1/orders/analytics/summary
 */
exports.getOrdersSummary = async (req, res) => {
  try {
    // Get total orders count
    const totalOrders = await prisma.order.count();
    
    // Get orders by status
    const ordersByStatus = await prisma.order.groupBy({
      by: ['status'],
      _count: { _all: true },
      _sum: { totalAmount: true }
    });
    
    // Format orders by status
    const formattedOrdersByStatus = ordersByStatus.map(item => ({
      status: item.status,
      count: item._count._all,
      amount: item._sum.totalAmount
    }));
    
    // Get orders by payment status
    const ordersByPaymentStatus = await prisma.order.groupBy({
      by: ['paymentStatus'],
      _count: { _all: true },
      _sum: { totalAmount: true }
    });
    
    // Format orders by payment status
    const formattedOrdersByPaymentStatus = ordersByPaymentStatus.map(item => ({
      status: item.paymentStatus,
      count: item._count._all,
      amount: item._sum.totalAmount
    }));
    
    // Get total sales amount
    const totalSalesResult = await prisma.$queryRaw`
      SELECT SUM(total_amount) as totalSales FROM orders WHERE payment_status = 'paid'
    `;
    const totalSales = parseFloat(totalSalesResult[0]?.totalSales || 0);
    
    // Get monthly orders for the past year
    const oneYearAgo = new Date();
    oneYearAgo.setFullYear(oneYearAgo.getFullYear() - 1);
    
    const monthlyOrdersData = await prisma.$queryRaw`
      SELECT 
        date_trunc('month', order_date) as month,
        count(*) as count,
        sum(total_amount) as amount
      FROM orders
      WHERE order_date >= ${oneYearAgo}
      GROUP BY month
      ORDER BY month ASC
    `;
    
    // Format monthly orders data
    const monthlyOrders = monthlyOrdersData.map(item => ({
      month: new Date(item.month).toISOString().substring(0, 7),
      count: Number(item.count),
      amount: parseFloat(item.amount)
    }));
    
    res.json(formatSuccessResponse({
      totalOrders,
      totalSales,
      ordersByStatus: formattedOrdersByStatus,
      ordersByPaymentStatus: formattedOrdersByPaymentStatus,
      monthlyOrders
    }, 'Orders summary retrieved successfully'));
  } catch (error) {
    logger.error(`Error fetching orders summary: ${error.message}`);
    res.status(500).json(formatErrorResponse('Failed to fetch orders summary'));
  }
};

/**
 * Delete order
 * @route DELETE /api/v1/orders/:id
 */
exports.deleteOrder = async (req, res) => {
  try {
    const orderId = parseInt(req.params.id);
    
    // Check if order exists
    const order = await prisma.order.findUnique({
      where: { id: orderId }
    });
    
    if (!order) {
      return res.status(404).json(formatErrorResponse('Order not found'));
    }
    
    // Delete order (Prisma will cascade delete order items)
    await prisma.order.delete({
      where: { id: orderId }
    });
    
    // Log admin activity
    await prisma.adminActivity.create({
      data: {
        userId: req.user.id,
        action: 'deleted',
        entityType: 'order',
        entityId: orderId,
        details: `Deleted order: ${order.orderNumber}`
      }
    });
    
    res.json(formatSuccessResponse(null, 'Order deleted successfully'));
  } catch (error) {
    logger.error(`Error deleting order: ${error.message}`);
    res.status(500).json(formatErrorResponse('Failed to delete order'));
  }
};