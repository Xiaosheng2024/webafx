const { prisma } = require('../config/db');
const { formatSuccessResponse, formatErrorResponse } = require('../utils/responseFormatter');
const logger = require('../utils/logger');

/**
 * Get dashboard statistics
 * @route GET /api/v1/dashboard/stats
 */
exports.getDashboardStats = async (req, res) => {
  try {
    // Get product count
    const totalProducts = await prisma.product.count();
    
    // Get order count
    const totalOrders = await prisma.order.count();
    
    // Get user count
    const totalUsers = await prisma.user.count({
      where: { role: 'USER' }
    });
    
    // Get recent orders
    const recentOrders = await prisma.order.findMany({
      take: 5,
      orderBy: {
        orderDate: 'desc'
      },
      include: {
        items: true
      }
    });
    
    // Format recent orders for the dashboard
    const formattedRecentOrders = recentOrders.map(order => ({
      id: order.id,
      orderNumber: order.orderNumber,
      customer: order.customerName,
      products: order.items.map(item => item.productName).join(', '),
      amount: order.totalAmount,
      status: order.status,
      date: order.orderDate.toISOString().split('T')[0]
    }));
    
    // Get product categories distribution
    const categories = await prisma.productCategory.findMany({
      include: {
        _count: {
          select: { products: true }
        }
      }
    });
    
    const productCategories = categories.map(category => ({
      name: category.name,
      value: category._count.products
    }));
    
    // Get monthly sales data for the past 6 months
    const today = new Date();
    const sixMonthsAgo = new Date(today.getFullYear(), today.getMonth() - 5, 1);
    
    // Aggregate monthly sales
    const monthlySalesData = await prisma.$queryRaw`
      SELECT 
        date_trunc('month', order_date) as month,
        sum(total_amount) as sales
      FROM orders
      WHERE order_date >= ${sixMonthsAgo}
      GROUP BY month
      ORDER BY month ASC
    `;
    
    // Format monthly sales for the dashboard
    const monthNames = ['1月', '2月', '3月', '4月', '5月', '6月', '7月', '8月', '9月', '10月', '11月', '12月'];
    const monthlySales = monthlySalesData.map(item => ({
      name: monthNames[new Date(item.month).getMonth()],
      sales: parseFloat(item.sales)
    }));
    
    // Return dashboard stats
    res.json(formatSuccessResponse({
      totalProducts,
      totalOrders,
      totalUsers,
      recentOrders: formattedRecentOrders,
      productCategories,
      monthlySales
    }));
  } catch (error) {
    logger.error(`Error fetching dashboard stats: ${error.message}`);
    res.status(500).json(formatErrorResponse('Failed to fetch dashboard statistics'));
  }
};

/**
 * Get recent admin activity
 * @route GET /api/v1/dashboard/recent-activity
 */
exports.getRecentActivity = async (req, res) => {
  try {
    const recentActivity = await prisma.adminActivity.findMany({
      take: 20,
      orderBy: {
        createdAt: 'desc'
      },
      include: {
        user: {
          select: {
            name: true,
            email: true
          }
        }
      }
    });
    
    res.json(formatSuccessResponse(recentActivity));
  } catch (error) {
    logger.error(`Error fetching recent activity: ${error.message}`);
    res.status(500).json(formatErrorResponse('Failed to fetch recent activity'));
  }
};

/**
 * Get sales statistics
 * @route GET /api/v1/dashboard/sales
 */
exports.getSalesStats = async (req, res) => {
  try {
    // Get total sales amount
    const salesResult = await prisma.$queryRaw`
      SELECT SUM(total_amount) as totalSales FROM orders
    `;
    const totalSales = parseFloat(salesResult[0]?.totalSales || 0);
    
    // Get sales data by status
    const salesByStatus = await prisma.order.groupBy({
      by: ['status'],
      _sum: {
        totalAmount: true
      },
      _count: {
        id: true
      }
    });
    
    // Format sales by status
    const formattedSalesByStatus = salesByStatus.map(item => ({
      status: item.status,
      count: item._count.id,
      amount: item._sum.totalAmount
    }));
    
    // Get daily sales for the past 30 days
    const thirtyDaysAgo = new Date();
    thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);
    
    const dailySales = await prisma.$queryRaw`
      SELECT 
        DATE(order_date) as date,
        SUM(total_amount) as amount,
        COUNT(*) as count
      FROM orders
      WHERE order_date >= ${thirtyDaysAgo}
      GROUP BY DATE(order_date)
      ORDER BY date ASC
    `;
    
    res.json(formatSuccessResponse({
      totalSales,
      salesByStatus: formattedSalesByStatus,
      dailySales
    }));
  } catch (error) {
    logger.error(`Error fetching sales stats: ${error.message}`);
    res.status(500).json(formatErrorResponse('Failed to fetch sales statistics'));
  }
};