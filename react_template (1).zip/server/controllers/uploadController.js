const fs = require('fs').promises;
const path = require('path');
const { formatSuccessResponse, formatErrorResponse } = require('../utils/responseFormatter');
const logger = require('../utils/logger');
const config = require('../config/config');

/**
 * Upload a single file
 * @route POST /api/v1/upload
 */
exports.uploadFile = async (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json(formatErrorResponse('No file uploaded'));
    }

    // Get uploaded file details
    const { filename, originalname, mimetype, size } = req.file;
    const subFolder = req.uploadSubFolder || 'misc';
    const filePath = `/uploads/${subFolder}/${filename}`;

    // Log admin activity
    const prisma = req.app.locals.prisma;
    await prisma.adminActivity.create({
      data: {
        userId: req.user.id,
        action: 'uploaded',
        entityType: 'file',
        details: `Uploaded file: ${originalname} (${filePath})`
      }
    });

    // Return file details
    res.status(201).json(formatSuccessResponse({
      filename,
      originalName: originalname,
      mimetype,
      size,
      path: filePath
    }, 'File uploaded successfully'));
  } catch (error) {
    logger.error(`File upload error: ${error.message}`);
    res.status(500).json(formatErrorResponse('Failed to upload file'));
  }
};

/**
 * Upload multiple files
 * @route POST /api/v1/upload/multiple
 */
exports.uploadMultipleFiles = async (req, res) => {
  try {
    if (!req.files || req.files.length === 0) {
      return res.status(400).json(formatErrorResponse('No files uploaded'));
    }

    // Process uploaded files
    const uploadedFiles = req.files.map(file => {
      const subFolder = req.uploadSubFolder || 'misc';
      return {
        filename: file.filename,
        originalName: file.originalname,
        mimetype: file.mimetype,
        size: file.size,
        path: `/uploads/${subFolder}/${file.filename}`
      };
    });

    // Log admin activity
    const prisma = req.app.locals.prisma;
    await prisma.adminActivity.create({
      data: {
        userId: req.user.id,
        action: 'uploaded',
        entityType: 'files',
        details: `Uploaded ${uploadedFiles.length} files`
      }
    });

    // Return files details
    res.status(201).json(formatSuccessResponse(
      uploadedFiles,
      `${uploadedFiles.length} files uploaded successfully`
    ));
  } catch (error) {
    logger.error(`Multiple file upload error: ${error.message}`);
    res.status(500).json(formatErrorResponse('Failed to upload files'));
  }
};

/**
 * Delete a file
 * @route DELETE /api/v1/upload
 */
exports.deleteFile = async (req, res) => {
  try {
    const { filePath } = req.body;
    
    if (!filePath) {
      return res.status(400).json(formatErrorResponse('File path is required'));
    }

    // Validate file path for security
    const normalizedPath = path.normalize(filePath).replace(/^(\.\.(\/|\\|$))+/, '');
    const isPathValid = normalizedPath.startsWith('/uploads/');

    if (!isPathValid) {
      return res.status(400).json(formatErrorResponse('Invalid file path'));
    }

    // Remove the leading slash and get full path
    const relativePath = normalizedPath.substring(1); // Remove leading slash
    const fullPath = path.join(__dirname, '..', relativePath);
    
    // Check if file exists
    try {
      await fs.access(fullPath);
    } catch (error) {
      return res.status(404).json(formatErrorResponse('File not found'));
    }

    // Delete the file
    await fs.unlink(fullPath);

    // Log admin activity
    const prisma = req.app.locals.prisma;
    await prisma.adminActivity.create({
      data: {
        userId: req.user.id,
        action: 'deleted',
        entityType: 'file',
        details: `Deleted file: ${filePath}`
      }
    });

    res.json(formatSuccessResponse(null, 'File deleted successfully'));
  } catch (error) {
    logger.error(`File deletion error: ${error.message}`);
    res.status(500).json(formatErrorResponse('Failed to delete file'));
  }
};