const { validationResult } = require('express-validator');
const bcrypt = require('bcryptjs');
const { prisma } = require('../config/db');
const { formatSuccessResponse, formatErrorResponse, formatPaginationMeta } = require('../utils/responseFormatter');
const logger = require('../utils/logger');

/**
 * Get all users with pagination
 * @route GET /api/v1/users
 */
exports.getAllUsers = async (req, res) => {
  try {
    // Pagination parameters
    const page = parseInt(req.query.page) || 1;
    const limit = parseInt(req.query.limit) || 10;
    const skip = (page - 1) * limit;
    
    // Search parameters
    const search = req.query.search;
    const role = req.query.role;
    
    // Build filter conditions
    const where = {};
    
    if (search) {
      where.OR = [
        { name: { contains: search, mode: 'insensitive' } },
        { email: { contains: search, mode: 'insensitive' } }
      ];
    }
    
    if (role) {
      where.role = role;
    }
    
    // Get total count for pagination
    const totalUsers = await prisma.user.count({ where });
    
    // Get users
    const users = await prisma.user.findMany({
      where,
      select: {
        id: true,
        name: true,
        email: true,
        role: true,
        isActive: true,
        createdAt: true,
        _count: {
          select: { articles: true }
        }
      },
      skip,
      take: limit,
      orderBy: { createdAt: 'desc' }
    });
    
    // Format users with article count
    const formattedUsers = users.map(user => ({
      id: user.id,
      name: user.name,
      email: user.email,
      role: user.role,
      isActive: user.isActive,
      createdAt: user.createdAt,
      articleCount: user._count.articles
    }));
    
    // Create pagination metadata
    const meta = formatPaginationMeta(totalUsers, page, limit);
    
    res.json(formatSuccessResponse(formattedUsers, 'Users retrieved successfully', meta));
  } catch (error) {
    logger.error(`Error fetching users: ${error.message}`);
    res.status(500).json(formatErrorResponse('Failed to fetch users'));
  }
};

/**
 * Get user by ID
 * @route GET /api/v1/users/:id
 */
exports.getUserById = async (req, res) => {
  try {
    const userId = parseInt(req.params.id);
    
    const user = await prisma.user.findUnique({
      where: { id: userId },
      select: {
        id: true,
        name: true,
        email: true,
        role: true,
        isActive: true,
        createdAt: true,
        updatedAt: true,
        _count: {
          select: {
            articles: true,
            caseStudies: true,
            activities: true
          }
        },
        activities: {
          take: 10,
          orderBy: { createdAt: 'desc' }
        }
      }
    });
    
    if (!user) {
      return res.status(404).json(formatErrorResponse('User not found'));
    }
    
    // Format user data
    const formattedUser = {
      id: user.id,
      name: user.name,
      email: user.email,
      role: user.role,
      isActive: user.isActive,
      createdAt: user.createdAt,
      updatedAt: user.updatedAt,
      stats: {
        articles: user._count.articles,
        caseStudies: user._count.caseStudies,
        activities: user._count.activities
      },
      recentActivities: user.activities
    };
    
    res.json(formatSuccessResponse(formattedUser, 'User retrieved successfully'));
  } catch (error) {
    logger.error(`Error fetching user: ${error.message}`);
    res.status(500).json(formatErrorResponse('Failed to fetch user'));
  }
};

/**
 * Create new user
 * @route POST /api/v1/users
 */
exports.createUser = async (req, res) => {
  try {
    // Validate request body
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json(formatErrorResponse('Validation error', null, errors.array()));
    }
    
    const { email, name, password, role } = req.body;
    
    // Check if user already exists
    const existingUser = await prisma.user.findUnique({
      where: { email }
    });
    
    if (existingUser) {
      return res.status(400).json(formatErrorResponse('User with this email already exists'));
    }
    
    // Hash password
    const salt = await bcrypt.genSalt(10);
    const hashedPassword = await bcrypt.hash(password, salt);
    
    // Create new user
    const newUser = await prisma.user.create({
      data: {
        email,
        name,
        password: hashedPassword,
        role,
        isActive: true
      }
    });
    
    // Log admin activity
    await prisma.adminActivity.create({
      data: {
        userId: req.user.id,
        action: 'created',
        entityType: 'user',
        entityId: newUser.id,
        details: `Created new ${role} user: ${email}`
      }
    });
    
    // Return success response without password
    res.status(201).json(formatSuccessResponse({
      id: newUser.id,
      name: newUser.name,
      email: newUser.email,
      role: newUser.role,
      isActive: newUser.isActive,
      createdAt: newUser.createdAt
    }, 'User created successfully'));
  } catch (error) {
    logger.error(`Error creating user: ${error.message}`);
    res.status(500).json(formatErrorResponse('Failed to create user'));
  }
};

/**
 * Update user
 * @route PUT /api/v1/users/:id
 */
exports.updateUser = async (req, res) => {
  try {
    // Validate request body
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json(formatErrorResponse('Validation error', null, errors.array()));
    }
    
    const userId = parseInt(req.params.id);
    const { email, name, role } = req.body;
    
    // Check if user exists
    const user = await prisma.user.findUnique({
      where: { id: userId }
    });
    
    if (!user) {
      return res.status(404).json(formatErrorResponse('User not found'));
    }
    
    // Check if email is already in use by another user
    if (email && email !== user.email) {
      const existingUser = await prisma.user.findUnique({
        where: { email }
      });
      
      if (existingUser) {
        return res.status(400).json(formatErrorResponse('Email is already in use by another user'));
      }
    }
    
    // Build update data
    const updateData = {};
    if (email) updateData.email = email;
    if (name) updateData.name = name;
    if (role) updateData.role = role;
    
    // Update user
    const updatedUser = await prisma.user.update({
      where: { id: userId },
      data: updateData
    });
    
    // Log admin activity
    await prisma.adminActivity.create({
      data: {
        userId: req.user.id,
        action: 'updated',
        entityType: 'user',
        entityId: userId,
        details: `Updated user: ${updatedUser.email}`
      }
    });
    
    // Return updated user without password
    res.json(formatSuccessResponse({
      id: updatedUser.id,
      name: updatedUser.name,
      email: updatedUser.email,
      role: updatedUser.role,
      isActive: updatedUser.isActive,
      updatedAt: updatedUser.updatedAt
    }, 'User updated successfully'));
  } catch (error) {
    logger.error(`Error updating user: ${error.message}`);
    res.status(500).json(formatErrorResponse('Failed to update user'));
  }
};

/**
 * Toggle user active status
 * @route PUT /api/v1/users/:id/status
 */
exports.toggleUserStatus = async (req, res) => {
  try {
    // Validate request body
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json(formatErrorResponse('Validation error', null, errors.array()));
    }
    
    const userId = parseInt(req.params.id);
    const { isActive } = req.body;
    
    // Check if user exists
    const user = await prisma.user.findUnique({
      where: { id: userId }
    });
    
    if (!user) {
      return res.status(404).json(formatErrorResponse('User not found'));
    }
    
    // Prevent deactivating your own account
    if (userId === req.user.id && isActive === false) {
      return res.status(400).json(formatErrorResponse('Cannot deactivate your own account'));
    }
    
    // Update user status
    const updatedUser = await prisma.user.update({
      where: { id: userId },
      data: { isActive }
    });
    
    // Log admin activity
    await prisma.adminActivity.create({
      data: {
        userId: req.user.id,
        action: 'updated',
        entityType: 'user',
        entityId: userId,
        details: `${isActive ? 'Activated' : 'Deactivated'} user: ${updatedUser.email}`
      }
    });
    
    res.json(formatSuccessResponse({
      id: updatedUser.id,
      isActive: updatedUser.isActive
    }, `User ${isActive ? 'activated' : 'deactivated'} successfully`));
  } catch (error) {
    logger.error(`Error toggling user status: ${error.message}`);
    res.status(500).json(formatErrorResponse('Failed to update user status'));
  }
};

/**
 * Delete user
 * @route DELETE /api/v1/users/:id
 */
exports.deleteUser = async (req, res) => {
  try {
    const userId = parseInt(req.params.id);
    
    // Check if user exists
    const user = await prisma.user.findUnique({
      where: { id: userId }
    });
    
    if (!user) {
      return res.status(404).json(formatErrorResponse('User not found'));
    }
    
    // Prevent deleting your own account
    if (userId === req.user.id) {
      return res.status(400).json(formatErrorResponse('Cannot delete your own account'));
    }
    
    // Delete user
    await prisma.user.delete({
      where: { id: userId }
    });
    
    // Log admin activity
    await prisma.adminActivity.create({
      data: {
        userId: req.user.id,
        action: 'deleted',
        entityType: 'user',
        entityId: userId,
        details: `Deleted user: ${user.email}`
      }
    });
    
    res.json(formatSuccessResponse(null, 'User deleted successfully'));
  } catch (error) {
    logger.error(`Error deleting user: ${error.message}`);
    
    // Handle reference constraints
    if (error.code === 'P2003') {
      return res.status(400).json(formatErrorResponse('Cannot delete user because it is referenced by other records'));
    }
    
    res.status(500).json(formatErrorResponse('Failed to delete user'));
  }
};