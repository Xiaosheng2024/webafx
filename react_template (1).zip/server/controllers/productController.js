// Product controller for the admin panel backend
const { validationResult } = require('express-validator');
const { prisma } = require('../config/db');
const { formatSuccessResponse, formatErrorResponse, formatPaginationMeta } = require('../utils/responseFormatter');
const logger = require('../utils/logger');

/**
 * Get all products with pagination and filtering
 * @route GET /api/v1/products
 */
exports.getAllProducts = async (req, res) => {
  try {
    // Pagination parameters
    const page = parseInt(req.query.page) || 1;
    const limit = parseInt(req.query.limit) || 10;
    const skip = (page - 1) * limit;
    
    // Filter parameters
    const search = req.query.search;
    const categoryId = req.query.categoryId ? parseInt(req.query.categoryId) : undefined;
    const minPrice = req.query.minPrice ? parseFloat(req.query.minPrice) : undefined;
    const maxPrice = req.query.maxPrice ? parseFloat(req.query.maxPrice) : undefined;
    const isPublished = req.query.isPublished === 'true' ? true : 
                      req.query.isPublished === 'false' ? false : undefined;
    
    // Build filter conditions
    const where = {};
    
    if (search) {
      where.OR = [
        { name: { contains: search, mode: 'insensitive' } },
        { description: { contains: search, mode: 'insensitive' } },
        { sku: { contains: search, mode: 'insensitive' } }
      ];
    }
    
    if (categoryId) {
      where.categoryId = categoryId;
    }
    
    if (minPrice !== undefined || maxPrice !== undefined) {
      where.price = {};
      if (minPrice !== undefined) where.price.gte = minPrice;
      if (maxPrice !== undefined) where.price.lte = maxPrice;
    }
    
    if (isPublished !== undefined) {
      where.isPublished = isPublished;
    }
    
    // Get total count for pagination
    const totalProducts = await prisma.product.count({ where });
    
    // Get products with relations
    const products = await prisma.product.findMany({
      where,
      include: {
        category: {
          select: {
            id: true,
            name: true,
            slug: true
          }
        },
        images: {
          take: 1,
          orderBy: {
            displayOrder: 'asc'
          }
        },
        _count: {
          select: {
            specifications: true,
            images: true
          }
        },
        tags: {
          include: {
            tag: true
          }
        }
      },
      skip,
      take: limit,
      orderBy: { updatedAt: 'desc' }
    });
    
    // Format products for response
    const formattedProducts = products.map(product => ({
      id: product.id,
      name: product.name,
      slug: product.slug,
      description: product.description,
      sku: product.sku,
      price: product.price,
      stockQuantity: product.stockQuantity,
      isPublished: product.isPublished,
      publishDate: product.publishDate,
      featuredImageUrl: product.featuredImageUrl || (product.images.length > 0 ? product.images[0].imageUrl : null),
      createdAt: product.createdAt,
      updatedAt: product.updatedAt,
      category: product.category,
      tags: product.tags.map(pt => pt.tag),
      counts: {
        specifications: product._count.specifications,
        images: product._count.images
      }
    }));
    
    // Create pagination metadata
    const meta = formatPaginationMeta(totalProducts, page, limit);
    
    res.json(formatSuccessResponse(formattedProducts, 'Products retrieved successfully', meta));
  } catch (error) {
    logger.error(`Error fetching products: ${error.message}`);
    res.status(500).json(formatErrorResponse('Failed to fetch products'));
  }
};

/**
 * Get product by ID
 * @route GET /api/v1/products/:id
 */
exports.getProductById = async (req, res) => {
  try {
    const productId = parseInt(req.params.id);
    
    const product = await prisma.product.findUnique({
      where: { id: productId },
      include: {
        category: true,
        images: {
          orderBy: {
            displayOrder: 'asc'
          }
        },
        specifications: {
          orderBy: {
            displayOrder: 'asc'
          }
        },
        documents: true,
        videos: true,
        attributes: true,
        tags: {
          include: {
            tag: true
          }
        },
        relatedFrom: {
          include: {
            toProduct: {
              select: {
                id: true,
                name: true,
                slug: true,
                featuredImageUrl: true,
                price: true
              }
            }
          }
        }
      }
    });
    
    if (!product) {
      return res.status(404).json(formatErrorResponse('Product not found'));
    }
    
    // Format product data
    const formattedProduct = {
      ...product,
      tags: product.tags.map(pt => pt.tag),
      relatedProducts: product.relatedFrom.map(rel => rel.toProduct)
    };
    
    // Remove the raw relations data
    delete formattedProduct.relatedFrom;
    delete formattedProduct.tags;
    
    res.json(formatSuccessResponse(formattedProduct, 'Product retrieved successfully'));
  } catch (error) {
    logger.error(`Error fetching product: ${error.message}`);
    res.status(500).json(formatErrorResponse('Failed to fetch product'));
  }
};

/**
 * Create new product
 * @route POST /api/v1/products
 */
exports.createProduct = async (req, res) => {
  try {
    // Validate request body
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json(formatErrorResponse('Validation error', null, errors.array()));
    }
    
    const { 
      name, slug, description, categoryId, price, sku, 
      stockQuantity, featuredImageUrl, isPublished, tags 
    } = req.body;
    
    // Check if slug already exists
    const existingProduct = await prisma.product.findUnique({
      where: { slug }
    });
    
    if (existingProduct) {
      return res.status(400).json(formatErrorResponse('A product with this slug already exists'));
    }
    
    // Check if category exists
    const category = await prisma.productCategory.findUnique({
      where: { id: categoryId }
    });
    
    if (!category) {
      return res.status(400).json(formatErrorResponse('Category not found'));
    }
    
    // Create product
    const product = await prisma.product.create({
      data: {
        name,
        slug,
        description,
        categoryId,
        price,
        sku,
        stockQuantity: stockQuantity || 0,
        featuredImageUrl,
        isPublished: isPublished || false,
        publishDate: isPublished ? new Date() : null
      }
    });
    
    // Add tags if provided
    if (tags && Array.isArray(tags) && tags.length > 0) {
      const tagConnections = [];
      
      for (const tagId of tags) {
        // Check if tag exists
        const tagExists = await prisma.tag.findUnique({ where: { id: tagId } });
        if (tagExists) {
          tagConnections.push({
            productId: product.id,
            tagId
          });
        }
      }
      
      if (tagConnections.length > 0) {
        await prisma.tagsOnProducts.createMany({
          data: tagConnections
        });
      }
    }
    
    // Log admin activity
    await prisma.adminActivity.create({
      data: {
        userId: req.user.id,
        action: 'created',
        entityType: 'product',
        entityId: product.id,
        details: `Created product: ${name}`
      }
    });
    
    // Get complete product with relationships
    const createdProduct = await prisma.product.findUnique({
      where: { id: product.id },
      include: {
        category: true,
        tags: {
          include: {
            tag: true
          }
        }
      }
    });
    
    res.status(201).json(formatSuccessResponse(
      {
        ...createdProduct,
        tags: createdProduct.tags.map(pt => pt.tag)
      }, 
      'Product created successfully'
    ));
  } catch (error) {
    logger.error(`Error creating product: ${error.message}`);
    res.status(500).json(formatErrorResponse('Failed to create product'));
  }
};

/**
 * Update product
 * @route PUT /api/v1/products/:id
 */
exports.updateProduct = async (req, res) => {
  try {
    // Validate request body
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json(formatErrorResponse('Validation error', null, errors.array()));
    }
    
    const productId = parseInt(req.params.id);
    const { 
      name, slug, description, categoryId, price, sku, 
      stockQuantity, featuredImageUrl, tags 
    } = req.body;
    
    // Check if product exists
    const product = await prisma.product.findUnique({
      where: { id: productId }
    });
    
    if (!product) {
      return res.status(404).json(formatErrorResponse('Product not found'));
    }
    
    // Check if slug is already in use by another product
    if (slug && slug !== product.slug) {
      const existingProduct = await prisma.product.findUnique({
        where: { slug }
      });
      
      if (existingProduct && existingProduct.id !== productId) {
        return res.status(400).json(formatErrorResponse('Slug is already in use by another product'));
      }
    }
    
    // Check if category exists if provided
    if (categoryId) {
      const category = await prisma.productCategory.findUnique({
        where: { id: categoryId }
      });
      
      if (!category) {
        return res.status(400).json(formatErrorResponse('Category not found'));
      }
    }
    
    // Build update data
    const updateData = {};
    if (name) updateData.name = name;
    if (slug) updateData.slug = slug;
    if (description !== undefined) updateData.description = description;
    if (categoryId) updateData.categoryId = categoryId;
    if (price !== undefined) updateData.price = price;
    if (sku !== undefined) updateData.sku = sku;
    if (stockQuantity !== undefined) updateData.stockQuantity = stockQuantity;
    if (featuredImageUrl !== undefined) updateData.featuredImageUrl = featuredImageUrl;
    
    // Update product
    const updatedProduct = await prisma.product.update({
      where: { id: productId },
      data: updateData
    });
    
    // Update tags if provided
    if (tags && Array.isArray(tags)) {
      // Delete existing tags
      await prisma.tagsOnProducts.deleteMany({
        where: { productId }
      });
      
      // Add new tags
      if (tags.length > 0) {
        const tagConnections = [];
        
        for (const tagId of tags) {
          // Check if tag exists
          const tagExists = await prisma.tag.findUnique({ where: { id: tagId } });
          if (tagExists) {
            tagConnections.push({
              productId,
              tagId
            });
          }
        }
        
        if (tagConnections.length > 0) {
          await prisma.tagsOnProducts.createMany({
            data: tagConnections
          });
        }
      }
    }
    
    // Log admin activity
    await prisma.adminActivity.create({
      data: {
        userId: req.user.id,
        action: 'updated',
        entityType: 'product',
        entityId: productId,
        details: `Updated product: ${updatedProduct.name}`
      }
    });
    
    // Get complete product with relationships
    const completeProduct = await prisma.product.findUnique({
      where: { id: productId },
      include: {
        category: true,
        tags: {
          include: {
            tag: true
          }
        }
      }
    });
    
    res.json(formatSuccessResponse(
      {
        ...completeProduct,
        tags: completeProduct.tags.map(pt => pt.tag)
      }, 
      'Product updated successfully'
    ));
  } catch (error) {
    logger.error(`Error updating product: ${error.message}`);
    res.status(500).json(formatErrorResponse('Failed to update product'));
  }
};

/**
 * Delete product
 * @route DELETE /api/v1/products/:id
 */
exports.deleteProduct = async (req, res) => {
  try {
    const productId = parseInt(req.params.id);
    
    // Check if product exists
    const product = await prisma.product.findUnique({
      where: { id: productId }
    });
    
    if (!product) {
      return res.status(404).json(formatErrorResponse('Product not found'));
    }
    
    // Delete product (Prisma will cascade delete related records)
    await prisma.product.delete({
      where: { id: productId }
    });
    
    // Log admin activity
    await prisma.adminActivity.create({
      data: {
        userId: req.user.id,
        action: 'deleted',
        entityType: 'product',
        entityId: productId,
        details: `Deleted product: ${product.name}`
      }
    });
    
    res.json(formatSuccessResponse(null, 'Product deleted successfully'));
  } catch (error) {
    logger.error(`Error deleting product: ${error.message}`);
    
    // Handle reference constraints
    if (error.code === 'P2003') {
      return res.status(400).json(formatErrorResponse('Cannot delete product because it is referenced by other records'));
    }
    
    res.status(500).json(formatErrorResponse('Failed to delete product'));
  }
};

/**
 * Get all product categories
 * @route GET /api/v1/products/categories/all
 */
exports.getAllCategories = async (req, res) => {
  try {
    // Get all categories
    const categories = await prisma.productCategory.findMany({
      include: {
        _count: {
          select: { products: true }
        },
        parent: {
          select: {
            id: true,
            name: true,
            slug: true
          }
        },
        children: {
          select: {
            id: true,
            name: true,
            slug: true,
            description: true,
            imageUrl: true
          }
        }
      },
      orderBy: { name: 'asc' }
    });
    
    // Format categories for response
    const formattedCategories = categories.map(category => ({
      id: category.id,
      name: category.name,
      slug: category.slug,
      description: category.description,
      imageUrl: category.imageUrl,
      parentId: category.parentId,
      parent: category.parent,
      children: category.children,
      productCount: category._count.products
    }));
    
    res.json(formatSuccessResponse(formattedCategories, 'Categories retrieved successfully'));
  } catch (error) {
    logger.error(`Error fetching categories: ${error.message}`);
    res.status(500).json(formatErrorResponse('Failed to fetch categories'));
  }
};

/**
 * Add images to product
 * @route POST /api/v1/products/:id/images
 */
exports.addProductImages = async (req, res) => {
  try {
    // Validate request body
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json(formatErrorResponse('Validation error', null, errors.array()));
    }
    
    const productId = parseInt(req.params.id);
    const { images } = req.body;
    
    // Check if product exists
    const product = await prisma.product.findUnique({
      where: { id: productId }
    });
    
    if (!product) {
      return res.status(404).json(formatErrorResponse('Product not found'));
    }
    
    // Get current max display order
    const maxOrderResult = await prisma.productImage.findFirst({
      where: { productId },
      orderBy: { displayOrder: 'desc' },
      select: { displayOrder: true }
    });
    
    let startOrder = (maxOrderResult?.displayOrder || 0) + 1;
    
    // Add images
    const createdImages = [];
    
    for (const image of images) {
      const createdImage = await prisma.productImage.create({
        data: {
          productId,
          imageUrl: image.imageUrl,
          altText: image.altText || product.name,
          displayOrder: startOrder++
        }
      });
      
      createdImages.push(createdImage);
    }
    
    // Log admin activity
    await prisma.adminActivity.create({
      data: {
        userId: req.user.id,
        action: 'updated',
        entityType: 'product',
        entityId: productId,
        details: `Added ${images.length} images to product: ${product.name}`
      }
    });
    
    // Return created images
    res.status(201).json(formatSuccessResponse(
      createdImages, 
      `Added ${images.length} images to product`
    ));
  } catch (error) {
    logger.error(`Error adding product images: ${error.message}`);
    res.status(500).json(formatErrorResponse('Failed to add product images'));
  }
};

/**
 * Delete product image
 * @route DELETE /api/v1/products/images/:imageId
 */
exports.deleteProductImage = async (req, res) => {
  try {
    const imageId = parseInt(req.params.imageId);
    
    // Check if image exists
    const image = await prisma.productImage.findUnique({
      where: { id: imageId },
      include: { product: { select: { id: true, name: true } } }
    });
    
    if (!image) {
      return res.status(404).json(formatErrorResponse('Image not found'));
    }
    
    // Delete image
    await prisma.productImage.delete({
      where: { id: imageId }
    });
    
    // Log admin activity
    await prisma.adminActivity.create({
      data: {
        userId: req.user.id,
        action: 'deleted',
        entityType: 'productImage',
        entityId: imageId,
        details: `Deleted image from product: ${image.product.name}`
      }
    });
    
    res.json(formatSuccessResponse(null, 'Image deleted successfully'));
  } catch (error) {
    logger.error(`Error deleting product image: ${error.message}`);
    res.status(500).json(formatErrorResponse('Failed to delete product image'));
  }
};

/**
 * Add specifications to product
 * @route POST /api/v1/products/:id/specifications
 */
exports.addProductSpecifications = async (req, res) => {
  try {
    // Validate request body
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json(formatErrorResponse('Validation error', null, errors.array()));
    }
    
    const productId = parseInt(req.params.id);
    const { specifications } = req.body;
    
    // Check if product exists
    const product = await prisma.product.findUnique({
      where: { id: productId }
    });
    
    if (!product) {
      return res.status(404).json(formatErrorResponse('Product not found'));
    }
    
    // Get current max display order
    const maxOrderResult = await prisma.specification.findFirst({
      where: { productId },
      orderBy: { displayOrder: 'desc' },
      select: { displayOrder: true }
    });
    
    let startOrder = (maxOrderResult?.displayOrder || 0) + 1;
    
    // Add specifications
    const createdSpecs = [];
    
    for (const spec of specifications) {
      const createdSpec = await prisma.specification.create({
        data: {
          productId,
          group: spec.group || null,
          name: spec.name,
          value: spec.value,
          unit: spec.unit || null,
          displayOrder: spec.displayOrder || startOrder++
        }
      });
      
      createdSpecs.push(createdSpec);
    }
    
    // Log admin activity
    await prisma.adminActivity.create({
      data: {
        userId: req.user.id,
        action: 'updated',
        entityType: 'product',
        entityId: productId,
        details: `Added ${specifications.length} specifications to product: ${product.name}`
      }
    });
    
    // Return created specifications
    res.status(201).json(formatSuccessResponse(
      createdSpecs, 
      `Added ${specifications.length} specifications to product`
    ));
  } catch (error) {
    logger.error(`Error adding product specifications: ${error.message}`);
    res.status(500).json(formatErrorResponse('Failed to add product specifications'));
  }
};

/**
 * Toggle product publish status
 * @route PUT /api/v1/products/:id/publish
 */
exports.toggleProductPublishStatus = async (req, res) => {
  try {
    // Validate request body
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json(formatErrorResponse('Validation error', null, errors.array()));
    }
    
    const productId = parseInt(req.params.id);
    const { isPublished } = req.body;
    
    // Check if product exists
    const product = await prisma.product.findUnique({
      where: { id: productId }
    });
    
    if (!product) {
      return res.status(404).json(formatErrorResponse('Product not found'));
    }
    
    // Update product publish status
    const updatedProduct = await prisma.product.update({
      where: { id: productId },
      data: {
        isPublished,
        publishDate: isPublished && !product.isPublished ? new Date() : product.publishDate
      }
    });
    
    // Log admin activity
    await prisma.adminActivity.create({
      data: {
        userId: req.user.id,
        action: 'updated',
        entityType: 'product',
        entityId: productId,
        details: `${isPublished ? 'Published' : 'Unpublished'} product: ${product.name}`
      }
    });
    
    res.json(formatSuccessResponse({
      id: updatedProduct.id,
      isPublished: updatedProduct.isPublished,
      publishDate: updatedProduct.publishDate
    }, `Product ${isPublished ? 'published' : 'unpublished'} successfully`));
  } catch (error) {
    logger.error(`Error updating product publish status: ${error.message}`);
    res.status(500).json(formatErrorResponse('Failed to update product publish status'));
  }
};