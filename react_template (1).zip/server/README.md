# Admin Panel Backend

This repository contains the backend API for the enterprise website and e-commerce admin panel. It's built with Express.js, PostgreSQL, and Prisma ORM.

## Features

- User authentication and authorization
- Product management (CRUD operations)
- Order management
- Media upload functionality
- Dashboard analytics
- Content management (articles, case studies)
- Comprehensive API for admin panel operations

## Prerequisites

- Node.js (v14 or higher)
- PostgreSQL (v12 or higher)
- npm or pnpm package manager

## Installation

1. Clone the repository:
   

2. Install dependencies:
   

3. Set up environment variables:
   
   Edit the `.env` file and update the database connection string and other settings as needed.

4. Create the database:
   

5. Run database migrations:
   

6. Seed the database:
   

## Running the Server



The server will start on port 5000 by default (configurable in the `.env` file).

## API Routes Overview

- **Auth**: `/api/v1/auth` - Login, register, profile management
- **Products**: `/api/v1/products` - Product management
- **Orders**: `/api/v1/orders` - Order management
- **Users**: `/api/v1/users` - User management
- **Dashboard**: `/api/v1/dashboard` - Dashboard statistics
- **Upload**: `/api/v1/upload` - File upload functionality

## Default Admin User

After running the seed script, you can login with:

- **Email**: admin@example.com
- **Password**: admin123

## Project Structure
