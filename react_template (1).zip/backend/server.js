const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const morgan = require('morgan');
const path = require('path');
const dotenv = require('dotenv');
const logger = require('./src/utils/logger');

// Load environment variables
dotenv.config();

// Initialize express app
const app = express();

// Middlewares
app.use(cors());
app.use(helmet());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(morgan('combined', { stream: { write: message => logger.info(message.trim()) } }));

// Static files directory
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));

// Mock API Routes for demonstration purposes

// Define mock endpoints directly
app.get('/api/v1/users', (req, res) => {
  res.json({ success: true, data: [{ id: 1, name: 'Admin User', email: 'admin@example.com', role: 'admin' }] });
});

app.get('/api/v1/products', (req, res) => {
  res.json({ 
    success: true, 
    data: [
      { id: 1, name: 'Scanner X3000', price: 2999, category_id: 1, description: 'Professional high-speed scanner for enterprise use' },
      { id: 2, name: 'Printer P2000', price: 1499, category_id: 2, description: 'Laser color printer for medium workloads' }
    ] 
  });
});

app.get('/api/v1/categories', (req, res) => {
  res.json({ 
    success: true, 
    data: [
      { id: 1, name: 'Scanners', type: 'product' },
      { id: 2, name: 'Printers', type: 'product' },
      { id: 3, name: 'News', type: 'article' },
      { id: 4, name: 'Success Stories', type: 'case' }
    ] 
  });
});

app.get('/api/v1/articles', (req, res) => {
  res.json({ 
    success: true, 
    data: [
      { id: 1, title: 'New Scanner Release', content: 'Our new scanner model has been released!', category_id: 3 },
      { id: 2, title: 'Company Updates', content: 'Recent developments in our company', category_id: 3 }
    ] 
  });
});

app.post('/api/v1/auth/login', (req, res) => {
  const { email, password } = req.body;
  if (email === 'admin@example.com' && password === 'admin123') {
    res.json({ 
      success: true, 
      data: { 
        token: 'mock-jwt-token', 
        user: { id: 1, name: 'Admin User', email: 'admin@example.com', role: 'admin' } 
      } 
    });
  } else {
    res.status(401).json({ success: false, message: 'Invalid credentials' });
  }
});

app.get('/api/v1/admin/settings', (req, res) => {
  res.json({ 
    success: true, 
    data: [
      { id: 1, setting_key: 'site_title', setting_value: '企业官网/电商平台', setting_group: 'general' },
      { id: 2, setting_key: 'header_logo', setting_value: '/uploads/logo.png', setting_group: 'header' },
      { id: 3, setting_key: 'contact_email', setting_value: 'contact@example.com', setting_group: 'contact' }
    ] 
  });
});

// Root route
app.get('/api', (req, res) => {
  res.json({ message: 'Enterprise Website & E-Commerce Platform API' });
});

// Error Handling Middleware
app.use((req, res, next) => {
  const error = new Error(`Not Found - ${req.originalUrl}`);
  res.status(404);
  next(error);
});

app.use((err, req, res, next) => {
  const statusCode = res.statusCode === 200 ? 500 : res.statusCode;
  res.status(statusCode);
  res.json({
    success: false,
    message: err.message,
    stack: process.env.NODE_ENV === 'production' ? null : err.stack,
  });
});

// Start the server
const PORT = 8888; // Using a high port number to avoid conflicts
app.listen(PORT, () => {
  logger.info(`Server running in ${process.env.NODE_ENV || 'development'} mode on port ${PORT}`);
  logger.warn('Using mock data for demonstration purposes');
});

module.exports = app; // For testing purposes