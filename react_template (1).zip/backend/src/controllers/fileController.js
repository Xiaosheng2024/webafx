/**
 * File controller for handling file uploads and management
 */
const { query } = require('../config/database');
const logger = require('../utils/logger');
const config = require('../config/app');
const path = require('path');
const fs = require('fs');

/**
 * @desc    Upload a file
 * @route   POST /api/v1/files/upload
 * @access  Private/Admin/Editor
 */
const uploadFile = async (req, res, next) => {
  try {
    if (!req.file) {
      return res.status(400).json({
        message: 'No file uploaded'
      });
    }
    
    const { content_id, content_type = 'general' } = req.body;
    
    const file = req.file;
    const filePath = file.path.replace(/\\/g, '/');
    
    // Save file record in database
    const result = await query(
      `INSERT INTO files 
       (filename, original_name, file_path, file_type, file_size, uploaded_by, content_id, content_type)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        path.basename(file.path),
        file.originalname,
        filePath,
        file.mimetype,
        file.size,
        req.user.id,
        content_id || null,
        content_type
      ]
    );
    
    const fileRecord = await query(
      'SELECT * FROM files WHERE id = ?',
      [result.insertId]
    );
    
    res.status(201).json({
      message: 'File uploaded successfully',
      data: {
        ...fileRecord[0],
        url: `/${filePath}` // Return URL path to access file
      }
    });
  } catch (error) {
    logger.error(`File upload error: ${error.message}`);
    next(error);
  }
};

/**
 * @desc    Get file by ID
 * @route   GET /api/v1/files/:id
 * @access  Private/Admin/Editor
 */
const getFileById = async (req, res, next) => {
  try {
    const file = await query(
      'SELECT * FROM files WHERE id = ?',
      [req.params.id]
    );
    
    if (file.length === 0) {
      return res.status(404).json({
        message: 'File not found'
      });
    }
    
    res.json({
      message: 'File retrieved successfully',
      data: {
        ...file[0],
        url: `/${file[0].file_path}`
      }
    });
  } catch (error) {
    logger.error(`Get file error: ${error.message}`);
    next(error);
  }
};

/**
 * @desc    Get files by content
 * @route   GET /api/v1/files/content/:type/:id
 * @access  Private/Admin/Editor
 */
const getFilesByContent = async (req, res, next) => {
  try {
    const { type, id } = req.params;
    
    const files = await query(
      'SELECT * FROM files WHERE content_type = ? AND content_id = ?',
      [type, id]
    );
    
    // Add URL to each file
    const filesWithUrl = files.map(file => ({
      ...file,
      url: `/${file.file_path}`
    }));
    
    res.json({
      message: 'Files retrieved successfully',
      data: filesWithUrl
    });
  } catch (error) {
    logger.error(`Get files by content error: ${error.message}`);
    next(error);
  }
};

/**
 * @desc    Delete a file
 * @route   DELETE /api/v1/files/:id
 * @access  Private/Admin/Editor
 */
const deleteFile = async (req, res, next) => {
  try {
    // Get file record
    const file = await query(
      'SELECT * FROM files WHERE id = ?',
      [req.params.id]
    );
    
    if (file.length === 0) {
      return res.status(404).json({
        message: 'File not found'
      });
    }
    
    const filePath = path.join(__dirname, '../../../', file[0].file_path);
    
    // Delete file from storage
    if (fs.existsSync(filePath)) {
      fs.unlinkSync(filePath);
    }
    
    // Delete record from database
    await query(
      'DELETE FROM files WHERE id = ?',
      [req.params.id]
    );
    
    res.json({
      message: 'File deleted successfully'
    });
  } catch (error) {
    logger.error(`Delete file error: ${error.message}`);
    next(error);
  }
};

module.exports = {
  uploadFile,
  getFileById,
  getFilesByContent,
  deleteFile
};