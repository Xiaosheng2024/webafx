/**
 * Admin controller for managing website settings and content
 */
const { query } = require('../config/database');
const logger = require('../utils/logger');
const config = require('../config/app');
const path = require('path');
const fs = require('fs');

/**
 * @desc    Get dashboard stats
 * @route   GET /api/v1/admin/dashboard
 * @access  Private/Admin/Editor
 */
const getDashboardStats = async (req, res, next) => {
  try {
    // Get counts for various content types
    const productCount = await query('SELECT COUNT(*) as count FROM products');
    const articleCount = await query('SELECT COUNT(*) as count FROM articles');
    const caseCount = await query('SELECT COUNT(*) as count FROM cases');
    const categoryCount = await query('SELECT COUNT(*) as count FROM categories');
    const inquiryCount = await query('SELECT COUNT(*) as count FROM inquiries WHERE status = "new"');
    const userCount = await query('SELECT COUNT(*) as count FROM users');
    
    // Get recent inquiries
    const recentInquiries = await query(`
      SELECT * FROM inquiries 
      ORDER BY created_at DESC 
      LIMIT 5
    `);
    
    // Get recent content
    const recentProducts = await query(`
      SELECT p.id, p.name, p.created_at, u.name as created_by_name
      FROM products p
      LEFT JOIN users u ON p.created_by = u.id
      ORDER BY p.created_at DESC
      LIMIT 5
    `);
    
    const recentArticles = await query(`
      SELECT a.id, a.title, a.created_at, u.name as author_name
      FROM articles a
      LEFT JOIN users u ON a.author_id = u.id
      ORDER BY a.created_at DESC
      LIMIT 5
    `);
    
    res.json({
      message: 'Dashboard stats retrieved successfully',
      data: {
        counts: {
          products: productCount[0].count,
          articles: articleCount[0].count,
          cases: caseCount[0].count,
          categories: categoryCount[0].count,
          newInquiries: inquiryCount[0].count,
          users: userCount[0].count
        },
        recentInquiries,
        recentProducts,
        recentArticles
      }
    });
  } catch (error) {
    logger.error(`Get dashboard stats error: ${error.message}`);
    next(error);
  }
};

/**
 * @desc    Get all settings
 * @route   GET /api/v1/admin/settings
 * @access  Private/Admin
 */
const getSettings = async (req, res, next) => {
  try {
    const group = req.query.group || null;
    
    let sql = 'SELECT * FROM settings';
    const params = [];
    
    if (group) {
      sql += ' WHERE setting_group = ?';
      params.push(group);
    }
    
    sql += ' ORDER BY setting_group, setting_key';
    
    const settings = await query(sql, params);
    
    // Format settings based on type
    const formattedSettings = settings.map(setting => {
      const value = formatSettingValue(setting.setting_value, setting.setting_type);
      return { ...setting, value };
    });
    
    // Group settings by setting_group
    const groupedSettings = formattedSettings.reduce((acc, setting) => {
      const group = setting.setting_group;
      if (!acc[group]) {
        acc[group] = [];
      }
      acc[group].push(setting);
      return acc;
    }, {});
    
    res.json({
      message: 'Settings retrieved successfully',
      data: groupedSettings
    });
  } catch (error) {
    logger.error(`Get settings error: ${error.message}`);
    next(error);
  }
};

/**
 * @desc    Get setting by key
 * @route   GET /api/v1/admin/settings/:key
 * @access  Private/Admin
 */
const getSettingByKey = async (req, res, next) => {
  try {
    const settingKey = req.params.key;
    
    const settings = await query(
      'SELECT * FROM settings WHERE setting_key = ?',
      [settingKey]
    );
    
    if (settings.length === 0) {
      return res.status(404).json({
        message: 'Setting not found'
      });
    }
    
    const setting = settings[0];
    
    // Format value based on type
    setting.value = formatSettingValue(setting.setting_value, setting.setting_type);
    
    res.json({
      message: 'Setting retrieved successfully',
      data: setting
    });
  } catch (error) {
    logger.error(`Get setting error: ${error.message}`);
    next(error);
  }
};

/**
 * @desc    Update a setting
 * @route   PUT /api/v1/admin/settings/:key
 * @access  Private/Admin
 */
const updateSetting = async (req, res, next) => {
  try {
    const settingKey = req.params.key;
    const { value, description, setting_group } = req.body;
    
    // Check if setting exists
    const existingSetting = await query(
      'SELECT * FROM settings WHERE setting_key = ?',
      [settingKey]
    );
    
    // Convert value to string based on setting type
    const settingType = existingSetting.length > 0 
      ? existingSetting[0].setting_type 
      : determineSettingType(value);
    
    const settingValue = formatSettingValueForStorage(value, settingType);
    
    if (existingSetting.length === 0) {
      // Create new setting if it doesn't exist
      await query(
        `INSERT INTO settings 
         (setting_key, setting_value, setting_type, setting_group, description, updated_by)
         VALUES (?, ?, ?, ?, ?, ?)`,
        [
          settingKey,
          settingValue,
          settingType,
          setting_group || 'general',
          description || null,
          req.user.id
        ]
      );
    } else {
      // Update existing setting
      const updateFields = ['setting_value = ?', 'updated_by = ?'];
      const updateValues = [settingValue, req.user.id];
      
      if (description !== undefined) {
        updateFields.push('description = ?');
        updateValues.push(description);
      }
      
      if (setting_group !== undefined) {
        updateFields.push('setting_group = ?');
        updateValues.push(setting_group);
      }
      
      updateValues.push(settingKey);
      
      await query(
        `UPDATE settings SET ${updateFields.join(', ')} WHERE setting_key = ?`,
        updateValues
      );
    }
    
    // Get updated setting
    const updatedSetting = await query(
      'SELECT * FROM settings WHERE setting_key = ?',
      [settingKey]
    );
    
    // Format value for response
    updatedSetting[0].value = formatSettingValue(
      updatedSetting[0].setting_value, 
      updatedSetting[0].setting_type
    );
    
    res.json({
      message: 'Setting updated successfully',
      data: updatedSetting[0]
    });
  } catch (error) {
    logger.error(`Update setting error: ${error.message}`);
    next(error);
  }
};

/**
 * @desc    Delete a setting
 * @route   DELETE /api/v1/admin/settings/:key
 * @access  Private/Admin
 */
const deleteSetting = async (req, res, next) => {
  try {
    const settingKey = req.params.key;
    
    // Check if setting exists
    const existingSetting = await query(
      'SELECT * FROM settings WHERE setting_key = ?',
      [settingKey]
    );
    
    if (existingSetting.length === 0) {
      return res.status(404).json({
        message: 'Setting not found'
      });
    }
    
    // Delete setting
    await query(
      'DELETE FROM settings WHERE setting_key = ?',
      [settingKey]
    );
    
    res.json({
      message: 'Setting deleted successfully'
    });
  } catch (error) {
    logger.error(`Delete setting error: ${error.message}`);
    next(error);
  }
};

/**
 * @desc    Update header content
 * @route   PUT /api/v1/admin/header
 * @access  Private/Admin
 */
const updateHeaderContent = async (req, res, next) => {
  try {
    const { 
      site_title, 
      site_logo, 
      nav_items,
      contact_phone,
      contact_email 
    } = req.body;
    
    // Begin transaction
    const connection = await require('../config/database').getConnection();
    await connection.beginTransaction();
    
    try {
      // Update site title
      if (site_title !== undefined) {
        await updateSettingHelper(connection, 'site_title', site_title, 'text', 'header', 'Website title', req.user.id);
      }
      
      // Update logo
      if (req.file) {
        const logoPath = req.file.path.replace(/\\/g, '/');
        await updateSettingHelper(connection, 'site_logo', logoPath, 'text', 'header', 'Website logo path', req.user.id);
      }
      
      // Update navigation items if provided
      if (nav_items !== undefined) {
        const navItemsJson = JSON.stringify(nav_items);
        await updateSettingHelper(connection, 'nav_items', navItemsJson, 'json', 'header', 'Navigation menu items', req.user.id);
      }
      
      // Update contact information
      if (contact_phone !== undefined) {
        await updateSettingHelper(connection, 'contact_phone', contact_phone, 'text', 'contact', 'Contact phone number', req.user.id);
      }
      
      if (contact_email !== undefined) {
        await updateSettingHelper(connection, 'contact_email', contact_email, 'text', 'contact', 'Contact email address', req.user.id);
      }
      
      await connection.commit();
      
      // Get updated header settings
      const headerSettings = await query(
        'SELECT * FROM settings WHERE setting_group IN (?, ?)',
        ['header', 'contact']
      );
      
      // Format values
      const formattedSettings = headerSettings.map(setting => {
        const value = formatSettingValue(setting.setting_value, setting.setting_type);
        return { ...setting, value };
      });
      
      res.json({
        message: 'Header content updated successfully',
        data: formattedSettings
      });
    } catch (error) {
      await connection.rollback();
      throw error;
    } finally {
      connection.release();
    }
  } catch (error) {
    logger.error(`Update header error: ${error.message}`);
    next(error);
  }
};

/**
 * @desc    Get all inquiries with pagination
 * @route   GET /api/v1/admin/inquiries
 * @access  Private/Admin/Editor
 */
const getInquiries = async (req, res, next) => {
  try {
    const page = parseInt(req.query.page) || 1;
    const limit = parseInt(req.query.limit) || config.defaultPageSize;
    const status = req.query.status || null;
    
    let sql = `
      SELECT i.*, p.name as product_name
      FROM inquiries i
      LEFT JOIN products p ON i.related_product = p.id
    `;
    
    const queryParams = [];
    
    if (status) {
      sql += ' WHERE i.status = ?';
      queryParams.push(status);
    }
    
    // Add order and pagination
    sql += ' ORDER BY i.created_at DESC LIMIT ? OFFSET ?';
    queryParams.push(Number(limit), (Number(page) - 1) * Number(limit));
    
    // Execute query
    const inquiries = await query(sql, queryParams);
    
    // Count total for pagination
    let countSql = 'SELECT COUNT(*) as total FROM inquiries';
    
    if (status) {
      countSql += ' WHERE status = ?';
    }
    
    const totalResult = await query(countSql, status ? [status] : []);
    const total = totalResult[0].total;
    
    res.json({
      message: 'Inquiries retrieved successfully',
      data: inquiries,
      meta: {
        page,
        limit,
        totalItems: total,
        totalPages: Math.ceil(total / limit)
      }
    });
  } catch (error) {
    logger.error(`Get inquiries error: ${error.message}`);
    next(error);
  }
};

/**
 * @desc    Update inquiry status
 * @route   PUT /api/v1/admin/inquiries/:id
 * @access  Private/Admin/Editor
 */
const updateInquiryStatus = async (req, res, next) => {
  try {
    const { status } = req.body;
    
    // Check if inquiry exists
    const inquiry = await query(
      'SELECT * FROM inquiries WHERE id = ?',
      [req.params.id]
    );
    
    if (inquiry.length === 0) {
      return res.status(404).json({
        message: 'Inquiry not found'
      });
    }
    
    // Update inquiry status
    await query(
      'UPDATE inquiries SET status = ? WHERE id = ?',
      [status, req.params.id]
    );
    
    // Get updated inquiry
    const updatedInquiry = await query(
      `SELECT i.*, p.name as product_name
       FROM inquiries i
       LEFT JOIN products p ON i.related_product = p.id
       WHERE i.id = ?`,
      [req.params.id]
    );
    
    res.json({
      message: 'Inquiry status updated successfully',
      data: updatedInquiry[0]
    });
  } catch (error) {
    logger.error(`Update inquiry status error: ${error.message}`);
    next(error);
  }
};

// Helper functions
/**
 * Determine the type of a setting value
 */
const determineSettingType = (value) => {
  if (typeof value === 'boolean') {
    return 'boolean';
  } else if (typeof value === 'number') {
    return 'number';
  } else if (typeof value === 'object') {
    return 'json';
  } else {
    return 'text';
  }
};

/**
 * Format setting value for storage in database
 */
const formatSettingValueForStorage = (value, type) => {
  if (type === 'json' && typeof value !== 'string') {
    return JSON.stringify(value);
  }
  return String(value);
};

/**
 * Format setting value for response based on type
 */
const formatSettingValue = (value, type) => {
  if (!value) return null;
  
  switch (type) {
    case 'number':
      return parseFloat(value);
    case 'boolean':
      return value.toLowerCase() === 'true';
    case 'json':
      try {
        return JSON.parse(value);
      } catch (error) {
        logger.error(`Error parsing JSON setting: ${error.message}`);
        return value;
      }
    default:
      return value;
  }
};

/**
 * Helper function to update a setting within a transaction
 */
const updateSettingHelper = async (connection, key, value, type, group, description, userId) => {
  // Check if setting exists
  const [existingSettings] = await connection.query(
    'SELECT * FROM settings WHERE setting_key = ?',
    [key]
  );
  
  const settingValue = formatSettingValueForStorage(value, type);
  
  if (existingSettings.length === 0) {
    // Create new setting
    await connection.query(
      `INSERT INTO settings 
       (setting_key, setting_value, setting_type, setting_group, description, updated_by)
       VALUES (?, ?, ?, ?, ?, ?)`,
      [key, settingValue, type, group, description, userId]
    );
  } else {
    // Update existing setting
    await connection.query(
      `UPDATE settings 
       SET setting_value = ?, updated_by = ? 
       WHERE setting_key = ?`,
      [settingValue, userId, key]
    );
  }
};

module.exports = {
  getDashboardStats,
  getSettings,
  getSettingByKey,
  updateSetting,
  deleteSetting,
  updateHeaderContent,
  getInquiries,
  updateInquiryStatus
};