/**
 * Authentication controller
 */
const bcrypt = require('bcryptjs');
const userModel = require('../models/userModel');
const logger = require('../utils/logger');
const { query } = require('../config/database');
const config = require('../config/app');

/**
 * @desc    Register a new user
 * @route   POST /api/v1/auth/register
 * @access  Public
 */
const register = async (req, res, next) => {
  try {
    const { name, email, password } = req.body;

    // Check if user already exists
    const existingUser = await userModel.getByEmail(email);
    if (existingUser) {
      return res.status(400).json({
        message: 'User with this email already exists'
      });
    }

    // Create user
    const newUser = await userModel.create({
      name,
      email,
      password,
      role: 'user' // Default role for new registrations
    });

    // Generate JWT
    const token = await userModel.authenticate(email, password);

    res.status(201).json({
      message: 'User registered successfully',
      data: {
        ...newUser,
        token: token.token
      }
    });
  } catch (error) {
    logger.error(`Registration error: ${error.message}`);
    next(error);
  }
};

/**
 * @desc    Login user
 * @route   POST /api/v1/auth/login
 * @access  Public
 */
const login = async (req, res, next) => {
  try {
    const { email, password } = req.body;

    // Authenticate user
    const user = await userModel.authenticate(email, password);

    res.json({
      message: 'Login successful',
      data: user
    });
  } catch (error) {
    logger.error(`Login error: ${error.message}`);
    res.status(401).json({
      message: error.message || 'Invalid credentials'
    });
  }
};

/**
 * @desc    Get current user profile
 * @route   GET /api/v1/auth/me
 * @access  Private
 */
const getMe = async (req, res) => {
  res.json({
    message: 'User profile retrieved',
    data: req.user
  });
};

/**
 * @desc    Update password
 * @route   PUT /api/v1/auth/update-password
 * @access  Private
 */
const updatePassword = async (req, res, next) => {
  try {
    const { currentPassword, newPassword } = req.body;

    // Get user with password
    const user = await query(
      'SELECT id, password FROM users WHERE id = ?',
      [req.user.id]
    );

    if (user.length === 0) {
      return res.status(404).json({
        message: 'User not found'
      });
    }

    // Verify current password
    const isMatch = await bcrypt.compare(currentPassword, user[0].password);
    if (!isMatch) {
      return res.status(400).json({
        message: 'Current password is incorrect'
      });
    }

    // Update password
    await userModel.updatePassword(req.user.id, newPassword);

    res.json({
      message: 'Password updated successfully'
    });
  } catch (error) {
    logger.error(`Update password error: ${error.message}`);
    next(error);
  }
};

/**
 * @desc    Initialize default admin user if none exists
 * @access  Private
 */
const initializeDefaultAdmin = async () => {
  try {
    const adminExists = await query(
      'SELECT COUNT(*) as count FROM users WHERE role = ?',
      ['admin']
    );

    if (adminExists[0].count === 0) {
      await userModel.create({
        name: 'Admin',
        email: config.defaultAdminEmail,
        password: config.defaultAdminPassword,
        role: 'admin'
      });
      
      logger.info('Default admin user created');
    }
  } catch (error) {
    logger.error(`Error creating default admin: ${error.message}`);
  }
};

// Create default admin on startup
initializeDefaultAdmin();

module.exports = {
  register,
  login,
  getMe,
  updatePassword
};