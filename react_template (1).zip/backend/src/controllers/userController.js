/**
 * User controller for admin management of users
 */
const userModel = require('../models/userModel');
const logger = require('../utils/logger');
const config = require('../config/app');

/**
 * @desc    Get all users with pagination
 * @route   GET /api/v1/users
 * @access  Private/Admin
 */
const getUsers = async (req, res, next) => {
  try {
    const page = parseInt(req.query.page) || 1;
    const limit = parseInt(req.query.limit) || config.defaultPageSize;
    const status = req.query.status || null;

    // Get users with pagination
    const users = await userModel.getAll(page, limit, status);
    
    // Get total count for pagination
    const total = await userModel.count(status);

    res.json({
      message: 'Users retrieved successfully',
      data: users,
      meta: {
        page,
        limit,
        totalItems: total,
        totalPages: Math.ceil(total / limit)
      }
    });
  } catch (error) {
    logger.error(`Get users error: ${error.message}`);
    next(error);
  }
};

/**
 * @desc    Get user by ID
 * @route   GET /api/v1/users/:id
 * @access  Private/Admin
 */
const getUserById = async (req, res, next) => {
  try {
    const user = await userModel.getById(req.params.id);

    if (!user) {
      return res.status(404).json({
        message: 'User not found'
      });
    }

    res.json({
      message: 'User retrieved successfully',
      data: user
    });
  } catch (error) {
    logger.error(`Get user error: ${error.message}`);
    next(error);
  }
};

/**
 * @desc    Create a new user (by admin)
 * @route   POST /api/v1/users
 * @access  Private/Admin
 */
const createUser = async (req, res, next) => {
  try {
    const { name, email, password, role, avatar } = req.body;

    // Check if user already exists
    const existingUser = await userModel.getByEmail(email);
    if (existingUser) {
      return res.status(400).json({
        message: 'User with this email already exists'
      });
    }

    // Create user
    const newUser = await userModel.create({
      name,
      email,
      password,
      role: role || 'user',
      avatar
    });

    res.status(201).json({
      message: 'User created successfully',
      data: newUser
    });
  } catch (error) {
    logger.error(`Create user error: ${error.message}`);
    next(error);
  }
};

/**
 * @desc    Update user
 * @route   PUT /api/v1/users/:id
 * @access  Private/Admin
 */
const updateUser = async (req, res, next) => {
  try {
    const { name, email, role, avatar, status } = req.body;

    // Check if user exists
    const existingUser = await userModel.getById(req.params.id);
    if (!existingUser) {
      return res.status(404).json({
        message: 'User not found'
      });
    }

    // Update user
    const updatedUser = await userModel.update(req.params.id, {
      name,
      email,
      role,
      avatar,
      status
    });

    res.json({
      message: 'User updated successfully',
      data: updatedUser
    });
  } catch (error) {
    logger.error(`Update user error: ${error.message}`);
    next(error);
  }
};

/**
 * @desc    Delete user
 * @route   DELETE /api/v1/users/:id
 * @access  Private/Admin
 */
const deleteUser = async (req, res, next) => {
  try {
    // Check if user exists
    const existingUser = await userModel.getById(req.params.id);
    if (!existingUser) {
      return res.status(404).json({
        message: 'User not found'
      });
    }

    // Check if trying to delete self
    if (req.user.id === parseInt(req.params.id)) {
      return res.status(400).json({
        message: 'Cannot delete your own account through this endpoint'
      });
    }

    // Delete user
    await userModel.delete(req.params.id);

    res.json({
      message: 'User deleted successfully'
    });
  } catch (error) {
    logger.error(`Delete user error: ${error.message}`);
    next(error);
  }
};

/**
 * @desc    Reset user password (by admin)
 * @route   PUT /api/v1/users/:id/reset-password
 * @access  Private/Admin
 */
const resetPassword = async (req, res, next) => {
  try {
    const { password } = req.body;

    // Check if user exists
    const existingUser = await userModel.getById(req.params.id);
    if (!existingUser) {
      return res.status(404).json({
        message: 'User not found'
      });
    }

    // Update password
    await userModel.updatePassword(req.params.id, password);

    res.json({
      message: 'Password reset successfully'
    });
  } catch (error) {
    logger.error(`Reset password error: ${error.message}`);
    next(error);
  }
};

module.exports = {
  getUsers,
  getUserById,
  createUser,
  updateUser,
  deleteUser,
  resetPassword
};