/**
 * Product controller for managing products
 */
const { query } = require('../config/database');
const logger = require('../utils/logger');
const config = require('../config/app');
const path = require('path');
const fs = require('fs');

/**
 * @desc    Get all products with pagination and filtering
 * @route   GET /api/v1/products
 * @access  Public
 */
const getProducts = async (req, res, next) => {
  try {
    const page = parseInt(req.query.page) || 1;
    const limit = parseInt(req.query.limit) || config.defaultPageSize;
    const categoryId = req.query.category || null;
    const featured = req.query.featured ? req.query.featured === 'true' : null;
    const search = req.query.search || null;
    
    // Start building the SQL query
    let sql = `
      SELECT p.*, c.name as category_name,
      (SELECT image_url FROM product_images WHERE product_id = p.id AND is_primary = 1 LIMIT 1) as primary_image
      FROM products p
      LEFT JOIN categories c ON p.category_id = c.id 
      WHERE p.status = 'active'
    `;
    
    const queryParams = [];
    
    // Add category filter
    if (categoryId) {
      sql += ' AND p.category_id = ?';
      queryParams.push(categoryId);
    }
    
    // Add featured filter
    if (featured !== null) {
      sql += ' AND p.featured = ?';
      queryParams.push(featured);
    }
    
    // Add search functionality
    if (search) {
      sql += ' AND (p.name LIKE ? OR p.description LIKE ?)';
      queryParams.push(`%${search}%`, `%${search}%`);
    }
    
    // Add order and pagination
    sql += ' ORDER BY p.created_at DESC LIMIT ? OFFSET ?';
    queryParams.push(Number(limit), (Number(page) - 1) * Number(limit));
    
    // Execute the query
    const products = await query(sql, queryParams);
    
    // Get attributes for each product
    for (const product of products) {
      const attributes = await query(
        'SELECT attribute_name, attribute_value FROM product_attributes WHERE product_id = ?',
        [product.id]
      );
      product.attributes = attributes;
      
      // Get additional images
      const images = await query(
        'SELECT id, image_url, is_primary FROM product_images WHERE product_id = ? ORDER BY sort_order',
        [product.id]
      );
      product.images = images;
    }
    
    // Count total for pagination
    let countSql = `
      SELECT COUNT(*) as total FROM products p 
      WHERE p.status = 'active'
    `;
    
    // Apply same filters to count query
    let countParams = [];
    
    if (categoryId) {
      countSql += ' AND p.category_id = ?';
      countParams.push(categoryId);
    }
    
    if (featured !== null) {
      countSql += ' AND p.featured = ?';
      countParams.push(featured);
    }
    
    if (search) {
      countSql += ' AND (p.name LIKE ? OR p.description LIKE ?)';
      countParams.push(`%${search}%`, `%${search}%`);
    }
    
    const totalResult = await query(countSql, countParams);
    const total = totalResult[0].total;
    
    res.json({
      message: 'Products retrieved successfully',
      data: products,
      meta: {
        page,
        limit,
        totalItems: total,
        totalPages: Math.ceil(total / limit)
      }
    });
  } catch (error) {
    logger.error(`Get products error: ${error.message}`);
    next(error);
  }
};

/**
 * @desc    Get product by ID
 * @route   GET /api/v1/products/:id
 * @access  Public
 */
const getProductById = async (req, res, next) => {
  try {
    // Get product details
    const products = await query(`
      SELECT p.*, c.name as category_name
      FROM products p
      LEFT JOIN categories c ON p.category_id = c.id
      WHERE p.id = ? AND p.status = 'active'
    `, [req.params.id]);
    
    if (products.length === 0) {
      return res.status(404).json({
        message: 'Product not found'
      });
    }
    
    const product = products[0];
    
    // Get attributes
    const attributes = await query(
      'SELECT attribute_name, attribute_value FROM product_attributes WHERE product_id = ?',
      [product.id]
    );
    product.attributes = attributes;
    
    // Get images
    const images = await query(
      'SELECT id, image_url, is_primary FROM product_images WHERE product_id = ? ORDER BY sort_order',
      [product.id]
    );
    product.images = images;
    
    // Get related products
    const relatedProducts = await query(`
      SELECT p.*, 
      (SELECT image_url FROM product_images WHERE product_id = p.id AND is_primary = 1 LIMIT 1) as primary_image
      FROM products p
      JOIN product_relations pr ON p.id = pr.related_id
      WHERE pr.product_id = ? AND p.status = 'active'
      ORDER BY p.created_at DESC
      LIMIT 6
    `, [product.id]);
    
    product.related_products = relatedProducts;
    
    // Get tags
    const tags = await query(`
      SELECT t.id, t.name
      FROM tags t
      JOIN content_tags ct ON t.id = ct.tag_id
      WHERE ct.content_id = ? AND ct.content_type = 'product'
    `, [product.id]);
    
    product.tags = tags;
    
    res.json({
      message: 'Product retrieved successfully',
      data: product
    });
  } catch (error) {
    logger.error(`Get product error: ${error.message}`);
    next(error);
  }
};

/**
 * @desc    Create a new product
 * @route   POST /api/v1/products
 * @access  Private/Admin/Editor
 */
const createProduct = async (req, res, next) => {
  try {
    const { 
      name, model, description, category_id, price, 
      featured = false, status = 'active', attributes = [] 
    } = req.body;
    
    // Begin transaction
    const connection = await require('../config/database').getConnection();
    await connection.beginTransaction();
    
    try {
      // Create product
      const [result] = await connection.query(
        `INSERT INTO products (name, model, description, category_id, price, featured, status, created_by)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
        [name, model, description, category_id, price, featured, status, req.user.id]
      );
      
      const productId = result.insertId;
      
      // Add attributes if any
      if (attributes && attributes.length > 0) {
        const attributeValues = attributes.map(attr => 
          [productId, attr.name, attr.value]
        );
        
        await connection.query(
          `INSERT INTO product_attributes (product_id, attribute_name, attribute_value)
           VALUES ?`,
          [attributeValues]
        );
      }
      
      // Handle tags if provided
      if (req.body.tags && req.body.tags.length > 0) {
        for (const tagName of req.body.tags) {
          // Try to find existing tag or create new one
          let [tagResult] = await connection.query(
            'SELECT id FROM tags WHERE name = ?',
            [tagName]
          );
          
          let tagId;
          if (tagResult.length === 0) {
            // Create new tag
            const [newTag] = await connection.query(
              'INSERT INTO tags (name) VALUES (?)',
              [tagName]
            );
            tagId = newTag.insertId;
          } else {
            tagId = tagResult[0].id;
          }
          
          // Link tag to product
          await connection.query(
            `INSERT INTO content_tags (tag_id, content_id, content_type)
             VALUES (?, ?, 'product')`,
            [tagId, productId]
          );
        }
      }
      
      // Handle uploaded images if any
      if (req.files && req.files.length > 0) {
        const imageValues = req.files.map((file, index) => {
          const isPrimary = index === 0; // First image is primary by default
          return [productId, file.path.replace(/\\/g, '/'), isPrimary, index];
        });
        
        await connection.query(
          `INSERT INTO product_images (product_id, image_url, is_primary, sort_order)
           VALUES ?`,
          [imageValues]
        );
      }
      
      await connection.commit();
      
      // Get the created product with details
      const product = await query(
        `SELECT p.*, c.name as category_name
         FROM products p
         LEFT JOIN categories c ON p.category_id = c.id
         WHERE p.id = ?`,
        [productId]
      );
      
      res.status(201).json({
        message: 'Product created successfully',
        data: product[0]
      });
    } catch (error) {
      await connection.rollback();
      throw error;
    } finally {
      connection.release();
    }
  } catch (error) {
    logger.error(`Create product error: ${error.message}`);
    next(error);
  }
};

/**
 * @desc    Update a product
 * @route   PUT /api/v1/products/:id
 * @access  Private/Admin/Editor
 */
const updateProduct = async (req, res, next) => {
  try {
    const { 
      name, model, description, category_id, price, 
      featured, status, attributes = []
    } = req.body;
    
    // Check if product exists
    const productExists = await query(
      'SELECT id FROM products WHERE id = ?',
      [req.params.id]
    );
    
    if (productExists.length === 0) {
      return res.status(404).json({
        message: 'Product not found'
      });
    }
    
    // Begin transaction
    const connection = await require('../config/database').getConnection();
    await connection.beginTransaction();
    
    try {
      // Update product
      const updateFields = [];
      const updateValues = [];
      
      if (name !== undefined) {
        updateFields.push('name = ?');
        updateValues.push(name);
      }
      
      if (model !== undefined) {
        updateFields.push('model = ?');
        updateValues.push(model);
      }
      
      if (description !== undefined) {
        updateFields.push('description = ?');
        updateValues.push(description);
      }
      
      if (category_id !== undefined) {
        updateFields.push('category_id = ?');
        updateValues.push(category_id);
      }
      
      if (price !== undefined) {
        updateFields.push('price = ?');
        updateValues.push(price);
      }
      
      if (featured !== undefined) {
        updateFields.push('featured = ?');
        updateValues.push(featured);
      }
      
      if (status !== undefined) {
        updateFields.push('status = ?');
        updateValues.push(status);
      }
      
      if (updateFields.length > 0) {
        await connection.query(
          `UPDATE products SET ${updateFields.join(', ')} WHERE id = ?`,
          [...updateValues, req.params.id]
        );
      }
      
      // Update attributes if provided
      if (attributes && attributes.length > 0) {
        // Delete existing attributes
        await connection.query(
          'DELETE FROM product_attributes WHERE product_id = ?',
          [req.params.id]
        );
        
        // Insert new attributes
        const attributeValues = attributes.map(attr => 
          [req.params.id, attr.name, attr.value]
        );
        
        await connection.query(
          `INSERT INTO product_attributes (product_id, attribute_name, attribute_value)
           VALUES ?`,
          [attributeValues]
        );
      }
      
      // Update tags if provided
      if (req.body.tags !== undefined) {
        // Delete existing tag associations
        await connection.query(
          `DELETE FROM content_tags WHERE content_id = ? AND content_type = 'product'`,
          [req.params.id]
        );
        
        // Add new tags
        if (req.body.tags && req.body.tags.length > 0) {
          for (const tagName of req.body.tags) {
            // Try to find existing tag or create new one
            let [tagResult] = await connection.query(
              'SELECT id FROM tags WHERE name = ?',
              [tagName]
            );
            
            let tagId;
            if (tagResult.length === 0) {
              // Create new tag
              const [newTag] = await connection.query(
                'INSERT INTO tags (name) VALUES (?)',
                [tagName]
              );
              tagId = newTag.insertId;
            } else {
              tagId = tagResult[0].id;
            }
            
            // Link tag to product
            await connection.query(
              `INSERT INTO content_tags (tag_id, content_id, content_type)
               VALUES (?, ?, 'product')`,
              [tagId, req.params.id]
            );
          }
        }
      }
      
      // Handle uploaded images if any
      if (req.files && req.files.length > 0) {
        const productImages = await connection.query(
          'SELECT id, image_url FROM product_images WHERE product_id = ?',
          [req.params.id]
        );
        
        // Add new images
        const imageValues = req.files.map((file, index) => {
          // If there are no existing images, make the first uploaded image primary
          const isPrimary = productImages[0].length === 0 && index === 0;
          return [req.params.id, file.path.replace(/\\/g, '/'), isPrimary, index];
        });
        
        await connection.query(
          `INSERT INTO product_images (product_id, image_url, is_primary, sort_order)
           VALUES ?`,
          [imageValues]
        );
      }
      
      await connection.commit();
      
      // Get the updated product with details
      const product = await query(
        `SELECT p.*, c.name as category_name
         FROM products p
         LEFT JOIN categories c ON p.category_id = c.id
         WHERE p.id = ?`,
        [req.params.id]
      );
      
      // Get attributes
      const updatedAttributes = await query(
        'SELECT attribute_name, attribute_value FROM product_attributes WHERE product_id = ?',
        [req.params.id]
      );
      
      // Get images
      const images = await query(
        'SELECT id, image_url, is_primary FROM product_images WHERE product_id = ? ORDER BY sort_order',
        [req.params.id]
      );
      
      // Get tags
      const tags = await query(`
        SELECT t.id, t.name
        FROM tags t
        JOIN content_tags ct ON t.id = ct.tag_id
        WHERE ct.content_id = ? AND ct.content_type = 'product'
      `, [req.params.id]);
      
      res.json({
        message: 'Product updated successfully',
        data: {
          ...product[0],
          attributes: updatedAttributes,
          images,
          tags
        }
      });
    } catch (error) {
      await connection.rollback();
      throw error;
    } finally {
      connection.release();
    }
  } catch (error) {
    logger.error(`Update product error: ${error.message}`);
    next(error);
  }
};

/**
 * @desc    Delete a product
 * @route   DELETE /api/v1/products/:id
 * @access  Private/Admin
 */
const deleteProduct = async (req, res, next) => {
  try {
    // Check if product exists
    const product = await query(
      'SELECT id, status FROM products WHERE id = ?',
      [req.params.id]
    );
    
    if (product.length === 0) {
      return res.status(404).json({
        message: 'Product not found'
      });
    }
    
    // Get product images to delete the files
    const images = await query(
      'SELECT image_url FROM product_images WHERE product_id = ?',
      [req.params.id]
    );
    
    // Begin transaction
    const connection = await require('../config/database').getConnection();
    await connection.beginTransaction();
    
    try {
      // Delete product relations first
      await connection.query(
        'DELETE FROM product_relations WHERE product_id = ? OR related_id = ?',
        [req.params.id, req.params.id]
      );
      
      // Delete product attributes
      await connection.query(
        'DELETE FROM product_attributes WHERE product_id = ?',
        [req.params.id]
      );
      
      // Delete content_tags references
      await connection.query(
        `DELETE FROM content_tags WHERE content_id = ? AND content_type = 'product'`,
        [req.params.id]
      );
      
      // Delete product images from database
      await connection.query(
        'DELETE FROM product_images WHERE product_id = ?',
        [req.params.id]
      );
      
      // Delete the product
      await connection.query(
        'DELETE FROM products WHERE id = ?',
        [req.params.id]
      );
      
      await connection.commit();
      
      // Delete image files from storage
      for (const image of images) {
        if (image.image_url) {
          const imagePath = path.join(__dirname, '../../../', image.image_url);
          if (fs.existsSync(imagePath)) {
            fs.unlinkSync(imagePath);
          }
        }
      }
      
      res.json({
        message: 'Product deleted successfully'
      });
    } catch (error) {
      await connection.rollback();
      throw error;
    } finally {
      connection.release();
    }
  } catch (error) {
    logger.error(`Delete product error: ${error.message}`);
    next(error);
  }
};

/**
 * @desc    Update product images (order, primary, delete)
 * @route   PUT /api/v1/products/:id/images
 * @access  Private/Admin/Editor
 */
const updateProductImages = async (req, res, next) => {
  try {
    const { images } = req.body;
    const productId = req.params.id;
    
    // Check if product exists
    const product = await query(
      'SELECT id FROM products WHERE id = ?',
      [productId]
    );
    
    if (product.length === 0) {
      return res.status(404).json({
        message: 'Product not found'
      });
    }
    
    // Begin transaction
    const connection = await require('../config/database').getConnection();
    await connection.beginTransaction();
    
    try {
      // Get current images
      const currentImages = await connection.query(
        'SELECT id, image_url FROM product_images WHERE product_id = ?',
        [productId]
      );
      
      const currentImageIds = currentImages[0].map(img => img.id);
      const newImageIds = images.map(img => img.id).filter(id => id !== undefined);
      
      // Find images to delete
      const imagesToDelete = currentImageIds.filter(id => !newImageIds.includes(id));
      
      // Delete removed images
      if (imagesToDelete.length > 0) {
        // Get paths of images to delete
        const imagesToDeletePaths = currentImages[0]
          .filter(img => imagesToDelete.includes(img.id))
          .map(img => img.image_url);
        
        await connection.query(
          'DELETE FROM product_images WHERE id IN (?)',
          [imagesToDelete]
        );
        
        // Delete files after transaction completes
        for (const imagePath of imagesToDeletePaths) {
          if (imagePath) {
            const fullPath = path.join(__dirname, '../../../', imagePath);
            if (fs.existsSync(fullPath)) {
              fs.unlinkSync(fullPath);
            }
          }
        }
      }
      
      // Update remaining images order and primary status
      for (let i = 0; i < images.length; i++) {
        const img = images[i];
        
        if (img.id) {
          await connection.query(
            'UPDATE product_images SET is_primary = ?, sort_order = ? WHERE id = ?',
            [img.is_primary === true, i, img.id]
          );
        }
      }
      
      await connection.commit();
      
      // Get updated images
      const updatedImages = await query(
        'SELECT id, image_url, is_primary FROM product_images WHERE product_id = ? ORDER BY sort_order',
        [productId]
      );
      
      res.json({
        message: 'Product images updated successfully',
        data: updatedImages
      });
    } catch (error) {
      await connection.rollback();
      throw error;
    } finally {
      connection.release();
    }
  } catch (error) {
    logger.error(`Update product images error: ${error.message}`);
    next(error);
  }
};

/**
 * @desc    Get product categories
 * @route   GET /api/v1/products/categories
 * @access  Public
 */
const getProductCategories = async (req, res, next) => {
  try {
    const categories = await query(`
      SELECT c.*, 
        (SELECT COUNT(*) FROM products p WHERE p.category_id = c.id AND p.status = 'active') as product_count
      FROM categories c 
      WHERE c.type = 'product' AND c.status = 'active'
      ORDER BY c.name
    `);
    
    res.json({
      message: 'Product categories retrieved successfully',
      data: categories
    });
  } catch (error) {
    logger.error(`Get product categories error: ${error.message}`);
    next(error);
  }
};

module.exports = {
  getProducts,
  getProductById,
  createProduct,
  updateProduct,
  deleteProduct,
  updateProductImages,
  getProductCategories
};