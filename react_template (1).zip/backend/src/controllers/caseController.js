/**
 * Case controller for managing case studies
 */
const { query } = require('../config/database');
const logger = require('../utils/logger');
const config = require('../config/app');
const path = require('path');
const fs = require('fs');

/**
 * @desc    Get all cases with pagination and filtering
 * @route   GET /api/v1/cases
 * @access  Public
 */
const getCases = async (req, res, next) => {
  try {
    const page = parseInt(req.query.page) || 1;
    const limit = parseInt(req.query.limit) || config.defaultPageSize;
    const search = req.query.search || null;
    const industry = req.query.industry || null;
    
    // Start building the SQL query
    let sql = `
      SELECT c.*, 
      u.name as author_name
      FROM cases c
      LEFT JOIN users u ON c.author_id = u.id
      WHERE c.status = 'published'
    `;
    
    const queryParams = [];
    
    // Add industry filter
    if (industry) {
      sql += ' AND c.industry = ?';
      queryParams.push(industry);
    }
    
    // Add search functionality
    if (search) {
      sql += ' AND (c.title LIKE ? OR c.content LIKE ? OR c.summary LIKE ? OR c.client LIKE ?)';
      queryParams.push(`%${search}%`, `%${search}%`, `%${search}%`, `%${search}%`);
    }
    
    // Add order and pagination
    sql += ' ORDER BY c.created_at DESC LIMIT ? OFFSET ?';
    queryParams.push(Number(limit), (Number(page) - 1) * Number(limit));
    
    // Execute the query
    const cases = await query(sql, queryParams);
    
    // Count total for pagination
    let countSql = `
      SELECT COUNT(*) as total FROM cases c 
      WHERE c.status = 'published'
    `;
    
    // Apply same filters to count query
    let countParams = [];
    
    if (industry) {
      countSql += ' AND c.industry = ?';
      countParams.push(industry);
    }
    
    if (search) {
      countSql += ' AND (c.title LIKE ? OR c.content LIKE ? OR c.summary LIKE ? OR c.client LIKE ?)';
      countParams.push(`%${search}%`, `%${search}%`, `%${search}%`, `%${search}%`);
    }
    
    const totalResult = await query(countSql, countParams);
    const total = totalResult[0].total;
    
    // Get industries for filter
    const industries = await query(`
      SELECT DISTINCT industry 
      FROM cases 
      WHERE status = 'published' AND industry IS NOT NULL AND industry != ''
      ORDER BY industry
    `);
    
    res.json({
      message: 'Cases retrieved successfully',
      data: cases,
      meta: {
        page,
        limit,
        totalItems: total,
        totalPages: Math.ceil(total / limit),
        industries: industries.map(item => item.industry)
      }
    });
  } catch (error) {
    logger.error(`Get cases error: ${error.message}`);
    next(error);
  }
};

/**
 * @desc    Get case by ID
 * @route   GET /api/v1/cases/:id
 * @access  Public
 */
const getCaseById = async (req, res, next) => {
  try {
    // Get case details
    const cases = await query(`
      SELECT c.*, 
      u.name as author_name
      FROM cases c
      LEFT JOIN users u ON c.author_id = u.id
      WHERE c.id = ? AND c.status = 'published'
    `, [req.params.id]);
    
    if (cases.length === 0) {
      return res.status(404).json({
        message: 'Case not found'
      });
    }
    
    const caseStudy = cases[0];
    
    // Get related products if any
    const relatedProducts = await query(`
      SELECT p.id, p.name, p.model, 
      (SELECT image_url FROM product_images WHERE product_id = p.id AND is_primary = 1 LIMIT 1) as primary_image
      FROM products p
      JOIN content_relations cr ON p.id = cr.related_id AND cr.related_type = 'product'
      WHERE cr.content_id = ? AND cr.content_type = 'case'
      AND p.status = 'active'
      LIMIT 3
    `, [req.params.id]);
    
    caseStudy.related_products = relatedProducts;
    
    // Get similar cases
    const similarCases = await query(`
      SELECT id, title, client, industry, featured_image, summary
      FROM cases
      WHERE industry = ? AND status = 'published' AND id != ?
      ORDER BY created_at DESC
      LIMIT 3
    `, [caseStudy.industry, caseStudy.id]);
    
    caseStudy.similar_cases = similarCases;
    
    res.json({
      message: 'Case retrieved successfully',
      data: caseStudy
    });
  } catch (error) {
    logger.error(`Get case error: ${error.message}`);
    next(error);
  }
};

/**
 * @desc    Create a new case
 * @route   POST /api/v1/cases
 * @access  Private/Admin/Editor
 */
const createCase = async (req, res, next) => {
  try {
    const { 
      title, content, summary, client, industry, status = 'published'
    } = req.body;
    
    // Begin transaction
    const connection = await require('../config/database').getConnection();
    await connection.beginTransaction();
    
    try {
      // Get featured image from request if available
      let featuredImage = null;
      if (req.file) {
        featuredImage = req.file.path.replace(/\\/g, '/');
      }
      
      // Create case
      const [result] = await connection.query(
        `INSERT INTO cases (title, content, summary, client, industry, featured_image, author_id, status)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
        [title, content, summary, client, industry, featuredImage, req.user.id, status]
      );
      
      const caseId = result.insertId;
      
      // Handle related products if provided
      if (req.body.related_products && req.body.related_products.length > 0) {
        const relatedProducts = req.body.related_products;
        
        for (const productId of relatedProducts) {
          // Check if product exists
          const [productExists] = await connection.query(
            'SELECT id FROM products WHERE id = ?',
            [productId]
          );
          
          if (productExists.length > 0) {
            await connection.query(
              `INSERT INTO content_relations (content_id, content_type, related_id, related_type)
               VALUES (?, 'case', ?, 'product')`,
              [caseId, productId]
            );
          }
        }
      }
      
      await connection.commit();
      
      // Get the created case with details
      const caseStudy = await query(
        `SELECT c.*, u.name as author_name
         FROM cases c
         LEFT JOIN users u ON c.author_id = u.id
         WHERE c.id = ?`,
        [caseId]
      );
      
      res.status(201).json({
        message: 'Case created successfully',
        data: caseStudy[0]
      });
    } catch (error) {
      await connection.rollback();
      throw error;
    } finally {
      connection.release();
    }
  } catch (error) {
    logger.error(`Create case error: ${error.message}`);
    next(error);
  }
};

/**
 * @desc    Update a case
 * @route   PUT /api/v1/cases/:id
 * @access  Private/Admin/Editor
 */
const updateCase = async (req, res, next) => {
  try {
    const { 
      title, content, summary, client, industry, status
    } = req.body;
    
    // Check if case exists
    const caseExists = await query(
      'SELECT id, featured_image FROM cases WHERE id = ?',
      [req.params.id]
    );
    
    if (caseExists.length === 0) {
      return res.status(404).json({
        message: 'Case not found'
      });
    }
    
    // Begin transaction
    const connection = await require('../config/database').getConnection();
    await connection.beginTransaction();
    
    try {
      // Update case
      const updateFields = [];
      const updateValues = [];
      
      if (title !== undefined) {
        updateFields.push('title = ?');
        updateValues.push(title);
      }
      
      if (content !== undefined) {
        updateFields.push('content = ?');
        updateValues.push(content);
      }
      
      if (summary !== undefined) {
        updateFields.push('summary = ?');
        updateValues.push(summary);
      }
      
      if (client !== undefined) {
        updateFields.push('client = ?');
        updateValues.push(client);
      }
      
      if (industry !== undefined) {
        updateFields.push('industry = ?');
        updateValues.push(industry);
      }
      
      if (status !== undefined) {
        updateFields.push('status = ?');
        updateValues.push(status);
      }
      
      // Handle featured image update
      if (req.file) {
        updateFields.push('featured_image = ?');
        updateValues.push(req.file.path.replace(/\\/g, '/'));
        
        // Delete old featured image if exists
        if (caseExists[0].featured_image) {
          const oldImagePath = path.join(__dirname, '../../../', caseExists[0].featured_image);
          if (fs.existsSync(oldImagePath)) {
            fs.unlinkSync(oldImagePath);
          }
        }
      }
      
      if (updateFields.length > 0) {
        await connection.query(
          `UPDATE cases SET ${updateFields.join(', ')} WHERE id = ?`,
          [...updateValues, req.params.id]
        );
      }
      
      // Update related products if provided
      if (req.body.related_products !== undefined) {
        // Delete existing product relations
        await connection.query(
          `DELETE FROM content_relations 
           WHERE content_id = ? AND content_type = 'case' AND related_type = 'product'`,
          [req.params.id]
        );
        
        // Add new product relations
        if (req.body.related_products && req.body.related_products.length > 0) {
          for (const productId of req.body.related_products) {
            // Check if product exists
            const [productExists] = await connection.query(
              'SELECT id FROM products WHERE id = ?',
              [productId]
            );
            
            if (productExists.length > 0) {
              await connection.query(
                `INSERT INTO content_relations (content_id, content_type, related_id, related_type)
                 VALUES (?, 'case', ?, 'product')`,
                [req.params.id, productId]
              );
            }
          }
        }
      }
      
      await connection.commit();
      
      // Get the updated case with details
      const caseStudy = await query(
        `SELECT c.*, u.name as author_name
         FROM cases c
         LEFT JOIN users u ON c.author_id = u.id
         WHERE c.id = ?`,
        [req.params.id]
      );
      
      // Get related products
      const relatedProducts = await query(`
        SELECT p.id, p.name, p.model, 
        (SELECT image_url FROM product_images WHERE product_id = p.id AND is_primary = 1 LIMIT 1) as primary_image
        FROM products p
        JOIN content_relations cr ON p.id = cr.related_id AND cr.related_type = 'product'
        WHERE cr.content_id = ? AND cr.content_type = 'case'
      `, [req.params.id]);
      
      res.json({
        message: 'Case updated successfully',
        data: {
          ...caseStudy[0],
          related_products: relatedProducts
        }
      });
    } catch (error) {
      await connection.rollback();
      throw error;
    } finally {
      connection.release();
    }
  } catch (error) {
    logger.error(`Update case error: ${error.message}`);
    next(error);
  }
};

/**
 * @desc    Delete a case
 * @route   DELETE /api/v1/cases/:id
 * @access  Private/Admin
 */
const deleteCase = async (req, res, next) => {
  try {
    // Check if case exists
    const caseStudy = await query(
      'SELECT id, featured_image FROM cases WHERE id = ?',
      [req.params.id]
    );
    
    if (caseStudy.length === 0) {
      return res.status(404).json({
        message: 'Case not found'
      });
    }
    
    // Begin transaction
    const connection = await require('../config/database').getConnection();
    await connection.beginTransaction();
    
    try {
      // Delete content relations
      await connection.query(
        `DELETE FROM content_relations 
         WHERE (content_id = ? AND content_type = 'case')
         OR (related_id = ? AND related_type = 'case')`,
        [req.params.id, req.params.id]
      );
      
      // Delete the case
      await connection.query(
        'DELETE FROM cases WHERE id = ?',
        [req.params.id]
      );
      
      await connection.commit();
      
      // Delete featured image if exists
      if (caseStudy[0].featured_image) {
        const imagePath = path.join(__dirname, '../../../', caseStudy[0].featured_image);
        if (fs.existsSync(imagePath)) {
          fs.unlinkSync(imagePath);
        }
      }
      
      res.json({
        message: 'Case deleted successfully'
      });
    } catch (error) {
      await connection.rollback();
      throw error;
    } finally {
      connection.release();
    }
  } catch (error) {
    logger.error(`Delete case error: ${error.message}`);
    next(error);
  }
};

module.exports = {
  getCases,
  getCaseById,
  createCase,
  updateCase,
  deleteCase
};