/**
 * Article controller for managing articles
 */
const { query } = require('../config/database');
const logger = require('../utils/logger');
const config = require('../config/app');
const path = require('path');
const fs = require('fs');

/**
 * @desc    Get all articles with pagination and filtering
 * @route   GET /api/v1/articles
 * @access  Public
 */
const getArticles = async (req, res, next) => {
  try {
    const page = parseInt(req.query.page) || 1;
    const limit = parseInt(req.query.limit) || config.defaultPageSize;
    const categoryId = req.query.category || null;
    const featured = req.query.featured ? req.query.featured === 'true' : null;
    const search = req.query.search || null;
    
    // Start building the SQL query
    let sql = `
      SELECT a.*, 
      c.name as category_name,
      u.name as author_name
      FROM articles a
      LEFT JOIN categories c ON a.category_id = c.id
      LEFT JOIN users u ON a.author_id = u.id
      WHERE a.status = 'published'
    `;
    
    const queryParams = [];
    
    // Add category filter
    if (categoryId) {
      sql += ' AND a.category_id = ?';
      queryParams.push(categoryId);
    }
    
    // Add featured filter
    if (featured !== null) {
      sql += featured ? ' AND a.featured_image IS NOT NULL' : ' AND a.featured_image IS NULL';
    }
    
    // Add search functionality
    if (search) {
      sql += ' AND (a.title LIKE ? OR a.content LIKE ? OR a.summary LIKE ?)';
      queryParams.push(`%${search}%`, `%${search}%`, `%${search}%`);
    }
    
    // Add order and pagination
    sql += ' ORDER BY a.created_at DESC LIMIT ? OFFSET ?';
    queryParams.push(Number(limit), (Number(page) - 1) * Number(limit));
    
    // Execute the query
    const articles = await query(sql, queryParams);
    
    // Get tags for each article
    for (const article of articles) {
      const tags = await query(`
        SELECT t.id, t.name
        FROM tags t
        JOIN content_tags ct ON t.id = ct.tag_id
        WHERE ct.content_id = ? AND ct.content_type = 'article'
      `, [article.id]);
      
      article.tags = tags;
    }
    
    // Count total for pagination
    let countSql = `
      SELECT COUNT(*) as total FROM articles a 
      WHERE a.status = 'published'
    `;
    
    // Apply same filters to count query
    let countParams = [];
    
    if (categoryId) {
      countSql += ' AND a.category_id = ?';
      countParams.push(categoryId);
    }
    
    if (featured !== null) {
      countSql += featured ? ' AND a.featured_image IS NOT NULL' : ' AND a.featured_image IS NULL';
    }
    
    if (search) {
      countSql += ' AND (a.title LIKE ? OR a.content LIKE ? OR a.summary LIKE ?)';
      countParams.push(`%${search}%`, `%${search}%`, `%${search}%`);
    }
    
    const totalResult = await query(countSql, countParams);
    const total = totalResult[0].total;
    
    res.json({
      message: 'Articles retrieved successfully',
      data: articles,
      meta: {
        page,
        limit,
        totalItems: total,
        totalPages: Math.ceil(total / limit)
      }
    });
  } catch (error) {
    logger.error(`Get articles error: ${error.message}`);
    next(error);
  }
};

/**
 * @desc    Get article by ID
 * @route   GET /api/v1/articles/:id
 * @access  Public
 */
const getArticleById = async (req, res, next) => {
  try {
    // Get article details
    const articles = await query(`
      SELECT a.*, 
      c.name as category_name,
      u.name as author_name
      FROM articles a
      LEFT JOIN categories c ON a.category_id = c.id
      LEFT JOIN users u ON a.author_id = u.id
      WHERE a.id = ? AND a.status = 'published'
    `, [req.params.id]);
    
    if (articles.length === 0) {
      return res.status(404).json({
        message: 'Article not found'
      });
    }
    
    const article = articles[0];
    
    // Get tags
    const tags = await query(`
      SELECT t.id, t.name
      FROM tags t
      JOIN content_tags ct ON t.id = ct.tag_id
      WHERE ct.content_id = ? AND ct.content_type = 'article'
    `, [article.id]);
    
    article.tags = tags;
    
    // Get related articles
    const relatedArticles = await query(`
      SELECT a.id, a.title, a.summary, a.featured_image, a.created_at
      FROM articles a
      JOIN content_tags ct1 ON a.id = ct1.content_id AND ct1.content_type = 'article'
      JOIN content_tags ct2 ON ct1.tag_id = ct2.tag_id AND ct2.content_type = 'article'
      WHERE ct2.content_id = ? 
      AND a.id != ?
      AND a.status = 'published'
      GROUP BY a.id
      ORDER BY COUNT(a.id) DESC, a.created_at DESC
      LIMIT 3
    `, [article.id, article.id]);
    
    article.related_articles = relatedArticles;
    
    // Get related products if any
    const relatedProducts = await query(`
      SELECT p.id, p.name, p.model, 
      (SELECT image_url FROM product_images WHERE product_id = p.id AND is_primary = 1 LIMIT 1) as primary_image
      FROM products p
      JOIN content_relations cr ON p.id = cr.related_id AND cr.related_type = 'product'
      WHERE cr.content_id = ? AND cr.content_type = 'article'
      AND p.status = 'active'
      LIMIT 3
    `, [article.id]);
    
    article.related_products = relatedProducts;
    
    res.json({
      message: 'Article retrieved successfully',
      data: article
    });
  } catch (error) {
    logger.error(`Get article error: ${error.message}`);
    next(error);
  }
};

/**
 * @desc    Create a new article
 * @route   POST /api/v1/articles
 * @access  Private/Admin/Editor
 */
const createArticle = async (req, res, next) => {
  try {
    const { 
      title, content, summary, category_id, status = 'published'
    } = req.body;
    
    // Begin transaction
    const connection = await require('../config/database').getConnection();
    await connection.beginTransaction();
    
    try {
      // Get featured image from request if available
      let featuredImage = null;
      if (req.file) {
        featuredImage = req.file.path.replace(/\\/g, '/');
      }
      
      // Create article
      const [result] = await connection.query(
        `INSERT INTO articles (title, content, summary, category_id, featured_image, author_id, status)
         VALUES (?, ?, ?, ?, ?, ?, ?)`,
        [title, content, summary, category_id, featuredImage, req.user.id, status]
      );
      
      const articleId = result.insertId;
      
      // Handle tags if provided
      if (req.body.tags && req.body.tags.length > 0) {
        for (const tagName of req.body.tags) {
          // Try to find existing tag or create new one
          let [tagResult] = await connection.query(
            'SELECT id FROM tags WHERE name = ?',
            [tagName]
          );
          
          let tagId;
          if (tagResult.length === 0) {
            // Create new tag
            const [newTag] = await connection.query(
              'INSERT INTO tags (name) VALUES (?)',
              [tagName]
            );
            tagId = newTag.insertId;
          } else {
            tagId = tagResult[0].id;
          }
          
          // Link tag to article
          await connection.query(
            `INSERT INTO content_tags (tag_id, content_id, content_type)
             VALUES (?, ?, 'article')`,
            [tagId, articleId]
          );
        }
      }
      
      // Handle related products if provided
      if (req.body.related_products && req.body.related_products.length > 0) {
        const relatedProducts = req.body.related_products;
        
        for (const productId of relatedProducts) {
          // Check if product exists
          const [productExists] = await connection.query(
            'SELECT id FROM products WHERE id = ?',
            [productId]
          );
          
          if (productExists.length > 0) {
            await connection.query(
              `INSERT INTO content_relations (content_id, content_type, related_id, related_type)
               VALUES (?, 'article', ?, 'product')`,
              [articleId, productId]
            );
          }
        }
      }
      
      await connection.commit();
      
      // Get the created article with details
      const article = await query(
        `SELECT a.*, c.name as category_name, u.name as author_name
         FROM articles a
         LEFT JOIN categories c ON a.category_id = c.id
         LEFT JOIN users u ON a.author_id = u.id
         WHERE a.id = ?`,
        [articleId]
      );
      
      res.status(201).json({
        message: 'Article created successfully',
        data: article[0]
      });
    } catch (error) {
      await connection.rollback();
      throw error;
    } finally {
      connection.release();
    }
  } catch (error) {
    logger.error(`Create article error: ${error.message}`);
    next(error);
  }
};

/**
 * @desc    Update an article
 * @route   PUT /api/v1/articles/:id
 * @access  Private/Admin/Editor
 */
const updateArticle = async (req, res, next) => {
  try {
    const { 
      title, content, summary, category_id, status
    } = req.body;
    
    // Check if article exists
    const articleExists = await query(
      'SELECT id, featured_image FROM articles WHERE id = ?',
      [req.params.id]
    );
    
    if (articleExists.length === 0) {
      return res.status(404).json({
        message: 'Article not found'
      });
    }
    
    // Begin transaction
    const connection = await require('../config/database').getConnection();
    await connection.beginTransaction();
    
    try {
      // Update article
      const updateFields = [];
      const updateValues = [];
      
      if (title !== undefined) {
        updateFields.push('title = ?');
        updateValues.push(title);
      }
      
      if (content !== undefined) {
        updateFields.push('content = ?');
        updateValues.push(content);
      }
      
      if (summary !== undefined) {
        updateFields.push('summary = ?');
        updateValues.push(summary);
      }
      
      if (category_id !== undefined) {
        updateFields.push('category_id = ?');
        updateValues.push(category_id);
      }
      
      if (status !== undefined) {
        updateFields.push('status = ?');
        updateValues.push(status);
      }
      
      // Handle featured image update
      if (req.file) {
        updateFields.push('featured_image = ?');
        updateValues.push(req.file.path.replace(/\\/g, '/'));
        
        // Delete old featured image if exists
        if (articleExists[0].featured_image) {
          const oldImagePath = path.join(__dirname, '../../../', articleExists[0].featured_image);
          if (fs.existsSync(oldImagePath)) {
            fs.unlinkSync(oldImagePath);
          }
        }
      }
      
      if (updateFields.length > 0) {
        await connection.query(
          `UPDATE articles SET ${updateFields.join(', ')} WHERE id = ?`,
          [...updateValues, req.params.id]
        );
      }
      
      // Update tags if provided
      if (req.body.tags !== undefined) {
        // Delete existing tag associations
        await connection.query(
          `DELETE FROM content_tags WHERE content_id = ? AND content_type = 'article'`,
          [req.params.id]
        );
        
        // Add new tags
        if (req.body.tags && req.body.tags.length > 0) {
          for (const tagName of req.body.tags) {
            // Try to find existing tag or create new one
            let [tagResult] = await connection.query(
              'SELECT id FROM tags WHERE name = ?',
              [tagName]
            );
            
            let tagId;
            if (tagResult.length === 0) {
              // Create new tag
              const [newTag] = await connection.query(
                'INSERT INTO tags (name) VALUES (?)',
                [tagName]
              );
              tagId = newTag.insertId;
            } else {
              tagId = tagResult[0].id;
            }
            
            // Link tag to article
            await connection.query(
              `INSERT INTO content_tags (tag_id, content_id, content_type)
               VALUES (?, ?, 'article')`,
              [tagId, req.params.id]
            );
          }
        }
      }
      
      // Update related products if provided
      if (req.body.related_products !== undefined) {
        // Delete existing product relations
        await connection.query(
          `DELETE FROM content_relations 
           WHERE content_id = ? AND content_type = 'article' AND related_type = 'product'`,
          [req.params.id]
        );
        
        // Add new product relations
        if (req.body.related_products && req.body.related_products.length > 0) {
          for (const productId of req.body.related_products) {
            // Check if product exists
            const [productExists] = await connection.query(
              'SELECT id FROM products WHERE id = ?',
              [productId]
            );
            
            if (productExists.length > 0) {
              await connection.query(
                `INSERT INTO content_relations (content_id, content_type, related_id, related_type)
                 VALUES (?, 'article', ?, 'product')`,
                [req.params.id, productId]
              );
            }
          }
        }
      }
      
      await connection.commit();
      
      // Get the updated article with details
      const article = await query(
        `SELECT a.*, c.name as category_name, u.name as author_name
         FROM articles a
         LEFT JOIN categories c ON a.category_id = c.id
         LEFT JOIN users u ON a.author_id = u.id
         WHERE a.id = ?`,
        [req.params.id]
      );
      
      // Get tags
      const tags = await query(`
        SELECT t.id, t.name
        FROM tags t
        JOIN content_tags ct ON t.id = ct.tag_id
        WHERE ct.content_id = ? AND ct.content_type = 'article'
      `, [req.params.id]);
      
      // Get related products
      const relatedProducts = await query(`
        SELECT p.id, p.name, p.model, 
        (SELECT image_url FROM product_images WHERE product_id = p.id AND is_primary = 1 LIMIT 1) as primary_image
        FROM products p
        JOIN content_relations cr ON p.id = cr.related_id AND cr.related_type = 'product'
        WHERE cr.content_id = ? AND cr.content_type = 'article'
      `, [req.params.id]);
      
      res.json({
        message: 'Article updated successfully',
        data: {
          ...article[0],
          tags,
          related_products: relatedProducts
        }
      });
    } catch (error) {
      await connection.rollback();
      throw error;
    } finally {
      connection.release();
    }
  } catch (error) {
    logger.error(`Update article error: ${error.message}`);
    next(error);
  }
};

/**
 * @desc    Delete an article
 * @route   DELETE /api/v1/articles/:id
 * @access  Private/Admin
 */
const deleteArticle = async (req, res, next) => {
  try {
    // Check if article exists
    const article = await query(
      'SELECT id, featured_image FROM articles WHERE id = ?',
      [req.params.id]
    );
    
    if (article.length === 0) {
      return res.status(404).json({
        message: 'Article not found'
      });
    }
    
    // Begin transaction
    const connection = await require('../config/database').getConnection();
    await connection.beginTransaction();
    
    try {
      // Delete content relations
      await connection.query(
        `DELETE FROM content_relations 
         WHERE (content_id = ? AND content_type = 'article')
         OR (related_id = ? AND related_type = 'article')`,
        [req.params.id, req.params.id]
      );
      
      // Delete content tags
      await connection.query(
        `DELETE FROM content_tags WHERE content_id = ? AND content_type = 'article'`,
        [req.params.id]
      );
      
      // Delete the article
      await connection.query(
        'DELETE FROM articles WHERE id = ?',
        [req.params.id]
      );
      
      await connection.commit();
      
      // Delete featured image if exists
      if (article[0].featured_image) {
        const imagePath = path.join(__dirname, '../../../', article[0].featured_image);
        if (fs.existsSync(imagePath)) {
          fs.unlinkSync(imagePath);
        }
      }
      
      res.json({
        message: 'Article deleted successfully'
      });
    } catch (error) {
      await connection.rollback();
      throw error;
    } finally {
      connection.release();
    }
  } catch (error) {
    logger.error(`Delete article error: ${error.message}`);
    next(error);
  }
};

/**
 * @desc    Get article categories
 * @route   GET /api/v1/articles/categories
 * @access  Public
 */
const getArticleCategories = async (req, res, next) => {
  try {
    const categories = await query(`
      SELECT c.*, 
        (SELECT COUNT(*) FROM articles a WHERE a.category_id = c.id AND a.status = 'published') as article_count
      FROM categories c 
      WHERE c.type = 'article' AND c.status = 'active'
      ORDER BY c.name
    `);
    
    res.json({
      message: 'Article categories retrieved successfully',
      data: categories
    });
  } catch (error) {
    logger.error(`Get article categories error: ${error.message}`);
    next(error);
  }
};

module.exports = {
  getArticles,
  getArticleById,
  createArticle,
  updateArticle,
  deleteArticle,
  getArticleCategories
};