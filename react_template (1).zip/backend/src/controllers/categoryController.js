/**
 * Category controller for managing categories
 */
const { query } = require('../config/database');
const logger = require('../utils/logger');
const config = require('../config/app');
const path = require('path');
const fs = require('fs');

/**
 * @desc    Get all categories with optional type filter
 * @route   GET /api/v1/categories
 * @access  Public
 */
const getCategories = async (req, res, next) => {
  try {
    const type = req.query.type || null;
    const parentId = req.query.parent || null;
    
    let sql = `
      SELECT c.*, 
      (SELECT COUNT(*) FROM categories WHERE parent_id = c.id) as child_count
      FROM categories c 
      WHERE c.status = 'active'
    `;
    
    const params = [];
    
    // Filter by type if provided
    if (type) {
      sql += ' AND c.type = ?';
      params.push(type);
    }
    
    // Filter by parent_id if provided
    if (parentId !== null) {
      if (parentId === 'null') {
        // Get top-level categories
        sql += ' AND c.parent_id IS NULL';
      } else {
        // Get child categories of specified parent
        sql += ' AND c.parent_id = ?';
        params.push(parentId);
      }
    }
    
    sql += ' ORDER BY c.name';
    
    const categories = await query(sql, params);
    
    res.json({
      message: 'Categories retrieved successfully',
      data: categories
    });
  } catch (error) {
    logger.error(`Get categories error: ${error.message}`);
    next(error);
  }
};

/**
 * @desc    Get category by ID
 * @route   GET /api/v1/categories/:id
 * @access  Public
 */
const getCategoryById = async (req, res, next) => {
  try {
    const categoryId = req.params.id;
    
    const categories = await query(`
      SELECT c.*, 
      (SELECT COUNT(*) FROM categories WHERE parent_id = c.id) as child_count
      FROM categories c 
      WHERE c.id = ? AND c.status = 'active'
    `, [categoryId]);
    
    if (categories.length === 0) {
      return res.status(404).json({
        message: 'Category not found'
      });
    }
    
    const category = categories[0];
    
    // Get child categories if any
    if (category.child_count > 0) {
      const children = await query(`
        SELECT c.*
        FROM categories c
        WHERE c.parent_id = ? AND c.status = 'active'
        ORDER BY c.name
      `, [categoryId]);
      
      category.children = children;
    }
    
    res.json({
      message: 'Category retrieved successfully',
      data: category
    });
  } catch (error) {
    logger.error(`Get category error: ${error.message}`);
    next(error);
  }
};

/**
 * @desc    Create a new category
 * @route   POST /api/v1/categories
 * @access  Private/Admin/Editor
 */
const createCategory = async (req, res, next) => {
  try {
    const { name, description, parent_id, type, status = 'active' } = req.body;
    
    // Handle image upload if provided
    let imagePath = null;
    if (req.file) {
      imagePath = req.file.path.replace(/\\/g, '/');
    }
    
    // Create category
    const result = await query(
      `INSERT INTO categories (name, description, parent_id, image, type, status)
       VALUES (?, ?, ?, ?, ?, ?)`,
      [name, description, parent_id || null, imagePath, type, status]
    );
    
    const categoryId = result.insertId;
    
    const category = await query(
      'SELECT * FROM categories WHERE id = ?',
      [categoryId]
    );
    
    res.status(201).json({
      message: 'Category created successfully',
      data: category[0]
    });
  } catch (error) {
    logger.error(`Create category error: ${error.message}`);
    next(error);
  }
};

/**
 * @desc    Update a category
 * @route   PUT /api/v1/categories/:id
 * @access  Private/Admin/Editor
 */
const updateCategory = async (req, res, next) => {
  try {
    const categoryId = req.params.id;
    const { name, description, parent_id, type, status } = req.body;
    
    // Check if category exists
    const existingCategory = await query(
      'SELECT * FROM categories WHERE id = ?',
      [categoryId]
    );
    
    if (existingCategory.length === 0) {
      return res.status(404).json({
        message: 'Category not found'
      });
    }
    
    // Prevent circular parent reference
    if (parent_id && parent_id !== 'null' && parseInt(parent_id) === parseInt(categoryId)) {
      return res.status(400).json({
        message: 'Category cannot be its own parent'
      });
    }
    
    // Build update fields
    const updateFields = [];
    const updateValues = [];
    
    if (name !== undefined) {
      updateFields.push('name = ?');
      updateValues.push(name);
    }
    
    if (description !== undefined) {
      updateFields.push('description = ?');
      updateValues.push(description);
    }
    
    if (parent_id !== undefined) {
      if (parent_id === 'null') {
        updateFields.push('parent_id = NULL');
      } else {
        updateFields.push('parent_id = ?');
        updateValues.push(parent_id);
      }
    }
    
    if (type !== undefined) {
      updateFields.push('type = ?');
      updateValues.push(type);
    }
    
    if (status !== undefined) {
      updateFields.push('status = ?');
      updateValues.push(status);
    }
    
    // Handle image update
    if (req.file) {
      updateFields.push('image = ?');
      updateValues.push(req.file.path.replace(/\\/g, '/'));
      
      // Delete old image if exists
      if (existingCategory[0].image) {
        const oldImagePath = path.join(__dirname, '../../../', existingCategory[0].image);
        if (fs.existsSync(oldImagePath)) {
          fs.unlinkSync(oldImagePath);
        }
      }
    }
    
    // If no fields to update
    if (updateFields.length === 0) {
      return res.json({
        message: 'No changes to update',
        data: existingCategory[0]
      });
    }
    
    // Update category
    updateValues.push(categoryId);
    await query(
      `UPDATE categories SET ${updateFields.join(', ')} WHERE id = ?`,
      updateValues
    );
    
    const updatedCategory = await query(
      'SELECT * FROM categories WHERE id = ?',
      [categoryId]
    );
    
    res.json({
      message: 'Category updated successfully',
      data: updatedCategory[0]
    });
  } catch (error) {
    logger.error(`Update category error: ${error.message}`);
    next(error);
  }
};

/**
 * @desc    Delete a category
 * @route   DELETE /api/v1/categories/:id
 * @access  Private/Admin
 */
const deleteCategory = async (req, res, next) => {
  try {
    const categoryId = req.params.id;
    
    // Check if category exists
    const category = await query(
      'SELECT * FROM categories WHERE id = ?',
      [categoryId]
    );
    
    if (category.length === 0) {
      return res.status(404).json({
        message: 'Category not found'
      });
    }
    
    // Check if has child categories
    const childCount = await query(
      'SELECT COUNT(*) as count FROM categories WHERE parent_id = ?',
      [categoryId]
    );
    
    if (childCount[0].count > 0) {
      return res.status(400).json({
        message: 'Cannot delete category with child categories. Delete or reassign child categories first.'
      });
    }
    
    // Check if has associated products or articles
    if (category[0].type === 'product') {
      const productCount = await query(
        'SELECT COUNT(*) as count FROM products WHERE category_id = ?',
        [categoryId]
      );
      
      if (productCount[0].count > 0) {
        return res.status(400).json({
          message: 'Cannot delete category with associated products. Reassign products first.'
        });
      }
    } else if (category[0].type === 'article') {
      const articleCount = await query(
        'SELECT COUNT(*) as count FROM articles WHERE category_id = ?',
        [categoryId]
      );
      
      if (articleCount[0].count > 0) {
        return res.status(400).json({
          message: 'Cannot delete category with associated articles. Reassign articles first.'
        });
      }
    }
    
    // Delete category
    await query(
      'DELETE FROM categories WHERE id = ?',
      [categoryId]
    );
    
    // Delete category image if exists
    if (category[0].image) {
      const imagePath = path.join(__dirname, '../../../', category[0].image);
      if (fs.existsSync(imagePath)) {
        fs.unlinkSync(imagePath);
      }
    }
    
    res.json({
      message: 'Category deleted successfully'
    });
  } catch (error) {
    logger.error(`Delete category error: ${error.message}`);
    next(error);
  }
};

module.exports = {
  getCategories,
  getCategoryById,
  createCategory,
  updateCategory,
  deleteCategory
};