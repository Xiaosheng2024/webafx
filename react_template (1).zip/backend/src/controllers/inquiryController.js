/**
 * Inquiry controller for handling customer inquiries
 */
const { query } = require('../config/database');
const logger = require('../utils/logger');
const config = require('../config/app');

/**
 * @desc    Submit a new inquiry
 * @route   POST /api/v1/inquiries
 * @access  Public
 */
const submitInquiry = async (req, res, next) => {
  try {
    const { name, email, phone, company, subject, message, related_product } = req.body;
    
    if (!name || !email || !subject || !message) {
      return res.status(400).json({
        message: 'Please provide name, email, subject, and message'
      });
    }
    
    // Validate email format
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
      return res.status(400).json({
        message: 'Please provide a valid email address'
      });
    }
    
    // Create new inquiry
    const result = await query(
      `INSERT INTO inquiries (name, email, phone, company, subject, message, related_product, status)
       VALUES (?, ?, ?, ?, ?, ?, ?, 'new')`,
      [name, email, phone || null, company || null, subject, message, related_product || null]
    );
    
    // Get the created inquiry
    const inquiry = await query(
      'SELECT * FROM inquiries WHERE id = ?',
      [result.insertId]
    );
    
    // TODO: Send notification email to admin if enabled
    if (config.enableEmailNotifications) {
      // Implement email sending logic here
    }
    
    res.status(201).json({
      message: 'Inquiry submitted successfully',
      data: inquiry[0]
    });
  } catch (error) {
    logger.error(`Submit inquiry error: ${error.message}`);
    next(error);
  }
};

/**
 * @desc    Get all inquiries (for admin/editor)
 * @route   GET /api/v1/inquiries
 * @access  Private/Admin/Editor
 */
const getInquiries = async (req, res, next) => {
  try {
    const page = parseInt(req.query.page) || 1;
    const limit = parseInt(req.query.limit) || config.defaultPageSize;
    const status = req.query.status || null;
    
    let sql = `
      SELECT i.*, p.name as product_name
      FROM inquiries i
      LEFT JOIN products p ON i.related_product = p.id
    `;
    
    const queryParams = [];
    
    if (status) {
      sql += ' WHERE i.status = ?';
      queryParams.push(status);
    }
    
    // Add order and pagination
    sql += ' ORDER BY i.created_at DESC LIMIT ? OFFSET ?';
    queryParams.push(Number(limit), (Number(page) - 1) * Number(limit));
    
    // Execute query
    const inquiries = await query(sql, queryParams);
    
    // Count total for pagination
    let countSql = 'SELECT COUNT(*) as total FROM inquiries';
    
    if (status) {
      countSql += ' WHERE status = ?';
    }
    
    const totalResult = await query(countSql, status ? [status] : []);
    const total = totalResult[0].total;
    
    res.json({
      message: 'Inquiries retrieved successfully',
      data: inquiries,
      meta: {
        page,
        limit,
        totalItems: total,
        totalPages: Math.ceil(total / limit)
      }
    });
  } catch (error) {
    logger.error(`Get inquiries error: ${error.message}`);
    next(error);
  }
};

/**
 * @desc    Get inquiry by ID
 * @route   GET /api/v1/inquiries/:id
 * @access  Private/Admin/Editor
 */
const getInquiryById = async (req, res, next) => {
  try {
    const inquiry = await query(
      `SELECT i.*, p.name as product_name
       FROM inquiries i
       LEFT JOIN products p ON i.related_product = p.id
       WHERE i.id = ?`,
      [req.params.id]
    );
    
    if (inquiry.length === 0) {
      return res.status(404).json({
        message: 'Inquiry not found'
      });
    }
    
    res.json({
      message: 'Inquiry retrieved successfully',
      data: inquiry[0]
    });
  } catch (error) {
    logger.error(`Get inquiry error: ${error.message}`);
    next(error);
  }
};

/**
 * @desc    Update inquiry status
 * @route   PUT /api/v1/inquiries/:id
 * @access  Private/Admin/Editor
 */
const updateInquiryStatus = async (req, res, next) => {
  try {
    const { status } = req.body;
    
    if (!status || !['new', 'in-progress', 'completed', 'spam'].includes(status)) {
      return res.status(400).json({
        message: 'Please provide a valid status (new, in-progress, completed, spam)'
      });
    }
    
    // Check if inquiry exists
    const inquiry = await query(
      'SELECT * FROM inquiries WHERE id = ?',
      [req.params.id]
    );
    
    if (inquiry.length === 0) {
      return res.status(404).json({
        message: 'Inquiry not found'
      });
    }
    
    // Update status
    await query(
      'UPDATE inquiries SET status = ? WHERE id = ?',
      [status, req.params.id]
    );
    
    // Get updated inquiry
    const updatedInquiry = await query(
      `SELECT i.*, p.name as product_name
       FROM inquiries i
       LEFT JOIN products p ON i.related_product = p.id
       WHERE i.id = ?`,
      [req.params.id]
    );
    
    res.json({
      message: 'Inquiry status updated successfully',
      data: updatedInquiry[0]
    });
  } catch (error) {
    logger.error(`Update inquiry status error: ${error.message}`);
    next(error);
  }
};

/**
 * @desc    Delete inquiry
 * @route   DELETE /api/v1/inquiries/:id
 * @access  Private/Admin
 */
const deleteInquiry = async (req, res, next) => {
  try {
    // Check if inquiry exists
    const inquiry = await query(
      'SELECT * FROM inquiries WHERE id = ?',
      [req.params.id]
    );
    
    if (inquiry.length === 0) {
      return res.status(404).json({
        message: 'Inquiry not found'
      });
    }
    
    // Delete inquiry
    await query(
      'DELETE FROM inquiries WHERE id = ?',
      [req.params.id]
    );
    
    res.json({
      message: 'Inquiry deleted successfully'
    });
  } catch (error) {
    logger.error(`Delete inquiry error: ${error.message}`);
    next(error);
  }
};

module.exports = {
  submitInquiry,
  getInquiries,
  getInquiryById,
  updateInquiryStatus,
  deleteInquiry
};