module.exports = {
  // Application configuration
  name: 'Enterprise Website & E-Commerce Platform',
  env: process.env.NODE_ENV || 'development',
  port: process.env.PORT || 5000,
  apiUrl: process.env.API_URL || 'http://localhost:5000/api/v1',
  frontendUrl: process.env.FRONTEND_URL || 'http://localhost:5173',

  // Security configuration
  jwtSecret: process.env.JWT_SECRET || 'your_jwt_secret',
  jwtExpiresIn: process.env.JWT_EXPIRES_IN || '30d',
  saltRounds: 10,

  // Upload configuration
  uploadDir: process.env.UPLOAD_DIR || 'uploads',
  maxFileSize: process.env.MAX_FILE_SIZE || 5 * 1024 * 1024, // 5MB
  allowedFileTypes: ['image/jpeg', 'image/png', 'image/gif', 'application/pdf', 'application/msword', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'],

  // Cache configuration
  useRedisCache: process.env.USE_REDIS_CACHE === 'true',
  cacheTTL: {
    short: 60 * 5, // 5 minutes
    medium: 60 * 30, // 30 minutes
    long: 60 * 60 * 24, // 24 hours
  },

  // Pagination defaults
  defaultPageSize: 20,
  maxPageSize: 100,

  // Admin configuration
  defaultAdminEmail: process.env.DEFAULT_ADMIN_EMAIL || 'admin@example.com',
  defaultAdminPassword: process.env.DEFAULT_ADMIN_PASSWORD || 'admin123',

  // Notification configuration
  enableEmailNotifications: process.env.ENABLE_EMAIL_NOTIFICATIONS === 'true',
  notificationEmail: process.env.NOTIFICATION_EMAIL || 'notifications@example.com',
  
  // SEO configuration
  siteTitle: '企业官网/电商平台',
  siteDescription: '专业的企业官网/电商平台，用于展示及推广扫描设备、打印机设备、软件服务器和集成打包方案',
  defaultMetaKeywords: '扫描设备,打印设备,软件服务器,集成打包方案',
};