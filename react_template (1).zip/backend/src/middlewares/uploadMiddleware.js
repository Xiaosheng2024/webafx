/**
 * Middleware for file upload handling
 */

const multer = require('multer');
const path = require('path');
const fs = require('fs');
const sharp = require('sharp');
const config = require('../config/app');
const logger = require('../utils/logger');

// Ensure upload directory exists
const uploadDir = path.join(__dirname, '../../', config.uploadDir);
if (!fs.existsSync(uploadDir)) {
  fs.mkdirSync(uploadDir, { recursive: true });
}

// Create subdirectories for different content types
const contentTypes = ['products', 'articles', 'cases', 'users', 'general'];
contentTypes.forEach(type => {
  const dir = path.join(uploadDir, type);
  if (!fs.existsSync(dir)) {
    fs.mkdirSync(dir, { recursive: true });
  }
});

// Configure storage
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    // Determine which folder to save to based on req.body.contentType or default to 'general'
    const contentType = req.body.contentType && contentTypes.includes(req.body.contentType)
      ? req.body.contentType 
      : 'general';
    
    const destination = path.join(uploadDir, contentType);
    cb(null, destination);
  },
  filename: (req, file, cb) => {
    // Generate unique filename with timestamp and original extension
    const fileExt = path.extname(file.originalname);
    const fileName = `${Date.now()}-${Math.round(Math.random() * 1E9)}${fileExt}`;
    cb(null, fileName);
  }
});

// File filter to check file types
const fileFilter = (req, file, cb) => {
  const allowedTypes = config.allowedFileTypes;
  
  if (allowedTypes.includes(file.mimetype)) {
    cb(null, true);
  } else {
    cb(new Error(`File type ${file.mimetype} is not allowed. Allowed types: ${allowedTypes.join(', ')}`), false);
  }
};

// Create multer upload instance
const upload = multer({ 
  storage,
  limits: {
    fileSize: config.maxFileSize // from config
  },
  fileFilter
});

/**
 * Image processing middleware for resizing images
 */
const resizeImage = async (req, res, next) => {
  if (!req.file || !req.file.path || !req.file.mimetype.startsWith('image/')) {
    return next();
  }

  try {
    const imagePath = req.file.path;
    const resizedPath = `${imagePath.split('.').slice(0, -1).join('.')}-resized.jpg`;
    
    // Get dimensions from query params or use defaults
    const width = parseInt(req.query.width, 10) || 800;
    const height = parseInt(req.query.height, 10) || 600;
    const quality = parseInt(req.query.quality, 10) || 80;

    await sharp(imagePath)
      .resize(width, height, {
        fit: 'inside',
        withoutEnlargement: true
      })
      .jpeg({ quality })
      .toFile(resizedPath);

    // Replace original file with resized version
    fs.unlinkSync(imagePath);
    fs.renameSync(resizedPath, imagePath);
    
    // Update file size in req.file object
    const stats = fs.statSync(imagePath);
    req.file.size = stats.size;
    
    next();
  } catch (error) {
    logger.error(`Image resize error: ${error.message}`);
    next(error);
  }
};

/**
 * Upload middleware for single file
 * @param {string} fieldName - Form field name for the file
 */
const uploadSingle = (fieldName) => {
  return (req, res, next) => {
    upload.single(fieldName)(req, res, (err) => {
      if (err) {
        if (err instanceof multer.MulterError) {
          // Multer error (file size, etc.)
          return res.status(400).json({
            message: `Upload error: ${err.message}`
          });
        }
        return res.status(400).json({
          message: `File upload error: ${err.message}`
        });
      }
      next();
    });
  };
};

/**
 * Upload middleware for multiple files
 * @param {string} fieldName - Form field name for the files
 * @param {number} maxCount - Maximum number of files
 */
const uploadMultiple = (fieldName, maxCount = 5) => {
  return (req, res, next) => {
    upload.array(fieldName, maxCount)(req, res, (err) => {
      if (err) {
        if (err instanceof multer.MulterError) {
          return res.status(400).json({
            message: `Upload error: ${err.message}`
          });
        }
        return res.status(400).json({
          message: `File upload error: ${err.message}`
        });
      }
      next();
    });
  };
};

module.exports = {
  uploadSingle,
  uploadMultiple,
  resizeImage
};