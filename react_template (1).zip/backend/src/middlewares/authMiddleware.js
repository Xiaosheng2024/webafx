/**
 * Authentication and authorization middleware
 */

const jwt = require('jsonwebtoken');
const { query } = require('../config/database');
const logger = require('../utils/logger');
const config = require('../config/app');

/**
 * Middleware to protect routes - verifies JWT token
 */
const protect = async (req, res, next) => {
  let token;

  // Check for Authorization header with Bearer token
  if (req.headers.authorization && req.headers.authorization.startsWith('Bearer')) {
    try {
      // Extract token from header
      token = req.headers.authorization.split(' ')[1];

      // Verify token
      const decoded = jwt.verify(token, config.jwtSecret);

      // Fetch user from database (exclude password)
      const users = await query(
        'SELECT id, name, email, role, avatar, status FROM users WHERE id = ? AND status = ?',
        [decoded.id, 'active']
      );

      if (users.length === 0) {
        return res.status(401).json({
          message: 'Not authorized, account inactive or doesn\'t exist'
        });
      }

      // Set user in request object
      req.user = users[0];
      next();
    } catch (error) {
      logger.error(`Auth error: ${error.message}`);
      res.status(401).json({
        message: 'Not authorized, token failed'
      });
    }
  }

  if (!token) {
    res.status(401).json({
      message: 'Not authorized, no token'
    });
  }
};

/**
 * Middleware to restrict access to specific user roles
 */
const restrictTo = (...roles) => {
  return (req, res, next) => {
    if (!req.user) {
      return res.status(401).json({
        message: 'Please login first'
      });
    }

    if (!roles.includes(req.user.role)) {
      return res.status(403).json({
        message: 'You do not have permission to perform this action'
      });
    }

    next();
  };
};

/**
 * Check if user owns the resource or is an admin
 */
const isOwnerOrAdmin = (tableName, paramName = 'id') => {
  return async (req, res, next) => {
    try {
      // Skip check if user is admin
      if (req.user.role === 'admin') {
        return next();
      }

      const resourceId = req.params[paramName];
      
      // Query to check if the resource belongs to the user
      const resource = await query(
        `SELECT created_by FROM ${tableName} WHERE id = ?`,
        [resourceId]
      );

      // If resource doesn't exist
      if (resource.length === 0) {
        return res.status(404).json({
          message: 'Resource not found'
        });
      }

      // Check if user is the owner
      if (resource[0].created_by !== req.user.id) {
        return res.status(403).json({
          message: 'You do not have permission to modify this resource'
        });
      }

      next();
    } catch (error) {
      logger.error(`Error in ownership check: ${error.message}`);
      next(error);
    }
  };
};

module.exports = { protect, restrictTo, isOwnerOrAdmin };