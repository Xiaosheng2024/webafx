/**
 * Error handling middleware functions
 */

const logger = require('../utils/logger');

/**
 * 404 Not Found middleware - Handles requests to non-existing routes
 */
const notFound = (req, res, next) => {
  const error = new Error(`Not Found - ${req.originalUrl}`);
  res.status(404);
  next(error);
};

/**
 * Error handler middleware - Formats and returns error responses
 */
const errorHandler = (err, req, res, next) => {
  // Log the error
  logger.error(`${err.message}`, { 
    stack: err.stack,
    url: req.originalUrl,
    method: req.method
  });

  // Set status code (default to 500 if not set or if set to 200)
  const statusCode = res.statusCode === 200 ? 500 : res.statusCode;
  res.status(statusCode);

  // Determine what error info to expose based on environment
  const errorResponse = {
    message: err.message,
    stack: process.env.NODE_ENV === 'production' ? '🥞' : err.stack,
  };

  // For validation errors, include validation info
  if (err.errors) {
    errorResponse.errors = err.errors;
  }

  // Send error response
  res.json(errorResponse);
};

/**
 * Validation error handler - Formats and returns validation errors
 */
const validationErrorHandler = (err, req, res, next) => {
  if (err && err.array) {
    // This is express-validator error
    const validationErrors = err.array().map(error => ({
      field: error.path,
      message: error.msg
    }));

    return res.status(400).json({
      message: 'Validation failed',
      errors: validationErrors
    });
  }
  next(err);
};

module.exports = { notFound, errorHandler, validationErrorHandler };