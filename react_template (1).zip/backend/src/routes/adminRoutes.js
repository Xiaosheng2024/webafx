/**
 * Admin Routes
 */
const express = require('express');
const {
  getDashboardStats,
  getSettings,
  getSettingByKey,
  updateSetting,
  deleteSetting,
  updateHeaderContent,
  getInquiries,
  updateInquiryStatus
} = require('../controllers/adminController');
const { protect, restrictTo } = require('../middlewares/authMiddleware');
const { uploadSingle } = require('../middlewares/uploadMiddleware');
const router = express.Router();

// All admin routes require authentication
router.use(protect);

// Dashboard stats - accessible by admin and editor
router.get('/dashboard', restrictTo('admin', 'editor'), getDashboardStats);

// Settings routes - admin only
router.get('/settings', restrictTo('admin'), getSettings);
router.get('/settings/:key', restrictTo('admin'), getSettingByKey);
router.put('/settings/:key', restrictTo('admin'), updateSetting);
router.delete('/settings/:key', restrictTo('admin'), deleteSetting);

// Header content management - admin only
router.put('/header', restrictTo('admin'), uploadSingle('site_logo'), updateHeaderContent);

// Inquiry management - admin and editor
router.get('/inquiries', restrictTo('admin', 'editor'), getInquiries);
router.put('/inquiries/:id', restrictTo('admin', 'editor'), updateInquiryStatus);

module.exports = router;