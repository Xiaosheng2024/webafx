/**
 * Article Routes
 */
const express = require('express');
const {
  getArticles,
  getArticleById,
  createArticle,
  updateArticle,
  deleteArticle,
  getArticleCategories
} = require('../controllers/articleController');
const { protect, restrictTo, isOwnerOrAdmin } = require('../middlewares/authMiddleware');
const { uploadSingle, resizeImage } = require('../middlewares/uploadMiddleware');
const router = express.Router();

// Public routes
router.get('/', getArticles);
router.get('/categories', getArticleCategories);
router.get('/:id', getArticleById);

// Protected routes - admin and editor only
router.use(protect);
router.use(restrictTo('admin', 'editor'));

// Article CRUD operations
router.post('/', uploadSingle('featured_image'), resizeImage, createArticle);
router.put('/:id', uploadSingle('featured_image'), resizeImage, updateArticle);
router.delete('/:id', restrictTo('admin'), deleteArticle);

module.exports = router;