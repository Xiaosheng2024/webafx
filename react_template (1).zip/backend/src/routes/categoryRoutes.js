/**
 * Category Routes
 */
const express = require('express');
const {
  getCategories,
  getCategoryById,
  createCategory,
  updateCategory,
  deleteCategory
} = require('../controllers/categoryController');
const { protect, restrictTo } = require('../middlewares/authMiddleware');
const { uploadSingle, resizeImage } = require('../middlewares/uploadMiddleware');
const router = express.Router();

// Public routes
router.get('/', getCategories);
router.get('/:id', getCategoryById);

// Protected routes
router.use(protect);
router.use(restrictTo('admin', 'editor'));

// Category CRUD operations
router.post('/', uploadSingle('image'), resizeImage, createCategory);
router.put('/:id', uploadSingle('image'), resizeImage, updateCategory);
router.delete('/:id', restrictTo('admin'), deleteCategory);

module.exports = router;