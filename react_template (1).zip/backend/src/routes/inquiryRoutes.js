/**
 * Inquiry Routes
 */
const express = require('express');
const {
  submitInquiry,
  getInquiries,
  getInquiryById,
  updateInquiryStatus,
  deleteInquiry
} = require('../controllers/inquiryController');
const { protect, restrictTo } = require('../middlewares/authMiddleware');
const router = express.Router();

// Public routes
router.post('/', submitInquiry);

// Protected routes
router.use(protect);
router.use(restrictTo('admin', 'editor'));

router.get('/', getInquiries);
router.get('/:id', getInquiryById);
router.put('/:id', updateInquiryStatus);
router.delete('/:id', restrictTo('admin'), deleteInquiry);

module.exports = router;