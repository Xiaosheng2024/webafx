/**
 * File Routes
 */
const express = require('express');
const {
  uploadFile,
  getFileById,
  getFilesByContent,
  deleteFile
} = require('../controllers/fileController');
const { protect, restrictTo } = require('../middlewares/authMiddleware');
const { uploadSingle } = require('../middlewares/uploadMiddleware');
const router = express.Router();

// All routes are protected
router.use(protect);
router.use(restrictTo('admin', 'editor'));

router.post('/upload', uploadSingle('file'), uploadFile);
router.get('/:id', getFileById);
router.get('/content/:type/:id', getFilesByContent);
router.delete('/:id', deleteFile);

module.exports = router;