/**
 * Case Study Routes
 */
const express = require('express');
const {
  getCases,
  getCaseById,
  createCase,
  updateCase,
  deleteCase
} = require('../controllers/caseController');
const { protect, restrictTo } = require('../middlewares/authMiddleware');
const { uploadSingle, resizeImage } = require('../middlewares/uploadMiddleware');
const router = express.Router();

// Public routes
router.get('/', getCases);
router.get('/:id', getCaseById);

// Protected routes - admin and editor only
router.use(protect);
router.use(restrictTo('admin', 'editor'));

// Case CRUD operations
router.post('/', uploadSingle('featured_image'), resizeImage, createCase);
router.put('/:id', uploadSingle('featured_image'), resizeImage, updateCase);
router.delete('/:id', restrictTo('admin'), deleteCase);

module.exports = router;