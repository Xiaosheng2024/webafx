/**
 * Product Routes
 */
const express = require('express');
const {
  getProducts,
  getProductById,
  createProduct,
  updateProduct,
  deleteProduct,
  updateProductImages,
  getProductCategories
} = require('../controllers/productController');
const { protect, restrictTo, isOwnerOrAdmin } = require('../middlewares/authMiddleware');
const { uploadMultiple, resizeImage } = require('../middlewares/uploadMiddleware');
const router = express.Router();

// Public routes
router.get('/', getProducts);
router.get('/categories', getProductCategories);
router.get('/:id', getProductById);

// Protected routes - admin and editor only
router.use(protect);
router.use(restrictTo('admin', 'editor'));

// Product CRUD operations
router.post('/', uploadMultiple('images', 10), createProduct);
router.put('/:id', uploadMultiple('images', 10), updateProduct);
router.delete('/:id', restrictTo('admin'), deleteProduct);

// Product image management
router.put('/:id/images', updateProductImages);

module.exports = router;