/**
 * User model for handling database operations
 */

const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { query } = require('../config/database');
const config = require('../config/app');

const userModel = {
  /**
   * Create a new user
   * @param {Object} userData - User data
   * @returns {Object} Created user
   */
  async create(userData) {
    const { name, email, password, role = 'user', avatar = null } = userData;
    
    // Hash password
    const salt = await bcrypt.genSalt(config.saltRounds);
    const hashedPassword = await bcrypt.hash(password, salt);
    
    const result = await query(
      `INSERT INTO users (name, email, password, role, avatar, status) 
       VALUES (?, ?, ?, ?, ?, 'active')`,
      [name, email, hashedPassword, role, avatar]
    );
    
    const user = await query(
      'SELECT id, name, email, role, avatar, status, created_at FROM users WHERE id = ?',
      [result.insertId]
    );
    
    return user[0];
  },

  /**
   * Get user by ID
   * @param {number} id - User ID
   * @returns {Object|null} User or null if not found
   */
  async getById(id) {
    const users = await query(
      'SELECT id, name, email, role, avatar, status, created_at FROM users WHERE id = ?',
      [id]
    );
    
    return users.length > 0 ? users[0] : null;
  },

  /**
   * Get user by email
   * @param {string} email - User email
   * @returns {Object|null} User or null if not found
   */
  async getByEmail(email) {
    const users = await query(
      'SELECT id, name, email, password, role, avatar, status, created_at FROM users WHERE email = ?',
      [email]
    );
    
    return users.length > 0 ? users[0] : null;
  },

  /**
   * Get all users with pagination
   * @param {number} page - Page number
   * @param {number} limit - Number of items per page
   * @param {string} status - Filter by status
   * @returns {Array} List of users
   */
  async getAll(page = 1, limit = config.defaultPageSize, status = null) {
    let sql = 'SELECT id, name, email, role, avatar, status, created_at FROM users';
    const params = [];
    
    // Add status filter if provided
    if (status) {
      sql += ' WHERE status = ?';
      params.push(status);
    }
    
    // Add pagination
    sql += ' ORDER BY created_at DESC LIMIT ? OFFSET ?';
    params.push(Number(limit), (Number(page) - 1) * Number(limit));
    
    return await query(sql, params);
  },

  /**
   * Count total users (for pagination)
   * @param {string} status - Filter by status
   * @returns {number} Total count
   */
  async count(status = null) {
    let sql = 'SELECT COUNT(*) as total FROM users';
    const params = [];
    
    if (status) {
      sql += ' WHERE status = ?';
      params.push(status);
    }
    
    const result = await query(sql, params);
    return result[0].total;
  },

  /**
   * Update user details
   * @param {number} id - User ID
   * @param {Object} userData - User data to update
   * @returns {Object} Updated user
   */
  async update(id, userData) {
    const fields = [];
    const values = [];
    
    // Build update query based on provided fields
    Object.keys(userData).forEach(key => {
      if (['name', 'email', 'role', 'avatar', 'status'].includes(key)) {
        fields.push(`${key} = ?`);
        values.push(userData[key]);
      }
    });
    
    if (fields.length === 0) {
      throw new Error('No valid fields provided for update');
    }
    
    values.push(id);
    
    await query(
      `UPDATE users SET ${fields.join(', ')} WHERE id = ?`,
      values
    );
    
    const users = await query(
      'SELECT id, name, email, role, avatar, status, created_at FROM users WHERE id = ?',
      [id]
    );
    
    return users[0];
  },

  /**
   * Update user password
   * @param {number} id - User ID
   * @param {string} password - New password
   * @returns {boolean} Success status
   */
  async updatePassword(id, password) {
    const salt = await bcrypt.genSalt(config.saltRounds);
    const hashedPassword = await bcrypt.hash(password, salt);
    
    await query(
      'UPDATE users SET password = ? WHERE id = ?',
      [hashedPassword, id]
    );
    
    return true;
  },

  /**
   * Delete a user
   * @param {number} id - User ID
   * @returns {boolean} Success status
   */
  async delete(id) {
    const result = await query(
      'DELETE FROM users WHERE id = ?',
      [id]
    );
    
    return result.affectedRows > 0;
  },

  /**
   * Authenticate user and generate JWT
   * @param {string} email - User email
   * @param {string} password - User password
   * @returns {Object} User with token
   */
  async authenticate(email, password) {
    const user = await this.getByEmail(email);
    
    if (!user) {
      throw new Error('Invalid credentials');
    }
    
    if (user.status !== 'active') {
      throw new Error('User account is not active');
    }
    
    const isMatch = await bcrypt.compare(password, user.password);
    
    if (!isMatch) {
      throw new Error('Invalid credentials');
    }
    
    // Remove password from returned user object
    const { password: _, ...userWithoutPassword } = user;
    
    // Generate JWT token
    const token = generateToken(user.id);
    
    return {
      ...userWithoutPassword,
      token
    };
  }
};

/**
 * Generate JWT token for a user
 * @param {number} userId - User ID
 * @returns {string} JWT token
 */
const generateToken = (userId) => {
  return jwt.sign(
    { id: userId },
    config.jwtSecret,
    { expiresIn: config.jwtExpiresIn }
  );
};

module.exports = userModel;