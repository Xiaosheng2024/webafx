// src/utils/auth.js
const TOKEN_KEY = 'cms_token';
const USER_INFO_KEY = 'cms_user_info';

// Token management
export function getToken() {
  return localStorage.getItem(TOKEN_KEY);
}

export function setToken(token) {
  return localStorage.setItem(TOKEN_KEY, token);
}

export function removeToken() {
  localStorage.removeItem(TOKEN_KEY);
  removeUserInfo();
}

// User info management
export function getUserInfo() {
  const userInfoStr = localStorage.getItem(USER_INFO_KEY);
  return userInfoStr ? JSON.parse(userInfoStr) : null;
}

export function setUserInfo(userInfo) {
  return localStorage.setItem(USER_INFO_KEY, JSON.stringify(userInfo));
}

export function removeUserInfo() {
  return localStorage.removeItem(USER_INFO_KEY);
}

// Permission helpers
export function hasPermission(permissionCode) {
  const userInfo = getUserInfo();
  if (!userInfo || !userInfo.permissions) {
    return false;
  }
  
  return userInfo.permissions.includes(permissionCode);
}

export function hasAnyPermission(permissionCodes) {
  const userInfo = getUserInfo();
  if (!userInfo || !userInfo.permissions) {
    return false;
  }
  
  return permissionCodes.some(code => userInfo.permissions.includes(code));
}

export function hasRole(roleName) {
  const userInfo = getUserInfo();
  if (!userInfo || !userInfo.roles) {
    return false;
  }
  
  return userInfo.roles.includes(roleName);
}

export default {
  getToken,
  setToken,
  removeToken,
  getUserInfo,
  setUserInfo,
  removeUserInfo,
  hasPermission,
  hasAnyPermission,
  hasRole
};