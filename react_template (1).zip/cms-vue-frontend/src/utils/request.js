// src/utils/request.js
import axios from 'axios';
import { ElMessage } from 'element-plus';
import { getToken, removeToken } from '@/utils/auth';
import router from '@/router';

// Create axios instance
const service = axios.create({
  baseURL: '/api', // API base URL prefix
  timeout: 15000, // Request timeout
  headers: {
    'Content-Type': 'application/json'
  }
});

// Request interceptor
service.interceptors.request.use(
  config => {
    // Add token to headers if exists
    const token = getToken();
    if (token) {
      config.headers['Authorization'] = `Bearer ${token}`;
    }
    return config;
  },
  error => {
    console.error('Request error:', error);
    return Promise.reject(error);
  }
);

// Response interceptor
service.interceptors.response.use(
  response => {
    const res = response.data;
    
    // If the custom status code is not 200, it is judged as an error.
    if (res.code && res.code !== 200) {
      ElMessage({
        message: res.message || 'Error',
        type: 'error',
        duration: 5 * 1000
      });

      // Handle specific error codes
      if (res.code === 401) {
        // Token expired or invalid
        removeToken();
        router.push('/login');
      }
      
      return Promise.reject(new Error(res.message || 'Error'));
    } else {
      return res;
    }
  },
  error => {
    console.error('Response error:', error);
    
    // Handle different HTTP status codes
    if (error.response) {
      switch (error.response.status) {
        case 401:
          // Unauthorized: Token invalid or expired
          removeToken();
          router.push('/login');
          ElMessage({
            message: 'Authentication failed, please login again',
            type: 'error',
            duration: 5 * 1000
          });
          break;
        case 403:
          // Forbidden: No permission
          router.push('/403');
          ElMessage({
            message: 'You do not have permission to access this resource',
            type: 'error',
            duration: 5 * 1000
          });
          break;
        case 404:
          // Not found
          router.push('/404');
          break;
        case 500:
          // Server error
          ElMessage({
            message: 'Server error, please try again later',
            type: 'error',
            duration: 5 * 1000
          });
          break;
        default:
          ElMessage({
            message: error.message || 'Request failed',
            type: 'error',
            duration: 5 * 1000
          });
      }
    } else {
      // Network error or request cancelled
      ElMessage({
        message: 'Network error, please check your connection',
        type: 'error',
        duration: 5 * 1000
      });
    }
    
    return Promise.reject(error);
  }
);

// Helper methods
export const request = {
  get(url, params) {
    return service({
      url,
      method: 'get',
      params
    });
  },
  
  post(url, data) {
    return service({
      url,
      method: 'post',
      data
    });
  },
  
  put(url, data) {
    return service({
      url,
      method: 'put',
      data
    });
  },
  
  delete(url, params) {
    return service({
      url,
      method: 'delete',
      params
    });
  },
  
  // For file upload with FormData
  upload(url, formData) {
    return service({
      url,
      method: 'post',
      data: formData,
      headers: {
        'Content-Type': 'multipart/form-data'
      }
    });
  },
  
  // For download files
  download(url, params, filename) {
    return service({
      url,
      method: 'get',
      params,
      responseType: 'blob'
    }).then(response => {
      // Create blob link to download
      const blob = new Blob([response]);
      const link = document.createElement('a');
      link.href = window.URL.createObjectURL(blob);
      link.download = filename;
      link.click();
      window.URL.revokeObjectURL(link.href);
    });
  }
};

export default service;