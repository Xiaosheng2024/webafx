// src/router/index.js
import { createRouter, createWebHistory } from 'vue-router';
import { getToken } from '@/utils/auth';
import { ElMessage } from 'element-plus';

const routes = [
  {
    path: '/login',
    name: 'Login',
    component: () => import('@/views/Login.vue'),
    meta: { title: 'Login', requiresAuth: false }
  },
  {
    path: '/',
    component: () => import('@/components/layout/Content.vue'),
    redirect: '/dashboard',
    children: [
      {
        path: 'dashboard',
        name: 'Dashboard',
        component: () => import('@/views/Dashboard.vue'),
        meta: { title: 'Dashboard', icon: 'Odometer', requiresAuth: true }
      },
      {
        path: 'content',
        name: 'Content',
        meta: { title: 'Content Management', icon: 'Document', requiresAuth: true },
        children: [
          {
            path: 'articles',
            name: 'ArticleList',
            component: () => import('@/views/content/ArticleList.vue'),
            meta: { title: 'Article List', requiresAuth: true }
          },
          {
            path: 'articles/create',
            name: 'ArticleCreate',
            component: () => import('@/views/content/ArticleEdit.vue'),
            meta: { title: 'Create Article', requiresAuth: true }
          },
          {
            path: 'articles/edit/:id',
            name: 'ArticleEdit',
            component: () => import('@/views/content/ArticleEdit.vue'),
            meta: { title: 'Edit Article', requiresAuth: true }
          },
          {
            path: 'categories',
            name: 'CategoryManagement',
            component: () => import('@/views/content/CategoryManagement.vue'),
            meta: { title: 'Category Management', requiresAuth: true }
          }
        ]
      },
      {
        path: 'system',
        name: 'System',
        meta: { title: 'System Management', icon: 'Setting', requiresAuth: true },
        children: [
          {
            path: 'users',
            name: 'UserManagement',
            component: () => import('@/views/system/UserManagement.vue'),
            meta: { title: 'User Management', requiresAuth: true }
          },
          {
            path: 'roles',
            name: 'RoleManagement',
            component: () => import('@/views/system/RoleManagement.vue'),
            meta: { title: 'Role Management', requiresAuth: true }
          }
        ]
      }
    ]
  },
  {
    path: '/:pathMatch(.*)*',
    redirect: '/404'
  },
  {
    path: '/404',
    component: () => import('@/views/404.vue'),
    meta: { title: '404', requiresAuth: false }
  }
];

const router = createRouter({
  history: createWebHistory(),
  routes
});

// Navigation guard
router.beforeEach((to, from, next) => {
  // Set page title
  document.title = to.meta.title ? `${to.meta.title} - CMS Admin` : 'CMS Admin System';
  
  // Check if the route requires authentication
  if (to.meta.requiresAuth) {
    const token = getToken();
    if (token) {
      next();
    } else {
      ElMessage.error('Please login first');
      next({ path: '/login', query: { redirect: to.fullPath } });
    }
  } else {
    next();
  }
});

export default router;