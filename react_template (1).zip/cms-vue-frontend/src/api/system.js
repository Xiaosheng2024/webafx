// src/api/system.js
import { request } from '@/utils/request';

/**
 * Get dashboard data
 * @returns {Promise} - Promise with dashboard statistics and charts data
 */
export function getDashboardData() {
  return request.get('/system/dashboard');
}

/**
 * Get system settings
 * @returns {Promise} - Promise with system settings
 */
export function getSettings() {
  return request.get('/system/settings');
}

/**
 * Update system settings
 * @param {Object} data - Settings data
 * @returns {Promise} - Promise with updated settings
 */
export function updateSettings(data) {
  return request.put('/system/settings', data);
}

/**
 * Get roles list
 * @returns {Promise} - Promise with roles
 */
export function getRoles() {
  return request.get('/system/roles');
}

/**
 * Create a new role
 * @param {Object} data - Role data
 * @returns {Promise} - Promise with created role
 */
export function createRole(data) {
  return request.post('/system/roles', data);
}

/**
 * Update a role
 * @param {string|number} id - Role ID
 * @param {Object} data - Role data to update
 * @returns {Promise} - Promise with updated role
 */
export function updateRole(id, data) {
  return request.put(`/system/roles/${id}`, data);
}

/**
 * Delete a role
 * @param {string|number} id - Role ID
 * @returns {Promise} - Promise with response
 */
export function deleteRole(id) {
  return request.delete(`/system/roles/${id}`);
}

/**
 * Get permissions for a role
 * @param {string|number} roleId - Role ID
 * @returns {Promise} - Promise with permissions tree
 */
export function getRolePermissions(roleId) {
  return request.get(`/system/roles/${roleId}/permissions`);
}

/**
 * Update role permissions
 * @param {string|number} roleId - Role ID
 * @param {Array} permissionIds - Array of permission IDs
 * @returns {Promise} - Promise with response
 */
export function updateRolePermissions(roleId, permissionIds) {
  return request.put(`/system/roles/${roleId}/permissions`, { 
    permissionIds 
  });
}

/**
 * Get all permissions tree
 * @returns {Promise} - Promise with permissions tree
 */
export function getAllPermissions() {
  return request.get('/system/permissions');
}

/**
 * Get system logs
 * @param {Object} params - Query parameters for pagination and filtering
 * @returns {Promise} - Promise with logs
 */
export function getSystemLogs(params) {
  return request.get('/system/logs', params);
}

/**
 * Get system info (CPU, memory, disk usage)
 * @returns {Promise} - Promise with system info
 */
export function getSystemInfo() {
  return request.get('/system/info');
}

/**
 * Backup system data
 * @returns {Promise} - Promise with backup info
 */
export function backupSystem() {
  return request.post('/system/backup');
}

/**
 * Get backup history
 * @returns {Promise} - Promise with backups list
 */
export function getBackups() {
  return request.get('/system/backups');
}

/**
 * Restore system from backup
 * @param {string} backupId - Backup ID
 * @returns {Promise} - Promise with restore result
 */
export function restoreBackup(backupId) {
  return request.post(`/system/backups/${backupId}/restore`);
}

export default {
  getDashboardData,
  getSettings,
  updateSettings,
  getRoles,
  createRole,
  updateRole,
  deleteRole,
  getRolePermissions,
  updateRolePermissions,
  getAllPermissions,
  getSystemLogs,
  getSystemInfo,
  backupSystem,
  getBackups,
  restoreBackup
};