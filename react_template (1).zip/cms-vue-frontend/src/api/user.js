// src/api/user.js
import { request } from '@/utils/request';
import { setUserInfo, removeUserInfo } from '@/utils/auth';

/**
 * User login
 * @param {string} username - Username
 * @param {string} password - Password
 * @returns {Promise} - Promise with login response
 */
export function login(username, password) {
  return request.post('/auth/login', {
    username,
    password
  }).then(response => {
    if (response.data && response.data.userInfo) {
      setUserInfo(response.data.userInfo);
    }
    return response.data;
  });
}

/**
 * User logout
 * @returns {Promise} - Promise with logout response
 */
export function logout() {
  return request.post('/auth/logout').finally(() => {
    removeUserInfo();
  });
}

/**
 * Get user profile information
 * @returns {Promise} - Promise with user profile data
 */
export function getUserProfile() {
  return request.get('/user/profile');
}

/**
 * Update user profile
 * @param {Object} data - User profile data to update
 * @returns {Promise} - Promise with updated user data
 */
export function updateUserProfile(data) {
  return request.put('/user/profile', data);
}

/**
 * Change password
 * @param {string} oldPassword - Current password
 * @param {string} newPassword - New password
 * @returns {Promise} - Promise with response
 */
export function changePassword(oldPassword, newPassword) {
  return request.post('/user/change-password', {
    oldPassword,
    newPassword
  });
}

/**
 * Get list of users with pagination
 * @param {Object} params - Query parameters
 * @returns {Promise} - Promise with users list
 */
export function getUsers(params) {
  return request.get('/users', params);
}

/**
 * Create a new user
 * @param {Object} data - User data
 * @returns {Promise} - Promise with created user
 */
export function createUser(data) {
  return request.post('/users', data);
}

/**
 * Update a user
 * @param {string|number} username - Username or user ID
 * @param {Object} data - User data to update
 * @returns {Promise} - Promise with updated user
 */
export function updateUser(username, data) {
  return request.put(`/users/${username}`, data);
}

/**
 * Delete a user
 * @param {string|number} id - User ID
 * @returns {Promise} - Promise with response
 */
export function deleteUser(id) {
  return request.delete(`/users/${id}`);
}

/**
 * Update user status (activate/deactivate)
 * @param {string|number} id - User ID
 * @param {string} status - New status ('active' or 'inactive')
 * @returns {Promise} - Promise with response
 */
export function updateUserStatus(id, status) {
  return request.put(`/users/${id}/status`, { status });
}

/**
 * Reset user password
 * @param {string|number} id - User ID
 * @returns {Promise} - Promise with response containing new password
 */
export function resetUserPassword(id) {
  return request.post(`/users/${id}/reset-password`);
}

export default {
  login,
  logout,
  getUserProfile,
  updateUserProfile,
  changePassword,
  getUsers,
  createUser,
  updateUser,
  deleteUser,
  updateUserStatus,
  resetUserPassword
};