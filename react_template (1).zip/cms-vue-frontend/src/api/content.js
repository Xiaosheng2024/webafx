// src/api/content.js
import { request } from '@/utils/request';

/**
 * Get articles with pagination and filters
 * @param {Object} params - Query parameters
 * @returns {Promise} - Promise with articles list
 */
export function getArticles(params) {
  return request.get('/content/articles', params);
}

/**
 * Get article by ID
 * @param {string|number} id - Article ID
 * @returns {Promise} - Promise with article data
 */
export function getArticle(id) {
  return request.get(`/content/articles/${id}`);
}

/**
 * Create a new article
 * @param {Object} data - Article data
 * @returns {Promise} - Promise with created article
 */
export function createArticle(data) {
  return request.post('/content/articles', data);
}

/**
 * Update an article
 * @param {string|number} id - Article ID
 * @param {Object} data - Article data to update
 * @returns {Promise} - Promise with updated article
 */
export function updateArticle(id, data) {
  return request.put(`/content/articles/${id}`, data);
}

/**
 * Delete an article
 * @param {string|number} id - Article ID
 * @returns {Promise} - Promise with response
 */
export function deleteArticle(id) {
  return request.delete(`/content/articles/${id}`);
}

/**
 * Update article status
 * @param {string|number} id - Article ID
 * @param {string} status - New status ('published', 'draft', 'archived')
 * @returns {Promise} - Promise with response
 */
export function updateArticleStatus(id, status) {
  return request.put(`/content/articles/${id}/status`, { status });
}

/**
 * Upload article cover image
 * @param {File} file - Image file
 * @returns {Promise} - Promise with uploaded file URL
 */
export function uploadArticleImage(file) {
  const formData = new FormData();
  formData.append('file', file);
  return request.upload('/content/upload', formData);
}

/**
 * Get categories list
 * @returns {Promise} - Promise with categories
 */
export function getCategories() {
  return request.get('/content/categories');
}

/**
 * Create a new category
 * @param {Object} data - Category data
 * @returns {Promise} - Promise with created category
 */
export function createCategory(data) {
  return request.post('/content/categories', data);
}

/**
 * Update a category
 * @param {string|number} id - Category ID
 * @param {Object} data - Category data to update
 * @returns {Promise} - Promise with updated category
 */
export function updateCategory(id, data) {
  return request.put(`/content/categories/${id}`, data);
}

/**
 * Delete a category
 * @param {string|number} id - Category ID
 * @returns {Promise} - Promise with response
 */
export function deleteCategory(id) {
  return request.delete(`/content/categories/${id}`);
}

/**
 * Get tags list
 * @returns {Promise} - Promise with tags
 */
export function getTags() {
  return request.get('/content/tags');
}

export default {
  getArticles,
  getArticle,
  createArticle,
  updateArticle,
  deleteArticle,
  updateArticleStatus,
  uploadArticleImage,
  getCategories,
  createCategory,
  updateCategory,
  deleteCategory,
  getTags
};