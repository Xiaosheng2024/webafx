<!-- src/views/content/ArticleList.vue -->
<template>
  <div class="article-list-container">
    <el-card class="filter-container">
      <div class="filter-section">
        <el-input
          v-model="searchQuery"
          placeholder="Search articles"
          clearable
          class="filter-item"
          @keyup.enter="handleSearch"
        >
          <template #append>
            <el-button :icon="Search" @click="handleSearch" />
          </template>
        </el-input>
        
        <el-select
          v-model="categoryId"
          placeholder="Select category"
          clearable
          class="filter-item"
        >
          <el-option
            v-for="item in categories"
            :key="item.id"
            :label="item.name"
            :value="item.id"
          />
        </el-select>
        
        <el-select
          v-model="status"
          placeholder="Status"
          clearable
          class="filter-item"
        >
          <el-option label="Published" value="published" />
          <el-option label="Draft" value="draft" />
          <el-option label="Archived" value="archived" />
        </el-select>
        
        <el-date-picker
          v-model="dateRange"
          class="filter-item"
          type="daterange"
          range-separator="To"
          start-placeholder="Start date"
          end-placeholder="End date"
          value-format="YYYY-MM-DD"
        />
        
        <div class="button-group">
          <el-button type="primary" @click="handleSearch">Search</el-button>
          <el-button @click="resetFilters">Reset</el-button>
        </div>
      </div>
    </el-card>
    
    <el-card class="table-container">
      <div class="table-header">
        <h3>Article List</h3>
        <el-button type="primary" @click="handleCreateArticle">
          <el-icon><Plus /></el-icon>
          New Article
        </el-button>
      </div>
      
      <el-table
        v-loading="loading"
        :data="articleList"
        border
        style="width: 100%"
      >
        <el-table-column label="ID" prop="id" width="80" />
        <el-table-column label="Title" prop="title" min-width="200" show-overflow-tooltip />
        <el-table-column label="Category" prop="categoryName" width="120" />
        <el-table-column label="Author" prop="author" width="120" />
        <el-table-column label="Status" width="100">
          <template #default="{ row }">
            <el-tag :type="statusTagType(row.status)">
              {{ row.status }}
            </el-tag>
          </template>
        </el-table-column>
        <el-table-column label="Views" prop="views" width="80" />
        <el-table-column label="Created At" prop="createdAt" width="150" />
        <el-table-column label="Updated At" prop="updatedAt" width="150" />
        <el-table-column label="Actions" width="200" fixed="right">
          <template #default="{ row }">
            <el-button 
              size="small" 
              type="primary" 
              plain
              @click="handleEdit(row)"
            >
              Edit
            </el-button>
            <el-button 
              size="small" 
              :type="row.status === 'published' ? 'info' : 'success'" 
              plain
              @click="handlePublishToggle(row)"
            >
              {{ row.status === 'published' ? 'Unpublish' : 'Publish' }}
            </el-button>
            <el-button 
              size="small" 
              type="danger" 
              plain
              @click="handleDelete(row)"
            >
              Delete
            </el-button>
          </template>
        </el-table-column>
      </el-table>
      
      <div class="pagination-container">
        <el-pagination
          v-model:current-page="currentPage"
          v-model:page-size="pageSize"
          :page-sizes="[10, 20, 50, 100]"
          :total="total"
          layout="total, sizes, prev, pager, next, jumper"
          @size-change="handleSizeChange"
          @current-change="handleCurrentChange"
        />
      </div>
    </el-card>
  </div>
</template>

<script setup>
import { ref, reactive, onMounted, computed } from 'vue';
import { useRouter } from 'vue-router';
import { Search, Plus } from '@element-plus/icons-vue';
import { ElMessage, ElMessageBox } from 'element-plus';
import { getArticles, deleteArticle, updateArticleStatus } from '@/api/content';
import { getCategories } from '@/api/content';

// Router
const router = useRouter();

// Component data
const loading = ref(false);
const articleList = ref([]);
const categories = ref([]);
const total = ref(0);
const currentPage = ref(1);
const pageSize = ref(10);

// Search filters
const searchQuery = ref('');
const categoryId = ref('');
const status = ref('');
const dateRange = ref([]);

// Status tag type
const statusTagType = (status) => {
  const types = {
    'published': 'success',
    'draft': 'info',
    'archived': 'danger'
  };
  return types[status] || 'info';
};

// Methods
const fetchArticles = async () => {
  loading.value = true;
  
  try {
    const params = {
      page: currentPage.value,
      pageSize: pageSize.value,
      query: searchQuery.value,
      categoryId: categoryId.value,
      status: status.value,
      startDate: dateRange.value && dateRange.value.length > 0 ? dateRange.value[0] : null,
      endDate: dateRange.value && dateRange.value.length > 0 ? dateRange.value[1] : null
    };
    
    const response = await getArticles(params);
    articleList.value = response.data;
    total.value = response.total;
  } catch (error) {
    console.error('Failed to fetch articles:', error);
    // For development, use mock data
    mockArticles();
  } finally {
    loading.value = false;
  }
};

const fetchCategories = async () => {
  try {
    const response = await getCategories();
    categories.value = response;
  } catch (error) {
    console.error('Failed to fetch categories:', error);
    // Mock categories for development
    categories.value = [
      { id: 1, name: 'Technology' },
      { id: 2, name: 'Design' },
      { id: 3, name: 'Business' },
      { id: 4, name: 'Lifestyle' }
    ];
  }
};

// Mock data for development
const mockArticles = () => {
  const mockData = [];
  const titles = [
    'Getting Started with Vue 3', 
    'Java Spring Boot Best Practices', 
    'MyBatis Advanced Usage Guide', 
    'Frontend Development Trends 2023',
    'Database Optimization Techniques',
    'Modern UI/UX Design Principles',
    'Content Management System Architecture',
    'RESTful API Design Guidelines',
    'Security Best Practices for Web Applications',
    'Microservices vs Monolithic Architecture'
  ];
  
  const statuses = ['published', 'draft', 'archived'];
  const authors = ['John Doe', 'Jane Smith', 'Admin User'];
  const categories = ['Technology', 'Design', 'Business'];
  
  for (let i = 1; i <= 20; i++) {
    const createdAt = new Date(Date.now() - Math.floor(Math.random() * 30) * 24 * 60 * 60 * 1000);
    const updatedAt = new Date(createdAt.getTime() + Math.floor(Math.random() * 10) * 24 * 60 * 60 * 1000);
    
    mockData.push({
      id: i,
      title: titles[Math.floor(Math.random() * titles.length)],
      categoryName: categories[Math.floor(Math.random() * categories.length)],
      author: authors[Math.floor(Math.random() * authors.length)],
      status: statuses[Math.floor(Math.random() * statuses.length)],
      views: Math.floor(Math.random() * 1000),
      createdAt: createdAt.toISOString().substring(0, 10),
      updatedAt: updatedAt.toISOString().substring(0, 10)
    });
  }
  
  articleList.value = mockData.slice(0, pageSize.value);
  total.value = mockData.length;
};

const handleSearch = () => {
  currentPage.value = 1;
  fetchArticles();
};

const resetFilters = () => {
  searchQuery.value = '';
  categoryId.value = '';
  status.value = '';
  dateRange.value = [];
  currentPage.value = 1;
  fetchArticles();
};

const handleSizeChange = (size) => {
  pageSize.value = size;
  fetchArticles();
};

const handleCurrentChange = (page) => {
  currentPage.value = page;
  fetchArticles();
};

const handleCreateArticle = () => {
  router.push('/content/articles/create');
};

const handleEdit = (row) => {
  router.push(`/content/articles/edit/${row.id}`);
};

const handlePublishToggle = async (row) => {
  try {
    const newStatus = row.status === 'published' ? 'draft' : 'published';
    await updateArticleStatus(row.id, newStatus);
    
    // Update local state
    const index = articleList.value.findIndex(item => item.id === row.id);
    if (index !== -1) {
      articleList.value[index].status = newStatus;
    }
    
    ElMessage.success(`Article ${newStatus === 'published' ? 'published' : 'unpublished'} successfully`);
  } catch (error) {
    console.error('Failed to update article status:', error);
    ElMessage.error('Failed to update article status');
  }
};

const handleDelete = (row) => {
  ElMessageBox.confirm(
    'This will permanently delete the article. Continue?',
    'Warning',
    {
      confirmButtonText: 'OK',
      cancelButtonText: 'Cancel',
      type: 'warning'
    }
  )
    .then(async () => {
      try {
        await deleteArticle(row.id);
        fetchArticles();
        ElMessage.success('Article deleted successfully');
      } catch (error) {
        console.error('Failed to delete article:', error);
        ElMessage.error('Failed to delete article');
      }
    })
    .catch(() => {
      // User canceled the deletion
    });
};

// Lifecycle hooks
onMounted(() => {
  fetchArticles();
  fetchCategories();
});
</script>

<style scoped>
.article-list-container {
  padding: 20px;
}

.filter-container {
  margin-bottom: 20px;
}

.filter-section {
  display: flex;
  flex-wrap: wrap;
  gap: 15px;
  align-items: center;
}

.filter-item {
  min-width: 200px;
}

.button-group {
  margin-left: auto;
}

.table-container {
  margin-bottom: 20px;
}

.table-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 20px;
}

.pagination-container {
  margin-top: 20px;
  display: flex;
  justify-content: flex-end;
}
</style>