<!-- src/views/content/ArticleEdit.vue -->
<template>
  <div class="article-edit-container">
    <el-card class="form-container">
      <template #header>
        <div class="card-header">
          <h2>{{ isEdit ? 'Edit Article' : 'Create Article' }}</h2>
        </div>
      </template>
      
      <el-form 
        ref="articleFormRef" 
        :model="articleForm" 
        :rules="rules" 
        label-position="top"
        @submit.prevent="submitForm"
      >
        <el-form-item label="Title" prop="title">
          <el-input 
            v-model="articleForm.title" 
            placeholder="Enter article title" 
            maxlength="100" 
            show-word-limit
          />
        </el-form-item>
        
        <el-row :gutter="20">
          <el-col :span="12">
            <el-form-item label="Category" prop="categoryId">
              <el-select 
                v-model="articleForm.categoryId" 
                placeholder="Select category" 
                style="width: 100%"
              >
                <el-option 
                  v-for="item in categories" 
                  :key="item.id" 
                  :label="item.name" 
                  :value="item.id"
                />
              </el-select>
            </el-form-item>
          </el-col>
          
          <el-col :span="12">
            <el-form-item label="Status" prop="status">
              <el-select 
                v-model="articleForm.status" 
                placeholder="Select status" 
                style="width: 100%"
              >
                <el-option label="Published" value="published" />
                <el-option label="Draft" value="draft" />
              </el-select>
            </el-form-item>
          </el-col>
        </el-row>
        
        <el-form-item label="Summary" prop="summary">
          <el-input 
            v-model="articleForm.summary" 
            type="textarea" 
            :rows="3" 
            placeholder="Brief summary of the article" 
            maxlength="200" 
            show-word-limit
          />
        </el-form-item>
        
        <el-form-item label="Cover Image" prop="coverImage">
          <el-upload
            class="cover-uploader"
            action="/api/upload"
            :show-file-list="false"
            :on-success="handleCoverSuccess"
            :before-upload="beforeCoverUpload"
          >
            <img v-if="articleForm.coverImage" :src="articleForm.coverImage" class="cover-image" />
            <el-icon v-else class="cover-uploader-icon"><Plus /></el-icon>
          </el-upload>
          <div class="el-upload__tip">
            Upload a cover image for your article (JPG/PNG, max 2MB)
          </div>
        </el-form-item>
        
        <el-form-item label="Content" prop="content">
          <div class="editor-container">
            <div ref="editorElement" class="editor"></div>
          </div>
        </el-form-item>
        
        <el-form-item label="Tags">
          <el-tag
            v-for="tag in dynamicTags"
            :key="tag"
            class="mx-1"
            closable
            :disable-transitions="false"
            @close="handleTagClose(tag)"
          >
            {{ tag }}
          </el-tag>
          <el-input
            v-if="inputVisible"
            ref="InputRef"
            v-model="inputValue"
            class="tag-input"
            size="small"
            @keyup.enter="handleTagConfirm"
            @blur="handleTagConfirm"
          />
          <el-button v-else class="button-new-tag" size="small" @click="showTagInput">
            + New Tag
          </el-button>
        </el-form-item>
        
        <el-form-item>
          <el-button type="primary" :loading="loading" @click="submitForm">
            {{ isEdit ? 'Update' : 'Create' }}
          </el-button>
          <el-button @click="goBack">Cancel</el-button>
        </el-form-item>
      </el-form>
    </el-card>
  </div>
</template>

<script setup>
import { ref, reactive, computed, onMounted, nextTick, onBeforeUnmount } from 'vue';
import { useRoute, useRouter } from 'vue-router';
import { ElMessage, ElMessageBox } from 'element-plus';
import { Plus } from '@element-plus/icons-vue';
import { getArticle, createArticle, updateArticle } from '@/api/content';
import { getCategories } from '@/api/content';
import ClassicEditor from '@ckeditor/ckeditor5-build-classic';

// Router and route
const router = useRouter();
const route = useRoute();

// Component state
const articleId = computed(() => route.params.id);
const isEdit = computed(() => !!articleId.value);
const loading = ref(false);
const editorInstance = ref(null);
const editorElement = ref(null);
const articleFormRef = ref(null);
const categories = ref([]);

// Form data
const articleForm = reactive({
  title: '',
  categoryId: '',
  status: 'draft',
  summary: '',
  content: '',
  coverImage: '',
  tags: []
});

// Form validation rules
const rules = {
  title: [
    { required: true, message: 'Please enter article title', trigger: 'blur' },
    { min: 3, max: 100, message: 'Title length should be 3 to 100 characters', trigger: 'blur' }
  ],
  categoryId: [
    { required: true, message: 'Please select a category', trigger: 'change' }
  ],
  status: [
    { required: true, message: 'Please select a status', trigger: 'change' }
  ],
  summary: [
    { max: 200, message: 'Summary length should not exceed 200 characters', trigger: 'blur' }
  ],
  content: [
    { required: true, message: 'Please enter article content', trigger: 'blur' }
  ]
};

// Tags handling
const dynamicTags = ref([]);
const inputVisible = ref(false);
const inputValue = ref('');
const InputRef = ref(null);

// CKEditor initialization
const initEditor = () => {
  if (editorElement.value) {
    ClassicEditor
      .create(editorElement.value, {
        toolbar: [
          'heading', '|', 
          'bold', 'italic', 'link', 'bulletedList', 'numberedList', '|',
          'outdent', 'indent', '|',
          'imageUpload', 'blockQuote', 'insertTable', 'mediaEmbed', '|',
          'undo', 'redo'
        ],
        placeholder: 'Write your article content here...'
      })
      .then(editor => {
        editorInstance.value = editor;
        
        // Set initial content if editing
        if (articleForm.content) {
          editor.setData(articleForm.content);
        }
        
        // Listen for content changes
        editor.model.document.on('change:data', () => {
          articleForm.content = editor.getData();
        });
      })
      .catch(error => {
        console.error('Editor initialization failed:', error);
        ElMessage.error('Failed to initialize the editor');
      });
  }
};

// Fetch article data if editing
const fetchArticle = async () => {
  if (!isEdit.value) return;
  
  loading.value = true;
  try {
    const article = await getArticle(articleId.value);
    
    // Update form data
    Object.keys(articleForm).forEach(key => {
      if (article[key] !== undefined) {
        articleForm[key] = article[key];
      }
    });
    
    // Handle tags
    dynamicTags.value = article.tags || [];
    
    // Update editor content
    if (editorInstance.value) {
      editorInstance.value.setData(articleForm.content);
    }
  } catch (error) {
    console.error('Failed to fetch article:', error);
    ElMessage.error('Failed to load article data');
    
    // Mock data for development
    articleForm.title = 'Sample Article Title';
    articleForm.categoryId = 1;
    articleForm.status = 'draft';
    articleForm.summary = 'This is a sample article summary for development purposes.';
    articleForm.content = '<p>This is a sample article content. Replace it with your actual content.</p>';
    articleForm.coverImage = 'https://via.placeholder.com/800x400';
    dynamicTags.value = ['Vue', 'JavaScript', 'Frontend'];
  } finally {
    loading.value = false;
  }
};

// Fetch categories
const fetchCategories = async () => {
  try {
    const response = await getCategories();
    categories.value = response;
  } catch (error) {
    console.error('Failed to fetch categories:', error);
    
    // Mock categories for development
    categories.value = [
      { id: 1, name: 'Technology' },
      { id: 2, name: 'Design' },
      { id: 3, name: 'Business' },
      { id: 4, name: 'Lifestyle' }
    ];
  }
};

// Image upload handling
const handleCoverSuccess = (res, file) => {
  articleForm.coverImage = URL.createObjectURL(file.raw);
};

const beforeCoverUpload = (file) => {
  const isJPG = file.type === 'image/jpeg';
  const isPNG = file.type === 'image/png';
  const isLt2M = file.size / 1024 / 1024 < 2;

  if (!isJPG && !isPNG) {
    ElMessage.error('Cover image must be JPG or PNG format!');
    return false;
  }
  if (!isLt2M) {
    ElMessage.error('Cover image size cannot exceed 2MB!');
    return false;
  }
  return true;
};

// Tag handling methods
const showTagInput = () => {
  inputVisible.value = true;
  nextTick(() => {
    InputRef.value.focus();
  });
};

const handleTagClose = (tag) => {
  dynamicTags.value.splice(dynamicTags.value.indexOf(tag), 1);
};

const handleTagConfirm = () => {
  if (inputValue.value) {
    if (dynamicTags.value.indexOf(inputValue.value) === -1) {
      dynamicTags.value.push(inputValue.value);
    }
  }
  inputVisible.value = false;
  inputValue.value = '';
};

// Form submission
const submitForm = () => {
  articleFormRef.value.validate(async (valid) => {
    if (!valid) {
      return false;
    }
    
    if (editorInstance.value) {
      articleForm.content = editorInstance.value.getData();
    }
    
    // Add tags to form data
    articleForm.tags = dynamicTags.value;
    
    loading.value = true;
    try {
      if (isEdit.value) {
        await updateArticle(articleId.value, articleForm);
        ElMessage.success('Article updated successfully');
      } else {
        await createArticle(articleForm);
        ElMessage.success('Article created successfully');
      }
      
      // Navigate back to article list
      router.push('/content/articles');
    } catch (error) {
      console.error('Failed to save article:', error);
      ElMessage.error(error.message || 'Failed to save article');
    } finally {
      loading.value = false;
    }
  });
};

// Navigation
const goBack = () => {
  ElMessageBox.confirm(
    'Are you sure you want to cancel? Any unsaved changes will be lost.',
    'Warning',
    {
      confirmButtonText: 'Yes',
      cancelButtonText: 'No',
      type: 'warning',
    }
  ).then(() => {
    router.push('/content/articles');
  }).catch(() => {
    // Stay on the current page
  });
};

// Lifecycle hooks
onMounted(async () => {
  await fetchCategories();
  
  // Initialize the editor after DOM is ready
  nextTick(() => {
    initEditor();
  });
  
  // Fetch article data if we're editing
  if (isEdit.value) {
    fetchArticle();
  }
});

onBeforeUnmount(() => {
  // Clean up editor instance
  if (editorInstance.value) {
    editorInstance.value.destroy();
  }
});
</script>

<style scoped>
.article-edit-container {
  padding: 20px;
}

.form-container {
  margin-bottom: 20px;
}

.card-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.editor-container {
  border: 1px solid #dcdfe6;
  border-radius: 4px;
  min-height: 400px;
}

.editor {
  height: 400px;
}

.cover-uploader {
  border: 1px dashed #d9d9d9;
  border-radius: 6px;
  cursor: pointer;
  position: relative;
  overflow: hidden;
  width: 300px;
  height: 180px;
  display: flex;
  justify-content: center;
  align-items: center;
}

.cover-uploader:hover {
  border-color: #409EFF;
}

.cover-uploader-icon {
  font-size: 28px;
  color: #8c939d;
  width: 178px;
  height: 178px;
  line-height: 178px;
  text-align: center;
}

.cover-image {
  max-width: 100%;
  max-height: 100%;
  display: block;
}

.el-tag {
  margin-right: 10px;
  margin-bottom: 10px;
}

.tag-input {
  width: 90px;
  margin-left: 10px;
  vertical-align: bottom;
}

.button-new-tag {
  margin-left: 10px;
  height: 32px;
  line-height: 30px;
  padding-top: 0;
  padding-bottom: 0;
}
</style>