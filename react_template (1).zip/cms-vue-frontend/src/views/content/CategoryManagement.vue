<!-- src/views/content/CategoryManagement.vue -->
<template>
  <div class="category-management-container">
    <el-card class="category-card">
      <template #header>
        <div class="card-header">
          <h2>Category Management</h2>
          <el-button type="primary" @click="handleAddCategory">
            <el-icon><Plus /></el-icon>
            Add Category
          </el-button>
        </div>
      </template>
      
      <div class="category-content">
        <el-table
          v-loading="loading"
          :data="categories"
          border
          style="width: 100%"
        >
          <el-table-column label="ID" prop="id" width="80" />
          <el-table-column label="Name" prop="name" min-width="150" />
          <el-table-column label="Description" prop="description" min-width="300" show-overflow-tooltip />
          <el-table-column label="Articles Count" prop="articleCount" width="120" />
          <el-table-column label="Created At" prop="createdAt" width="150" />
          <el-table-column label="Actions" width="200" fixed="right">
            <template #default="{ row }">
              <el-button 
                size="small" 
                type="primary" 
                plain
                @click="handleEdit(row)"
              >
                Edit
              </el-button>
              <el-button 
                size="small" 
                type="danger" 
                plain
                :disabled="row.articleCount > 0"
                @click="handleDelete(row)"
              >
                Delete
              </el-button>
            </template>
          </el-table-column>
        </el-table>
      </div>
    </el-card>
    
    <!-- Category Dialog -->
    <el-dialog
      v-model="dialogVisible"
      :title="isEdit ? 'Edit Category' : 'Add Category'"
      width="500px"
    >
      <el-form
        ref="categoryFormRef"
        :model="categoryForm"
        :rules="rules"
        label-width="100px"
      >
        <el-form-item label="Name" prop="name">
          <el-input v-model="categoryForm.name" placeholder="Enter category name" />
        </el-form-item>
        
        <el-form-item label="Description" prop="description">
          <el-input 
            v-model="categoryForm.description" 
            type="textarea" 
            :rows="3" 
            placeholder="Enter category description" 
          />
        </el-form-item>
        
        <el-form-item label="Sort Order" prop="sortOrder">
          <el-input-number v-model="categoryForm.sortOrder" :min="1" :max="100" />
        </el-form-item>
      </el-form>
      
      <template #footer>
        <span class="dialog-footer">
          <el-button @click="dialogVisible = false">Cancel</el-button>
          <el-button type="primary" :loading="submitLoading" @click="submitForm">
            {{ isEdit ? 'Update' : 'Create' }}
          </el-button>
        </span>
      </template>
    </el-dialog>
  </div>
</template>

<script setup>
import { ref, reactive, computed, onMounted } from 'vue';
import { ElMessage, ElMessageBox } from 'element-plus';
import { Plus } from '@element-plus/icons-vue';
import { getCategories, createCategory, updateCategory, deleteCategory } from '@/api/content';

// Component data
const loading = ref(false);
const submitLoading = ref(false);
const dialogVisible = ref(false);
const isEdit = ref(false);
const categories = ref([]);
const categoryFormRef = ref(null);
const currentId = ref(null);

// Category form
const categoryForm = reactive({
  name: '',
  description: '',
  sortOrder: 1
});

// Form validation rules
const rules = {
  name: [
    { required: true, message: 'Please enter category name', trigger: 'blur' },
    { min: 2, max: 50, message: 'Length should be 2 to 50 characters', trigger: 'blur' }
  ],
  description: [
    { max: 200, message: 'Description cannot exceed 200 characters', trigger: 'blur' }
  ],
  sortOrder: [
    { required: true, message: 'Please enter sort order', trigger: 'blur' }
  ]
};

// Fetch categories
const fetchCategories = async () => {
  loading.value = true;
  try {
    const response = await getCategories();
    categories.value = response;
  } catch (error) {
    console.error('Failed to fetch categories:', error);
    ElMessage.error('Failed to load categories');
    
    // Mock data for development
    categories.value = [
      { 
        id: 1, 
        name: 'Technology', 
        description: 'Articles about technology, programming, and software development',
        articleCount: 12,
        createdAt: '2023-05-10'
      },
      { 
        id: 2, 
        name: 'Design', 
        description: 'UI/UX design, graphic design, and other design-related topics',
        articleCount: 8,
        createdAt: '2023-05-11'
      },
      { 
        id: 3, 
        name: 'Business', 
        description: 'Business strategies, management, and entrepreneurship',
        articleCount: 5,
        createdAt: '2023-05-12'
      },
      { 
        id: 4, 
        name: 'Lifestyle', 
        description: 'Health, productivity, and personal development',
        articleCount: 0,
        createdAt: '2023-05-13'
      }
    ];
  } finally {
    loading.value = false;
  }
};

// Handle add category
const handleAddCategory = () => {
  resetForm();
  isEdit.value = false;
  dialogVisible.value = true;
};

// Handle edit category
const handleEdit = (row) => {
  resetForm();
  isEdit.value = true;
  currentId.value = row.id;
  
  // Fill form with category data
  categoryForm.name = row.name;
  categoryForm.description = row.description || '';
  categoryForm.sortOrder = row.sortOrder || 1;
  
  dialogVisible.value = true;
};

// Handle delete category
const handleDelete = (row) => {
  // Check if category has articles
  if (row.articleCount > 0) {
    ElMessage.warning('Cannot delete category with articles. Please move articles to another category first.');
    return;
  }
  
  ElMessageBox.confirm(
    'This will permanently delete the category. Continue?',
    'Warning',
    {
      confirmButtonText: 'OK',
      cancelButtonText: 'Cancel',
      type: 'warning',
    }
  )
    .then(async () => {
      try {
        await deleteCategory(row.id);
        ElMessage.success('Category deleted successfully');
        fetchCategories();
      } catch (error) {
        console.error('Failed to delete category:', error);
        ElMessage.error('Failed to delete category');
      }
    })
    .catch(() => {
      // User canceled the operation
    });
};

// Reset form
const resetForm = () => {
  categoryForm.name = '';
  categoryForm.description = '';
  categoryForm.sortOrder = 1;
  
  // Reset validation
  if (categoryFormRef.value) {
    categoryFormRef.value.resetFields();
  }
};

// Submit form
const submitForm = () => {
  categoryFormRef.value.validate(async (valid) => {
    if (!valid) {
      return;
    }
    
    submitLoading.value = true;
    try {
      if (isEdit.value) {
        await updateCategory(currentId.value, categoryForm);
        ElMessage.success('Category updated successfully');
      } else {
        await createCategory(categoryForm);
        ElMessage.success('Category created successfully');
      }
      
      dialogVisible.value = false;
      fetchCategories();
    } catch (error) {
      console.error('Failed to save category:', error);
      ElMessage.error(error.message || 'Failed to save category');
    } finally {
      submitLoading.value = false;
    }
  });
};

// Lifecycle hooks
onMounted(() => {
  fetchCategories();
});
</script>

<style scoped>
.category-management-container {
  padding: 20px;
}

.category-card {
  margin-bottom: 20px;
}

.card-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.category-content {
  margin-top: 20px;
}

.dialog-footer {
  display: flex;
  justify-content: flex-end;
  gap: 10px;
}
</style>