<!-- src/views/Dashboard.vue -->
<template>
  <div class="dashboard-container">
    <el-row :gutter="20">
      <el-col :span="8">
        <el-card class="box-card">
          <template #header>
            <div class="card-header">
              <span>Content Statistics</span>
            </div>
          </template>
          <div class="card-body">
            <div class="statistic-item">
              <div class="statistic-icon">
                <el-icon><Document /></el-icon>
              </div>
              <div class="statistic-info">
                <div class="statistic-value">{{ statistics.articleCount }}</div>
                <div class="statistic-title">Articles</div>
              </div>
            </div>
            <div class="statistic-item">
              <div class="statistic-icon">
                <el-icon><Collection /></el-icon>
              </div>
              <div class="statistic-info">
                <div class="statistic-value">{{ statistics.categoryCount }}</div>
                <div class="statistic-title">Categories</div>
              </div>
            </div>
            <div class="statistic-item">
              <div class="statistic-icon">
                <el-icon><View /></el-icon>
              </div>
              <div class="statistic-info">
                <div class="statistic-value">{{ statistics.totalViews }}</div>
                <div class="statistic-title">Total Views</div>
              </div>
            </div>
          </div>
        </el-card>
      </el-col>
      
      <el-col :span="8">
        <el-card class="box-card">
          <template #header>
            <div class="card-header">
              <span>User Statistics</span>
            </div>
          </template>
          <div class="card-body">
            <div class="statistic-item">
              <div class="statistic-icon">
                <el-icon><User /></el-icon>
              </div>
              <div class="statistic-info">
                <div class="statistic-value">{{ statistics.userCount }}</div>
                <div class="statistic-title">Users</div>
              </div>
            </div>
            <div class="statistic-item">
              <div class="statistic-icon">
                <el-icon><UserFilled /></el-icon>
              </div>
              <div class="statistic-info">
                <div class="statistic-value">{{ statistics.adminCount }}</div>
                <div class="statistic-title">Admins</div>
              </div>
            </div>
            <div class="statistic-item">
              <div class="statistic-icon">
                <el-icon><Avatar /></el-icon>
              </div>
              <div class="statistic-info">
                <div class="statistic-value">{{ statistics.onlineUsers }}</div>
                <div class="statistic-title">Online Users</div>
              </div>
            </div>
          </div>
        </el-card>
      </el-col>
      
      <el-col :span="8">
        <el-card class="box-card">
          <template #header>
            <div class="card-header">
              <span>System Information</span>
            </div>
          </template>
          <div class="system-info">
            <div class="info-item">
              <span class="label">CPU Usage:</span>
              <el-progress :percentage="systemInfo.cpuUsage" :format="percentFormat" />
            </div>
            <div class="info-item">
              <span class="label">Memory Usage:</span>
              <el-progress :percentage="systemInfo.memoryUsage" :format="percentFormat" />
            </div>
            <div class="info-item">
              <span class="label">Disk Usage:</span>
              <el-progress :percentage="systemInfo.diskUsage" :format="percentFormat" />
            </div>
          </div>
        </el-card>
      </el-col>
    </el-row>
    
    <el-row :gutter="20" class="chart-row">
      <el-col :span="12">
        <el-card class="box-card">
          <template #header>
            <div class="card-header">
              <span>Content Trends (Last 7 Days)</span>
            </div>
          </template>
          <div class="chart-container">
            <div ref="contentTrendsChart" class="chart"></div>
          </div>
        </el-card>
      </el-col>
      
      <el-col :span="12">
        <el-card class="box-card">
          <template #header>
            <div class="card-header">
              <span>Popular Categories</span>
            </div>
          </template>
          <div class="chart-container">
            <div ref="categoriesChart" class="chart"></div>
          </div>
        </el-card>
      </el-col>
    </el-row>
    
    <el-row :gutter="20">
      <el-col :span="24">
        <el-card class="box-card">
          <template #header>
            <div class="card-header">
              <span>Recent Activities</span>
            </div>
          </template>
          <el-table :data="recentActivities" style="width: 100%" height="250">
            <el-table-column prop="time" label="Time" width="180" />
            <el-table-column prop="user" label="User" width="120" />
            <el-table-column prop="action" label="Action" />
            <el-table-column prop="target" label="Target" />
          </el-table>
        </el-card>
      </el-col>
    </el-row>
  </div>
</template>

<script setup>
import { ref, onMounted, onUnmounted } from 'vue';
import * as echarts from 'echarts';
import { getDashboardData } from '@/api/system';

// Component data
const statistics = ref({
  articleCount: 0,
  categoryCount: 0,
  totalViews: 0,
  userCount: 0,
  adminCount: 0,
  onlineUsers: 0
});

const systemInfo = ref({
  cpuUsage: 0,
  memoryUsage: 0,
  diskUsage: 0
});

const recentActivities = ref([]);

// Chart refs
const contentTrendsChart = ref(null);
const categoriesChart = ref(null);

let contentChart = null;
let categoryChart = null;

// Format percentage
const percentFormat = (percentage) => `${percentage.toFixed(1)}%`;

// Initialize dashboard data
const initDashboard = async () => {
  try {
    const data = await getDashboardData();
    statistics.value = data.statistics;
    systemInfo.value = data.systemInfo;
    recentActivities.value = data.recentActivities;
    
    // Initialize charts with data
    initContentTrendsChart(data.contentTrends);
    initCategoriesChart(data.categoryDistribution);
  } catch (error) {
    console.error('Failed to load dashboard data:', error);
    // Use mock data for development
    mockDashboardData();
  }
};

// Mock data for development
const mockDashboardData = () => {
  statistics.value = {
    articleCount: 256,
    categoryCount: 12,
    totalViews: 45628,
    userCount: 124,
    adminCount: 8,
    onlineUsers: 24
  };
  
  systemInfo.value = {
    cpuUsage: 42,
    memoryUsage: 58,
    diskUsage: 37
  };
  
  recentActivities.value = [
    { time: '2023-05-16 10:23:15', user: 'admin', action: 'Created article', target: 'Spring Boot Best Practices' },
    { time: '2023-05-16 09:45:32', user: 'john', action: 'Updated category', target: 'Web Development' },
    { time: '2023-05-16 09:12:08', user: 'admin', action: 'Deleted article', target: 'Outdated Tutorial' },
    { time: '2023-05-16 08:55:47', user: 'sarah', action: 'Created article', target: 'Vue.js Component Design' },
    { time: '2023-05-15 17:22:03', user: 'david', action: 'Updated article', target: 'Database Optimization Tips' }
  ];
  
  // Initialize charts with mock data
  initContentTrendsChart({
    days: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'],
    articles: [5, 8, 3, 12, 7, 4, 9],
    views: [120, 180, 150, 250, 190, 230, 300]
  });
  
  initCategoriesChart([
    { name: 'Technology', value: 42 },
    { name: 'Design', value: 28 },
    { name: 'Business', value: 18 },
    { name: 'Lifestyle', value: 12 }
  ]);
};

// Initialize content trends chart
const initContentTrendsChart = (data) => {
  if (!contentTrendsChart.value) return;
  
  contentChart = echarts.init(contentTrendsChart.value);
  
  const option = {
    tooltip: {
      trigger: 'axis',
      axisPointer: {
        type: 'shadow'
      }
    },
    legend: {
      data: ['Articles', 'Views']
    },
    grid: {
      left: '3%',
      right: '4%',
      bottom: '3%',
      containLabel: true
    },
    xAxis: {
      type: 'category',
      data: data.days
    },
    yAxis: [
      {
        type: 'value',
        name: 'Articles',
        minInterval: 1
      },
      {
        type: 'value',
        name: 'Views'
      }
    ],
    series: [
      {
        name: 'Articles',
        type: 'bar',
        data: data.articles
      },
      {
        name: 'Views',
        type: 'line',
        yAxisIndex: 1,
        data: data.views
      }
    ]
  };
  
  contentChart.setOption(option);
};

// Initialize categories chart
const initCategoriesChart = (data) => {
  if (!categoriesChart.value) return;
  
  categoryChart = echarts.init(categoriesChart.value);
  
  const option = {
    tooltip: {
      trigger: 'item',
      formatter: '{a} <br/>{b}: {c} ({d}%)'
    },
    legend: {
      orient: 'horizontal',
      bottom: 'bottom',
      data: data.map(item => item.name)
    },
    series: [
      {
        name: 'Category Distribution',
        type: 'pie',
        radius: '65%',
        center: ['50%', '45%'],
        data: data,
        emphasis: {
          itemStyle: {
            shadowBlur: 10,
            shadowOffsetX: 0,
            shadowColor: 'rgba(0, 0, 0, 0.5)'
          }
        }
      }
    ]
  };
  
  categoryChart.setOption(option);
};

// Handle window resize for charts
const handleResize = () => {
  contentChart && contentChart.resize();
  categoryChart && categoryChart.resize();
};

// Lifecycle hooks
onMounted(() => {
  initDashboard();
  window.addEventListener('resize', handleResize);
});

onUnmounted(() => {
  window.removeEventListener('resize', handleResize);
  contentChart && contentChart.dispose();
  categoryChart && categoryChart.dispose();
});
</script>

<style scoped>
.dashboard-container {
  padding: 20px;
}

.box-card {
  margin-bottom: 20px;
  height: 100%;
}

.card-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.card-body {
  display: flex;
  flex-direction: column;
  gap: 15px;
}

.statistic-item {
  display: flex;
  align-items: center;
  margin-bottom: 10px;
}

.statistic-icon {
  width: 50px;
  height: 50px;
  border-radius: 8px;
  background-color: #ecf5ff;
  color: #409EFF;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 24px;
  margin-right: 15px;
}

.statistic-info {
  flex: 1;
}

.statistic-value {
  font-size: 24px;
  font-weight: 600;
  color: #303133;
}

.statistic-title {
  font-size: 14px;
  color: #909399;
}

.system-info {
  padding: 10px 0;
}

.info-item {
  margin-bottom: 15px;
}

.label {
  display: block;
  margin-bottom: 5px;
  color: #606266;
}

.chart-row {
  margin-top: 10px;
}

.chart-container {
  height: 300px;
}

.chart {
  width: 100%;
  height: 100%;
}
</style>