<!-- src/views/system/UserManagement.vue -->
<template>
  <div class="user-management-container">
    <el-card class="filter-container">
      <div class="filter-section">
        <el-input
          v-model="searchQuery"
          placeholder="Search users"
          clearable
          class="filter-item"
          @keyup.enter="handleSearch"
        >
          <template #append>
            <el-button :icon="Search" @click="handleSearch" />
          </template>
        </el-input>
        
        <el-select
          v-model="roleId"
          placeholder="Select role"
          clearable
          class="filter-item"
        >
          <el-option
            v-for="item in roles"
            :key="item.id"
            :label="item.name"
            :value="item.id"
          />
        </el-select>
        
        <el-select
          v-model="status"
          placeholder="Status"
          clearable
          class="filter-item"
        >
          <el-option label="Active" value="active" />
          <el-option label="Inactive" value="inactive" />
        </el-select>
        
        <div class="button-group">
          <el-button type="primary" @click="handleSearch">Search</el-button>
          <el-button @click="resetFilters">Reset</el-button>
        </div>
      </div>
    </el-card>
    
    <el-card class="table-container">
      <div class="table-header">
        <h3>User List</h3>
        <el-button type="primary" @click="handleCreateUser">
          <el-icon><Plus /></el-icon>
          New User
        </el-button>
      </div>
      
      <el-table
        v-loading="loading"
        :data="userList"
        border
        style="width: 100%"
      >
        <el-table-column label="ID" prop="id" width="80" />
        <el-table-column label="Username" prop="username" min-width="120" />
        <el-table-column label="Name" prop="name" min-width="150" />
        <el-table-column label="Email" prop="email" min-width="200" />
        <el-table-column label="Role" prop="roleName" width="120" />
        <el-table-column label="Status" width="100">
          <template #default="{ row }">
            <el-tag :type="row.status === 'active' ? 'success' : 'info'">
              {{ row.status }}
            </el-tag>
          </template>
        </el-table-column>
        <el-table-column label="Created At" prop="createdAt" width="150" />
        <el-table-column label="Actions" width="200" fixed="right">
          <template #default="{ row }">
            <el-button 
              size="small" 
              type="primary" 
              plain
              @click="handleEdit(row)"
            >
              Edit
            </el-button>
            <el-button 
              size="small" 
              :type="row.status === 'active' ? 'warning' : 'success'" 
              plain
              @click="handleStatusToggle(row)"
            >
              {{ row.status === 'active' ? 'Deactivate' : 'Activate' }}
            </el-button>
            <el-button 
              size="small" 
              type="danger" 
              plain
              @click="handleDelete(row)"
            >
              Delete
            </el-button>
          </template>
        </el-table-column>
      </el-table>
      
      <div class="pagination-container">
        <el-pagination
          v-model:current-page="currentPage"
          v-model:page-size="pageSize"
          :page-sizes="[10, 20, 50, 100]"
          :total="total"
          layout="total, sizes, prev, pager, next, jumper"
          @size-change="handleSizeChange"
          @current-change="handleCurrentChange"
        />
      </div>
    </el-card>
    
    <!-- User Form Dialog -->
    <el-dialog
      v-model="dialogVisible"
      :title="isEdit ? 'Edit User' : 'Create User'"
      width="500px"
    >
      <el-form
        ref="userFormRef"
        :model="userForm"
        :rules="rules"
        label-width="100px"
      >
        <el-form-item label="Username" prop="username">
          <el-input 
            v-model="userForm.username" 
            placeholder="Enter username"
            :disabled="isEdit" 
          />
        </el-form-item>
        
        <el-form-item label="Name" prop="name">
          <el-input v-model="userForm.name" placeholder="Enter name" />
        </el-form-item>
        
        <el-form-item label="Email" prop="email">
          <el-input v-model="userForm.email" placeholder="Enter email" />
        </el-form-item>
        
        <el-form-item label="Password" prop="password" v-if="!isEdit">
          <el-input 
            v-model="userForm.password" 
            type="password" 
            placeholder="Enter password"
            show-password 
          />
        </el-form-item>
        
        <el-form-item label="Role" prop="roleId">
          <el-select v-model="userForm.roleId" placeholder="Select role" style="width: 100%">
            <el-option 
              v-for="item in roles" 
              :key="item.id" 
              :label="item.name" 
              :value="item.id" 
            />
          </el-select>
        </el-form-item>
        
        <el-form-item label="Status" prop="status">
          <el-radio-group v-model="userForm.status">
            <el-radio label="active">Active</el-radio>
            <el-radio label="inactive">Inactive</el-radio>
          </el-radio-group>
        </el-form-item>
      </el-form>
      
      <template #footer>
        <span class="dialog-footer">
          <el-button @click="dialogVisible = false">Cancel</el-button>
          <el-button type="primary" :loading="submitLoading" @click="submitForm">
            {{ isEdit ? 'Update' : 'Create' }}
          </el-button>
        </span>
      </template>
    </el-dialog>
  </div>
</template>

<script setup>
import { ref, reactive, onMounted } from 'vue';
import { ElMessage, ElMessageBox } from 'element-plus';
import { Search, Plus } from '@element-plus/icons-vue';
import { getUsers, createUser, updateUser, deleteUser, updateUserStatus } from '@/api/user';
import { getRoles } from '@/api/system';

// Component data
const loading = ref(false);
const submitLoading = ref(false);
const dialogVisible = ref(false);
const isEdit = ref(false);
const userList = ref([]);
const roles = ref([]);
const total = ref(0);
const currentPage = ref(1);
const pageSize = ref(10);
const userFormRef = ref(null);

// Search filters
const searchQuery = ref('');
const roleId = ref('');
const status = ref('');

// User form
const userForm = reactive({
  username: '',
  name: '',
  email: '',
  password: '',
  roleId: '',
  status: 'active'
});

// Form validation rules
const rules = {
  username: [
    { required: true, message: 'Please enter username', trigger: 'blur' },
    { min: 4, max: 20, message: 'Length should be 4 to 20 characters', trigger: 'blur' },
    { pattern: /^[a-zA-Z0-9_]+$/, message: 'Username can only contain letters, numbers, and underscores', trigger: 'blur' }
  ],
  name: [
    { required: true, message: 'Please enter name', trigger: 'blur' },
    { min: 2, max: 50, message: 'Length should be 2 to 50 characters', trigger: 'blur' }
  ],
  email: [
    { required: true, message: 'Please enter email', trigger: 'blur' },
    { type: 'email', message: 'Please enter a valid email address', trigger: 'blur' }
  ],
  password: [
    { required: true, message: 'Please enter password', trigger: 'blur' },
    { min: 6, max: 20, message: 'Length should be 6 to 20 characters', trigger: 'blur' }
  ],
  roleId: [
    { required: true, message: 'Please select role', trigger: 'change' }
  ],
  status: [
    { required: true, message: 'Please select status', trigger: 'change' }
  ]
};

// Methods
const fetchUsers = async () => {
  loading.value = true;
  
  try {
    const params = {
      page: currentPage.value,
      pageSize: pageSize.value,
      query: searchQuery.value,
      roleId: roleId.value,
      status: status.value
    };
    
    const response = await getUsers(params);
    userList.value = response.data;
    total.value = response.total;
  } catch (error) {
    console.error('Failed to fetch users:', error);
    mockUsers();
  } finally {
    loading.value = false;
  }
};

const fetchRoles = async () => {
  try {
    const response = await getRoles();
    roles.value = response;
  } catch (error) {
    console.error('Failed to fetch roles:', error);
    // Mock roles for development
    roles.value = [
      { id: 1, name: 'Admin' },
      { id: 2, name: 'Editor' },
      { id: 3, name: 'Viewer' }
    ];
  }
};

// Mock data for development
const mockUsers = () => {
  const mockData = [];
  
  for (let i = 1; i <= 20; i++) {
    const createdAt = new Date(Date.now() - Math.floor(Math.random() * 30) * 24 * 60 * 60 * 1000);
    
    mockData.push({
      id: i,
      username: `user${i}`,
      name: `User ${i}`,
      email: `user${i}@example.com`,
      roleName: i % 3 === 0 ? 'Admin' : i % 3 === 1 ? 'Editor' : 'Viewer',
      roleId: i % 3 === 0 ? 1 : i % 3 === 1 ? 2 : 3,
      status: i % 5 === 0 ? 'inactive' : 'active',
      createdAt: createdAt.toISOString().substring(0, 10)
    });
  }
  
  userList.value = mockData.slice(0, pageSize.value);
  total.value = mockData.length;
};

const handleSearch = () => {
  currentPage.value = 1;
  fetchUsers();
};

const resetFilters = () => {
  searchQuery.value = '';
  roleId.value = '';
  status.value = '';
  currentPage.value = 1;
  fetchUsers();
};

const handleSizeChange = (size) => {
  pageSize.value = size;
  fetchUsers();
};

const handleCurrentChange = (page) => {
  currentPage.value = page;
  fetchUsers();
};

const resetForm = () => {
  userForm.username = '';
  userForm.name = '';
  userForm.email = '';
  userForm.password = '';
  userForm.roleId = '';
  userForm.status = 'active';
  
  // Reset validation
  if (userFormRef.value) {
    userFormRef.value.resetFields();
  }
};

const handleCreateUser = () => {
  resetForm();
  isEdit.value = false;
  dialogVisible.value = true;
};

const handleEdit = (row) => {
  resetForm();
  isEdit.value = true;
  
  // Fill form with user data
  userForm.username = row.username;
  userForm.name = row.name;
  userForm.email = row.email;
  userForm.roleId = row.roleId;
  userForm.status = row.status;
  
  dialogVisible.value = true;
};

const handleStatusToggle = async (row) => {
  try {
    const newStatus = row.status === 'active' ? 'inactive' : 'active';
    await updateUserStatus(row.id, newStatus);
    
    // Update local state
    const index = userList.value.findIndex(item => item.id === row.id);
    if (index !== -1) {
      userList.value[index].status = newStatus;
    }
    
    ElMessage.success(`User ${newStatus === 'active' ? 'activated' : 'deactivated'} successfully`);
  } catch (error) {
    console.error('Failed to update user status:', error);
    ElMessage.error('Failed to update user status');
  }
};

const handleDelete = (row) => {
  ElMessageBox.confirm(
    'This will permanently delete the user. Continue?',
    'Warning',
    {
      confirmButtonText: 'OK',
      cancelButtonText: 'Cancel',
      type: 'warning',
    }
  )
    .then(async () => {
      try {
        await deleteUser(row.id);
        fetchUsers();
        ElMessage.success('User deleted successfully');
      } catch (error) {
        console.error('Failed to delete user:', error);
        ElMessage.error('Failed to delete user');
      }
    })
    .catch(() => {
      // User canceled the operation
    });
};

const submitForm = () => {
  userFormRef.value.validate(async (valid) => {
    if (!valid) {
      return;
    }
    
    submitLoading.value = true;
    try {
      if (isEdit.value) {
        await updateUser(userForm.username, userForm);
        ElMessage.success('User updated successfully');
      } else {
        await createUser(userForm);
        ElMessage.success('User created successfully');
      }
      
      dialogVisible.value = false;
      fetchUsers();
    } catch (error) {
      console.error('Failed to save user:', error);
      ElMessage.error(error.message || 'Failed to save user');
    } finally {
      submitLoading.value = false;
    }
  });
};

// Lifecycle hooks
onMounted(() => {
  fetchUsers();
  fetchRoles();
});
</script>

<style scoped>
.user-management-container {
  padding: 20px;
}

.filter-container {
  margin-bottom: 20px;
}

.filter-section {
  display: flex;
  flex-wrap: wrap;
  gap: 15px;
  align-items: center;
}

.filter-item {
  min-width: 200px;
}

.button-group {
  margin-left: auto;
}

.table-container {
  margin-bottom: 20px;
}

.table-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 20px;
}

.pagination-container {
  margin-top: 20px;
  display: flex;
  justify-content: flex-end;
}

.dialog-footer {
  display: flex;
  justify-content: flex-end;
  gap: 10px;
}
</style>