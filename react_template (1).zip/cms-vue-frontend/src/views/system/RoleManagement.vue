<!-- src/views/system/RoleManagement.vue -->
<template>
  <div class="role-management-container">
    <el-card class="role-card">
      <template #header>
        <div class="card-header">
          <h2>Role Management</h2>
          <el-button type="primary" @click="handleAddRole">
            <el-icon><Plus /></el-icon>
            Add Role
          </el-button>
        </div>
      </template>
      
      <div class="role-content">
        <el-table
          v-loading="loading"
          :data="roles"
          border
          style="width: 100%"
        >
          <el-table-column label="ID" prop="id" width="80" />
          <el-table-column label="Name" prop="name" width="150" />
          <el-table-column label="Description" prop="description" min-width="300" show-overflow-tooltip />
          <el-table-column label="Users Count" prop="userCount" width="120" />
          <el-table-column label="Created At" prop="createdAt" width="150" />
          <el-table-column label="Actions" width="250" fixed="right">
            <template #default="{ row }">
              <el-button 
                size="small" 
                type="primary" 
                plain
                @click="handleEdit(row)"
              >
                Edit
              </el-button>
              <el-button 
                size="small" 
                type="info" 
                plain
                @click="handlePermissions(row)"
              >
                Permissions
              </el-button>
              <el-button 
                size="small" 
                type="danger" 
                plain
                :disabled="row.userCount > 0 || row.name === 'Admin'"
                @click="handleDelete(row)"
              >
                Delete
              </el-button>
            </template>
          </el-table-column>
        </el-table>
      </div>
    </el-card>
    
    <!-- Role Dialog -->
    <el-dialog
      v-model="roleDialogVisible"
      :title="isEdit ? 'Edit Role' : 'Add Role'"
      width="500px"
    >
      <el-form
        ref="roleFormRef"
        :model="roleForm"
        :rules="rules"
        label-width="100px"
      >
        <el-form-item label="Name" prop="name">
          <el-input 
            v-model="roleForm.name" 
            placeholder="Enter role name" 
            :disabled="isEdit && roleForm.name === 'Admin'"
          />
        </el-form-item>
        
        <el-form-item label="Description" prop="description">
          <el-input 
            v-model="roleForm.description" 
            type="textarea" 
            :rows="3" 
            placeholder="Enter role description" 
          />
        </el-form-item>
      </el-form>
      
      <template #footer>
        <span class="dialog-footer">
          <el-button @click="roleDialogVisible = false">Cancel</el-button>
          <el-button type="primary" :loading="submitLoading" @click="submitRoleForm">
            {{ isEdit ? 'Update' : 'Create' }}
          </el-button>
        </span>
      </template>
    </el-dialog>
    
    <!-- Permissions Dialog -->
    <el-dialog
      v-model="permissionsDialogVisible"
      :title="`Edit Permissions for ${currentRole.name}`"
      width="600px"
    >
      <el-tree
        ref="permissionTreeRef"
        :data="permissionsTree"
        show-checkbox
        node-key="id"
        default-expand-all
        :props="{ label: 'name', children: 'children' }"
      />
      
      <template #footer>
        <span class="dialog-footer">
          <el-button @click="permissionsDialogVisible = false">Cancel</el-button>
          <el-button type="primary" :loading="permissionSubmitLoading" @click="submitPermissions">
            Save
          </el-button>
        </span>
      </template>
    </el-dialog>
  </div>
</template>

<script setup>
import { ref, reactive, onMounted } from 'vue';
import { ElMessage, ElMessageBox } from 'element-plus';
import { Plus } from '@element-plus/icons-vue';
import { getRoles, createRole, updateRole, deleteRole, getRolePermissions, updateRolePermissions } from '@/api/system';

// Component data
const loading = ref(false);
const submitLoading = ref(false);
const permissionSubmitLoading = ref(false);
const roleDialogVisible = ref(false);
const permissionsDialogVisible = ref(false);
const isEdit = ref(false);
const roles = ref([]);
const roleFormRef = ref(null);
const permissionTreeRef = ref(null);
const permissionsTree = ref([]);
const currentRole = ref({});
const currentRoleId = ref(null);

// Role form
const roleForm = reactive({
  name: '',
  description: ''
});

// Form validation rules
const rules = {
  name: [
    { required: true, message: 'Please enter role name', trigger: 'blur' },
    { min: 2, max: 50, message: 'Length should be 2 to 50 characters', trigger: 'blur' }
  ],
  description: [
    { max: 200, message: 'Description cannot exceed 200 characters', trigger: 'blur' }
  ]
};

// Fetch roles
const fetchRoles = async () => {
  loading.value = true;
  try {
    const response = await getRoles();
    roles.value = response;
  } catch (error) {
    console.error('Failed to fetch roles:', error);
    ElMessage.error('Failed to load roles');
    
    // Mock data for development
    roles.value = [
      { 
        id: 1, 
        name: 'Admin', 
        description: 'System administrator with full access to all features',
        userCount: 2,
        createdAt: '2023-05-10'
      },
      { 
        id: 2, 
        name: 'Editor', 
        description: 'Content editor with access to create and edit articles',
        userCount: 5,
        createdAt: '2023-05-11'
      },
      { 
        id: 3, 
        name: 'Viewer', 
        description: 'Read-only access to content',
        userCount: 10,
        createdAt: '2023-05-12'
      }
    ];
  } finally {
    loading.value = false;
  }
};

// Handle add role
const handleAddRole = () => {
  resetRoleForm();
  isEdit.value = false;
  roleDialogVisible.value = true;
};

// Handle edit role
const handleEdit = (row) => {
  resetRoleForm();
  isEdit.value = true;
  currentRoleId.value = row.id;
  
  // Fill form with role data
  roleForm.name = row.name;
  roleForm.description = row.description || '';
  
  roleDialogVisible.value = true;
};

// Handle permissions
const handlePermissions = async (row) => {
  currentRole.value = row;
  currentRoleId.value = row.id;
  
  try {
    // Fetch permissions for this role
    const permissions = await getRolePermissions(row.id);
    permissionsTree.value = permissions;
  } catch (error) {
    console.error('Failed to fetch permissions:', error);
    
    // Mock permission tree for development
    permissionsTree.value = [
      {
        id: 1,
        name: 'Dashboard',
        checked: true,
        children: []
      },
      {
        id: 2,
        name: 'Content Management',
        checked: row.name !== 'Viewer',
        children: [
          {
            id: 21,
            name: 'Articles',
            checked: row.name !== 'Viewer',
            children: [
              { id: 211, name: 'View Articles', checked: true },
              { id: 212, name: 'Create Articles', checked: row.name !== 'Viewer' },
              { id: 213, name: 'Edit Articles', checked: row.name !== 'Viewer' },
              { id: 214, name: 'Delete Articles', checked: row.name === 'Admin' }
            ]
          },
          {
            id: 22,
            name: 'Categories',
            checked: row.name !== 'Viewer',
            children: [
              { id: 221, name: 'View Categories', checked: true },
              { id: 222, name: 'Create Categories', checked: row.name === 'Admin' },
              { id: 223, name: 'Edit Categories', checked: row.name === 'Admin' },
              { id: 224, name: 'Delete Categories', checked: row.name === 'Admin' }
            ]
          }
        ]
      },
      {
        id: 3,
        name: 'System Management',
        checked: row.name === 'Admin',
        children: [
          {
            id: 31,
            name: 'Users',
            checked: row.name === 'Admin',
            children: [
              { id: 311, name: 'View Users', checked: row.name === 'Admin' },
              { id: 312, name: 'Create Users', checked: row.name === 'Admin' },
              { id: 313, name: 'Edit Users', checked: row.name === 'Admin' },
              { id: 314, name: 'Delete Users', checked: row.name === 'Admin' }
            ]
          },
          {
            id: 32,
            name: 'Roles',
            checked: row.name === 'Admin',
            children: [
              { id: 321, name: 'View Roles', checked: row.name === 'Admin' },
              { id: 322, name: 'Create Roles', checked: row.name === 'Admin' },
              { id: 323, name: 'Edit Roles', checked: row.name === 'Admin' },
              { id: 324, name: 'Delete Roles', checked: row.name === 'Admin' }
            ]
          }
        ]
      }
    ];
  }
  
  permissionsDialogVisible.value = true;
};

// Handle delete role
const handleDelete = (row) => {
  // Check if role has users or is Admin
  if (row.userCount > 0) {
    ElMessage.warning('Cannot delete role with users. Please reassign users to another role first.');
    return;
  }
  
  if (row.name === 'Admin') {
    ElMessage.warning('Cannot delete the Admin role.');
    return;
  }
  
  ElMessageBox.confirm(
    'This will permanently delete the role. Continue?',
    'Warning',
    {
      confirmButtonText: 'OK',
      cancelButtonText: 'Cancel',
      type: 'warning',
    }
  )
    .then(async () => {
      try {
        await deleteRole(row.id);
        ElMessage.success('Role deleted successfully');
        fetchRoles();
      } catch (error) {
        console.error('Failed to delete role:', error);
        ElMessage.error('Failed to delete role');
      }
    })
    .catch(() => {
      // User canceled the operation
    });
};

// Reset role form
const resetRoleForm = () => {
  roleForm.name = '';
  roleForm.description = '';
  
  // Reset validation
  if (roleFormRef.value) {
    roleFormRef.value.resetFields();
  }
};

// Submit role form
const submitRoleForm = () => {
  roleFormRef.value.validate(async (valid) => {
    if (!valid) {
      return;
    }
    
    submitLoading.value = true;
    try {
      if (isEdit.value) {
        await updateRole(currentRoleId.value, roleForm);
        ElMessage.success('Role updated successfully');
      } else {
        await createRole(roleForm);
        ElMessage.success('Role created successfully');
      }
      
      roleDialogVisible.value = false;
      fetchRoles();
    } catch (error) {
      console.error('Failed to save role:', error);
      ElMessage.error(error.message || 'Failed to save role');
    } finally {
      submitLoading.value = false;
    }
  });
};

// Submit permissions
const submitPermissions = async () => {
  permissionSubmitLoading.value = true;
  
  try {
    // Get checked nodes
    const checkedKeys = permissionTreeRef.value.getCheckedKeys();
    const halfCheckedKeys = permissionTreeRef.value.getHalfCheckedKeys();
    const allCheckedKeys = [...checkedKeys, ...halfCheckedKeys];
    
    await updateRolePermissions(currentRoleId.value, allCheckedKeys);
    ElMessage.success('Permissions updated successfully');
    permissionsDialogVisible.value = false;
  } catch (error) {
    console.error('Failed to update permissions:', error);
    ElMessage.error('Failed to update permissions');
  } finally {
    permissionSubmitLoading.value = false;
  }
};

// Lifecycle hooks
onMounted(() => {
  fetchRoles();
});
</script>

<style scoped>
.role-management-container {
  padding: 20px;
}

.role-card {
  margin-bottom: 20px;
}

.card-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.role-content {
  margin-top: 20px;
}

.dialog-footer {
  display: flex;
  justify-content: flex-end;
  gap: 10px;
}
</style>