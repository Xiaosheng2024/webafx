<!-- src/views/Login.vue -->
<template>
  <div class="login-container">
    <el-card class="login-card">
      <div class="title-container">
        <h3 class="title">Content Management System</h3>
      </div>
      
      <el-form
        ref="loginFormRef"
        :model="loginForm"
        :rules="loginRules"
        auto-complete="on"
        label-position="left"
      >
        <el-form-item prop="username">
          <el-input
            ref="usernameRef"
            v-model="loginForm.username"
            placeholder="Username"
            name="username"
            type="text"
            auto-complete="on"
            prefix-icon="User"
          />
        </el-form-item>
        
        <el-form-item prop="password">
          <el-input
            ref="passwordRef"
            v-model="loginForm.password"
            placeholder="Password"
            name="password"
            :type="passwordType"
            prefix-icon="Lock"
            auto-complete="on"
            @keyup.enter="handleLogin"
          >
            <template #suffix>
              <el-icon class="show-pwd" @click="togglePasswordVisibility">
                <component :is="passwordType === 'password' ? 'Hide' : 'View'" />
              </el-icon>
            </template>
          </el-input>
        </el-form-item>
        
        <el-form-item>
          <el-button
            :loading="loading"
            type="primary"
            style="width: 100%"
            @click.prevent="handleLogin"
          >
            Login
          </el-button>
        </el-form-item>
      </el-form>
    </el-card>
  </div>
</template>

<script setup>
import { ref, reactive, onMounted } from 'vue';
import { useRouter, useRoute } from 'vue-router';
import { login } from '@/api/user';
import { setToken } from '@/utils/auth';
import { ElMessage } from 'element-plus';

// Component data
const router = useRouter();
const route = useRoute();
const loading = ref(false);
const passwordType = ref('password');
const loginFormRef = ref(null);
const usernameRef = ref(null);
const passwordRef = ref(null);

const loginForm = reactive({
  username: 'admin',
  password: '123456'
});

const loginRules = {
  username: [{ required: true, message: 'Please enter username', trigger: 'blur' }],
  password: [{ required: true, message: 'Please enter password', trigger: 'blur' }]
};

// Methods
const togglePasswordVisibility = () => {
  passwordType.value = passwordType.value === 'password' ? 'text' : 'password';
};

const handleLogin = () => {
  loginFormRef.value.validate(async (valid) => {
    if (valid) {
      loading.value = true;
      try {
        const response = await login(loginForm.username, loginForm.password);
        setToken(response.token);
        
        // Redirect to dashboard or previously attempted page
        const redirectPath = route.query.redirect || '/dashboard';
        router.push(redirectPath);
        
        ElMessage.success('Login successful');
      } catch (error) {
        console.error('Login failed:', error);
        ElMessage.error(error.message || 'Login failed');
      } finally {
        loading.value = false;
      }
    } else {
      return false;
    }
  });
};

// Lifecycle hooks
onMounted(() => {
  // Focus username field on component mount
  usernameRef.value.focus();
});
</script>

<style scoped>
.login-container {
  display: flex;
  justify-content: center;
  align-items: center;
  height: 100vh;
  background-color: #f3f3f3;
  background-image: linear-gradient(to bottom right, #3a8ee6, #43bfa5);
}

.login-card {
  width: 400px;
  padding: 20px 35px;
  border-radius: 8px;
}

.title-container {
  margin-bottom: 30px;
  text-align: center;
}

.title {
  font-size: 26px;
  color: #303133;
  margin: 0 0 20px 0;
  font-weight: bold;
}

.show-pwd {
  cursor: pointer;
}
</style>