<!-- src/views/404.vue -->
<template>
  <div class="not-found-container">
    <div class="not-found-content">
      <el-result
        icon="error"
        title="404"
        sub-title="Sorry, the page you visited does not exist."
      >
        <template #extra>
          <el-button type="primary" @click="goHome">Back to Home</el-button>
          <el-button @click="goBack">Go Back</el-button>
        </template>
      </el-result>
      <div class="not-found-image">
        <img src="https://cdn.pixabay.com/photo/2017/03/09/12/31/error-2129569_960_720.jpg" alt="Page not found" />
      </div>
    </div>
  </div>
</template>

<script setup>
import { useRouter } from 'vue-router';

const router = useRouter();

// Navigate to home page
const goHome = () => {
  router.push('/');
};

// Go back to previous page
const goBack = () => {
  router.go(-1);
};
</script>

<style scoped>
.not-found-container {
  display: flex;
  justify-content: center;
  align-items: center;
  height: 100vh;
  background-color: #f5f7fa;
}

.not-found-content {
  display: flex;
  flex-direction: column;
  align-items: center;
  max-width: 800px;
  padding: 20px;
}

.not-found-image {
  margin-top: 20px;
  width: 100%;
  max-width: 500px;
}

.not-found-image img {
  width: 100%;
  height: auto;
  border-radius: 8px;
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
}

@media (max-width: 768px) {
  .not-found-content {
    padding: 15px;
  }
  
  .not-found-image {
    max-width: 90%;
  }
}
</style>