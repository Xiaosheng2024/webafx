<!-- src/components/layout/Content.vue -->
<template>
  <el-container class="layout-container">
    <el-aside :width="isCollapse ? '64px' : '210px'">
      <sidebar ref="sidebarRef" />
    </el-aside>
    <el-container>
      <el-header height="60px">
        <header-component :is-collapse="isCollapse" @toggle-sidebar="toggleSidebar" />
      </el-header>
      <el-main>
        <router-view v-slot="{ Component }">
          <transition name="fade-transform" mode="out-in">
            <keep-alive>
              <component :is="Component" />
            </keep-alive>
          </transition>
        </router-view>
      </el-main>
      <el-footer height="40px">
        <div class="footer">
          <span>© {{ new Date().getFullYear() }} Content Management System</span>
        </div>
      </el-footer>
    </el-container>
  </el-container>
</template>

<script setup>
import { ref } from 'vue';
import Sidebar from './Sidebar.vue';
import HeaderComponent from './Header.vue';

// State
const isCollapse = ref(false);
const sidebarRef = ref(null);

// Methods
const toggleSidebar = () => {
  isCollapse.value = !isCollapse.value;
  // Also notify the sidebar component
  if (sidebarRef.value) {
    sidebarRef.value.toggleSidebar();
  }
};
</script>

<style scoped>
.layout-container {
  height: 100%;
}

.el-aside {
  transition: width 0.28s;
  background-color: #304156;
  height: 100%;
  overflow: hidden;
}

.el-header {
  padding: 0;
  background-color: #fff;
  box-shadow: 0 1px 4px rgba(0, 21, 41, 0.08);
}

.el-main {
  padding: 20px;
  background-color: #f5f7fa;
  min-height: calc(100vh - 100px);
}

.el-footer {
  background-color: #fff;
  color: #606266;
  font-size: 14px;
  padding: 0;
  display: flex;
  align-items: center;
  justify-content: center;
}

.footer {
  text-align: center;
}

/* Transition for route changes */
.fade-transform-enter-active,
.fade-transform-leave-active {
  transition: all 0.3s;
}

.fade-transform-enter-from {
  opacity: 0;
  transform: translateX(30px);
}

.fade-transform-leave-to {
  opacity: 0;
  transform: translateX(-30px);
}
</style>