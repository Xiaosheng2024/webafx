<!-- src/components/layout/Header.vue -->
<template>
  <div class="header-container">
    <div class="left-menu">
      <div class="hamburger-container" @click="toggleSidebar">
        <el-icon :class="{'is-active': isCollapse}"><Fold /></el-icon>
      </div>
      <breadcrumb />
    </div>
    
    <div class="right-menu">
      <el-dropdown trigger="click">
        <div class="avatar-container">
          <img :src="avatarUrl" class="user-avatar">
          <span class="user-name">{{ username }}</span>
          <el-icon><CaretBottom /></el-icon>
        </div>
        <template #dropdown>
          <el-dropdown-menu>
            <el-dropdown-item @click="handleProfile">Profile</el-dropdown-item>
            <el-dropdown-item divided @click="handleLogout">Logout</el-dropdown-item>
          </el-dropdown-menu>
        </template>
      </el-dropdown>
    </div>
  </div>
</template>

<script setup>
import { ref, computed } from 'vue';
import { useRouter } from 'vue-router';
import { removeToken } from '@/utils/auth';

// Breadcrumb component
const Breadcrumb = defineComponent({
  name: 'Breadcrumb',
  setup() {
    const route = useRoute();
    const router = useRouter();
    
    const breadcrumbs = computed(() => {
      let matched = route.matched.filter(item => item.meta && item.meta.title);
      const first = matched[0];
      
      if (first && first.path !== '/dashboard') {
        matched = [{ path: '/dashboard', meta: { title: 'Dashboard' } }].concat(matched);
      }
      
      return matched;
    });
    
    const handleLink = (item) => {
      const { redirect, path } = item;
      if (redirect) {
        router.push(redirect);
        return;
      }
      router.push(path);
    };
    
    return { breadcrumbs, handleLink };
  },
  render() {
    return (
      <el-breadcrumb separator="/">
        {this.breadcrumbs.map((item, index) => (
          <el-breadcrumb-item key={item.path}>
            {index === this.breadcrumbs.length - 1 ? (
              <span class="no-redirect">{item.meta.title}</span>
            ) : (
              <a onClick={() => this.handleLink(item)}>{item.meta.title}</a>
            )}
          </el-breadcrumb-item>
        ))}
      </el-breadcrumb>
    );
  }
});

// Props
const props = defineProps({
  isCollapse: {
    type: Boolean,
    default: false
  }
});

// Emit events
const emit = defineEmits(['toggle-sidebar']);

// Component data
const router = useRouter();
const username = ref('Admin');
const avatarUrl = ref('https://i.pravatar.cc/80');

// Methods
const toggleSidebar = () => {
  emit('toggle-sidebar');
};

const handleProfile = () => {
  // Navigate to profile page or open profile dialog
  console.log('Go to profile page');
};

const handleLogout = () => {
  // Clear authentication and redirect to login
  removeToken();
  router.push('/login');
};
</script>

<style scoped>
.header-container {
  height: 60px;
  background-color: #fff;
  box-shadow: 0 1px 4px rgba(0, 21, 41, 0.08);
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 0 15px;
}

.hamburger-container {
  line-height: 60px;
  height: 100%;
  padding: 0 15px;
  cursor: pointer;
  transition: background 0.3s;
}

.hamburger-container:hover {
  background: rgba(0, 0, 0, 0.025);
}

.is-active {
  transform: rotate(180deg);
}

.left-menu {
  display: flex;
  align-items: center;
}

.right-menu {
  display: flex;
  align-items: center;
}

.avatar-container {
  display: flex;
  align-items: center;
  cursor: pointer;
  padding: 0 8px;
}

.user-avatar {
  width: 32px;
  height: 32px;
  border-radius: 50%;
  margin-right: 8px;
}

.user-name {
  margin-right: 4px;
  color: #606266;
}
</style>