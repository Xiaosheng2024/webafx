<!-- src/components/layout/Sidebar.vue -->
<template>
  <div class="sidebar-container">
    <el-menu
      :default-active="activeMenu"
      :collapse="isCollapse"
      background-color="#304156"
      text-color="#bfcbd9"
      active-text-color="#409EFF"
      :unique-opened="true"
      :collapse-transition="false"
      mode="vertical"
      router
    >
      <div class="logo-container">
        <h1 v-if="!isCollapse">CMS System</h1>
        <h1 v-else>CMS</h1>
      </div>
      
      <sidebar-item 
        v-for="route in routes" 
        :key="route.path" 
        :item="route" 
        :base-path="route.path" 
      />
    </el-menu>
  </div>
</template>

<script setup>
import { computed, ref } from 'vue';
import { useRoute } from 'vue-router';

// Import routes from router
import router from '@/router';

// Sub-component for menu items
const SidebarItem = defineComponent({
  name: 'SidebarItem',
  props: {
    item: {
      type: Object,
      required: true
    },
    basePath: {
      type: String,
      required: true
    }
  },
  setup(props) {
    const { item, basePath } = toRefs(props);
    
    const hasChildren = computed(() => {
      return item.value.children && item.value.children.length > 0;
    });
    
    const resolvePath = (routePath) => {
      if (/^(https?:|mailto:|tel:)/.test(routePath)) {
        return routePath;
      }
      return path.resolve(basePath.value, routePath);
    };
    
    return { hasChildren, resolvePath };
  },
  render() {
    if (this.hasChildren) {
      return (
        <el-sub-menu index={this.item.path}>
          {{
            title: () => (
              <>
                {this.item.meta && this.item.meta.icon && (
                  <el-icon><component is={this.item.meta.icon} /></el-icon>
                )}
                <span>{this.item.meta ? this.item.meta.title : 'Unknown'}</span>
              </>
            ),
            default: () => this.item.children.map(child => (
              <sidebar-item
                key={child.path}
                item={child}
                base-path={this.resolvePath(child.path)}
              />
            ))
          }}
        </el-sub-menu>
      );
    } else {
      return (
        <el-menu-item index={this.resolvePath(this.item.path)}>
          {this.item.meta && this.item.meta.icon && (
            <el-icon><component is={this.item.meta.icon} /></el-icon>
          )}
          <template #title>{this.item.meta ? this.item.meta.title : 'Unknown'}</template>
        </el-menu-item>
      );
    }
  }
});

// Component data and methods
const route = useRoute();
const isCollapse = ref(false);

const routes = computed(() => {
  const routeConfig = router.options.routes;
  // Filter out routes that should be displayed in sidebar
  return routeConfig.find(r => r.path === '/')?.children || [];
});

const activeMenu = computed(() => {
  const { meta, path } = route;
  // If set path in meta, use that as active menu
  if (meta.activeMenu) {
    return meta.activeMenu;
  }
  return path;
});

// Method to toggle sidebar collapse
const toggleSidebar = () => {
  isCollapse.value = !isCollapse.value;
};

// Expose to parent
defineExpose({
  toggleSidebar
});
</script>

<style scoped>
.sidebar-container {
  height: 100%;
  background-color: #304156;
  transition: width 0.28s;
  width: 210px;
  overflow: hidden;
}

.logo-container {
  height: 60px;
  line-height: 60px;
  text-align: center;
  color: #fff;
  background-color: #2b2f3a;
}

.logo-container h1 {
  font-size: 20px;
  margin: 0;
  font-weight: 600;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}

.el-menu {
  border: none;
  height: 100%;
  width: 100%;
}
</style>