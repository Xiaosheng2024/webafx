// src/router/index.js
import { createRouter, createWebHistory } from 'vue-router'
import Layout from '@/components/layout/Layout.vue'

// Public routes (no authentication required)
const publicRoutes = [
  {
    path: '/login',
    name: 'Login',
    component: () => import('@/views/Login.vue')
  },
  {
    path: '/404',
    name: 'NotFound',
    component: () => import('@/views/404.vue')
  }
]

// Protected routes (require authentication)
const protectedRoutes = [
  {
    path: '/',
    component: Layout,
    redirect: '/dashboard',
    children: [
      {
        path: 'dashboard',
        name: 'Dashboard',
        component: () => import('@/views/Dashboard.vue'),
        meta: { title: 'Dashboard', icon: 'dashboard' }
      },
      // Content Management
      {
        path: 'content',
        name: 'Content',
        redirect: '/content/article-list',
        meta: { title: 'Content Management', icon: 'document' },
        children: [
          {
            path: 'article-list',
            name: 'ArticleList',
            component: () => import('@/views/content/ArticleList.vue'),
            meta: { title: 'Article List' }
          },
          {
            path: 'article-edit',
            name: 'ArticleEdit',
            component: () => import('@/views/content/ArticleEdit.vue'),
            meta: { title: 'Article Editor' }
          },
          {
            path: 'category',
            name: 'CategoryManagement',
            component: () => import('@/views/content/CategoryManagement.vue'),
            meta: { title: 'Category Management' }
          }
        ]
      },
      // System Management
      {
        path: 'system',
        name: 'System',
        redirect: '/system/user',
        meta: { title: 'System Management', icon: 'setting' },
        children: [
          {
            path: 'user',
            name: 'UserManagement',
            component: () => import('@/views/system/UserManagement.vue'),
            meta: { title: 'User Management' }
          },
          {
            path: 'role',
            name: 'RoleManagement',
            component: () => import('@/views/system/RoleManagement.vue'),
            meta: { title: 'Role Management' }
          }
        ]
      },
      // Profile
      {
        path: 'profile',
        name: 'Profile',
        component: () => import('@/views/system/Profile.vue'),
        meta: { title: 'User Profile' }
      }
    ]
  }
]

const routes = [...publicRoutes, ...protectedRoutes, {
  path: '/:pathMatch(.*)*',
  redirect: '/404'
}]

const router = createRouter({
  history: createWebHistory(import.meta.env.BASE_URL),
  routes
})

// Navigation guard
router.beforeEach((to, from, next) => {
  // Get token from cookie
  const token = localStorage.getItem('token')
  
  // If route requires authentication and user is not logged in
  if (to.path !== '/login' && !token) {
    next('/login')
  } 
  // If user is already logged in and tries to access login page
  else if (to.path === '/login' && token) {
    next('/dashboard')
  } else {
    next()
  }
})

export default router