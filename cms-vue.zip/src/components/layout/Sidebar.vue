<!-- src/components/layout/Sidebar.vue -->
<template>
  <div class="sidebar">
    <div class="logo-container">
      <router-link to="/" class="logo-link">
        <h1 class="logo-title">CMS</h1>
      </router-link>
    </div>
    <el-scrollbar>
      <el-menu
        :default-active="activeMenu"
        background-color="#304156"
        text-color="#bfcbd9"
        active-text-color="#409EFF"
        :unique-opened="false"
        :collapse-transition="false"
        mode="vertical"
      >
        <template v-for="(route, index) in routes" :key="index">
          <!-- If the route has no children -->
          <el-menu-item v-if="!route.children || route.children.length === 0" :index="route.path">
            <router-link :to="route.path">
              <el-icon v-if="route.meta && route.meta.icon">
                <component :is="route.meta.icon"></component>
              </el-icon>
              <span>{{ route.meta?.title || 'Unnamed' }}</span>
            </router-link>
          </el-menu-item>

          <!-- If the route has only one child -->
          <el-menu-item 
            v-else-if="route.children.length === 1" 
            :index="route.path + '/' + route.children[0].path"
          >
            <router-link :to="`/${route.path}/${route.children[0].path}`">
              <el-icon v-if="route.meta && route.meta.icon">
                <component :is="route.meta.icon"></component>
              </el-icon>
              <span>{{ route.children[0].meta?.title || 'Unnamed' }}</span>
            </router-link>
          </el-menu-item>

          <!-- If the route has multiple children -->
          <el-sub-menu v-else :index="route.path">
            <template #title>
              <el-icon v-if="route.meta && route.meta.icon">
                <component :is="route.meta.icon"></component>
              </el-icon>
              <span>{{ route.meta?.title || 'Unnamed' }}</span>
            </template>
            <el-menu-item 
              v-for="child in route.children" 
              :key="child.path" 
              :index="route.path + '/' + child.path"
            >
              <router-link :to="`/${route.path}/${child.path}`">
                {{ child.meta?.title || 'Unnamed' }}
              </router-link>
            </el-menu-item>
          </el-sub-menu>
        </template>
      </el-menu>
    </el-scrollbar>
  </div>
</template>

<script setup>
import { ref, computed } from 'vue'
import { useRoute } from 'vue-router'
import { 
  Document, 
  Setting, 
  Location, 
  User, 
  Menu as IconMenu, 
  Histogram 
} from '@element-plus/icons-vue'

const route = useRoute()

// Compute active menu based on current route path
const activeMenu = computed(() => {
  const { path } = route
  return path
})

// Mock routes with meta data - these would normally come from your router configuration
const routes = ref([
  {
    path: 'dashboard',
    meta: { title: 'Dashboard', icon: 'Histogram' },
    children: []
  },
  {
    path: 'content',
    meta: { title: 'Content Management', icon: 'Document' },
    children: [
      { path: 'article-list', meta: { title: 'Article List' } },
      { path: 'article-edit', meta: { title: 'Article Editor' } },
      { path: 'category', meta: { title: 'Category Management' } }
    ]
  },
  {
    path: 'system',
    meta: { title: 'System Management', icon: 'Setting' },
    children: [
      { path: 'user', meta: { title: 'User Management' } },
      { path: 'role', meta: { title: 'Role Management' } }
    ]
  },
  {
    path: 'profile',
    meta: { title: 'User Profile', icon: 'User' },
    children: []
  }
])
</script>

<style scoped>
.sidebar {
  display: flex;
  flex-direction: column;
  height: 100%;
  background-color: #304156;
}

.logo-container {
  height: 50px;
  padding: 10px 0;
  text-align: center;
  background-color: #263445;
}

.logo-link {
  text-decoration: none;
}

.logo-title {
  color: #fff;
  font-size: 20px;
  margin: 0;
  line-height: 30px;
}

.el-menu {
  border-right: none;
}

.el-menu-item, .el-sub-menu {
  height: 50px;
  line-height: 50px;
}

.el-menu-item a {
  color: inherit;
  text-decoration: none;
  width: 100%;
  display: block;
}

.el-icon {
  margin-right: 10px;
  vertical-align: middle;
}
</style>