<!-- src/components/layout/Header.vue -->
<template>
  <div class="header">
    <div class="left-menu">
      <el-button plain type="primary" :icon="Fold" size="small" @click="toggleSidebar">
        Toggle Sidebar
      </el-button>
    </div>

    <div class="right-menu">
      <span class="right-menu-item">{{ currentTime }}</span>
      
      <el-dropdown class="avatar-container" trigger="click">
        <div class="avatar-wrapper">
          <el-avatar :size="32" :src="userAvatar">
            {{ userInfo.name ? userInfo.name.charAt(0).toUpperCase() : 'U' }}
          </el-avatar>
          <span class="username">{{ userInfo.name }}</span>
          <el-icon><CaretBottom /></el-icon>
        </div>
        <template #dropdown>
          <el-dropdown-menu>
            <el-dropdown-item @click="goToProfile">
              <el-icon><User /></el-icon>
              Profile
            </el-dropdown-item>
            <el-dropdown-item @click="goToDashboard">
              <el-icon><Histogram /></el-icon>
              Dashboard
            </el-dropdown-item>
            <el-dropdown-item divided @click="handleLogout">
              <el-icon><SwitchButton /></el-icon>
              Logout
            </el-dropdown-item>
          </el-dropdown-menu>
        </template>
      </el-dropdown>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted, onBeforeUnmount } from 'vue'
import { useRouter } from 'vue-router'
import { ElMessageBox } from 'element-plus'
import {
  Fold,
  CaretBottom,
  User,
  Histogram,
  SwitchButton
} from '@element-plus/icons-vue'

const router = useRouter()
const currentTime = ref(formatCurrentTime())
let clockInterval = null

// Mock user information - would normally come from your state management
const userInfo = ref({
  name: 'Admin User',
  avatar: ''
})

// Method to update time
function formatCurrentTime() {
  const now = new Date()
  return now.toLocaleString()
}

// Navigation methods
function goToProfile() {
  router.push('/profile')
}

function goToDashboard() {
  router.push('/dashboard')
}

// Logout handler
function handleLogout() {
  ElMessageBox.confirm(
    'Are you sure you want to logout?',
    'Logout',
    {
      confirmButtonText: 'Confirm',
      cancelButtonText: 'Cancel',
      type: 'warning',
    }
  ).then(() => {
    // In a real app, we would perform logout actions
    // Such as clearing tokens, calling a logout API etc.
    localStorage.removeItem('token')
    router.push('/login')
  }).catch(() => {
    // User canceled logout
  })
}

// Sidebar toggle - this would normally interact with a global state manager
function toggleSidebar() {
  // In a real app, this would toggle a sidebar state
  const appWrapper = document.querySelector('.app-wrapper')
  appWrapper.classList.toggle('sidebar-collapsed')
}

// Avatar fallback
const userAvatar = ref(userInfo.value.avatar || '')

// Setup clock
onMounted(() => {
  clockInterval = setInterval(() => {
    currentTime.value = formatCurrentTime()
  }, 1000)
})

onBeforeUnmount(() => {
  if (clockInterval) {
    clearInterval(clockInterval)
  }
})
</script>

<style scoped>
.header {
  background-color: #fff;
  box-shadow: 0 1px 4px rgba(0, 21, 41, 0.08);
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 0 20px;
  height: 50px;
  position: relative;
}

.left-menu {
  display: flex;
  align-items: center;
}

.right-menu {
  display: flex;
  align-items: center;
}

.right-menu-item {
  margin-right: 15px;
  color: #606266;
}

.avatar-container {
  cursor: pointer;
  margin-left: 10px;
}

.avatar-wrapper {
  display: flex;
  align-items: center;
  color: #606266;
}

.username {
  margin: 0 5px;
  max-width: 100px;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
</style>