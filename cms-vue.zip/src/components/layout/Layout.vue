<!-- src/components/layout/Layout.vue -->
<template>
  <div class="app-wrapper">
    <Sidebar class="sidebar-container" />
    <div class="main-container">
      <Header />
      <div class="app-main">
        <router-view />
      </div>
    </div>
  </div>
</template>

<script setup>
import Sidebar from './Sidebar.vue'
import Header from './Header.vue'
</script>

<style scoped>
.app-wrapper {
  position: relative;
  height: 100%;
  width: 100%;
  display: flex;
}

.sidebar-container {
  width: 210px;
  height: 100%;
  position: fixed;
  left: 0;
  top: 0;
  bottom: 0;
  overflow-y: auto;
  overflow-x: hidden;
  background-color: #304156;
  transition: width 0.28s;
  z-index: 1001;
}

.main-container {
  min-height: 100%;
  transition: margin-left 0.28s;
  margin-left: 210px;
  position: relative;
  width: calc(100% - 210px);
  display: flex;
  flex-direction: column;
}

.app-main {
  padding: 20px;
  flex: 1;
  overflow-y: auto;
  background-color: #f0f2f5;
  position: relative;
}
</style>