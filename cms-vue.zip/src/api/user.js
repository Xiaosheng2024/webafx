// src/api/user.js
import request from '@/utils/request'

/**
 * User login
 * @param {Object} data - Login credentials
 * @returns {Promise}
 */
export function login(data) {
  return request({
    url: '/auth/login',
    method: 'post',
    data
  })
}

/**
 * User logout
 * @returns {Promise}
 */
export function logout() {
  return request({
    url: '/auth/logout',
    method: 'post'
  })
}

/**
 * Get user profile
 * @returns {Promise}
 */
export function getUserProfile() {
  return request({
    url: '/user/profile',
    method: 'get'
  })
}

/**
 * Update user profile
 * @param {Object} data - Profile data
 * @returns {Promise}
 */
export function updateProfile(data) {
  return request({
    url: '/user/profile',
    method: 'put',
    data
  })
}

/**
 * Change password
 * @param {Object} data - Password data
 * @returns {Promise}
 */
export function changePassword(data) {
  return request({
    url: '/user/changePassword',
    method: 'post',
    data
  })
}

/**
 * Upload avatar
 * @param {FormData} data - Form data containing avatar
 * @returns {Promise}
 */
export function uploadAvatar(data) {
  return request({
    url: '/user/avatar',
    method: 'post',
    data,
    headers: {
      'Content-Type': 'multipart/form-data'
    }
  })
}

/**
 * Get users list
 * @param {Object} params - Query parameters
 * @returns {Promise}
 */
export function getUsers(params) {
  return request({
    url: '/system/users',
    method: 'get',
    params
  })
}

/**
 * Get user by ID
 * @param {number} id - User ID
 * @returns {Promise}
 */
export function getUserById(id) {
  return request({
    url: `/system/users/${id}`,
    method: 'get'
  })
}

/**
 * Create user
 * @param {Object} data - User data
 * @returns {Promise}
 */
export function createUser(data) {
  return request({
    url: '/system/users',
    method: 'post',
    data
  })
}

/**
 * Update user
 * @param {number} id - User ID
 * @param {Object} data - User data
 * @returns {Promise}
 */
export function updateUser(id, data) {
  return request({
    url: `/system/users/${id}`,
    method: 'put',
    data
  })
}

/**
 * Delete user
 * @param {number} id - User ID
 * @returns {Promise}
 */
export function deleteUser(id) {
  return request({
    url: `/system/users/${id}`,
    method: 'delete'
  })
}

/**
 * Reset user password
 * @param {number} id - User ID
 * @returns {Promise}
 */
export function resetPassword(id) {
  return request({
    url: `/system/users/${id}/resetPassword`,
    method: 'post'
  })
}

/**
 * Update user status
 * @param {number} id - User ID
 * @param {number} status - Status (0: disabled, 1: enabled)
 * @returns {Promise}
 */
export function updateUserStatus(id, status) {
  return request({
    url: `/system/users/${id}/status`,
    method: 'put',
    data: { status }
  })
}