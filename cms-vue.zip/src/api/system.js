// src/api/system.js
import request from '@/utils/request'

// Roles

/**
 * Get roles list
 * @param {Object} params - Query parameters
 * @returns {Promise}
 */
export function getRoles(params) {
  return request({
    url: '/system/roles',
    method: 'get',
    params
  })
}

/**
 * Get role details by ID
 * @param {number} id - Role ID
 * @returns {Promise}
 */
export function getRoleById(id) {
  return request({
    url: `/system/roles/${id}`,
    method: 'get'
  })
}

/**
 * Create new role
 * @param {Object} data - Role data
 * @returns {Promise}
 */
export function createRole(data) {
  return request({
    url: '/system/roles',
    method: 'post',
    data
  })
}

/**
 * Update role
 * @param {number} id - Role ID
 * @param {Object} data - Role data
 * @returns {Promise}
 */
export function updateRole(id, data) {
  return request({
    url: `/system/roles/${id}`,
    method: 'put',
    data
  })
}

/**
 * Delete role
 * @param {number} id - Role ID
 * @returns {Promise}
 */
export function deleteRole(id) {
  return request({
    url: `/system/roles/${id}`,
    method: 'delete'
  })
}

// Permissions

/**
 * Get all permissions
 * @returns {Promise}
 */
export function getAllPermissions() {
  return request({
    url: '/system/permissions',
    method: 'get'
  })
}

/**
 * Get role permissions
 * @param {number} roleId - Role ID
 * @returns {Promise}
 */
export function getRolePermissions(roleId) {
  return request({
    url: `/system/roles/${roleId}/permissions`,
    method: 'get'
  })
}

/**
 * Update role permissions
 * @param {number} roleId - Role ID
 * @param {Array} permissionIds - Permission IDs
 * @returns {Promise}
 */
export function updateRolePermissions(roleId, permissionIds) {
  return request({
    url: `/system/roles/${roleId}/permissions`,
    method: 'put',
    data: { permissionIds }
  })
}

// Menu

/**
 * Get menu tree
 * @returns {Promise}
 */
export function getMenuTree() {
  return request({
    url: '/system/menus',
    method: 'get'
  })
}

// System Settings

/**
 * Get system settings
 * @returns {Promise}
 */
export function getSystemSettings() {
  return request({
    url: '/system/settings',
    method: 'get'
  })
}

/**
 * Update system settings
 * @param {Object} data - Settings data
 * @returns {Promise}
 */
export function updateSystemSettings(data) {
  return request({
    url: '/system/settings',
    method: 'put',
    data
  })
}

/**
 * Get system logs
 * @param {Object} params - Query parameters
 * @returns {Promise}
 */
export function getSystemLogs(params) {
  return request({
    url: '/system/logs',
    method: 'get',
    params
  })
}

/**
 * Clear system logs
 * @returns {Promise}
 */
export function clearSystemLogs() {
  return request({
    url: '/system/logs',
    method: 'delete'
  })
}