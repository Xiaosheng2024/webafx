// src/api/content.js
import request from '@/utils/request'

/**
 * Get dashboard statistics
 * @returns {Promise}
 */
export function getDashboardStats() {
  return request({
    url: '/content/dashboard/stats',
    method: 'get'
  })
}

/**
 * Get recent articles
 * @param {number} limit - Number of articles to fetch
 * @returns {Promise}
 */
export function getRecentArticles(limit = 5) {
  return request({
    url: '/content/articles/recent',
    method: 'get',
    params: { limit }
  })
}

/**
 * Get articles with pagination and filters
 * @param {Object} params - Query parameters
 * @returns {Promise}
 */
export function getArticles(params) {
  return request({
    url: '/content/articles',
    method: 'get',
    params
  })
}

/**
 * Get article by ID
 * @param {number} id - Article ID
 * @returns {Promise}
 */
export function getArticleById(id) {
  return request({
    url: `/content/articles/${id}`,
    method: 'get'
  })
}

/**
 * Create new article
 * @param {Object} data - Article data
 * @returns {Promise}
 */
export function createArticle(data) {
  return request({
    url: '/content/articles',
    method: 'post',
    data
  })
}

/**
 * Update article
 * @param {number} id - Article ID
 * @param {Object} data - Article data
 * @returns {Promise}
 */
export function updateArticle(id, data) {
  return request({
    url: `/content/articles/${id}`,
    method: 'put',
    data
  })
}

/**
 * Delete article
 * @param {number} id - Article ID
 * @returns {Promise}
 */
export function deleteArticle(id) {
  return request({
    url: `/content/articles/${id}`,
    method: 'delete'
  })
}

/**
 * Update article status
 * @param {number} id - Article ID
 * @param {string} status - Article status (draft, published, archived)
 * @returns {Promise}
 */
export function updateArticleStatus(id, status) {
  return request({
    url: `/content/articles/${id}/status`,
    method: 'put',
    data: { status }
  })
}

/**
 * Upload article featured image
 * @param {FormData} data - Form data containing image file
 * @returns {Promise}
 */
export function uploadArticleImage(data) {
  return request({
    url: '/content/articles/image',
    method: 'post',
    data,
    headers: {
      'Content-Type': 'multipart/form-data'
    }
  })
}

/**
 * Get categories
 * @returns {Promise}
 */
export function getCategories() {
  return request({
    url: '/content/categories',
    method: 'get'
  })
}

/**
 * Get category by ID
 * @param {number} id - Category ID
 * @returns {Promise}
 */
export function getCategoryById(id) {
  return request({
    url: `/content/categories/${id}`,
    method: 'get'
  })
}

/**
 * Create new category
 * @param {Object} data - Category data
 * @returns {Promise}
 */
export function createCategory(data) {
  return request({
    url: '/content/categories',
    method: 'post',
    data
  })
}

/**
 * Update category
 * @param {number} id - Category ID
 * @param {Object} data - Category data
 * @returns {Promise}
 */
export function updateCategory(id, data) {
  return request({
    url: `/content/categories/${id}`,
    method: 'put',
    data
  })
}

/**
 * Delete category
 * @param {number} id - Category ID
 * @returns {Promise}
 */
export function deleteCategory(id) {
  return request({
    url: `/content/categories/${id}`,
    method: 'delete'
  })
}