<!-- src/App.vue -->
<template>
  <el-config-provider :locale="locale">
    <router-view />
  </el-config-provider>
</template>

<script setup>
import { ElConfigProvider } from 'element-plus'
import enUS from 'element-plus/lib/locale/lang/en'
import 'element-plus/dist/index.css'
import NProgress from 'nprogress'
import 'nprogress/nprogress.css'
import { useRouter } from 'vue-router'
import { onMounted } from 'vue'

const locale = enUS
const router = useRouter()

// Configure NProgress
NProgress.configure({ 
  showSpinner: false,
  easing: 'ease',
  speed: 500
})

// Setup router hooks for progress bar
onMounted(() => {
  router.beforeEach((to, from, next) => {
    if (to.path !== from.path) {
      NProgress.start()
    }
    next()
  })

  router.afterEach(() => {
    NProgress.done()
  })
})
</script>

<style>
* {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
}

html, body {
  font-family: 'Helvetica Neue', Helvetica, 'PingFang SC', 'Hiragino Sans GB',
    'Microsoft YaHei', '微软雅黑', Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  height: 100%;
  width: 100%;
  overflow: hidden;
}

#app {
  height: 100%;
  width: 100%;
}

/* NProgress styles */
#nprogress .bar {
  background: #409EFF !important;
  height: 3px;
}

/* Global Element Plus overrides */
.el-table th.el-table__cell {
  background-color: #f5f7fa;
}

.el-pagination {
  justify-content: center;
  margin-top: 20px;
}

.el-card {
  margin-bottom: 20px;
}

/* Layout styles */
.page-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 20px;
}

.page-header h2 {
  font-size: 20px;
  font-weight: 600;
  color: #303133;
  margin: 0;
}
</style>