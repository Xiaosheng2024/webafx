<!-- src/views/404.vue -->
<template>
  <div class="error-container">
    <div class="error-content">
      <div class="error-image">
        <el-icon :size="100" class="error-icon"><Warning /></el-icon>
      </div>
      <h1 class="error-title">404</h1>
      <h2 class="error-subtitle">Page Not Found</h2>
      <p class="error-description">
        Sorry, the page you are looking for does not exist or has been moved.
      </p>
      <el-button type="primary" @click="goHome">Back to Home</el-button>
    </div>
  </div>
</template>

<script setup>
import { useRouter } from 'vue-router';
import { Warning } from '@element-plus/icons-vue';

const router = useRouter();

const goHome = () => {
  router.push('/');
};
</script>

<style scoped>
.error-container {
  height: 100vh;
  width: 100%;
  display: flex;
  justify-content: center;
  align-items: center;
  background-color: #f0f2f5;
}

.error-content {
  text-align: center;
  padding: 40px;
  max-width: 500px;
}

.error-image {
  margin-bottom: 24px;
  width: 200px;
  height: 200px;
  margin: 0 auto;
}

.error-title {
  font-size: 72px;
  color: #303133;
  margin: 0 0 10px;
  font-weight: 600;
}

.error-subtitle {
  font-size: 24px;
  color: #606266;
  margin: 0 0 15px;
  font-weight: 500;
}

.error-description {
  font-size: 16px;
  color: #909399;
  margin-bottom: 24px;
}
</style>