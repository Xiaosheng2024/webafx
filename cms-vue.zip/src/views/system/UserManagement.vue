<!-- src/views/system/UserManagement.vue -->
<template>
  <div class="user-management-container">
    <div class="page-header">
      <h2>User Management</h2>
      <el-button type="primary" @click="showAddUserDialog">
        <el-icon><Plus /></el-icon>
        New User
      </el-button>
    </div>

    <!-- Search Form -->
    <el-card class="search-card">
      <el-form :model="searchForm" ref="searchFormRef" label-width="100px" class="search-form" @submit.prevent>
        <el-row :gutter="20">
          <el-col :xs="24" :sm="8" :md="6">
            <el-form-item label="Username:">
              <el-input v-model="searchForm.username" placeholder="Search by username" clearable />
            </el-form-item>
          </el-col>
          <el-col :xs="24" :sm="8" :md="6">
            <el-form-item label="Name:">
              <el-input v-model="searchForm.name" placeholder="Search by name" clearable />
            </el-form-item>
          </el-col>
          <el-col :xs="24" :sm="8" :md="6">
            <el-form-item label="Role:">
              <el-select v-model="searchForm.roleId" placeholder="Select role" clearable>
                <el-option v-for="role in roles" :key="role.id" :label="role.name" :value="role.id" />
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :xs="24" :sm="8" :md="6">
            <el-form-item label="Status:">
              <el-select v-model="searchForm.status" placeholder="Select status" clearable>
                <el-option label="Active" :value="1" />
                <el-option label="Disabled" :value="0" />
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :xs="24" class="form-buttons">
            <el-button type="primary" @click="handleSearch">Search</el-button>
            <el-button @click="resetSearch">Reset</el-button>
          </el-col>
        </el-row>
      </el-form>
    </el-card>

    <!-- User Table -->
    <el-card class="table-card">
      <el-table 
        :data="tableData" 
        v-loading="loading"
        style="width: 100%"
      >
        <el-table-column type="index" width="50" />
        <el-table-column prop="username" label="Username" min-width="120" />
        <el-table-column prop="name" label="Name" min-width="120" />
        <el-table-column prop="email" label="Email" min-width="180" show-overflow-tooltip />
        <el-table-column prop="roleName" label="Role" width="120" />
        <el-table-column prop="createTime" label="Create Time" width="170" sortable />
        <el-table-column prop="lastLoginTime" label="Last Login" width="170" sortable />
        <el-table-column prop="status" label="Status" width="100">
          <template #default="scope">
            <el-tag :type="scope.row.status === 1 ? 'success' : 'danger'">
              {{ scope.row.status === 1 ? 'Active' : 'Disabled' }}
            </el-tag>
          </template>
        </el-table-column>
        <el-table-column fixed="right" label="Operations" width="250">
          <template #default="scope">
            <el-button type="primary" size="small" link @click="handleEdit(scope.row)">Edit</el-button>
            <el-button 
              type="success" 
              size="small" 
              link 
              v-if="scope.row.status === 0"
              @click="handleStatusChange(scope.row, 1)"
            >
              Enable
            </el-button>
            <el-button 
              type="warning" 
              size="small" 
              link 
              v-if="scope.row.status === 1"
              @click="handleStatusChange(scope.row, 0)"
            >
              Disable
            </el-button>
            <el-button type="danger" size="small" link @click="handleDelete(scope.row)">
              Delete
            </el-button>
            <el-button type="info" size="small" link @click="handleResetPassword(scope.row)">
              Reset Password
            </el-button>
          </template>
        </el-table-column>
      </el-table>

      <!-- Pagination -->
      <el-pagination
        class="cms-pagination"
        :current-page="pagination.current"
        :page-size="pagination.pageSize"
        :total="pagination.total"
        :page-sizes="[10, 20, 50, 100]"
        layout="total, sizes, prev, pager, next, jumper"
        @size-change="handleSizeChange"
        @current-change="handleCurrentChange"
      />
    </el-card>

    <!-- User Dialog -->
    <el-dialog 
      v-model="dialogVisible" 
      :title="dialogType === 'add' ? 'Add User' : 'Edit User'"
      width="500px"
    >
      <el-form 
        ref="userFormRef"
        :model="userForm" 
        :rules="formRules"
        label-width="100px"
      >
        <el-form-item label="Username" prop="username" v-if="dialogType === 'add'">
          <el-input v-model="userForm.username" placeholder="Enter username" />
        </el-form-item>

        <el-form-item label="Name" prop="name">
          <el-input v-model="userForm.name" placeholder="Enter name" />
        </el-form-item>

        <el-form-item label="Email" prop="email">
          <el-input v-model="userForm.email" placeholder="Enter email" />
        </el-form-item>

        <el-form-item label="Phone" prop="phone">
          <el-input v-model="userForm.phone" placeholder="Enter phone number" />
        </el-form-item>

        <el-form-item label="Password" prop="password" v-if="dialogType === 'add'">
          <el-input v-model="userForm.password" placeholder="Enter password" type="password" show-password />
        </el-form-item>

        <el-form-item label="Role" prop="roleId">
          <el-select v-model="userForm.roleId" placeholder="Select role" style="width: 100%">
            <el-option v-for="role in roles" :key="role.id" :label="role.name" :value="role.id" />
          </el-select>
        </el-form-item>

        <el-form-item label="Status">
          <el-switch v-model="userForm.status" :active-value="1" :inactive-value="0" />
        </el-form-item>
      </el-form>
      <template #footer>
        <div class="dialog-footer">
          <el-button @click="dialogVisible = false">Cancel</el-button>
          <el-button type="primary" @click="submitUserForm" :loading="submitLoading">
            Confirm
          </el-button>
        </div>
      </template>
    </el-dialog>
  </div>
</template>

<script setup>
import { ref, reactive, onMounted } from 'vue'
import { ElMessage, ElMessageBox } from 'element-plus'
import { Plus } from '@element-plus/icons-vue'
import { getUsers, createUser, updateUser, deleteUser, resetPassword, updateUserStatus } from '@/api/user'
import { getRoles } from '@/api/system'

const loading = ref(false)
const submitLoading = ref(false)
const dialogVisible = ref(false)
const dialogType = ref('add') // 'add' or 'edit'
const userFormRef = ref(null)
const searchFormRef = ref(null)
const tableData = ref([])
const roles = ref([])

// Search form
const searchForm = reactive({
  username: '',
  name: '',
  roleId: '',
  status: ''
})

// Pagination
const pagination = reactive({
  current: 1,
  pageSize: 10,
  total: 0
})

// User form
const userForm = reactive({
  id: null,
  username: '',
  name: '',
  email: '',
  phone: '',
  password: '',
  roleId: '',
  status: 1
})

// Form validation rules
const formRules = {
  username: [
    { required: true, message: 'Please enter username', trigger: 'blur' },
    { min: 4, max: 20, message: 'Length should be 4 to 20 characters', trigger: 'blur' }
  ],
  name: [
    { required: true, message: 'Please enter name', trigger: 'blur' }
  ],
  email: [
    { required: true, message: 'Please enter email', trigger: 'blur' },
    { type: 'email', message: 'Please enter valid email address', trigger: 'blur' }
  ],
  password: [
    { required: true, message: 'Please enter password', trigger: 'blur' },
    { min: 6, message: 'Password must be at least 6 characters', trigger: 'blur' }
  ],
  roleId: [
    { required: true, message: 'Please select a role', trigger: 'change' }
  ]
}

// Handle search
const handleSearch = () => {
  pagination.current = 1
  fetchUsers()
}

// Reset search form
const resetSearch = () => {
  searchFormRef.value?.resetFields()
  pagination.current = 1
  fetchUsers()
}

// Fetch users from API
const fetchUsers = async () => {
  loading.value = true
  try {
    // In a real app, we would call the API
    // const response = await getUsers({
    //   page: pagination.current,
    //   pageSize: pagination.pageSize,
    //   ...searchForm
    // })
    
    // For now, use mock data
    setTimeout(() => {
      // Mock user data
      tableData.value = [
        {
          id: 1,
          username: 'admin',
          name: 'Admin User',
          email: 'admin@example.com',
          phone: '1234567890',
          roleId: 1,
          roleName: 'Administrator',
          status: 1,
          createTime: '2023-11-01 10:00',
          lastLoginTime: '2023-11-24 08:30'
        },
        {
          id: 2,
          username: 'editor',
          name: 'Content Editor',
          email: 'editor@example.com',
          phone: '1234567891',
          roleId: 2,
          roleName: 'Editor',
          status: 1,
          createTime: '2023-11-02 11:00',
          lastLoginTime: '2023-11-23 14:45'
        },
        {
          id: 3,
          username: 'user',
          name: 'Regular User',
          email: 'user@example.com',
          phone: '1234567892',
          roleId: 3,
          roleName: 'User',
          status: 1,
          createTime: '2023-11-03 09:30',
          lastLoginTime: '2023-11-22 16:20'
        },
        {
          id: 4,
          username: 'guest',
          name: 'Guest User',
          email: 'guest@example.com',
          phone: '1234567893',
          roleId: 4,
          roleName: 'Guest',
          status: 0,
          createTime: '2023-11-04 14:15',
          lastLoginTime: '2023-11-10 11:10'
        }
      ]
      
      // Set pagination total
      pagination.total = 4
      
      loading.value = false
    }, 800)
  } catch (error) {
    console.error('Error loading users:', error)
    ElMessage({ message: 'Failed to load users', type: 'error' })
    loading.value = false
  }
}

// Fetch roles for dropdown
const fetchRoles = async () => {
  try {
    // In a real app, we would call the API
    // const response = await getRoles()
    
    // For now, use mock data
    roles.value = [
      { id: 1, name: 'Administrator' },
      { id: 2, name: 'Editor' },
      { id: 3, name: 'User' },
      { id: 4, name: 'Guest' }
    ]
  } catch (error) {
    console.error('Error loading roles:', error)
    ElMessage({ message: 'Failed to load roles', type: 'error' })
  }
}

// Handle pagination size change
const handleSizeChange = (size) => {
  pagination.pageSize = size
  fetchUsers()
}

// Handle pagination current page change
const handleCurrentChange = (current) => {
  pagination.current = current
  fetchUsers()
}

// Show add user dialog
const showAddUserDialog = () => {
  resetUserForm()
  dialogType.value = 'add'
  dialogVisible.value = true
}

// Show edit user dialog
const handleEdit = (row) => {
  resetUserForm()
  dialogType.value = 'edit'
  
  // Populate form with user data
  Object.assign(userForm, {
    id: row.id,
    name: row.name,
    email: row.email,
    phone: row.phone,
    roleId: row.roleId,
    status: row.status
  })
  
  dialogVisible.value = true
}

// Reset user form
const resetUserForm = () => {
  Object.assign(userForm, {
    id: null,
    username: '',
    name: '',
    email: '',
    phone: '',
    password: '',
    roleId: '',
    status: 1
  })
  
  // Reset form validation
  if (userFormRef.value) {
    userFormRef.value.resetFields()
  }
}

// Handle user deletion
const handleDelete = (row) => {
  ElMessageBox.confirm(
    `Are you sure you want to delete the user "${row.username}"?`,
    'Delete User',
    {
      confirmButtonText: 'Delete',
      cancelButtonText: 'Cancel',
      type: 'warning'
    }
  ).then(async () => {
    try {
      // In a real app, we would call the API
      // await deleteUser(row.id)
      
      // For now, remove from local data
      tableData.value = tableData.value.filter(user => user.id !== row.id)
      pagination.total--
      
      ElMessage({ message: 'User deleted successfully', type: 'success' })
    } catch (error) {
      console.error('Error deleting user:', error)
      ElMessage({ message: 'Failed to delete user', type: 'error' })
    }
  }).catch(() => {
    // User cancelled
  })
}

// Handle status change
const handleStatusChange = (row, status) => {
  const statusText = status === 1 ? 'enable' : 'disable'
  ElMessageBox.confirm(
    `Are you sure you want to ${statusText} the user "${row.username}"?`,
    `${status === 1 ? 'Enable' : 'Disable'} User`,
    {
      confirmButtonText: 'Confirm',
      cancelButtonText: 'Cancel',
      type: 'warning'
    }
  ).then(async () => {
    try {
      // In a real app, we would call the API
      // await updateUserStatus(row.id, status)
      
      // For now, update local data
      const index = tableData.value.findIndex(user => user.id === row.id)
      tableData.value[index].status = status
      
      ElMessage({ 
        message: `User ${statusText}d successfully`, 
        type: 'success' 
      })
    } catch (error) {
      console.error(`Error ${statusText}ing user:`, error)
      ElMessage({ message: `Failed to ${statusText} user`, type: 'error' })
    }
  }).catch(() => {
    // User cancelled
  })
}

// Handle password reset
const handleResetPassword = (row) => {
  ElMessageBox.confirm(
    `Are you sure you want to reset the password for "${row.username}"?`,
    'Reset Password',
    {
      confirmButtonText: 'Reset',
      cancelButtonText: 'Cancel',
      type: 'warning'
    }
  ).then(async () => {
    try {
      // In a real app, we would call the API
      // await resetPassword(row.id)
      
      ElMessage({ 
        message: 'Password has been reset successfully. The new password has been sent to the user\'s email.', 
        type: 'success' 
      })
    } catch (error) {
      console.error('Error resetting password:', error)
      ElMessage({ message: 'Failed to reset password', type: 'error' })
    }
  }).catch(() => {
    // User cancelled
  })
}

// Submit user form
const submitUserForm = () => {
  userFormRef.value.validate(async (valid) => {
    if (valid) {
      submitLoading.value = true
      try {
        if (dialogType.value === 'add') {
          // In a real app, we would call the API
          // await createUser(userForm)
          
          // For now, add to local data
          const newUser = {
            ...userForm,
            id: tableData.value.length + 1,
            roleName: roles.value.find(role => role.id === userForm.roleId)?.name || '',
            createTime: new Date().toISOString().replace('T', ' ').substring(0, 16),
            lastLoginTime: '-'
          }
          
          tableData.value.push(newUser)
          pagination.total++
          
          ElMessage({ message: 'User created successfully', type: 'success' })
        } else {
          // In a real app, we would call the API
          // await updateUser(userForm.id, userForm)
          
          // For now, update local data
          const index = tableData.value.findIndex(user => user.id === userForm.id)
          const roleName = roles.value.find(role => role.id === userForm.roleId)?.name || ''
          
          tableData.value[index] = {
            ...tableData.value[index],
            ...userForm,
            roleName
          }
          
          ElMessage({ message: 'User updated successfully', type: 'success' })
        }
        
        dialogVisible.value = false
      } catch (error) {
        console.error('Error saving user:', error)
        ElMessage({ message: 'Failed to save user', type: 'error' })
      } finally {
        submitLoading.value = false
      }
    }
  })
}

// Load users and roles on component mount
onMounted(() => {
  fetchRoles()
  fetchUsers()
})
</script>

<style scoped>
.user-management-container {
  padding: 20px;
}

.page-header {
  display: flex;
  justify-content: space-between;
  margin-bottom: 20px;
  align-items: center;
}

.search-card,
.table-card {
  margin-bottom: 20px;
}

.form-buttons {
  display: flex;
  justify-content: center;
  margin-top: 10px;
}

.cms-pagination {
  margin-top: 20px;
  display: flex;
  justify-content: center;
}

.dialog-footer {
  display: flex;
  justify-content: flex-end;
}
</style>