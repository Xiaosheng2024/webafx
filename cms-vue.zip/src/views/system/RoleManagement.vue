<!-- src/views/system/RoleManagement.vue -->
<template>
  <div class="role-management-container">
    <div class="page-header">
      <h2>Role Management</h2>
      <el-button type="primary" @click="showAddRoleDialog">
        <el-icon><Plus /></el-icon>
        New Role
      </el-button>
    </div>

    <!-- Role Table -->
    <el-card class="role-table-card">
      <el-table 
        :data="tableData" 
        v-loading="loading"
        style="width: 100%"
      >
        <el-table-column type="index" width="50" />
        <el-table-column prop="name" label="Role Name" min-width="150" />
        <el-table-column prop="code" label="Role Code" width="150" />
        <el-table-column prop="description" label="Description" min-width="200" show-overflow-tooltip />
        <el-table-column prop="userCount" label="Users" width="100" />
        <el-table-column prop="createTime" label="Create Time" width="170" sortable />
        <el-table-column prop="status" label="Status" width="100">
          <template #default="scope">
            <el-tag :type="scope.row.status ? 'success' : 'danger'">
              {{ scope.row.status ? 'Active' : 'Inactive' }}
            </el-tag>
          </template>
        </el-table-column>
        <el-table-column fixed="right" label="Operations" width="250">
          <template #default="scope">
            <el-button type="primary" size="small" link @click="handleEdit(scope.row)">Edit</el-button>
            <el-button 
              type="primary" 
              size="small" 
              link 
              @click="handlePermission(scope.row)"
            >
              Permissions
            </el-button>
            <el-button 
              type="success" 
              size="small" 
              link 
              v-if="!scope.row.status"
              @click="handleStatusChange(scope.row, true)"
            >
              Enable
            </el-button>
            <el-button 
              type="warning" 
              size="small" 
              link 
              v-if="scope.row.status"
              @click="handleStatusChange(scope.row, false)"
            >
              Disable
            </el-button>
            <el-button 
              type="danger" 
              size="small" 
              link 
              @click="handleDelete(scope.row)"
              :disabled="scope.row.isSystemRole"
            >
              Delete
            </el-button>
          </template>
        </el-table-column>
      </el-table>
    </el-card>

    <!-- Role Dialog -->
    <el-dialog 
      v-model="dialogVisible" 
      :title="dialogType === 'add' ? 'Add Role' : 'Edit Role'"
      width="500px"
    >
      <el-form 
        ref="roleFormRef"
        :model="roleForm" 
        :rules="formRules"
        label-width="100px"
      >
        <el-form-item label="Role Name" prop="name">
          <el-input v-model="roleForm.name" placeholder="Enter role name" />
        </el-form-item>

        <el-form-item label="Role Code" prop="code" v-if="dialogType === 'add' || !roleForm.isSystemRole">
          <el-input v-model="roleForm.code" placeholder="Enter role code" :disabled="roleForm.isSystemRole" />
        </el-form-item>

        <el-form-item label="Description" prop="description">
          <el-input 
            v-model="roleForm.description" 
            type="textarea" 
            rows="3" 
            placeholder="Enter role description" 
          />
        </el-form-item>

        <el-form-item label="Status" v-if="!roleForm.isSystemRole">
          <el-switch v-model="roleForm.status" />
        </el-form-item>
      </el-form>
      <template #footer>
        <div class="dialog-footer">
          <el-button @click="dialogVisible = false">Cancel</el-button>
          <el-button type="primary" @click="submitRoleForm" :loading="submitLoading">
            Confirm
          </el-button>
        </div>
      </template>
    </el-dialog>

    <!-- Permission Dialog -->
    <el-dialog 
      v-model="permDialogVisible" 
      title="Assign Permissions"
      width="600px"
    >
      <div v-if="permDialogVisible" class="permission-container">
        <el-tree
          ref="permissionTreeRef"
          :data="permissionTree"
          show-checkbox
          node-key="id"
          :props="{ label: 'name', children: 'children' }"
          :default-checked-keys="selectedPermissions"
          :check-strictly="false"
        />
      </div>
      <template #footer>
        <div class="dialog-footer">
          <el-button @click="permDialogVisible = false">Cancel</el-button>
          <el-button type="primary" @click="savePermissions" :loading="permSubmitLoading">
            Save
          </el-button>
        </div>
      </template>
    </el-dialog>
  </div>
</template>

<script setup>
import { ref, reactive, onMounted } from 'vue'
import { ElMessage, ElMessageBox } from 'element-plus'
import { Plus } from '@element-plus/icons-vue'
import { getRoles, createRole, updateRole, deleteRole, getRolePermissions, updateRolePermissions, getAllPermissions } from '@/api/system'

const loading = ref(false)
const submitLoading = ref(false)
const permSubmitLoading = ref(false)
const dialogVisible = ref(false)
const permDialogVisible = ref(false)
const dialogType = ref('add') // 'add' or 'edit'
const roleFormRef = ref(null)
const permissionTreeRef = ref(null)
const tableData = ref([])
const currentRoleId = ref(null)
const selectedPermissions = ref([])

// Permission tree data
const permissionTree = ref([])

// Role form
const roleForm = reactive({
  id: null,
  name: '',
  code: '',
  description: '',
  status: true,
  isSystemRole: false
})

// Form validation rules
const formRules = {
  name: [
    { required: true, message: 'Please enter role name', trigger: 'blur' },
    { min: 2, max: 50, message: 'Length should be 2 to 50 characters', trigger: 'blur' }
  ],
  code: [
    { required: true, message: 'Please enter role code', trigger: 'blur' },
    { pattern: /^[A-Z_]+$/, message: 'Code can only include uppercase letters and underscores', trigger: 'blur' }
  ],
  description: [
    { max: 200, message: 'Description cannot exceed 200 characters', trigger: 'blur' }
  ]
}

// Fetch roles from API
const fetchRoles = async () => {
  loading.value = true
  try {
    // In a real app, we would call the API
    // const response = await getRoles()
    
    // For now, use mock data
    setTimeout(() => {
      tableData.value = [
        {
          id: 1,
          name: 'Administrator',
          code: 'ADMIN',
          description: 'System administrator with full access to all features',
          userCount: 2,
          createTime: '2023-11-01 10:00',
          status: true,
          isSystemRole: true
        },
        {
          id: 2,
          name: 'Editor',
          code: 'EDITOR',
          description: 'Content editor with access to manage articles and categories',
          userCount: 5,
          createTime: '2023-11-01 10:05',
          status: true,
          isSystemRole: true
        },
        {
          id: 3,
          name: 'User',
          code: 'USER',
          description: 'Regular user with limited access',
          userCount: 10,
          createTime: '2023-11-01 10:10',
          status: true,
          isSystemRole: true
        },
        {
          id: 4,
          name: 'Guest',
          code: 'GUEST',
          description: 'Guest user with read-only access',
          userCount: 3,
          createTime: '2023-11-01 10:15',
          status: false,
          isSystemRole: true
        },
        {
          id: 5,
          name: 'Content Manager',
          code: 'CONTENT_MANAGER',
          description: 'Manages all content related operations',
          userCount: 2,
          createTime: '2023-11-10 14:30',
          status: true,
          isSystemRole: false
        }
      ]
      
      loading.value = false
    }, 800)
  } catch (error) {
    console.error('Error loading roles:', error)
    ElMessage({ message: 'Failed to load roles', type: 'error' })
    loading.value = false
  }
}

// Fetch all permissions
const fetchPermissions = async () => {
  try {
    // In a real app, we would call the API
    // const response = await getAllPermissions()
    
    // For now, use mock data
    permissionTree.value = [
      {
        id: 1,
        name: 'Dashboard',
        children: [
          { id: 101, name: 'View Dashboard' }
        ]
      },
      {
        id: 2,
        name: 'Content Management',
        children: [
          { id: 201, name: 'View Articles' },
          { id: 202, name: 'Create Article' },
          { id: 203, name: 'Edit Article' },
          { id: 204, name: 'Delete Article' },
          { id: 205, name: 'Manage Categories' }
        ]
      },
      {
        id: 3,
        name: 'User Management',
        children: [
          { id: 301, name: 'View Users' },
          { id: 302, name: 'Create User' },
          { id: 303, name: 'Edit User' },
          { id: 304, name: 'Delete User' }
        ]
      },
      {
        id: 4,
        name: 'Role Management',
        children: [
          { id: 401, name: 'View Roles' },
          { id: 402, name: 'Create Role' },
          { id: 403, name: 'Edit Role' },
          { id: 404, name: 'Delete Role' },
          { id: 405, name: 'Assign Permissions' }
        ]
      },
      {
        id: 5,
        name: 'System Settings',
        children: [
          { id: 501, name: 'View Settings' },
          { id: 502, name: 'Edit Settings' }
        ]
      }
    ]
  } catch (error) {
    console.error('Error loading permissions:', error)
    ElMessage({ message: 'Failed to load permissions', type: 'error' })
  }
}

// Fetch role permissions
const fetchRolePermissions = async (roleId) => {
  try {
    // In a real app, we would call the API
    // const response = await getRolePermissions(roleId)
    
    // For now, use mock data based on role ID
    let permissionIds = []
    
    // Mock different permissions for different roles
    switch(roleId) {
      case 1: // Admin
        permissionIds = [101, 201, 202, 203, 204, 205, 301, 302, 303, 304, 401, 402, 403, 404, 405, 501, 502]
        break
      case 2: // Editor
        permissionIds = [101, 201, 202, 203, 204, 205]
        break
      case 3: // User
        permissionIds = [101, 201]
        break
      case 4: // Guest
        permissionIds = [101]
        break
      case 5: // Content Manager
        permissionIds = [101, 201, 202, 203, 204, 205]
        break
      default:
        permissionIds = []
    }
    
    selectedPermissions.value = permissionIds
  } catch (error) {
    console.error('Error loading role permissions:', error)
    ElMessage({ message: 'Failed to load role permissions', type: 'error' })
  }
}

// Show add role dialog
const showAddRoleDialog = () => {
  resetRoleForm()
  dialogType.value = 'add'
  dialogVisible.value = true
}

// Show edit role dialog
const handleEdit = (row) => {
  resetRoleForm()
  dialogType.value = 'edit'
  
  // Populate form with role data
  Object.assign(roleForm, {
    id: row.id,
    name: row.name,
    code: row.code,
    description: row.description,
    status: row.status,
    isSystemRole: row.isSystemRole
  })
  
  dialogVisible.value = true
}

// Show permission dialog
const handlePermission = async (row) => {
  currentRoleId.value = row.id
  permDialogVisible.value = true
  
  // Fetch role permissions
  await fetchRolePermissions(row.id)
}

// Reset role form
const resetRoleForm = () => {
  Object.assign(roleForm, {
    id: null,
    name: '',
    code: '',
    description: '',
    status: true,
    isSystemRole: false
  })
  
  // Reset form validation
  if (roleFormRef.value) {
    roleFormRef.value.resetFields()
  }
}

// Handle role deletion
const handleDelete = (row) => {
  if (row.isSystemRole) {
    ElMessage({ message: 'System roles cannot be deleted', type: 'warning' })
    return
  }
  
  ElMessageBox.confirm(
    `Are you sure you want to delete the role "${row.name}"?`,
    'Delete Role',
    {
      confirmButtonText: 'Delete',
      cancelButtonText: 'Cancel',
      type: 'warning'
    }
  ).then(async () => {
    try {
      // In a real app, we would call the API
      // await deleteRole(row.id)
      
      // For now, remove from local data
      tableData.value = tableData.value.filter(role => role.id !== row.id)
      
      ElMessage({ message: 'Role deleted successfully', type: 'success' })
    } catch (error) {
      console.error('Error deleting role:', error)
      ElMessage({ message: 'Failed to delete role', type: 'error' })
    }
  }).catch(() => {
    // User cancelled
  })
}

// Handle status change
const handleStatusChange = (row, status) => {
  if (row.isSystemRole) {
    ElMessage({ message: 'System role status cannot be changed', type: 'warning' })
    return
  }
  
  const statusText = status ? 'enable' : 'disable'
  ElMessageBox.confirm(
    `Are you sure you want to ${statusText} the role "${row.name}"?`,
    `${status ? 'Enable' : 'Disable'} Role`,
    {
      confirmButtonText: 'Confirm',
      cancelButtonText: 'Cancel',
      type: 'warning'
    }
  ).then(async () => {
    try {
      // In a real app, we would call the API
      // await updateRole(row.id, { status })
      
      // For now, update local data
      const index = tableData.value.findIndex(role => role.id === row.id)
      tableData.value[index].status = status
      
      ElMessage({ 
        message: `Role ${statusText}d successfully`, 
        type: 'success' 
      })
    } catch (error) {
      console.error(`Error ${statusText}ing role:`, error)
      ElMessage({ message: `Failed to ${statusText} role`, type: 'error' })
    }
  }).catch(() => {
    // User cancelled
  })
}

// Submit role form
const submitRoleForm = () => {
  roleFormRef.value.validate(async (valid) => {
    if (valid) {
      submitLoading.value = true
      try {
        if (dialogType.value === 'add') {
          // In a real app, we would call the API
          // await createRole(roleForm)
          
          // For now, add to local data
          const newRole = {
            ...roleForm,
            id: tableData.value.length + 1,
            userCount: 0,
            createTime: new Date().toISOString().replace('T', ' ').substring(0, 16)
          }
          
          tableData.value.push(newRole)
          
          ElMessage({ message: 'Role created successfully', type: 'success' })
        } else {
          // In a real app, we would call the API
          // await updateRole(roleForm.id, roleForm)
          
          // For now, update local data
          const index = tableData.value.findIndex(role => role.id === roleForm.id)
          
          tableData.value[index] = {
            ...tableData.value[index],
            name: roleForm.name,
            description: roleForm.description,
            status: roleForm.status
          }
          
          // Only update code if not a system role
          if (!roleForm.isSystemRole) {
            tableData.value[index].code = roleForm.code
          }
          
          ElMessage({ message: 'Role updated successfully', type: 'success' })
        }
        
        dialogVisible.value = false
      } catch (error) {
        console.error('Error saving role:', error)
        ElMessage({ message: 'Failed to save role', type: 'error' })
      } finally {
        submitLoading.value = false
      }
    }
  })
}

// Save role permissions
const savePermissions = async () => {
  permSubmitLoading.value = true
  try {
    // Get selected permissions from tree
    const selectedKeys = permissionTreeRef.value.getCheckedKeys()
    const halfCheckedKeys = permissionTreeRef.value.getHalfCheckedKeys()
    const allSelectedKeys = [...selectedKeys, ...halfCheckedKeys]
    
    // In a real app, we would call the API
    // await updateRolePermissions(currentRoleId.value, allSelectedKeys)
    
    ElMessage({ message: 'Permissions updated successfully', type: 'success' })
    permDialogVisible.value = false
  } catch (error) {
    console.error('Error updating permissions:', error)
    ElMessage({ message: 'Failed to update permissions', type: 'error' })
  } finally {
    permSubmitLoading.value = false
  }
}

// Load roles and permissions on component mount
onMounted(() => {
  fetchRoles()
  fetchPermissions()
})
</script>

<style scoped>
.role-management-container {
  padding: 20px;
}

.page-header {
  display: flex;
  justify-content: space-between;
  margin-bottom: 20px;
  align-items: center;
}

.role-table-card {
  margin-bottom: 20px;
}

.dialog-footer {
  display: flex;
  justify-content: flex-end;
}

.permission-container {
  max-height: 400px;
  overflow-y: auto;
  padding: 10px;
  border: 1px solid #ebeef5;
  border-radius: 4px;
}
</style>