<!-- src/views/system/Profile.vue -->
<template>
  <div class="profile-container">
    <div class="page-header">
      <h2>My Profile</h2>
    </div>

    <el-row :gutter="20">
      <el-col :xs="24" :md="8">
        <el-card class="profile-card">
          <div class="profile-avatar-container">
            <el-avatar :size="120" :src="userInfo.avatar || defaultAvatar" />
            <div class="avatar-upload">
              <el-upload
                class="avatar-uploader"
                action=""
                :show-file-list="false"
                :auto-upload="false"
                :on-change="handleAvatarChange"
              >
                <el-button size="small" type="primary">Change Avatar</el-button>
              </el-upload>
            </div>
          </div>
          <div class="profile-info">
            <h3>{{ userInfo.name }}</h3>
            <p class="profile-username">@{{ userInfo.username }}</p>
            <p class="profile-role">{{ userInfo.roleName }}</p>
          </div>
          <div class="profile-meta">
            <div class="meta-item">
              <span class="meta-label">Member Since</span>
              <span class="meta-value">{{ userInfo.createTime }}</span>
            </div>
            <div class="meta-item">
              <span class="meta-label">Last Login</span>
              <span class="meta-value">{{ userInfo.lastLoginTime }}</span>
            </div>
          </div>
        </el-card>
      </el-col>
      <el-col :xs="24" :md="16">
        <el-card>
          <template #header>
            <div class="card-header">
              <span>Profile Information</span>
              <el-button type="primary" @click="updateProfile" :loading="loading">Save Changes</el-button>
            </div>
          </template>
          <el-form
            ref="profileFormRef"
            :model="profileForm"
            :rules="formRules"
            label-width="120px"
            label-position="top"
          >
            <el-row :gutter="20">
              <el-col :xs="24" :sm="12">
                <el-form-item label="Name" prop="name">
                  <el-input v-model="profileForm.name" placeholder="Enter your name" />
                </el-form-item>
              </el-col>
              <el-col :xs="24" :sm="12">
                <el-form-item label="Username" prop="username">
                  <el-input v-model="profileForm.username" placeholder="Enter username" disabled />
                </el-form-item>
              </el-col>
            </el-row>
            <el-row :gutter="20">
              <el-col :xs="24" :sm="12">
                <el-form-item label="Email" prop="email">
                  <el-input v-model="profileForm.email" placeholder="Enter your email" />
                </el-form-item>
              </el-col>
              <el-col :xs="24" :sm="12">
                <el-form-item label="Phone" prop="phone">
                  <el-input v-model="profileForm.phone" placeholder="Enter your phone number" />
                </el-form-item>
              </el-col>
            </el-row>
            <el-form-item label="Bio" prop="bio">
              <el-input
                v-model="profileForm.bio"
                type="textarea"
                rows="4"
                placeholder="Tell us about yourself"
              />
            </el-form-item>
          </el-form>
        </el-card>

        <el-card class="security-card">
          <template #header>
            <div class="card-header">
              <span>Security</span>
            </div>
          </template>
          <el-form
            ref="passwordFormRef"
            :model="passwordForm"
            :rules="passwordRules"
            label-width="180px"
          >
            <el-form-item label="Current Password" prop="currentPassword">
              <el-input
                v-model="passwordForm.currentPassword"
                type="password"
                placeholder="Enter current password"
                show-password
              />
            </el-form-item>
            <el-form-item label="New Password" prop="newPassword">
              <el-input
                v-model="passwordForm.newPassword"
                type="password"
                placeholder="Enter new password"
                show-password
              />
            </el-form-item>
            <el-form-item label="Confirm New Password" prop="confirmPassword">
              <el-input
                v-model="passwordForm.confirmPassword"
                type="password"
                placeholder="Confirm new password"
                show-password
              />
            </el-form-item>
            <el-form-item>
              <el-button type="primary" @click="changePassword" :loading="passwordLoading">
                Change Password
              </el-button>
            </el-form-item>
          </el-form>
        </el-card>
      </el-col>
    </el-row>
  </div>
</template>

<script setup>
import { ref, reactive, onMounted } from 'vue'
import { ElMessage } from 'element-plus'
import { changePassword, updateProfile } from '@/api/user'
import { getUserInfo } from '@/utils/auth'

const loading = ref(false)
const passwordLoading = ref(false)
const profileFormRef = ref(null)
const passwordFormRef = ref(null)
const defaultAvatar = 'https://cube.elemecdn.com/3/7c/3ea6beec64369c2642b92c6726f1epng.png'

// User information
const userInfo = reactive({
  id: 1,
  name: 'Admin User',
  username: 'admin',
  email: 'admin@example.com',
  phone: '1234567890',
  bio: 'I am a system administrator for the CMS.',
  avatar: '',
  roleName: 'Administrator',
  createTime: '2023-11-01 10:00',
  lastLoginTime: '2023-11-24 08:30'
})

// Profile form
const profileForm = reactive({
  name: '',
  username: '',
  email: '',
  phone: '',
  bio: ''
})

// Password form
const passwordForm = reactive({
  currentPassword: '',
  newPassword: '',
  confirmPassword: ''
})

// Form rules for profile
const formRules = {
  name: [
    { required: true, message: 'Please enter your name', trigger: 'blur' },
    { min: 2, max: 50, message: 'Name must be between 2 and 50 characters', trigger: 'blur' }
  ],
  email: [
    { required: true, message: 'Please enter your email', trigger: 'blur' },
    { type: 'email', message: 'Please enter a valid email', trigger: 'blur' }
  ],
  phone: [
    { pattern: /^[0-9\-+()]{6,20}$/, message: 'Please enter a valid phone number', trigger: 'blur' }
  ]
}

// Password validation rules
const validatePass = (rule, value, callback) => {
  if (value === '') {
    callback(new Error('Please enter the new password'))
  } else {
    if (passwordForm.confirmPassword !== '' && value !== passwordForm.confirmPassword) {
      passwordFormRef.value.validateField('confirmPassword')
    }
    callback()
  }
}

const validateConfirmPass = (rule, value, callback) => {
  if (value === '') {
    callback(new Error('Please confirm the new password'))
  } else if (value !== passwordForm.newPassword) {
    callback(new Error('Passwords do not match'))
  } else {
    callback()
  }
}

// Form rules for password
const passwordRules = {
  currentPassword: [
    { required: true, message: 'Please enter your current password', trigger: 'blur' }
  ],
  newPassword: [
    { required: true, validator: validatePass, trigger: 'blur' },
    { min: 6, message: 'Password must be at least 6 characters', trigger: 'blur' }
  ],
  confirmPassword: [
    { required: true, validator: validateConfirmPass, trigger: 'blur' }
  ]
}

// Load user data
const loadUserData = () => {
  // In a real app, we would fetch from API based on stored user info
  // const currentUser = getUserInfo()
  // if (currentUser?.id) {
  //   const response = await getUserDetails(currentUser.id)
  //   Object.assign(userInfo, response)
  // }
  
  // For now, populate profile form from mock user info
  Object.assign(profileForm, {
    name: userInfo.name,
    username: userInfo.username,
    email: userInfo.email,
    phone: userInfo.phone,
    bio: userInfo.bio
  })
}

// Handle avatar change
const handleAvatarChange = (file) => {
  // In a real app, we would handle file upload
  const fileUrl = URL.createObjectURL(file.raw)
  userInfo.avatar = fileUrl
  
  // Here we would upload the file to the server
  // const formData = new FormData()
  // formData.append('avatar', file.raw)
  // await uploadAvatar(formData)
  
  ElMessage({
    message: 'Avatar updated successfully',
    type: 'success'
  })
}

// Update profile
const updateProfile = () => {
  profileFormRef.value.validate(async (valid) => {
    if (valid) {
      loading.value = true
      try {
        // In a real app, we would call the API
        // await updateProfile(profileForm)
        
        // Update local user info
        Object.assign(userInfo, profileForm)
        
        ElMessage({
          message: 'Profile updated successfully',
          type: 'success'
        })
      } catch (error) {
        console.error('Error updating profile:', error)
        ElMessage({
          message: 'Failed to update profile',
          type: 'error'
        })
      } finally {
        loading.value = false
      }
    }
  })
}

// Change password
const changePassword = () => {
  passwordFormRef.value.validate(async (valid) => {
    if (valid) {
      passwordLoading.value = true
      try {
        // In a real app, we would call the API
        // await changePassword(passwordForm)
        
        // Reset form
        Object.keys(passwordForm).forEach(key => {
          passwordForm[key] = ''
        })
        
        ElMessage({
          message: 'Password changed successfully',
          type: 'success'
        })
      } catch (error) {
        console.error('Error changing password:', error)
        ElMessage({
          message: 'Failed to change password',
          type: 'error'
        })
      } finally {
        passwordLoading.value = false
      }
    }
  })
}

// Load user data on component mount
onMounted(() => {
  loadUserData()
})
</script>

<style scoped>
.profile-container {
  padding: 20px;
}

.profile-card {
  text-align: center;
}

.profile-avatar-container {
  margin-bottom: 20px;
  display: flex;
  flex-direction: column;
  align-items: center;
}

.avatar-upload {
  margin-top: 15px;
}

.profile-info h3 {
  font-size: 18px;
  margin: 10px 0 5px;
}

.profile-username {
  font-size: 14px;
  color: #909399;
  margin-bottom: 5px;
}

.profile-role {
  font-size: 14px;
  color: #409EFF;
  margin-bottom: 15px;
}

.profile-meta {
  border-top: 1px solid #ebeef5;
  padding-top: 15px;
  margin-top: 15px;
  text-align: left;
}

.meta-item {
  display: flex;
  justify-content: space-between;
  margin-bottom: 8px;
}

.meta-label {
  color: #909399;
}

.meta-value {
  font-weight: 500;
}

.card-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.security-card {
  margin-top: 20px;
}
</style>