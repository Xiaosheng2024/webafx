<!-- src/views/Login.vue -->
<template>
  <div class="login-container">
    <div class="login-card">
      <div class="login-header">
        <h2 class="login-title">Content Management System</h2>
      </div>
      <el-form ref="loginFormRef" :model="loginForm" :rules="rules" class="login-form" @submit.prevent="handleLogin">
        <el-form-item prop="username">
          <el-input 
            v-model="loginForm.username" 
            placeholder="Username" 
            prefix-icon="User"
          />
        </el-form-item>
        <el-form-item prop="password">
          <el-input 
            v-model="loginForm.password" 
            placeholder="Password" 
            prefix-icon="Lock" 
            type="password" 
            show-password
            @keyup.enter="handleLogin"
          />
        </el-form-item>
        <el-form-item>
          <el-checkbox v-model="loginForm.rememberMe">Remember me</el-checkbox>
        </el-form-item>
        <el-form-item>
          <el-button type="primary" :loading="loading" class="login-button" @click="handleLogin">
            Sign In
          </el-button>
        </el-form-item>
      </el-form>
      <div class="demo-accounts">
        <p>Demo Accounts:</p>
        <div class="demo-account" v-for="(account, index) in demoAccounts" :key="index">
          <p><strong>{{ account.role }}:</strong> {{ account.username }} / {{ account.password }}</p>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, reactive } from 'vue'
import { useRouter } from 'vue-router'
import { ElMessage } from 'element-plus'
import { User, Lock } from '@element-plus/icons-vue'
import { login } from '@/api/user'
import { setToken } from '@/utils/auth'

const router = useRouter()
const loading = ref(false)
const loginFormRef = ref(null)

// Demo accounts for easy access in the demo system
const demoAccounts = [
  { role: 'Administrator', username: 'admin', password: 'admin123' },
  { role: 'Editor', username: 'editor', password: 'editor123' },
  { role: 'User', username: 'user', password: 'user123' }
]

// Form data
const loginForm = reactive({
  username: '',
  password: '',
  rememberMe: false
})

// Form validation rules
const rules = {
  username: [
    { required: true, message: 'Please enter username', trigger: 'blur' },
    { min: 3, max: 20, message: 'Length should be 3 to 20 characters', trigger: 'blur' }
  ],
  password: [
    { required: true, message: 'Please enter password', trigger: 'blur' },
    { min: 6, max: 20, message: 'Length should be 6 to 20 characters', trigger: 'blur' }
  ]
}

// Login handler
const handleLogin = () => {
  loginFormRef.value.validate(async (valid) => {
    if (valid) {
      loading.value = true
      
      try {
        // In a real app, we would call the login API
        // const res = await login(loginForm)
        
        // For demo purposes, hardcode successful login
        if (
          (loginForm.username === 'admin' && loginForm.password === 'admin123') ||
          (loginForm.username === 'editor' && loginForm.password === 'editor123') ||
          (loginForm.username === 'user' && loginForm.password === 'user123')
        ) {
          // Mock token
          const token = 'demo-token-' + Date.now()
          
          // Store token
          setToken(token, loginForm.rememberMe ? 7 * 24 * 60 * 60 * 1000 : 0)
          
          // Store user information
          const userInfo = {
            id: 1,
            username: loginForm.username,
            name: loginForm.username === 'admin' ? 'Administrator' : 
                  loginForm.username === 'editor' ? 'Content Editor' : 'Regular User',
            avatar: '',
            roles: [loginForm.username],
          }
          
          localStorage.setItem('userInfo', JSON.stringify(userInfo))
          
          ElMessage({
            message: 'Login successful',
            type: 'success',
          })
          
          // Redirect to dashboard
          router.push('/')
        } else {
          // Invalid credentials
          ElMessage.error('Invalid username or password')
        }
      } catch (error) {
        console.error('Login error:', error)
        ElMessage.error(error.message || 'Login failed')
      } finally {
        loading.value = false
      }
    }
  })
}
</script>

<style scoped>
.login-container {
  display: flex;
  justify-content: center;
  align-items: center;
  height: 100vh;
  background-color: #f0f2f5;
  background-image: linear-gradient(135deg, #f0f2f5 0%, #e6f7ff 100%);
}

.login-card {
  width: 400px;
  padding: 40px;
  background: white;
  border-radius: 4px;
  box-shadow: 0 2px 12px 0 rgba(0, 0, 0, 0.1);
}

.login-header {
  text-align: center;
  margin-bottom: 30px;
}

.login-title {
  font-size: 24px;
  color: #303133;
  margin: 0;
}

.login-form {
  margin-bottom: 20px;
}

.login-button {
  width: 100%;
}

.demo-accounts {
  margin-top: 20px;
  padding-top: 20px;
  border-top: 1px dashed #dcdfe6;
  font-size: 14px;
  color: #606266;
}

.demo-account {
  margin-top: 5px;
}
</style>