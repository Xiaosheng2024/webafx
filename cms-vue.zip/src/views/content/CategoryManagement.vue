<!-- src/views/content/CategoryManagement.vue -->
<template>
  <div class="category-management-container">
    <div class="page-header">
      <h2>Category Management</h2>
      <el-button type="primary" @click="showAddCategoryDialog">
        <el-icon><Plus /></el-icon>
        New Category
      </el-button>
    </div>

    <!-- Category Table -->
    <el-card class="category-table-card">
      <el-table 
        :data="tableData" 
        v-loading="loading"
        style="width: 100%"
        row-key="id"
        default-expand-all
        :tree-props="{ children: 'children' }"
      >
        <el-table-column prop="id" label="ID" width="80" />
        <el-table-column prop="name" label="Category Name" min-width="200" />
        <el-table-column prop="code" label="Code" width="150" />
        <el-table-column prop="articleCount" label="Articles" width="100" />
        <el-table-column prop="sort" label="Sort Order" width="100" />
        <el-table-column prop="createTime" label="Create Time" width="180" />
        <el-table-column label="Status" width="100">
          <template #default="scope">
            <el-tag :type="scope.row.status ? 'success' : 'danger'">
              {{ scope.row.status ? 'Active' : 'Inactive' }}
            </el-tag>
          </template>
        </el-table-column>
        <el-table-column fixed="right" label="Operations" width="230">
          <template #default="scope">
            <el-button type="primary" size="small" link @click="handleEdit(scope.row)">Edit</el-button>
            <el-button type="primary" size="small" link @click="handleAddSubCategory(scope.row)">Add Sub-category</el-button>
            <el-button 
              type="danger" 
              size="small" 
              link 
              @click="handleDelete(scope.row)"
              :disabled="hasChildren(scope.row)"
            >
              Delete
            </el-button>
          </template>
        </el-table-column>
      </el-table>
    </el-card>

    <!-- Category Dialog -->
    <el-dialog 
      v-model="dialogVisible" 
      :title="dialogType === 'add' ? 'Add Category' : 'Edit Category'"
      width="500px"
    >
      <el-form 
        ref="categoryFormRef"
        :model="categoryForm" 
        :rules="formRules"
        label-width="100px"
        @submit.prevent
      >
        <el-form-item label="Name" prop="name">
          <el-input v-model="categoryForm.name" placeholder="Category name" />
        </el-form-item>

        <el-form-item label="Code" prop="code">
          <el-input v-model="categoryForm.code" placeholder="Category code" />
        </el-form-item>

        <el-form-item label="Parent" prop="parentId" v-if="dialogType === 'add' && !addingSubCategory">
          <el-cascader
            v-model="categoryForm.parentId"
            :options="categoryOptions"
            :props="{ checkStrictly: true, value: 'id', label: 'name' }"
            placeholder="Select parent category"
            clearable
          />
        </el-form-item>

        <el-form-item label="Sort Order" prop="sort">
          <el-input-number v-model="categoryForm.sort" :min="0" :max="1000" />
        </el-form-item>

        <el-form-item label="Status">
          <el-switch v-model="categoryForm.status" />
        </el-form-item>

        <el-form-item label="Description" prop="description">
          <el-input 
            v-model="categoryForm.description" 
            type="textarea" 
            rows="3" 
            placeholder="Category description" 
          />
        </el-form-item>
      </el-form>
      <template #footer>
        <div class="dialog-footer">
          <el-button @click="dialogVisible = false">Cancel</el-button>
          <el-button type="primary" @click="submitCategoryForm" :loading="submitLoading">
            Confirm
          </el-button>
        </div>
      </template>
    </el-dialog>
  </div>
</template>

<script setup>
import { ref, reactive, onMounted } from 'vue'
import { ElMessage, ElMessageBox } from 'element-plus'
import { Plus } from '@element-plus/icons-vue'

const loading = ref(false)
const submitLoading = ref(false)
const dialogVisible = ref(false)
const dialogType = ref('add') // 'add' or 'edit'
const addingSubCategory = ref(false)
const categoryFormRef = ref(null)

// Category table data
const tableData = ref([])

// Category form
const categoryForm = reactive({
  id: null,
  name: '',
  code: '',
  parentId: null,
  sort: 0,
  status: true,
  description: ''
})

// Form validation rules
const formRules = {
  name: [
    { required: true, message: 'Please enter category name', trigger: 'blur' },
    { min: 2, max: 50, message: 'Length should be 2 to 50 characters', trigger: 'blur' }
  ],
  code: [
    { required: true, message: 'Please enter category code', trigger: 'blur' },
    { pattern: /^[a-z0-9_-]+$/, message: 'Code can only include lowercase letters, numbers, underscores and dashes', trigger: 'blur' }
  ],
  sort: [
    { required: true, message: 'Please enter sort order', trigger: 'blur' }
  ]
}

// Category options for parent selection
const categoryOptions = ref([])

// Check if category has children
const hasChildren = (row) => {
  return row.children && row.children.length > 0
}

// Fetch categories from API
const fetchCategories = async () => {
  loading.value = true
  try {
    // In a real app, we would fetch from API
    // const response = await getCategories()
    
    // Mock data for demo
    setTimeout(() => {
      tableData.value = [
        {
          id: 1,
          name: 'Technology',
          code: 'technology',
          articleCount: 25,
          sort: 1,
          status: true,
          createTime: '2023-11-01 10:30',
          description: 'Technology related articles',
          children: [
            {
              id: 4,
              name: 'Programming',
              code: 'programming',
              articleCount: 15,
              sort: 1,
              status: true,
              createTime: '2023-11-01 10:35',
              description: 'Programming tutorials and guides',
              parentId: 1
            },
            {
              id: 5,
              name: 'Hardware',
              code: 'hardware',
              articleCount: 10,
              sort: 2,
              status: true,
              createTime: '2023-11-01 10:40',
              description: 'Hardware reviews and news',
              parentId: 1
            }
          ]
        },
        {
          id: 2,
          name: 'Business',
          code: 'business',
          articleCount: 18,
          sort: 2,
          status: true,
          createTime: '2023-11-01 11:00',
          description: 'Business related articles',
          children: []
        },
        {
          id: 3,
          name: 'Design',
          code: 'design',
          articleCount: 12,
          sort: 3,
          status: true,
          createTime: '2023-11-01 11:30',
          description: 'Design related articles',
          children: [
            {
              id: 6,
              name: 'UI/UX',
              code: 'ui-ux',
              articleCount: 8,
              sort: 1,
              status: true,
              createTime: '2023-11-01 11:35',
              description: 'User Interface and Experience Design',
              parentId: 3
            },
            {
              id: 7,
              name: 'Graphic Design',
              code: 'graphic-design',
              articleCount: 4,
              sort: 2,
              status: false,
              createTime: '2023-11-01 11:40',
              description: 'Graphic Design resources and tutorials',
              parentId: 3
            }
          ]
        }
      ]
      
      // Prepare options for parent category selection
      prepareCategoryOptions()
      
      loading.value = false
    }, 800)
  } catch (error) {
    console.error('Error loading categories:', error)
    ElMessage({ message: 'Failed to load categories', type: 'error' })
    loading.value = false
  }
}

// Prepare category options for cascader
const prepareCategoryOptions = () => {
  // Function to transform table data to options format
  const transformToOptions = (categories) => {
    return categories.map(category => {
      const option = {
        id: category.id,
        name: category.name,
        children: []
      }
      
      if (category.children && category.children.length > 0) {
        option.children = transformToOptions(category.children)
      }
      
      return option
    })
  }
  
  categoryOptions.value = transformToOptions(tableData.value)
}

// Show add category dialog
const showAddCategoryDialog = () => {
  resetCategoryForm()
  dialogType.value = 'add'
  addingSubCategory.value = false
  dialogVisible.value = true
}

// Show edit category dialog
const handleEdit = (row) => {
  resetCategoryForm()
  dialogType.value = 'edit'
  
  // Populate form with selected category data
  Object.assign(categoryForm, {
    id: row.id,
    name: row.name,
    code: row.code,
    parentId: row.parentId,
    sort: row.sort,
    status: row.status,
    description: row.description
  })
  
  dialogVisible.value = true
}

// Show add subcategory dialog
const handleAddSubCategory = (row) => {
  resetCategoryForm()
  dialogType.value = 'add'
  addingSubCategory.value = true
  categoryForm.parentId = row.id
  dialogVisible.value = true
}

// Reset category form
const resetCategoryForm = () => {
  Object.assign(categoryForm, {
    id: null,
    name: '',
    code: '',
    parentId: null,
    sort: 0,
    status: true,
    description: ''
  })
  
  // Reset form validation
  if (categoryFormRef.value) {
    categoryFormRef.value.resetFields()
  }
}

// Submit category form
const submitCategoryForm = () => {
  categoryFormRef.value.validate(async (valid) => {
    if (valid) {
      submitLoading.value = true
      try {
        if (dialogType.value === 'add') {
          // In a real app, we would call API
          // await createCategory(categoryForm)
          
          // For demo, add to local data
          const newCategory = {
            ...categoryForm,
            id: Math.floor(Math.random() * 1000) + 100, // Generate a fake ID
            createTime: new Date().toISOString().replace('T', ' ').substring(0, 16),
            articleCount: 0,
            children: []
          }
          
          if (categoryForm.parentId) {
            // Add as child to parent
            const addChildToParent = (categories, parentId) => {
              for (let i = 0; i < categories.length; i++) {
                if (categories[i].id === parentId) {
                  categories[i].children = categories[i].children || []
                  categories[i].children.push(newCategory)
                  return true
                }
                if (categories[i].children && categories[i].children.length > 0) {
                  if (addChildToParent(categories[i].children, parentId)) {
                    return true
                  }
                }
              }
              return false
            }
            
            addChildToParent(tableData.value, categoryForm.parentId)
          } else {
            // Add as top-level category
            tableData.value.push(newCategory)
          }
          
          ElMessage({ message: 'Category added successfully', type: 'success' })
        } else {
          // In a real app, we would call API
          // await updateCategory(categoryForm.id, categoryForm)
          
          // For demo, update local data
          const updateCategoryById = (categories, id) => {
            for (let i = 0; i < categories.length; i++) {
              if (categories[i].id === id) {
                Object.assign(categories[i], {
                  name: categoryForm.name,
                  code: categoryForm.code,
                  sort: categoryForm.sort,
                  status: categoryForm.status,
                  description: categoryForm.description
                })
                return true
              }
              if (categories[i].children && categories[i].children.length > 0) {
                if (updateCategoryById(categories[i].children, id)) {
                  return true
                }
              }
            }
            return false
          }
          
          updateCategoryById(tableData.value, categoryForm.id)
          ElMessage({ message: 'Category updated successfully', type: 'success' })
        }
        
        dialogVisible.value = false
        
        // Refresh category options
        prepareCategoryOptions()
      } catch (error) {
        console.error('Error saving category:', error)
        ElMessage({ message: 'Failed to save category', type: 'error' })
      } finally {
        submitLoading.value = false
      }
    }
  })
}

// Delete category
const handleDelete = (row) => {
  ElMessageBox.confirm(
    `Are you sure you want to delete the category "${row.name}"?`,
    'Delete Category',
    {
      confirmButtonText: 'Delete',
      cancelButtonText: 'Cancel',
      type: 'warning'
    }
  ).then(async () => {
    try {
      // In a real app, we would call API
      // await deleteCategory(row.id)
      
      // For demo, remove from local data
      const removeCategory = (categories, id) => {
        for (let i = 0; i < categories.length; i++) {
          if (categories[i].id === id) {
            categories.splice(i, 1)
            return true
          }
          if (categories[i].children && categories[i].children.length > 0) {
            if (removeCategory(categories[i].children, id)) {
              return true
            }
          }
        }
        return false
      }
      
      removeCategory(tableData.value, row.id)
      ElMessage({ message: 'Category deleted successfully', type: 'success' })
      
      // Refresh category options
      prepareCategoryOptions()
    } catch (error) {
      console.error('Error deleting category:', error)
      ElMessage({ message: 'Failed to delete category', type: 'error' })
    }
  }).catch(() => {
    // User cancelled
  })
}

// Load categories on component mount
onMounted(() => {
  fetchCategories()
})
</script>

<style scoped>
.category-management-container {
  padding: 20px;
}

.page-header {
  display: flex;
  justify-content: space-between;
  margin-bottom: 20px;
  align-items: center;
}

.category-table-card {
  margin-bottom: 20px;
}

.dialog-footer {
  display: flex;
  justify-content: flex-end;
}
</style>