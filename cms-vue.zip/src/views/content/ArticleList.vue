<!-- src/views/content/ArticleList.vue -->
<template>
  <div class="article-list-container">
    <div class="page-header">
      <h2>Article Management</h2>
      <router-link to="/content/article-edit">
        <el-button type="primary">
          <el-icon><Plus /></el-icon>
          New Article
        </el-button>
      </router-link>
    </div>

    <!-- Search Form -->
    <el-card class="search-card">
      <el-form :model="searchForm" ref="searchFormRef" label-width="100px" class="search-form" @submit.prevent>
        <el-row :gutter="20">
          <el-col :xs="24" :sm="8" :md="6">
            <el-form-item label="Title:">
              <el-input v-model="searchForm.title" placeholder="Search by title" clearable />
            </el-form-item>
          </el-col>
          <el-col :xs="24" :sm="8" :md="6">
            <el-form-item label="Category:">
              <el-select v-model="searchForm.categoryId" placeholder="Select category" clearable>
                <el-option v-for="item in categories" :key="item.id" :label="item.name" :value="item.id" />
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :xs="24" :sm="8" :md="6">
            <el-form-item label="Status:">
              <el-select v-model="searchForm.status" placeholder="Select status" clearable>
                <el-option label="Draft" value="draft" />
                <el-option label="Published" value="published" />
                <el-option label="Archived" value="archived" />
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :xs="24" :sm="8" :md="6">
            <el-form-item label="Date Range:">
              <el-date-picker
                v-model="searchForm.dateRange"
                type="daterange"
                range-separator="~"
                start-placeholder="Start"
                end-placeholder="End"
                value-format="YYYY-MM-DD"
                style="width: 100%"
              />
            </el-form-item>
          </el-col>
          <el-col :xs="24" class="form-buttons">
            <el-button type="primary" @click="handleSearch">Search</el-button>
            <el-button @click="resetSearch">Reset</el-button>
          </el-col>
        </el-row>
      </el-form>
    </el-card>

    <!-- Article Table -->
    <el-card class="table-card">
      <el-table 
        :data="tableData" 
        v-loading="loading"
        style="width: 100%"
      >
        <el-table-column type="index" width="50" />
        <el-table-column prop="title" label="Title" min-width="200" show-overflow-tooltip />
        <el-table-column prop="categoryName" label="Category" width="120" />
        <el-table-column prop="author" label="Author" width="120" />
        <el-table-column prop="createTime" label="Create Time" width="180" sortable />
        <el-table-column prop="publishTime" label="Publish Time" width="180" sortable />
        <el-table-column prop="views" label="Views" width="80" sortable />
        <el-table-column prop="status" label="Status" width="100">
          <template #default="scope">
            <el-tag :type="getStatusType(scope.row.status)">
              {{ scope.row.status }}
            </el-tag>
          </template>
        </el-table-column>
        <el-table-column fixed="right" label="Operations" width="200">
          <template #default="scope">
            <router-link :to="`/content/article-edit?id=${scope.row.id}`">
              <el-button type="primary" size="small" link>Edit</el-button>
            </router-link>
            <el-button 
              v-if="scope.row.status !== 'published'" 
              type="success" 
              size="small" 
              link 
              @click="handlePublish(scope.row)"
            >
              Publish
            </el-button>
            <el-button 
              v-if="scope.row.status === 'published'" 
              type="warning" 
              size="small" 
              link 
              @click="handleArchive(scope.row)"
            >
              Archive
            </el-button>
            <el-button 
              type="danger" 
              size="small" 
              link 
              @click="handleDelete(scope.row)"
            >
              Delete
            </el-button>
          </template>
        </el-table-column>
      </el-table>

      <!-- Pagination -->
      <el-pagination
        class="cms-pagination"
        :current-page="pagination.current"
        :page-size="pagination.pageSize"
        :total="pagination.total"
        :page-sizes="[10, 20, 50, 100]"
        layout="total, sizes, prev, pager, next, jumper"
        @size-change="handleSizeChange"
        @current-change="handleCurrentChange"
      />
    </el-card>
  </div>
</template>

<script setup>
import { ref, reactive, onMounted } from 'vue'
import { ElMessage, ElMessageBox } from 'element-plus'
import { Plus } from '@element-plus/icons-vue'
import { getArticles, deleteArticle, updateArticleStatus } from '@/api/content'

const loading = ref(false)
const searchFormRef = ref(null)
const tableData = ref([])

// Categories data
const categories = ref([
  { id: 1, name: 'Technology' },
  { id: 2, name: 'Business' },
  { id: 3, name: 'Design' },
  { id: 4, name: 'Marketing' }
])

// Search form
const searchForm = reactive({
  title: '',
  categoryId: '',
  status: '',
  dateRange: []
})

// Pagination
const pagination = reactive({
  current: 1,
  pageSize: 10,
  total: 0
})

// Get status type for element-ui tag
const getStatusType = (status) => {
  switch (status) {
    case 'published':
      return 'success'
    case 'draft':
      return 'info'
    case 'archived':
      return 'warning'
    default:
      return 'info'
  }
}

// Handle search
const handleSearch = () => {
  pagination.current = 1
  fetchArticles()
}

// Reset search form
const resetSearch = () => {
  searchFormRef.value?.resetFields()
  pagination.current = 1
  fetchArticles()
}

// Fetch articles from API
const fetchArticles = async () => {
  loading.value = true
  try {
    // Prepare params
    const params = {
      page: pagination.current,
      pageSize: pagination.pageSize,
      title: searchForm.title,
      categoryId: searchForm.categoryId,
      status: searchForm.status
    }

    if (searchForm.dateRange && searchForm.dateRange.length === 2) {
      params.startDate = searchForm.dateRange[0]
      params.endDate = searchForm.dateRange[1]
    }

    // In a real app, we would call the API
    // const response = await getArticles(params)
    
    // For now, use mock data
    setTimeout(() => {
      // Mock article data
      tableData.value = [
        {
          id: 1,
          title: 'Introduction to Content Management Systems',
          categoryId: 1,
          categoryName: 'Technology',
          author: 'Admin User',
          status: 'published',
          views: 132,
          createTime: '2023-11-24 10:30',
          publishTime: '2023-11-24 14:36'
        },
        {
          id: 2,
          title: 'Business Strategies for 2024',
          categoryId: 2,
          categoryName: 'Business',
          author: 'Content Editor',
          status: 'published',
          views: 98,
          createTime: '2023-11-23 14:15',
          publishTime: '2023-11-23 16:20'
        },
        {
          id: 3,
          title: 'Modern UI/UX Design Principles',
          categoryId: 3,
          categoryName: 'Design',
          author: 'Design Team',
          status: 'published',
          views: 76,
          createTime: '2023-11-22 09:45',
          publishTime: '2023-11-22 11:30'
        },
        {
          id: 4,
          title: 'Marketing Trends to Watch',
          categoryId: 4,
          categoryName: 'Marketing',
          author: 'Marketing Manager',
          status: 'draft',
          views: 0,
          createTime: '2023-11-21 16:20',
          publishTime: null
        },
        {
          id: 5,
          title: 'Database Optimization Techniques',
          categoryId: 1,
          categoryName: 'Technology',
          author: 'Tech Writer',
          status: 'published',
          views: 112,
          createTime: '2023-11-20 11:10',
          publishTime: '2023-11-20 14:25'
        },
        {
          id: 6,
          title: 'AI in Content Management',
          categoryId: 1,
          categoryName: 'Technology',
          author: 'Admin User',
          status: 'draft',
          views: 0,
          createTime: '2023-11-19 15:40',
          publishTime: null
        },
        {
          id: 7,
          title: 'Social Media Marketing Guide',
          categoryId: 4,
          categoryName: 'Marketing',
          author: 'Social Media Expert',
          status: 'archived',
          views: 45,
          createTime: '2023-11-18 09:20',
          publishTime: '2023-11-18 10:15'
        }
      ]
      
      // Set pagination total
      pagination.total = 15
      
      loading.value = false
    }, 800)
  } catch (error) {
    console.error('Error loading articles:', error)
    ElMessage({ message: 'Failed to load articles', type: 'error' })
    loading.value = false
  }
}

// Handle pagination size change
const handleSizeChange = (size) => {
  pagination.pageSize = size
  fetchArticles()
}

// Handle pagination current page change
const handleCurrentChange = (current) => {
  pagination.current = current
  fetchArticles()
}

// Handle article deletion
const handleDelete = (row) => {
  ElMessageBox.confirm(
    `Are you sure you want to delete the article "${row.title}"?`,
    'Delete Article',
    {
      confirmButtonText: 'Delete',
      cancelButtonText: 'Cancel',
      type: 'warning'
    }
  ).then(async () => {
    try {
      // In a real app, we would call the API
      // await deleteArticle(row.id)
      
      // For now, remove from local data
      tableData.value = tableData.value.filter(article => article.id !== row.id)
      pagination.total--
      
      ElMessage({ message: 'Article deleted successfully', type: 'success' })
    } catch (error) {
      console.error('Error deleting article:', error)
      ElMessage({ message: 'Failed to delete article', type: 'error' })
    }
  }).catch(() => {
    // User cancelled
  })
}

// Handle article publishing
const handlePublish = (row) => {
  ElMessageBox.confirm(
    `Are you sure you want to publish the article "${row.title}"?`,
    'Publish Article',
    {
      confirmButtonText: 'Publish',
      cancelButtonText: 'Cancel',
      type: 'info'
    }
  ).then(async () => {
    try {
      // In a real app, we would call the API
      // await updateArticleStatus(row.id, 'published')
      
      // For now, update local data
      const index = tableData.value.findIndex(article => article.id === row.id)
      tableData.value[index].status = 'published'
      tableData.value[index].publishTime = new Date().toISOString().replace('T', ' ').substring(0, 16)
      
      ElMessage({ message: 'Article published successfully', type: 'success' })
    } catch (error) {
      console.error('Error publishing article:', error)
      ElMessage({ message: 'Failed to publish article', type: 'error' })
    }
  }).catch(() => {
    // User cancelled
  })
}

// Handle article archiving
const handleArchive = (row) => {
  ElMessageBox.confirm(
    `Are you sure you want to archive the article "${row.title}"?`,
    'Archive Article',
    {
      confirmButtonText: 'Archive',
      cancelButtonText: 'Cancel',
      type: 'warning'
    }
  ).then(async () => {
    try {
      // In a real app, we would call the API
      // await updateArticleStatus(row.id, 'archived')
      
      // For now, update local data
      const index = tableData.value.findIndex(article => article.id === row.id)
      tableData.value[index].status = 'archived'
      
      ElMessage({ message: 'Article archived successfully', type: 'success' })
    } catch (error) {
      console.error('Error archiving article:', error)
      ElMessage({ message: 'Failed to archive article', type: 'error' })
    }
  }).catch(() => {
    // User cancelled
  })
}

// Load articles on component mount
onMounted(() => {
  fetchArticles()
})
</script>

<style scoped>
.article-list-container {
  padding: 20px;
}

.search-card,
.table-card {
  margin-bottom: 20px;
}

.form-buttons {
  display: flex;
  justify-content: center;
  margin-top: 10px;
}

.cms-pagination {
  margin-top: 20px;
  display: flex;
  justify-content: center;
}
</style>