<!-- src/views/content/ArticleEdit.vue -->
<template>
  <div class="article-edit-container">
    <div class="page-header">
      <h2>{{ isEdit ? 'Edit Article' : 'Create Article' }}</h2>
      <div>
        <el-button @click="goBack">
          <el-icon><Back /></el-icon>
          Back to List
        </el-button>
      </div>
    </div>

    <el-card class="form-card">
      <el-form 
        ref="articleFormRef"
        :model="articleForm" 
        :rules="formRules"
        label-width="120px"
        label-position="top"
        @submit.prevent
      >
        <el-form-item label="Title" prop="title">
          <el-input v-model="articleForm.title" placeholder="Enter article title" />
        </el-form-item>

        <el-form-item label="Category" prop="categoryId">
          <el-select v-model="articleForm.categoryId" placeholder="Select category" style="width: 100%">
            <el-option 
              v-for="item in categories" 
              :key="item.id" 
              :label="item.name" 
              :value="item.id" 
            />
          </el-select>
        </el-form-item>

        <el-row :gutter="20">
          <el-col :xs="24" :md="12">
            <el-form-item label="Author" prop="author">
              <el-input v-model="articleForm.author" placeholder="Author name" />
            </el-form-item>
          </el-col>
          <el-col :xs="24" :md="12">
            <el-form-item label="Status" prop="status">
              <el-select v-model="articleForm.status" placeholder="Select status" style="width: 100%">
                <el-option label="Draft" value="draft" />
                <el-option label="Published" value="published" />
                <el-option label="Archived" value="archived" />
              </el-select>
            </el-form-item>
          </el-col>
        </el-row>

        <el-form-item label="Tags">
          <el-tag
            v-for="tag in articleForm.tags"
            :key="tag"
            closable
            @close="removeTag(tag)"
            class="article-tag"
          >
            {{ tag }}
          </el-tag>
          <el-input
            v-if="showTagInput"
            ref="tagInputRef"
            v-model="newTag"
            class="tag-input"
            size="small"
            @keyup.enter.native="addTag"
            @blur="addTag"
          />
          <el-button v-else class="button-new-tag" size="small" @click="showTagInputMethod">
            <el-icon><Plus /></el-icon> New Tag
          </el-button>
        </el-form-item>

        <el-form-item label="Summary" prop="summary">
          <el-input 
            v-model="articleForm.summary" 
            type="textarea" 
            placeholder="Brief summary of the article"
            :rows="3"
          />
        </el-form-item>

        <el-form-item label="Content" prop="content">
          <div class="editor-container">
            <div class="toolbar-container">
              <el-button-group>
                <el-button type="default" @click="insertHeading">H</el-button>
                <el-button type="default" @click="insertBold">B</el-button>
                <el-button type="default" @click="insertItalic">I</el-button>
                <el-button type="default" @click="insertLink">Link</el-button>
                <el-button type="default" @click="insertImage">Image</el-button>
                <el-button type="default" @click="insertList">List</el-button>
              </el-button-group>
            </div>
            <!-- In a real app, we would use a rich text editor like TinyMCE or Quill -->
            <el-input 
              v-model="articleForm.content" 
              type="textarea" 
              class="content-editor"
              placeholder="Write your article content here..."
              :rows="15"
            />
          </div>
        </el-form-item>

        <el-form-item label="Featured Image">
          <el-upload
            class="image-upload"
            action=""
            list-type="picture-card"
            :auto-upload="false"
            :limit="1"
            :on-change="handleImageChange"
            :on-remove="handleImageRemove"
            :file-list="fileList"
          >
            <el-icon><Plus /></el-icon>
          </el-upload>
        </el-form-item>

        <el-form-item>
          <div class="form-actions">
            <el-button type="primary" :loading="loading" @click="saveArticle">
              {{ isEdit ? 'Update' : 'Create' }}
            </el-button>
            <el-button type="success" @click="saveAndPublish" v-if="articleForm.status !== 'published'">
              Save & Publish
            </el-button>
            <el-button @click="resetForm">Reset</el-button>
          </div>
        </el-form-item>
      </el-form>
    </el-card>
  </div>
</template>

<script setup>
import { ref, reactive, computed, onMounted, nextTick } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { ElMessage, ElMessageBox } from 'element-plus'
import { Back, Plus } from '@element-plus/icons-vue'
import { getArticleById, createArticle, updateArticle } from '@/api/content'

const route = useRoute()
const router = useRouter()
const loading = ref(false)
const articleFormRef = ref(null)

// Tag input related
const tagInputRef = ref(null)
const newTag = ref('')
const showTagInput = ref(false)

// Upload related
const fileList = ref([])

// Determine if editing or creating
const articleId = computed(() => route.query.id)
const isEdit = computed(() => !!articleId.value)

// Form model
const articleForm = reactive({
  title: '',
  categoryId: '',
  author: '',
  status: 'draft',
  summary: '',
  content: '',
  tags: [],
  featuredImage: ''
})

// Form validation rules
const formRules = {
  title: [
    { required: true, message: 'Please enter article title', trigger: 'blur' },
    { min: 3, max: 100, message: 'Title must be between 3 and 100 characters', trigger: 'blur' }
  ],
  categoryId: [
    { required: true, message: 'Please select a category', trigger: 'change' }
  ],
  author: [
    { required: true, message: 'Please enter author name', trigger: 'blur' }
  ],
  status: [
    { required: true, message: 'Please select a status', trigger: 'change' }
  ],
  content: [
    { required: true, message: 'Please enter article content', trigger: 'blur' },
    { min: 10, message: 'Content must be at least 10 characters', trigger: 'blur' }
  ],
  summary: [
    { max: 500, message: 'Summary cannot exceed 500 characters', trigger: 'blur' }
  ]
}

// Mock categories
const categories = ref([
  { id: 1, name: 'Technology' },
  { id: 2, name: 'Business' },
  { id: 3, name: 'Design' },
  { id: 4, name: 'Marketing' }
])

// Fetch article data if editing
const fetchArticleData = async () => {
  if (!isEdit.value) return
  
  loading.value = true
  try {
    // In a real app, we would fetch from API
    // const response = await getArticleById(articleId.value)
    
    // Mock data for editing
    const mockArticle = {
      id: articleId.value,
      title: 'Introduction to Content Management Systems',
      categoryId: 1,
      author: 'Admin',
      status: 'published',
      summary: 'A comprehensive guide to understanding CMS platforms.',
      content: `# Introduction to CMS\n\nContent Management Systems (CMS) are software applications that help users create, manage, and modify content on websites without specialized technical knowledge.\n\n## Key Features\n\n- User-friendly content editing\n- Media management\n- User roles and permissions\n- Templates and themes\n\n## Popular CMS Platforms\n\n1. WordPress\n2. Drupal\n3. Joomla\n4. Strapi`,
      tags: ['CMS', 'Technology', 'Web Development'],
      featuredImage: 'https://example.com/images/cms-intro.jpg',
      createTime: '2023-11-24 10:30',
      updateTime: '2023-11-24 14:36'
    }
    
    // Populate the form with fetched data
    Object.assign(articleForm, {
      title: mockArticle.title,
      categoryId: mockArticle.categoryId,
      author: mockArticle.author,
      status: mockArticle.status,
      summary: mockArticle.summary,
      content: mockArticle.content,
      tags: mockArticle.tags
    })
    
    // Set featured image if exists
    if (mockArticle.featuredImage) {
      fileList.value = [{
        name: 'featured-image',
        url: mockArticle.featuredImage
      }]
      articleForm.featuredImage = mockArticle.featuredImage
    }
    
  } catch (error) {
    console.error('Error fetching article:', error)
    ElMessage({ message: 'Failed to load article data', type: 'error' })
  } finally {
    loading.value = false
  }
}

// Navigate back to article list
const goBack = () => {
  router.push('/content/article-list')
}

// Save article
const saveArticle = async () => {
  articleFormRef.value.validate(async (valid) => {
    if (valid) {
      loading.value = true
      try {
        // Prepare data for API
        const formData = { ...articleForm }
        
        // In a real app, we would submit to API
        if (isEdit.value) {
          // await updateArticle(articleId.value, formData)
          // Mock success
          ElMessage({ message: 'Article updated successfully', type: 'success' })
        } else {
          // await createArticle(formData)
          // Mock success
          ElMessage({ message: 'Article created successfully', type: 'success' })
        }
        
        // Navigate back to list
        router.push('/content/article-list')
      } catch (error) {
        console.error('Error saving article:', error)
        ElMessage({ message: 'Failed to save article', type: 'error' })
      } finally {
        loading.value = false
      }
    }
  })
}

// Save and publish
const saveAndPublish = () => {
  articleForm.status = 'published'
  saveArticle()
}

// Reset form
const resetForm = () => {
  ElMessageBox.confirm(
    'Are you sure you want to reset all fields? Unsaved changes will be lost.',
    'Warning',
    {
      confirmButtonText: 'Yes',
      cancelButtonText: 'No',
      type: 'warning'
    }
  ).then(() => {
    if (isEdit.value) {
      fetchArticleData()
    } else {
      articleFormRef.value.resetFields()
      articleForm.tags = []
      fileList.value = []
    }
    ElMessage({ message: 'Form has been reset', type: 'info' })
  }).catch(() => {
    // User cancelled reset
  })
}

// Tag methods
const showTagInputMethod = () => {
  showTagInput.value = true
  nextTick(() => {
    tagInputRef.value?.focus()
  })
}

const addTag = () => {
  if (newTag.value) {
    if (articleForm.tags.indexOf(newTag.value) === -1) {
      articleForm.tags.push(newTag.value)
    }
    newTag.value = ''
  }
  showTagInput.value = false
}

const removeTag = (tag) => {
  articleForm.tags = articleForm.tags.filter(t => t !== tag)
}

// Image upload methods
const handleImageChange = (file) => {
  // In a real app, we would handle file upload
  articleForm.featuredImage = URL.createObjectURL(file.raw)
}

const handleImageRemove = () => {
  articleForm.featuredImage = ''
}

// Text editor methods (simplified for demo)
const insertHeading = () => {
  articleForm.content += '\n# New Heading\n'
}

const insertBold = () => {
  articleForm.content += '**Bold Text**'
}

const insertItalic = () => {
  articleForm.content += '*Italic Text*'
}

const insertLink = () => {
  articleForm.content += '[Link Text](https://example.com)'
}

const insertImage = () => {
  articleForm.content += '![Image Description](https://example.com/image.jpg)'
}

const insertList = () => {
  articleForm.content += '\n- List item 1\n- List item 2\n- List item 3\n'
}

// Load article data on component mount if editing
onMounted(() => {
  fetchArticleData()
})
</script>

<style scoped>
.article-edit-container {
  padding: 20px;
}

.page-header {
  display: flex;
  justify-content: space-between;
  margin-bottom: 20px;
  align-items: center;
}

.form-card {
  margin-bottom: 20px;
}

.editor-container {
  border: 1px solid #dcdfe6;
  border-radius: 4px;
}

.toolbar-container {
  border-bottom: 1px solid #dcdfe6;
  padding: 8px;
  background-color: #f5f7fa;
}

.content-editor {
  border: none;
}

.form-actions {
  display: flex;
  gap: 10px;
}

.article-tag {
  margin-right: 8px;
  margin-bottom: 8px;
}

.tag-input {
  width: 100px;
  margin-right: 8px;
  vertical-align: bottom;
}

.button-new-tag {
  height: 32px;
  margin-right: 8px;
}

.image-upload .el-upload--picture-card {
  width: 200px;
  height: 200px;
  line-height: 200px;
}

/* Override Element Plus textarea styles for editor */
.content-editor :deep(.el-textarea__inner) {
  border: none;
  padding: 12px;
  min-height: 300px;
}
</style>