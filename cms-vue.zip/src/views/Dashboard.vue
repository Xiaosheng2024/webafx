<!-- src/views/Dashboard.vue -->
<template>
  <div class="dashboard-container">
    <div class="page-header">
      <h2>Dashboard</h2>
    </div>

    <!-- Statistics Cards -->
    <el-row :gutter="20">
      <el-col :xs="24" :sm="12" :md="6">
        <el-card class="stat-card">
          <div class="stat-icon">
            <el-icon><Document /></el-icon>
          </div>
          <div class="stat-content">
            <div class="stat-value">{{ statistics.articles }}</div>
            <div class="stat-label">Articles</div>
          </div>
        </el-card>
      </el-col>
      <el-col :xs="24" :sm="12" :md="6">
        <el-card class="stat-card">
          <div class="stat-icon">
            <el-icon><Folder /></el-icon>
          </div>
          <div class="stat-content">
            <div class="stat-value">{{ statistics.categories }}</div>
            <div class="stat-label">Categories</div>
          </div>
        </el-card>
      </el-col>
      <el-col :xs="24" :sm="12" :md="6">
        <el-card class="stat-card">
          <div class="stat-icon">
            <el-icon><User /></el-icon>
          </div>
          <div class="stat-content">
            <div class="stat-value">{{ statistics.users }}</div>
            <div class="stat-label">Users</div>
          </div>
        </el-card>
      </el-col>
      <el-col :xs="24" :sm="12" :md="6">
        <el-card class="stat-card">
          <div class="stat-icon">
            <el-icon><View /></el-icon>
          </div>
          <div class="stat-content">
            <div class="stat-value">{{ formatNumber(statistics.views) }}</div>
            <div class="stat-label">Total Views</div>
          </div>
        </el-card>
      </el-col>
    </el-row>

    <!-- Chart section -->
    <el-row :gutter="20">
      <el-col :xs="24" :lg="16">
        <el-card class="chart-card">
          <template #header>
            <div class="card-header">
              <span>Views Trend (Last 7 Days)</span>
            </div>
          </template>
          <div class="chart-container" ref="viewsChartRef"></div>
        </el-card>
      </el-col>
      <el-col :xs="24" :lg="8">
        <el-card class="chart-card">
          <template #header>
            <div class="card-header">
              <span>Content Distribution</span>
            </div>
          </template>
          <div class="chart-container" ref="pieChartRef"></div>
        </el-card>
      </el-col>
    </el-row>

    <!-- Recent articles section -->
    <el-card class="recent-card">
      <template #header>
        <div class="card-header">
          <span>Recent Articles</span>
          <router-link to="/content/article-list">
            <el-button type="primary" text>View All</el-button>
          </router-link>
        </div>
      </template>
      <el-table :data="recentArticles" style="width: 100%">
        <el-table-column prop="title" label="Title" min-width="180" show-overflow-tooltip />
        <el-table-column prop="author" label="Author" width="120" />
        <el-table-column prop="categoryName" label="Category" width="120" />
        <el-table-column prop="createTime" label="Published" width="180" sortable />
        <el-table-column prop="views" label="Views" width="100" sortable />
        <el-table-column label="Status" width="100">
          <template #default="scope">
            <el-tag :type="getStatusType(scope.row.status)">
              {{ scope.row.status }}
            </el-tag>
          </template>
        </el-table-column>
        <el-table-column fixed="right" label="Actions" width="120">
          <template #default="scope">
            <router-link :to="`/content/article-edit?id=${scope.row.id}`">
              <el-button type="primary" size="small" link>Edit</el-button>
            </router-link>
          </template>
        </el-table-column>
      </el-table>
    </el-card>
  </div>
</template>

<script setup>
import { ref, onMounted, onBeforeUnmount } from 'vue'
import { Document, Folder, User, View } from '@element-plus/icons-vue'
import * as echarts from 'echarts/core'
import { LineChart, PieChart } from 'echarts/charts'
import {
  TitleComponent,
  TooltipComponent,
  LegendComponent,
  GridComponent
} from 'echarts/components'
import { CanvasRenderer } from 'echarts/renderers'
import { getDashboardStats, getRecentArticles } from '@/api/content'

// Register ECharts components
echarts.use([
  TitleComponent,
  TooltipComponent,
  LegendComponent,
  GridComponent,
  LineChart,
  PieChart,
  CanvasRenderer
])

// Refs for chart containers
const viewsChartRef = ref(null)
const pieChartRef = ref(null)

// Chart instances
let viewsChart = null
let pieChart = null

// Data for dashboard
const statistics = ref({
  articles: 0,
  categories: 0,
  users: 0,
  views: 0
})

const recentArticles = ref([])

// Format large numbers with commas
const formatNumber = (num) => {
  return num.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',')
}

// Get status type for element-ui tag
const getStatusType = (status) => {
  switch (status) {
    case 'published':
      return 'success'
    case 'draft':
      return 'info'
    case 'archived':
      return 'warning'
    default:
      return 'info'
  }
}

// Initialize charts
const initCharts = () => {
  // Views trend chart
  viewsChart = echarts.init(viewsChartRef.value)
  const viewsOption = {
    tooltip: {
      trigger: 'axis'
    },
    legend: {
      data: ['Page Views', 'Article Views']
    },
    grid: {
      left: '3%',
      right: '4%',
      bottom: '3%',
      containLabel: true
    },
    xAxis: {
      type: 'category',
      boundaryGap: false,
      data: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun']
    },
    yAxis: {
      type: 'value'
    },
    series: [
      {
        name: 'Page Views',
        type: 'line',
        data: [120, 132, 101, 134, 90, 230, 210],
        smooth: true,
        lineStyle: {
          width: 3
        },
        areaStyle: {
          opacity: 0.2
        },
        itemStyle: {
          color: '#409EFF'
        }
      },
      {
        name: 'Article Views',
        type: 'line',
        data: [45, 82, 56, 77, 65, 112, 98],
        smooth: true,
        lineStyle: {
          width: 3
        },
        areaStyle: {
          opacity: 0.2
        },
        itemStyle: {
          color: '#67C23A'
        }
      }
    ]
  }
  viewsChart.setOption(viewsOption)

  // Content distribution pie chart
  pieChart = echarts.init(pieChartRef.value)
  const pieOption = {
    tooltip: {
      trigger: 'item',
      formatter: '{a} <br/>{b}: {c} ({d}%)'
    },
    legend: {
      orient: 'vertical',
      right: 10,
      top: 'center',
      data: ['Technology', 'Business', 'Design', 'Marketing', 'Other']
    },
    series: [
      {
        name: 'Category',
        type: 'pie',
        radius: ['50%', '70%'],
        center: ['40%', '50%'],
        avoidLabelOverlap: false,
        itemStyle: {
          borderRadius: 10,
          borderColor: '#fff',
          borderWidth: 2
        },
        label: {
          show: false,
          position: 'center'
        },
        emphasis: {
          label: {
            show: true,
            fontSize: 12,
            fontWeight: 'bold'
          }
        },
        labelLine: {
          show: false
        },
        data: [
          { value: 25, name: 'Technology' },
          { value: 18, name: 'Business' },
          { value: 12, name: 'Design' },
          { value: 8, name: 'Marketing' },
          { value: 5, name: 'Other' }
        ]
      }
    ]
  }
  pieChart.setOption(pieOption)

  // Resize charts on window resize
  window.addEventListener('resize', handleResize)
}

const handleResize = () => {
  viewsChart && viewsChart.resize()
  pieChart && pieChart.resize()
}

// Fetch dashboard data
const fetchDashboardData = async () => {
  try {
    // In a real app, we would call the API
    // const response = await getDashboardStats()
    
    // For now, use mock data
    statistics.value = {
      articles: 68,
      categories: 12,
      users: 24,
      views: 15782
    }
  } catch (error) {
    console.error('Error fetching dashboard stats:', error)
  }
}

// Fetch recent articles
const fetchRecentArticles = async () => {
  try {
    // In a real app, we would call the API
    // const response = await getRecentArticles()
    
    // For now, use mock data
    recentArticles.value = [
      {
        id: 1,
        title: 'Introduction to Content Management Systems',
        author: 'Admin User',
        categoryName: 'Technology',
        createTime: '2023-11-24 10:30',
        views: 132,
        status: 'published'
      },
      {
        id: 2,
        title: 'Business Strategies for 2024',
        author: 'Content Editor',
        categoryName: 'Business',
        createTime: '2023-11-23 14:15',
        views: 98,
        status: 'published'
      },
      {
        id: 3,
        title: 'Modern UI/UX Design Principles',
        author: 'Design Team',
        categoryName: 'Design',
        createTime: '2023-11-22 09:45',
        views: 76,
        status: 'published'
      },
      {
        id: 4,
        title: 'Marketing Trends to Watch',
        author: 'Marketing Manager',
        categoryName: 'Marketing',
        createTime: '2023-11-21 16:20',
        views: 65,
        status: 'draft'
      },
      {
        id: 5,
        title: 'Database Optimization Techniques',
        author: 'Tech Writer',
        categoryName: 'Technology',
        createTime: '2023-11-20 11:10',
        views: 112,
        status: 'published'
      }
    ]
  } catch (error) {
    console.error('Error fetching recent articles:', error)
  }
}

// Lifecycle hooks
onMounted(() => {
  fetchDashboardData()
  fetchRecentArticles()
  // Initialize charts with a slight delay to ensure DOM is ready
  setTimeout(() => {
    initCharts()
  }, 50)
})

onBeforeUnmount(() => {
  // Clean up charts and event listeners
  if (viewsChart) {
    viewsChart.dispose()
    viewsChart = null
  }
  if (pieChart) {
    pieChart.dispose()
    pieChart = null
  }
  window.removeEventListener('resize', handleResize)
})
</script>

<style scoped>
.dashboard-container {
  padding: 20px;
}

.stat-card {
  display: flex;
  padding: 20px;
  margin-bottom: 20px;
}

.stat-icon {
  display: flex;
  align-items: center;
  justify-content: center;
  width: 60px;
  height: 60px;
  border-radius: 50%;
  color: white;
  font-size: 24px;
  margin-right: 15px;
}

.stat-card:nth-child(1) .stat-icon {
  background-color: #409EFF;
}

.stat-card:nth-child(2) .stat-icon {
  background-color: #67C23A;
}

.stat-card:nth-child(3) .stat-icon {
  background-color: #E6A23C;
}

.stat-card:nth-child(4) .stat-icon {
  background-color: #F56C6C;
}

.stat-content {
  flex: 1;
}

.stat-value {
  font-size: 24px;
  font-weight: bold;
  line-height: 1.2;
  color: #303133;
}

.stat-label {
  font-size: 14px;
  color: #909399;
  margin-top: 5px;
}

.chart-card {
  margin-bottom: 20px;
}

.chart-container {
  height: 300px;
  width: 100%;
}

.card-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.recent-card {
  margin-bottom: 20px;
}
</style>