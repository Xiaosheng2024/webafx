// src/utils/request.js
import axios from 'axios'
import { ElMessage, ElMessageBox } from 'element-plus'
import { getToken, clearAuth } from '@/utils/auth'
import router from '@/router'

// Create axios instance
const service = axios.create({
  baseURL: import.meta.env.VITE_API_BASE_URL || '/api', 
  timeout: 15000 // Request timeout: 15 seconds
})

// Request interceptor
service.interceptors.request.use(
  config => {
    const token = getToken()
    if (token) {
      config.headers['Authorization'] = `Bearer ${token}`
    }
    return config
  },
  error => {
    console.error('Request error:', error)
    return Promise.reject(error)
  }
)

// Response interceptor
service.interceptors.response.use(
  response => {
    const res = response.data
    
    // Check if the response has a success status code and contains 'code' field
    if (res.code !== undefined && res.code !== 200) {
      // Handle specific error codes
      switch (res.code) {
        case 401:
          // Token expired or invalid
          ElMessageBox.confirm(
            'Your session has expired, please login again',
            'Session Expired',
            {
              confirmButtonText: 'Re-login',
              cancelButtonText: 'Cancel',
              type: 'warning'
            }
          ).then(() => {
            clearAuth()
            router.push('/login')
          })
          break
        case 403:
          // Permission denied
          ElMessage({
            message: res.message || 'Permission denied',
            type: 'error',
            duration: 5000
          })
          break
        default:
          // Other errors
          ElMessage({
            message: res.message || 'Error',
            type: 'error',
            duration: 5000
          })
      }
      return Promise.reject(new Error(res.message || 'Error'))
    }
    
    // If response is direct data without code/data structure
    if (!res.code) {
      return res
    }
    
    // Normal response
    return res.data
  },
  error => {
    // Handle HTTP errors
    const { status, data } = error.response || {}
    let message = 'Connection error, please try again'
    
    if (status === 401) {
      // Unauthorized, clear auth and redirect to login
      message = 'Unauthorized, please log in again'
      clearAuth()
      router.push('/login')
    } else if (status === 403) {
      message = 'Forbidden: you do not have permission to access this resource'
    } else if (status === 404) {
      message = 'Request resource not found'
    } else if (status === 500) {
      message = 'Server error, please try again later'
    } else if (data && data.message) {
      message = data.message
    }
    
    ElMessage({
      message,
      type: 'error',
      duration: 5000
    })
    
    return Promise.reject(error)
  }
)

export default service