// src/utils/auth.js
/**
 * Token and user authentication utilities
 */

const TokenKey = 'cms_token'
const UserInfoKey = 'userInfo'

/**
 * Get token from localStorage
 */
export function getToken() {
  return localStorage.getItem(TokenKey)
}

/**
 * Set token to localStorage
 * @param {string} token - Authentication token
 * @param {number} expireTime - Token expiry time in milliseconds (0 for session only)
 */
export function setToken(token, expireTime = 0) {
  localStorage.setItem(TokenKey, token)
  
  // If expireTime is set, store expiry timestamp
  if (expireTime > 0) {
    const expireAt = Date.now() + expireTime
    localStorage.setItem('tokenExpireAt', expireAt.toString())
  } else {
    localStorage.removeItem('tokenExpireAt')
  }
}

/**
 * Remove token from localStorage
 */
export function removeToken() {
  localStorage.removeItem(TokenKey)
  localStorage.removeItem('tokenExpireAt')
}

/**
 * Check if token is expired
 */
export function isTokenExpired() {
  const expireAt = localStorage.getItem('tokenExpireAt')
  if (!expireAt) return false
  
  return parseInt(expireAt) < Date.now()
}

/**
 * Get user info from localStorage
 */
export function getUserInfo() {
  const userInfo = localStorage.getItem(UserInfoKey)
  return userInfo ? JSON.parse(userInfo) : null
}

/**
 * Set user info to localStorage
 * @param {Object} userInfo - User information object
 */
export function setUserInfo(userInfo) {
  localStorage.setItem(UserInfoKey, JSON.stringify(userInfo))
}

/**
 * Remove user info from localStorage
 */
export function removeUserInfo() {
  localStorage.removeItem(UserInfoKey)
}

/**
 * Check if user has specific role
 * @param {string} role - Role to check
 */
export function hasRole(role) {
  const userInfo = getUserInfo()
  return userInfo && userInfo.roles && userInfo.roles.includes(role)
}

/**
 * Clear all authentication data
 */
export function clearAuth() {
  removeToken()
  removeUserInfo()
}