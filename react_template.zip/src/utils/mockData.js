// src/utils/mockData.js
export const mockData = [
  {
    id: 1,
    name: "测试数据1",
    type: "类型A",
    status: "正常",
    createTime: "2024-01-23"
  },
  {
    id: 2,
    name: "测试数据2",
    type: "类型B",
    status: "异常",
    createTime: "2024-01-23"
  }
];

export const orderStats = {
  current: {
    totalShipments: 1285,
    shipmentTrend: 12.5,
    pendingOrders: 45,
    pendingTrend: -5.2,
    shippedOrders: 168,
    shippedTrend: 8.7
  },
  history: [
    { date: '2024-01-20', pendingOrders: 35, shippedOrders: 145 },
    { date: '2024-01-21', pendingOrders: 42, shippedOrders: 152 },
    { date: '2024-01-22', pendingOrders: 38, shippedOrders: 158 },
    { date: '2024-01-23', pendingOrders: 40, shippedOrders: 162 },
    { date: '2024-01-24', pendingOrders: 45, shippedOrders: 168 }
  ]
};

export const dailyStats = {
  totalOrders: 256,
  completedOrders: 187,
  processingOrders: 69,
  pdaStatus: [
    {
      material: "物料A",
      scanning: 15,
      total: 45
    },
    {
      material: "物料B",
      scanning: 8,
      total: 32
    },
    {
      material: "物料C",
      scanning: 12,
      total: 28
    },
    {
      material: "物料D",
      scanning: 6,
      total: 18
    }
  ]
};

export const materialStats = [
  {
    type: "物料A",
    count: 456,
    trend: 5.2
  },
  {
    type: "物料B",
    count: 324,
    trend: -2.8
  },
  {
    type: "物料C",
    count: 289,
    trend: 3.4
  },
  {
    type: "物料D",
    count: 167,
    trend: 1.5
  }
];

export const weeklyStats = [
  { date: '2024-01-22', completed: 156, total: 180 },
  { date: '2024-01-23', completed: 168, total: 195 },
  { date: '2024-01-24', completed: 172, total: 205 },
  { date: '2024-01-25', completed: 187, total: 256 },
  { date: '2024-01-26', completed: 0, total: 0 },
  { date: '2024-01-27', completed: 0, total: 0 },
  { date: '2024-01-28', completed: 0, total: 0 }
];

export const weeklyMaterialData = [
  {
    materialA: { completed: 45, total: 50 },
    materialB: { completed: 32, total: 35 },
    materialC: { completed: 28, total: 30 },
    materialD: { completed: 18, total: 20 }
  },
  {
    materialA: { completed: 42, total: 48 },
    materialB: { completed: 30, total: 38 },
    materialC: { completed: 25, total: 32 },
    materialD: { completed: 15, total: 22 }
  },
  {
    materialA: { completed: 48, total: 52 },
    materialB: { completed: 35, total: 40 },
    materialC: { completed: 30, total: 35 },
    materialD: { completed: 20, total: 25 }
  },
  {
    materialA: { completed: 40, total: 55 },
    materialB: { completed: 28, total: 42 },
    materialC: { completed: 22, total: 38 },
    materialD: { completed: 16, total: 28 }
  },
  // Empty data for future days will show as "- -"
  {},
  {},
  {}
];