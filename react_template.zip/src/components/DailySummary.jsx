// src/components/DailySummary.jsx
import React from 'react';

const StatusCard = ({ title, count, total }) => (
  <div className="bg-white rounded-lg p-4 shadow-sm">
    <h3 className="text-sm text-gray-500 mb-2">{title}</h3>
    <div className="flex items-baseline">
      <span className="text-2xl font-semibold">{count}</span>
      {total && <span className="text-sm text-gray-400 ml-2">/ {total}</span>}
    </div>
  </div>
);

const PdaStatusCard = ({ material, scanning, total }) => (
  <div className="bg-white rounded-lg p-4 shadow-sm">
    <h3 className="text-sm text-gray-500 mb-2">{material}</h3>
    <div className="flex flex-col">
      <div className="flex items-center justify-between">
        <span>正在扫描复核</span>
        <span className="font-semibold">{scanning}</span>
      </div>
      <div className="w-full bg-gray-200 rounded-full h-2 mt-2">
        <div 
          className="bg-blue-500 rounded-full h-2" 
          style={{ width: `${(scanning / total) * 100}%` }}
        />
      </div>
    </div>
  </div>
);

const DailySummary = ({ dailyStats }) => {
  return (
    <div className="grid gap-4">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <StatusCard 
          title="今日订单总数" 
          count={dailyStats.totalOrders} 
        />
        <StatusCard 
          title="完成订单" 
          count={dailyStats.completedOrders}
          total={dailyStats.totalOrders}
        />
        <StatusCard 
          title="处理中订单" 
          count={dailyStats.processingOrders}
          total={dailyStats.totalOrders}
        />
      </div>
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {dailyStats.pdaStatus.map((status, index) => (
          <PdaStatusCard
            key={index}
            material={status.material}
            scanning={status.scanning}
            total={status.total}
          />
        ))}
      </div>
    </div>
  );
};

export default DailySummary;