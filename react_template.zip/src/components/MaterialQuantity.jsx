// src/components/MaterialQuantity.jsx
import React from 'react';

const MaterialQuantity = ({ materials }) => {
  return (
    <div className="bg-white rounded-lg p-4 shadow-sm">
      <h2 className="text-base font-medium mb-2">物料数量统计</h2>
      <div className="space-y-3">
        {materials.map((material, index) => (
          <div 
            key={index}
            className="flex items-center justify-between p-2 bg-gray-50 rounded"
          >
            <span className="text-sm text-gray-600">{material.type}</span>
            <div className="flex items-center gap-2">
              <span className="font-medium">{material.count}</span>
              <span className={`text-xs ${
                material.trend >= 0 ? 'text-green-500' : 'text-red-500'
              }`}>
                {material.trend > 0 ? '↑' : '↓'} {Math.abs(material.trend)}%
              </span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default MaterialQuantity;