// src/components/MaterialProgress.jsx
import React from 'react';

const MaterialProgress = ({ pdaStatus }) => {
  return (
    <div className="bg-white rounded-lg p-4 shadow-sm">
      <h2 className="text-base font-medium mb-2">物料复核进度</h2>
      <div className="space-y-4">
        {pdaStatus.map((status, index) => (
          <div key={index} className="space-y-2">
            <div className="flex justify-between items-center">
              <span className="text-sm text-gray-500">{status.material}</span>
              <span className="text-sm font-medium">{status.scanning}/{status.total}</span>
            </div>
            <div className="w-full bg-gray-100 rounded-full h-2">
              <div 
                className="bg-blue-500 rounded-full h-2 transition-all duration-300"
                style={{ width: `${(status.scanning / status.total) * 100}%` }}
              />
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default MaterialProgress;