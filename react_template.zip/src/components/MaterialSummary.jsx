// src/components/MaterialSummary.jsx
import React from 'react';

const MaterialCard = ({ type, count, trend }) => (
  <div className="bg-white rounded-lg p-4 shadow-sm">
    <h3 className="text-sm text-gray-500 mb-2">{type}</h3>
    <div className="flex items-baseline justify-between">
      <span className="text-2xl font-semibold">{count}</span>
      <span className={`text-sm ${trend >= 0 ? 'text-green-500' : 'text-red-500'}`}>
        {trend > 0 ? '↑' : '↓'} {Math.abs(trend)}%
      </span>
    </div>
  </div>
);

const MaterialSummary = ({ materials }) => {
  return (
    <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
      {materials.map((material, index) => (
        <MaterialCard
          key={index}
          type={material.type}
          count={material.count}
          trend={material.trend}
        />
      ))}
    </div>
  );
};

export default MaterialSummary;