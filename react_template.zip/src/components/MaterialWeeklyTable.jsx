// src/components/MaterialWeeklyTable.jsx
import React, { useEffect, useState } from 'react';

const MaterialWeeklyTable = ({ data }) => {
  const days = ['周一', '周二', '周三', '周四', '周五', '周六', '周日'];
  const materials = ['A', 'B', 'C', 'D'];
  const currentDayIndex = new Date().getDay() || 7;

  return (
    <div className="overflow-x-auto">
      <table className="w-full border-collapse">
        <thead>
          <tr>
            <th className="py-2 px-4 bg-gray-50 border-b border-gray-200"></th>
            {materials.map(material => (
              <th key={material} className="py-2 px-4 bg-gray-50 border-b border-gray-200 text-center">
                物料{material}
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {days.map((day, index) => (
            <tr key={day} className={index % 2 === 0 ? 'bg-white' : 'bg-gray-50'}>
              <td className="py-3 px-4 border-b border-gray-200 font-medium">{day}</td>
              {materials.map(material => (
                <td 
                  key={`${day}-${material}`} 
                  className="py-3 px-4 border-b border-gray-200 text-center"
                >
                  {index < currentDayIndex ? (
                    <div className="flex flex-col items-center">
                      <span className="font-semibold">
                        {data[index]?.[`material${material}`]?.completed || 0}
                      </span>
                      <span className="text-sm text-gray-500">
                        总量: {data[index]?.[`material${material}`]?.total || 0}
                      </span>
                    </div>
                  ) : (
                    '- -'
                  )}
                </td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default MaterialWeeklyTable;