// src/components/StatsCards.jsx
import React from 'react';

const StatsCard = ({ title, value, subtext, trend }) => (
  <div className="bg-white rounded-lg p-4 shadow-sm">
    <h3 className="text-sm text-gray-500 mb-2">{title}</h3>
    <div className="flex items-baseline">
      <span className="text-2xl font-semibold">{value}</span>
      {trend && (
        <span className={`ml-2 text-sm ${
          trend > 0 ? 'text-green-500' : 'text-red-500'
        }`}>
          {trend > 0 ? '↑' : '↓'} {Math.abs(trend)}%
        </span>
      )}
    </div>
    {subtext && <p className="text-sm text-gray-400 mt-1">{subtext}</p>}
  </div>
);

const StatsCards = ({ stats }) => {
  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
      <StatsCard
        title="总发货量"
        value={stats.totalShipments}
        subtext="本月累计"
        trend={stats.shipmentTrend}
      />
      <StatsCard
        title="待发货订单"
        value={stats.pendingOrders}
        trend={stats.pendingTrend}
      />
      <StatsCard
        title="已发货订单"
        value={stats.shippedOrders}
        trend={stats.shippedTrend}
      />
    </div>
  );
};

export default StatsCards;