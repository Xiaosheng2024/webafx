// src/components/Header.jsx
import React from 'react';

const Header = () => {
  return (
    <header className="bg-white shadow-[0_2px_4px_rgba(0,0,0,0.1)] px-5 py-4 mb-5">
      <h1 className="text-xl font-semibold">数据管理系统</h1>
    </header>
  );
};

export default Header;