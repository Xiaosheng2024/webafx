// src/components/SearchBar.jsx
import React from 'react';

const SearchBar = ({ value, onSearch, onAdd }) => {
  return (
    <div className="flex gap-3">
      <div className="flex-1 flex">
        <input
          type="text"
          value={value}
          onChange={(e) => onSearch(e.target.value)}
          placeholder="搜索名称、类型..."
          className="flex-1 px-3 py-2 border border-[#ddd] rounded-l-md focus:outline-none focus:border-[#1890ff]"
        />
        <button
          onClick={() => onSearch(value)}
          className="px-4 py-2 bg-[#1890ff] text-white rounded-r-md hover:bg-[#40a9ff] transition-colors"
        >
          搜索
        </button>
      </div>
      <button
        onClick={onAdd}
        className="px-4 py-2 bg-[#1890ff] text-white rounded-md hover:bg-[#40a9ff] transition-colors"
      >
        新增
      </button>
    </div>
  );
};

export default SearchBar;