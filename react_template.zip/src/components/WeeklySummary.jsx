// src/components/WeeklySummary.jsx
import React, { useEffect, useState } from 'react';
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer
} from 'recharts';

const WeeklySummary = ({ weeklyData, refreshInterval = 5000 }) => {
  const [data, setData] = useState(weeklyData);

  useEffect(() => {
    const timer = setInterval(() => {
      setData(weeklyData);
    }, refreshInterval);

    return () => clearInterval(timer);
  }, [weeklyData, refreshInterval]);

  const days = ['周一', '周二', '周三', '周四', '周五', '周六', '周日'];
  const currentDayIndex = new Date().getDay() || 7;

  const formatData = data.map((item, index) => ({
    ...item,
    name: days[index],
    // Only show data for past and current days
    completed: index < currentDayIndex ? item.completed : undefined,
    total: index < currentDayIndex ? item.total : undefined,
  }));

  return (
    <div className="bg-white p-4 rounded-lg shadow-sm">
      <h2 className="text-lg font-medium mb-4">本周订单汇总</h2>
      <ResponsiveContainer width="100%" height={250}>
        <LineChart data={formatData}>
          <CartesianGrid strokeDasharray="3 3" />
          <XAxis dataKey="name" />
          <YAxis />
          <Tooltip />
          <Legend />
          <Line
            type="monotone"
            dataKey="completed"
            name="已完成订单"
            stroke="#1890ff"
            strokeWidth={2}
            dot={{ r: 4 }}
          />
          <Line
            type="monotone"
            dataKey="total"
            name="总订单数"
            stroke="#722ed1"
            strokeWidth={2}
            dot={{ r: 4 }}
          />
        </LineChart>
      </ResponsiveContainer>
    </div>
  );
};

export default WeeklySummary;