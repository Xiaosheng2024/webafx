// src/App.jsx
import { useState, useEffect } from 'react';
import Header from './components/Header';
import StatsCards from './components/StatsCards';
import OrderChart from './components/OrderChart';
import MaterialProgress from './components/MaterialProgress';
import MaterialQuantity from './components/MaterialQuantity';
import WeeklySummary from './components/WeeklySummary';
import MaterialWeeklyTable from './components/MaterialWeeklyTable';
import { orderStats, dailyStats, materialStats, weeklyStats, weeklyMaterialData } from './utils/mockData';

function App() {
  const [weeklyData, setWeeklyData] = useState(weeklyStats);
  const [materialData, setMaterialData] = useState(weeklyMaterialData);

  useEffect(() => {
    const timer = setInterval(() => {
      setWeeklyData(prev => [...prev]);
      setMaterialData(prev => [...prev]);
    }, 5000);

    return () => clearInterval(timer);
  }, []);

  return (
    <div className="min-h-screen bg-[#f0f2f5]">
      <Header />
      <main className="container mx-auto px-2 py-1">
        <div className="grid grid-cols-12 gap-2">
          {/* Left Column - 4 columns wide */}
          <div className="col-span-4 space-y-2">
            {/* Total Orders Summary */}
            <div className="bg-white rounded-lg p-3 shadow-sm">
              <div className="grid grid-cols-3 gap-3">
                <div>
                  <h3 className="text-sm text-gray-500">今日订单总数</h3>
                  <div className="text-2xl font-semibold mt-1">{dailyStats.totalOrders}</div>
                </div>
                <div>
                  <h3 className="text-sm text-gray-500">完成订单</h3>
                  <div className="text-2xl font-semibold mt-1">{dailyStats.completedOrders}</div>
                </div>
                <div>
                  <h3 className="text-sm text-gray-500">处理中订单</h3>
                  <div className="text-2xl font-semibold mt-1">{dailyStats.processingOrders}</div>
                </div>
              </div>
            </div>
            
            {/* Material Progress */}
            <MaterialProgress pdaStatus={dailyStats.pdaStatus} />
            
            {/* Material Quantity */}
            <MaterialQuantity materials={materialStats} />
          </div>

          {/* Right Column - 8 columns wide */}
          <div className="col-span-8 space-y-2">
            {/* Order Stats Cards */}
            <div className="bg-white rounded-lg p-3 shadow-sm">
              <h2 className="text-base font-medium mb-2">订单统计</h2>
              <StatsCards stats={orderStats.current} />
            </div>

            {/* Charts Grid */}
            <div className="grid grid-cols-2 gap-2">
              {/* Order Trend Chart */}
              <div className="bg-white rounded-lg p-3 shadow-sm">
                <h2 className="text-base font-medium mb-2">订单趋势分析</h2>
                <OrderChart data={orderStats.history} />
              </div>

              {/* Weekly Summary */}
              <div className="bg-white rounded-lg p-3 shadow-sm">
                <h2 className="text-base font-medium mb-2">本周订单汇总</h2>
                <WeeklySummary weeklyData={weeklyData} />
              </div>
            </div>

            {/* Weekly Material Table */}
            <div className="bg-white rounded-lg p-3 shadow-sm">
              <h2 className="text-base font-medium mb-2">每周物料统计</h2>
              <MaterialWeeklyTable data={materialData} />
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}

export default App;