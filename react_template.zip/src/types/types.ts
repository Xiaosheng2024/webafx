// src/types/types.ts
export interface DataItem {
  id: number;
  name: string;
  type: string;
  status: '正常' | '异常';
  createTime: string;
}

export interface SearchBarProps {
  value: string;
  onSearch: (text: string) => void;
  onAdd: () => void;
}

export interface DataTableProps {
  data: DataItem[];
  onEdit: (id: number) => void;
  onDelete: (id: number) => void;
}

export interface OrderStats {
  totalShipments: number;
  shipmentTrend: number;
  pendingOrders: number;
  pendingTrend: number;
  shippedOrders: number;
  shippedTrend: number;
}

export interface StatsCardsProps {
  stats: OrderStats;
}

export interface OrderHistory {
  date: string;
  pendingOrders: number;
  shippedOrders: number;
}

export interface OrderChartProps {
  data: OrderHistory[];
}