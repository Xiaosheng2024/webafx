// src/utils/auth.js
import Cookies from 'js-cookie'

const TOKEN_KEY = 'cms_token'
const TOKEN_EXPIRY_DAYS = 7

export function getToken() {
  return Cookies.get(TOKEN_KEY)
}

export function setToken(token, rememberMe = false) {
  if (rememberMe) {
    return Cookies.set(TOKEN_KEY, token, { expires: TOKEN_EXPIRY_DAYS })
  } else {
    return Cookies.set(TOKEN_KEY, token)
  }
}

export function removeToken() {
  return Cookies.remove(TOKEN_KEY)
}

export function isTokenExpired() {
  const token = getToken()
  if (!token) return true

  try {
    // Simple JWT expiration check (assumes JWT format)
    const payload = JSON.parse(atob(token.split('.')[1]))
    const expiry = payload.exp * 1000  // Convert to milliseconds
    return Date.now() >= expiry
  } catch (e) {
    console.error('Failed to check token expiry:', e)
    return true
  }
}

export function getUserInfo() {
  const token = getToken()
  if (!token) return null

  try {
    // Extract user info from token payload
    const payload = JSON.parse(atob(token.split('.')[1]))
    return {
      id: payload.sub,
      username: payload.username,
      name: payload.name,
      roles: payload.roles || []
    }
  } catch (e) {
    console.error('Failed to extract user info from token:', e)
    return null
  }
}