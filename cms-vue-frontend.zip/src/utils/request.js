// src/utils/request.js
import axios from 'axios'
import { ElMessage, ElMessageBox } from 'element-plus'
import { getToken, removeToken } from './auth'
import router from '@/router'

// Create axios instance with default config
const service = axios.create({
  baseURL: '/api',
  timeout: 10000
})

// Request interceptor
service.interceptors.request.use(
  config => {
    // Add authorization header if token exists
    const token = getToken()
    if (token) {
      config.headers['Authorization'] = `Bearer ${token}`
    }
    return config
  },
  error => {
    // Do something with request error
    console.error('Request error:', error)
    return Promise.reject(error)
  }
)

// Response interceptor
service.interceptors.response.use(
  response => {
    const res = response.data

    // Check if API returned an error
    if (res.code && res.code !== 200) {
      ElMessage({
        message: res.message || 'Error',
        type: 'error',
        duration: 5 * 1000
      })

      // Handle specific error codes
      if (res.code === 401) {
        // Authentication error - show relogin dialog
        showReloginDialog()
      }

      return Promise.reject(new Error(res.message || 'Error'))
    } else {
      return res
    }
  },
  error => {
    console.error('Response error:', error)
    
    // Extract error message
    const message = error.response?.data?.message || error.message
    
    // Handle different HTTP status codes
    if (error.response) {
      if (error.response.status === 401) {
        // Authentication error - show relogin dialog
        showReloginDialog()
      } else if (error.response.status === 403) {
        ElMessage({
          message: 'Access forbidden',
          type: 'error',
          duration: 5 * 1000
        })
      } else {
        ElMessage({
          message: message,
          type: 'error',
          duration: 5 * 1000
        })
      }
    } else {
      ElMessage({
        message: 'Network error, please check your connection',
        type: 'error',
        duration: 5 * 1000
      })
    }
    
    return Promise.reject(error)
  }
)

// Function to handle relogin
function showReloginDialog() {
  ElMessageBox.confirm(
    'Your session has expired, please login again',
    'Session Timeout',
    {
      confirmButtonText: 'Login',
      type: 'warning',
      showCancelButton: false,
      showClose: false,
      closeOnClickModal: false,
      closeOnPressEscape: false
    }
  ).then(() => {
    removeToken()
    router.push(`/login?redirect=${router.currentRoute.value.path}`)
  })
}

export default service