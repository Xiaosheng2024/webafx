<template>
  <div class="about-content container">
    <div class="action-header">
      <div class="page-title">
        <h1>Company Information Management</h1>
      </div>
      <div class="action-buttons">
        <el-button type="primary" @click="saveChanges" :loading="saving">
          <el-icon><Check /></el-icon> Save Changes
        </el-button>
      </div>
    </div>

    <el-tabs v-model="activeTab" tab-position="left" class="content-tabs">
      <el-tab-pane label="Company Overview" name="overview">
        <el-card class="tab-card">
          <template #header>
            <div class="card-header">
              <span>Company Overview</span>
            </div>
          </template>

          <el-form label-width="120px" :model="aboutData.overview">
            <el-form-item label="Company Name">
              <el-input v-model="aboutData.overview.companyName" placeholder="Enter company name" />
            </el-form-item>
            
            <el-form-item label="Logo">
              <el-upload
                class="logo-uploader"
                :action="uploadUrl"
                :headers="headers"
                :show-file-list="false"
                :on-success="(res) => handleImageSuccess(res, 'overview', 'logo')"
                :before-upload="beforeImageUpload"
              >
                <img v-if="aboutData.overview.logo" :src="aboutData.overview.logo" class="company-logo" />
                <el-icon v-else class="logo-uploader-icon"><Plus /></el-icon>
              </el-upload>
              <div class="upload-tip">Recommended size: 300x150px</div>
            </el-form-item>
            
            <el-form-item label="Year Founded">
              <el-input-number v-model="aboutData.overview.yearFounded" :min="1900" :max="2100" />
            </el-form-item>
            
            <el-form-item label="Headquarters">
              <el-input v-model="aboutData.overview.headquarters" placeholder="Enter headquarters location" />
            </el-form-item>
            
            <el-form-item label="Overview">
              <el-editor v-model="aboutData.overview.content" height="300px" />
            </el-form-item>
          </el-form>
        </el-card>
      </el-tab-pane>
      
      <el-tab-pane label="Mission & Vision" name="mission">
        <el-card class="tab-card">
          <template #header>
            <div class="card-header">
              <span>Mission & Vision</span>
            </div>
          </template>

          <el-form label-width="120px" :model="aboutData.mission">
            <el-form-item label="Mission Title">
              <el-input v-model="aboutData.mission.missionTitle" placeholder="Enter mission title" />
            </el-form-item>
            
            <el-form-item label="Mission">
              <el-editor v-model="aboutData.mission.missionContent" height="200px" />
            </el-form-item>
            
            <el-form-item label="Vision Title">
              <el-input v-model="aboutData.mission.visionTitle" placeholder="Enter vision title" />
            </el-form-item>
            
            <el-form-item label="Vision">
              <el-editor v-model="aboutData.mission.visionContent" height="200px" />
            </el-form-item>
            
            <el-form-item label="Values Title">
              <el-input v-model="aboutData.mission.valuesTitle" placeholder="Enter values title" />
            </el-form-item>
            
            <el-form-item label="Values">
              <div class="values-list">
                <div v-for="(value, index) in aboutData.mission.values" :key="index" class="value-item">
                  <el-row :gutter="10">
                    <el-col :span="7">
                      <el-input v-model="value.title" placeholder="Value title" />
                    </el-col>
                    <el-col :span="14">
                      <el-input v-model="value.description" placeholder="Value description" />
                    </el-col>
                    <el-col :span="3">
                      <el-button type="danger" circle @click="removeValue(index)">
                        <el-icon><Delete /></el-icon>
                      </el-button>
                    </el-col>
                  </el-row>
                </div>
                <div class="add-value-button">
                  <el-button type="primary" @click="addValue">
                    <el-icon><Plus /></el-icon> Add Value
                  </el-button>
                </div>
              </div>
            </el-form-item>
            
            <el-form-item label="Feature Image">
              <el-upload
                class="feature-image-uploader"
                :action="uploadUrl"
                :headers="headers"
                :show-file-list="false"
                :on-success="(res) => handleImageSuccess(res, 'mission', 'image')"
                :before-upload="beforeImageUpload"
              >
                <img v-if="aboutData.mission.image" :src="aboutData.mission.image" class="feature-image" />
                <el-icon v-else class="feature-image-uploader-icon"><Plus /></el-icon>
              </el-upload>
              <div class="upload-tip">Recommended size: 800x500px</div>
            </el-form-item>
          </el-form>
        </el-card>
      </el-tab-pane>
      
      <el-tab-pane label="History" name="history">
        <el-card class="tab-card">
          <template #header>
            <div class="card-header">
              <span>Company History</span>
            </div>
          </template>

          <el-form label-width="120px" :model="aboutData.history">
            <el-form-item label="History Title">
              <el-input v-model="aboutData.history.title" placeholder="Enter history title" />
            </el-form-item>
            
            <el-form-item label="Introduction">
              <el-input
                v-model="aboutData.history.introduction"
                type="textarea"
                :rows="3"
                placeholder="Enter brief introduction"
              />
            </el-form-item>
            
            <el-form-item label="History">
              <el-editor v-model="aboutData.history.content" height="300px" />
            </el-form-item>
            
            <el-form-item label="Timeline">
              <div class="timeline-list">
                <div v-for="(milestone, index) in aboutData.history.timeline" :key="index" class="milestone-item">
                  <el-row :gutter="10">
                    <el-col :span="4">
                      <el-input-number v-model="milestone.year" :min="1900" :max="2100" placeholder="Year" />
                    </el-col>
                    <el-col :span="17">
                      <el-input v-model="milestone.event" placeholder="Milestone description" />
                    </el-col>
                    <el-col :span="3">
                      <el-button type="danger" circle @click="removeMilestone(index)">
                        <el-icon><Delete /></el-icon>
                      </el-button>
                    </el-col>
                  </el-row>
                </div>
                <div class="add-milestone-button">
                  <el-button type="primary" @click="addMilestone">
                    <el-icon><Plus /></el-icon> Add Milestone
                  </el-button>
                </div>
              </div>
            </el-form-item>
            
            <el-form-item label="Feature Image">
              <el-upload
                class="feature-image-uploader"
                :action="uploadUrl"
                :headers="headers"
                :show-file-list="false"
                :on-success="(res) => handleImageSuccess(res, 'history', 'image')"
                :before-upload="beforeImageUpload"
              >
                <img v-if="aboutData.history.image" :src="aboutData.history.image" class="feature-image" />
                <el-icon v-else class="feature-image-uploader-icon"><Plus /></el-icon>
              </el-upload>
              <div class="upload-tip">Recommended size: 800x500px</div>
            </el-form-item>
          </el-form>
        </el-card>
      </el-tab-pane>
      
      <el-tab-pane label="SEO Settings" name="seo">
        <el-card class="tab-card">
          <template #header>
            <div class="card-header">
              <span>SEO Settings</span>
            </div>
          </template>

          <el-form label-width="150px" :model="aboutData.seo">
            <el-form-item label="Meta Title">
              <el-input v-model="aboutData.seo.metaTitle" placeholder="Enter meta title" />
            </el-form-item>
            
            <el-form-item label="Meta Description">
              <el-input
                v-model="aboutData.seo.metaDescription"
                type="textarea"
                :rows="4"
                placeholder="Enter meta description"
              />
            </el-form-item>
            
            <el-form-item label="Meta Keywords">
              <el-input v-model="aboutData.seo.metaKeywords" placeholder="Enter meta keywords, separated by commas" />
            </el-form-item>
            
            <el-form-item label="Social Image">
              <el-upload
                class="feature-image-uploader"
                :action="uploadUrl"
                :headers="headers"
                :show-file-list="false"
                :on-success="(res) => handleImageSuccess(res, 'seo', 'socialImage')"
                :before-upload="beforeImageUpload"
              >
                <img v-if="aboutData.seo.socialImage" :src="aboutData.seo.socialImage" class="feature-image" />
                <el-icon v-else class="feature-image-uploader-icon"><Plus /></el-icon>
              </el-upload>
              <div class="upload-tip">Recommended size: 1200x630px (for social sharing)</div>
            </el-form-item>
          </el-form>
        </el-card>
      </el-tab-pane>
    </el-tabs>
  </div>
</template>

<script>
import { ref, reactive, onMounted } from 'vue'
import { ElMessage } from 'element-plus'
import { Plus, Check, Delete } from '@element-plus/icons-vue'
import axios from 'axios'
import { getToken } from '@/utils/auth'

export default {
  name: 'AboutContent',
  setup() {
    const activeTab = ref('overview')
    const loading = ref(false)
    const saving = ref(false)
    
    // Upload related
    const uploadUrl = '/api/media'
    const headers = {
      Authorization: `Bearer ${getToken()}`
    }

    // About us data structure
    const aboutData = reactive({
      id: null,
      overview: {
        companyName: '',
        logo: '',
        yearFounded: new Date().getFullYear(),
        headquarters: '',
        content: ''
      },
      mission: {
        missionTitle: 'Our Mission',
        missionContent: '',
        visionTitle: 'Our Vision',
        visionContent: '',
        valuesTitle: 'Our Core Values',
        values: [],
        image: ''
      },
      history: {
        title: 'Our History',
        introduction: '',
        content: '',
        timeline: [],
        image: ''
      },
      seo: {
        metaTitle: 'About Us',
        metaDescription: '',
        metaKeywords: '',
        socialImage: ''
      }
    })

    // Fetch about content data
    const fetchAboutContent = async () => {
      loading.value = true
      try {
        const response = await axios.get('/api/about-contents/current')
        const data = response.data.data
        
        if (data) {
          aboutData.id = data.id
          
          // Populate overview data if available
          if (data.overview) {
            Object.assign(aboutData.overview, data.overview)
          }
          
          // Populate mission data if available
          if (data.mission) {
            Object.assign(aboutData.mission, data.mission)
          }
          
          // Populate history data if available
          if (data.history) {
            Object.assign(aboutData.history, data.history)
          }
          
          // Populate SEO data if available
          if (data.seo) {
            Object.assign(aboutData.seo, data.seo)
          }
          
          // Ensure arrays are initialized
          if (!Array.isArray(aboutData.mission.values) || aboutData.mission.values.length === 0) {
            aboutData.mission.values = [{ title: '', description: '' }]
          }
          
          if (!Array.isArray(aboutData.history.timeline) || aboutData.history.timeline.length === 0) {
            aboutData.history.timeline = [{ year: new Date().getFullYear(), event: '' }]
          }
        }
      } catch (error) {
        console.error('Failed to fetch about us content:', error)
        ElMessage.error('Failed to load about us content')
      } finally {
        loading.value = false
      }
    }

    // Save changes
    const saveChanges = async () => {
      saving.value = true
      try {
        // Filter out empty values
        aboutData.mission.values = aboutData.mission.values.filter(
          value => value.title.trim() !== '' || value.description.trim() !== ''
        )
        
        // Filter out empty timeline events
        aboutData.history.timeline = aboutData.history.timeline.filter(
          milestone => milestone.event.trim() !== ''
        )
        
        const payload = {
          overview: aboutData.overview,
          mission: aboutData.mission,
          history: aboutData.history,
          seo: aboutData.seo
        }
        
        let response
        if (aboutData.id) {
          response = await axios.put(`/api/about-contents/${aboutData.id}`, payload)
        } else {
          response = await axios.post('/api/about-contents', payload)
          aboutData.id = response.data.data.id
        }
        
        ElMessage.success('About content updated successfully')
      } catch (error) {
        console.error('Failed to save about content:', error)
        ElMessage.error('Failed to save about content')
      } finally {
        saving.value = false
      }
    }

    // Core values management
    const addValue = () => {
      aboutData.mission.values.push({ title: '', description: '' })
    }

    const removeValue = (index) => {
      aboutData.mission.values.splice(index, 1)
    }

    // History timeline management
    const addMilestone = () => {
      aboutData.history.timeline.push({ year: new Date().getFullYear(), event: '' })
    }

    const removeMilestone = (index) => {
      aboutData.history.timeline.splice(index, 1)
    }

    // Image upload handlers
    const handleImageSuccess = (response, section, field) => {
      if (response.code === 200) {
        aboutData[section][field] = response.data.url
        ElMessage.success('Image uploaded successfully')
      } else {
        ElMessage.error('Failed to upload image')
      }
    }

    const beforeImageUpload = (file) => {
      const isImage = file.type.startsWith('image/')
      const isLt5M = file.size / 1024 / 1024 < 5

      if (!isImage) {
        ElMessage.error('You can only upload image files!')
        return false
      }
      if (!isLt5M) {
        ElMessage.error('Image size cannot exceed 5MB!')
        return false
      }
      return true
    }

    onMounted(() => {
      fetchAboutContent()
    })

    return {
      activeTab,
      aboutData,
      loading,
      saving,
      uploadUrl,
      headers,
      addValue,
      removeValue,
      addMilestone,
      removeMilestone,
      saveChanges,
      handleImageSuccess,
      beforeImageUpload,
      Plus,
      Check,
      Delete
    }
  }
}
</script>

<style scoped>
.about-content {
  padding: 20px;
}

.action-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 20px;
}

.content-tabs {
  min-height: 500px;
}

.tab-card {
  margin-bottom: 20px;
}

.card-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
}

.logo-uploader,
.feature-image-uploader {
  cursor: pointer;
}

.logo-uploader-icon {
  font-size: 28px;
  color: #8c939d;
  width: 300px;
  height: 150px;
  line-height: 150px;
  text-align: center;
  border: 1px dashed #d9d9d9;
  border-radius: 6px;
}

.company-logo {
  width: 300px;
  height: 150px;
  display: block;
  object-fit: contain;
}

.feature-image-uploader-icon {
  font-size: 28px;
  color: #8c939d;
  width: 800px;
  height: 400px;
  line-height: 400px;
  text-align: center;
  border: 1px dashed #d9d9d9;
  border-radius: 6px;
}

.feature-image {
  width: 800px;
  max-width: 100%;
  height: auto;
  display: block;
  object-fit: contain;
}

.upload-tip {
  font-size: 12px;
  color: #909399;
  margin-top: 5px;
}

.values-list,
.timeline-list {
  margin-bottom: 10px;
}

.value-item,
.milestone-item {
  margin-bottom: 10px;
}

.add-value-button,
.add-milestone-button {
  margin-top: 10px;
}
</style>