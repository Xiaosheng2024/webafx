<template>
  <div class="team-members container">
    <div class="action-header">
      <div class="page-title">
        <h1>Team Members Management</h1>
      </div>
      <div class="action-buttons">
        <el-button type="primary" @click="showAddMemberDialog">
          <el-icon><Plus /></el-icon> Add Team Member
        </el-button>
      </div>
    </div>

    <el-card class="filter-container">
      <div class="filter-items">
        <el-form :inline="true" :model="queryParams" class="search-form">
          <el-form-item label="Name">
            <el-input
              v-model="queryParams.name"
              placeholder="Search by name"
              clearable
              @keyup.enter="handleSearch"
            />
          </el-form-item>
          <el-form-item label="Department">
            <el-select v-model="queryParams.department" placeholder="All Departments" clearable>
              <el-option
                v-for="dept in departmentOptions"
                :key="dept"
                :label="dept"
                :value="dept"
              />
            </el-select>
          </el-form-item>
          <el-form-item>
            <el-button type="primary" @click="handleSearch">
              <el-icon><Search /></el-icon> Search
            </el-button>
            <el-button @click="resetQuery">
              <el-icon><Refresh /></el-icon> Reset
            </el-button>
          </el-form-item>
        </el-form>
      </div>
    </el-card>

    <el-card class="table-container" v-loading="loading">
      <el-table
        :data="memberList"
        border
        style="width: 100%"
        row-key="id"
      >
        <el-table-column label="ID" prop="id" width="80" />
        <el-table-column label="Photo" width="120">
          <template #default="{ row }">
            <el-image
              v-if="row.photo"
              :src="row.photo"
              fit="cover"
              style="width: 80px; height: 80px; border-radius: 50%"
              :preview-src-list="[row.photo]"
            >
              <template #error>
                <div class="image-placeholder">No photo</div>
              </template>
            </el-image>
            <div v-else class="image-placeholder">No photo</div>
          </template>
        </el-table-column>
        <el-table-column label="Name" prop="name" min-width="150" show-overflow-tooltip />
        <el-table-column label="Position" prop="position" min-width="150" show-overflow-tooltip />
        <el-table-column label="Department" prop="department" width="150" show-overflow-tooltip />
        <el-table-column label="Order" prop="displayOrder" width="80" />
        <el-table-column label="Status" width="100">
          <template #default="{ row }">
            <el-tag :type="row.active ? 'success' : 'info'">
              {{ row.active ? 'Active' : 'Inactive' }}
            </el-tag>
          </template>
        </el-table-column>
        <el-table-column label="Operations" width="180" fixed="right">
          <template #default="{ row }">
            <el-button size="small" @click="handleEditMember(row)">Edit</el-button>
            <el-popconfirm
              title="Are you sure to delete this team member?"
              @confirm="handleDeleteMember(row)"
            >
              <template #reference>
                <el-button size="small" type="danger">Delete</el-button>
              </template>
            </el-popconfirm>
          </template>
        </el-table-column>
      </el-table>

      <div class="pagination-container">
        <el-pagination
          v-model:current-page="queryParams.page"
          v-model:page-size="queryParams.size"
          :page-sizes="[10, 20, 50, 100]"
          :total="total"
          layout="total, sizes, prev, pager, next, jumper"
          @size-change="handleSizeChange"
          @current-change="handleCurrentChange"
        />
      </div>
    </el-card>

    <!-- Team Member Dialog -->
    <el-dialog
      v-model="memberDialog.visible"
      :title="memberDialog.type === 'create' ? 'Add Team Member' : 'Edit Team Member'"
      width="600px"
      @close="resetMemberForm"
    >
      <el-form
        ref="memberFormRef"
        :model="memberForm"
        :rules="memberRules"
        label-width="120px"
      >
        <el-form-item label="Photo">
          <el-upload
            class="avatar-uploader"
            :action="uploadUrl"
            :headers="headers"
            :show-file-list="false"
            :on-success="handlePhotoSuccess"
            :before-upload="beforePhotoUpload"
          >
            <img v-if="memberForm.photo" :src="memberForm.photo" class="avatar" />
            <el-icon v-else class="avatar-uploader-icon"><Plus /></el-icon>
          </el-upload>
          <div class="upload-tip">Recommended size: 300x300px</div>
        </el-form-item>
        <el-form-item label="Name" prop="name">
          <el-input v-model="memberForm.name" placeholder="Enter member name" />
        </el-form-item>
        <el-form-item label="Position" prop="position">
          <el-input v-model="memberForm.position" placeholder="Enter position or title" />
        </el-form-item>
        <el-form-item label="Department" prop="department">
          <el-select v-model="memberForm.department" placeholder="Select department" filterable allow-create>
            <el-option
              v-for="dept in departmentOptions"
              :key="dept"
              :label="dept"
              :value="dept"
            />
          </el-select>
        </el-form-item>
        <el-form-item label="Display Order" prop="displayOrder">
          <el-input-number v-model="memberForm.displayOrder" :min="1" :max="999" />
        </el-form-item>
        <el-form-item label="Status" prop="active">
          <el-radio-group v-model="memberForm.active">
            <el-radio :label="true">Active</el-radio>
            <el-radio :label="false">Inactive</el-radio>
          </el-radio-group>
        </el-form-item>
        <el-form-item label="Bio/Description" prop="bio">
          <el-input
            v-model="memberForm.bio"
            type="textarea"
            :rows="4"
            placeholder="Enter member bio"
          />
        </el-form-item>
        <el-form-item label="Email">
          <el-input v-model="memberForm.email" placeholder="Enter email address" />
        </el-form-item>
        <el-form-item label="LinkedIn">
          <el-input v-model="memberForm.linkedin" placeholder="Enter LinkedIn profile URL" />
        </el-form-item>
        <el-form-item label="Twitter">
          <el-input v-model="memberForm.twitter" placeholder="Enter Twitter profile URL" />
        </el-form-item>
      </el-form>
      <template #footer>
        <div class="dialog-footer">
          <el-button @click="memberDialog.visible = false">Cancel</el-button>
          <el-button type="primary" @click="submitMemberForm" :loading="memberDialog.loading">
            {{ memberDialog.type === 'create' ? 'Create' : 'Update' }}
          </el-button>
        </div>
      </template>
    </el-dialog>
  </div>
</template>

<script>
import { ref, reactive, onMounted } from 'vue'
import { Plus, Search, Refresh } from '@element-plus/icons-vue'
import { ElMessage } from 'element-plus'
import axios from 'axios'
import { getToken } from '@/utils/auth'

export default {
  name: 'TeamMembers',
  setup() {
    const loading = ref(false)
    const memberList = ref([])
    const total = ref(0)
    const departmentOptions = ref([])
    const memberFormRef = ref(null)

    const queryParams = reactive({
      page: 1,
      size: 10,
      name: '',
      department: ''
    })

    const memberForm = reactive({
      id: undefined,
      name: '',
      position: '',
      department: '',
      bio: '',
      photo: '',
      email: '',
      linkedin: '',
      twitter: '',
      displayOrder: 1,
      active: true
    })

    const memberDialog = reactive({
      visible: false,
      type: 'create',
      loading: false
    })

    const memberRules = {
      name: [{ required: true, message: 'Please enter member name', trigger: 'blur' }],
      position: [{ required: true, message: 'Please enter member position', trigger: 'blur' }],
      department: [{ required: true, message: 'Please select department', trigger: 'change' }]
    }

    // Upload related
    const uploadUrl = '/api/media'
    const headers = {
      Authorization: `Bearer ${getToken()}`
    }

    // Fetch team members list
    const fetchTeamMembers = async () => {
      loading.value = true
      try {
        const response = await axios.get('/api/team-members', { params: queryParams })
        const data = response.data.data
        memberList.value = data.content || []
        total.value = data.totalElements || 0
        
        // Extract unique departments for filter dropdown
        const departments = new Set()
        memberList.value.forEach(member => {
          if (member.department) {
            departments.add(member.department)
          }
        })
        departmentOptions.value = Array.from(departments)
      } catch (error) {
        console.error('Failed to fetch team members:', error)
        ElMessage.error('Failed to load team members')
      } finally {
        loading.value = false
      }
    }

    // Handle search
    const handleSearch = () => {
      queryParams.page = 1
      fetchTeamMembers()
    }

    // Reset query params
    const resetQuery = () => {
      queryParams.name = ''
      queryParams.department = ''
      queryParams.page = 1
      fetchTeamMembers()
    }

    // Show add member dialog
    const showAddMemberDialog = () => {
      memberDialog.type = 'create'
      memberDialog.visible = true
      resetMemberForm()
    }

    // Handle edit team member
    const handleEditMember = (row) => {
      memberDialog.type = 'edit'
      memberDialog.visible = true
      
      nextTick(() => {
        Object.assign(memberForm, {
          id: row.id,
          name: row.name,
          position: row.position,
          department: row.department,
          bio: row.bio,
          photo: row.photo,
          email: row.email,
          linkedin: row.linkedin,
          twitter: row.twitter,
          displayOrder: row.displayOrder,
          active: row.active
        })
      })
    }

    // Reset member form
    const resetMemberForm = () => {
      if (memberFormRef.value) {
        memberFormRef.value.resetFields()
      }
      
      Object.assign(memberForm, {
        id: undefined,
        name: '',
        position: '',
        department: '',
        bio: '',
        photo: '',
        email: '',
        linkedin: '',
        twitter: '',
        displayOrder: 1,
        active: true
      })
    }

    // Photo upload handlers
    const handlePhotoSuccess = (response, uploadFile) => {
      if (response.code === 200) {
        memberForm.photo = response.data.url
        ElMessage.success('Photo uploaded successfully')
      } else {
        ElMessage.error('Failed to upload photo')
      }
    }

    const beforePhotoUpload = (file) => {
      const isImage = file.type.startsWith('image/')
      const isLt2M = file.size / 1024 / 1024 < 2

      if (!isImage) {
        ElMessage.error('You can only upload image files!')
        return false
      }
      if (!isLt2M) {
        ElMessage.error('Image size cannot exceed 2MB!')
        return false
      }
      return true
    }

    // Submit member form
    const submitMemberForm = async () => {
      if (!memberFormRef.value) return
      
      await memberFormRef.value.validate(async (valid) => {
        if (!valid) return
        
        memberDialog.loading = true
        try {
          const formData = { ...memberForm }
          
          if (memberDialog.type === 'create') {
            await axios.post('/api/team-members', formData)
            ElMessage.success('Team member created successfully')
          } else {
            await axios.put(`/api/team-members/${formData.id}`, formData)
            ElMessage.success('Team member updated successfully')
          }
          
          memberDialog.visible = false
          fetchTeamMembers()
        } catch (error) {
          console.error('Failed to save team member:', error)
          ElMessage.error('Failed to save team member')
        } finally {
          memberDialog.loading = false
        }
      })
    }

    // Handle delete team member
    const handleDeleteMember = async (row) => {
      try {
        await axios.delete(`/api/team-members/${row.id}`)
        ElMessage.success('Team member deleted successfully')
        fetchTeamMembers()
      } catch (error) {
        console.error('Failed to delete team member:', error)
        ElMessage.error('Failed to delete team member')
      }
    }

    // Pagination handlers
    const handleSizeChange = (size) => {
      queryParams.size = size
      fetchTeamMembers()
    }

    const handleCurrentChange = (page) => {
      queryParams.page = page
      fetchTeamMembers()
    }

    onMounted(() => {
      fetchTeamMembers()
    })

    return {
      loading,
      memberList,
      total,
      departmentOptions,
      queryParams,
      memberForm,
      memberFormRef,
      memberDialog,
      memberRules,
      uploadUrl,
      headers,
      handleSearch,
      resetQuery,
      showAddMemberDialog,
      handleEditMember,
      handleDeleteMember,
      resetMemberForm,
      submitMemberForm,
      handlePhotoSuccess,
      beforePhotoUpload,
      handleSizeChange,
      handleCurrentChange,
      Plus,
      Search,
      Refresh
    }
  }
}
</script>

<style scoped>
.team-members {
  padding: 20px;
}

.action-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 20px;
}

.filter-container {
  margin-bottom: 20px;
}

.table-container {
  margin-bottom: 20px;
}

.pagination-container {
  margin-top: 20px;
  display: flex;
  justify-content: flex-end;
}

.avatar-uploader {
  width: 150px;
  height: 150px;
  border: 1px dashed #d9d9d9;
  border-radius: 6px;
  cursor: pointer;
  position: relative;
  overflow: hidden;
}

.avatar-uploader-icon {
  font-size: 28px;
  color: #8c939d;
  width: 150px;
  height: 150px;
  line-height: 150px;
  text-align: center;
}

.avatar {
  width: 150px;
  height: 150px;
  display: block;
  object-fit: cover;
}

.upload-tip {
  font-size: 12px;
  color: #909399;
  margin-top: 5px;
}

.image-placeholder {
  width: 80px;
  height: 80px;
  display: flex;
  justify-content: center;
  align-items: center;
  background-color: #f5f7fa;
  color: #909399;
  font-size: 12px;
  border-radius: 50%;
}

.dialog-footer {
  display: flex;
  justify-content: flex-end;
}
</style>