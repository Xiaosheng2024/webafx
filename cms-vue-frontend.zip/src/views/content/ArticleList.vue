<!-- src/views/content/ArticleList.vue -->
<template>
  <div class="article-list">
    <div class="page-header flex-between">
      <h2>Article List</h2>
      <el-button type="primary" @click="handleCreate">
        <el-icon><Plus /></el-icon>
        New Article
      </el-button>
    </div>

    <!-- Search Form -->
    <el-card class="search-card">
      <el-form :model="searchForm" ref="searchFormRef" label-width="100px" class="search-form" @submit.prevent>
        <el-row :gutter="20">
          <el-col :xs="24" :sm="12" :md="8" :lg="6">
            <el-form-item label="Title:">
              <el-input v-model="searchForm.title" placeholder="Search by title" clearable />
            </el-form-item>
          </el-col>
          <el-col :xs="24" :sm="12" :md="8" :lg="6">
            <el-form-item label="Category:">
              <el-select v-model="searchForm.categoryId" placeholder="Select category" clearable>
                <el-option v-for="category in categories" :key="category.id" :label="category.name" :value="category.id" />
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :xs="24" :sm="12" :md="8" :lg="6">
            <el-form-item label="Status:">
              <el-select v-model="searchForm.status" placeholder="Select status" clearable>
                <el-option label="Published" value="published" />
                <el-option label="Draft" value="draft" />
                <el-option label="Archived" value="archived" />
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :xs="24" :sm="12" :md="8" :lg="6">
            <el-form-item label="Featured:">
              <el-select v-model="searchForm.featured" placeholder="Select featured" clearable>
                <el-option label="Yes" :value="true" />
                <el-option label="No" :value="false" />
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :xs="24" class="form-buttons">
            <el-button type="primary" @click="handleSearch">Search</el-button>
            <el-button @click="resetSearch">Reset</el-button>
          </el-col>
        </el-row>
      </el-form>
    </el-card>

    <!-- Table -->
    <el-card class="table-card">
      <div class="table-operations">
        <el-button-group>
          <el-button :disabled="!hasSelected" @click="handlePublish">Publish</el-button>
          <el-button :disabled="!hasSelected" @click="handleArchive">Archive</el-button>
          <el-button :disabled="!hasSelected" @click="handleFeature">Feature</el-button>
        </el-button-group>
        <el-button type="danger" :disabled="!hasSelected" @click="handleBatchDelete">Delete</el-button>
      </div>
      <el-table 
        :data="tableData" 
        v-loading="loading"
        style="width: 100%" 
        @selection-change="handleSelectionChange"
        row-key="id"
      >
        <el-table-column type="selection" width="55" />
        <el-table-column prop="id" label="ID" width="80" />
        <el-table-column prop="title" label="Title" min-width="200" show-overflow-tooltip>
          <template #default="scope">
            <router-link :to="`/content/article/edit/${scope.row.id}`" class="article-title-link">
              {{ scope.row.title }}
            </router-link>
          </template>
        </el-table-column>
        <el-table-column prop="categoryName" label="Category" width="120" />
        <el-table-column prop="author" label="Author" width="120" />
        <el-table-column prop="viewCount" label="Views" width="100" sortable />
        <el-table-column prop="featured" label="Featured" width="100">
          <template #default="scope">
            <el-tag v-if="scope.row.featured" type="success">Yes</el-tag>
            <span v-else>No</span>
          </template>
        </el-table-column>
        <el-table-column prop="status" label="Status" width="100">
          <template #default="scope">
            <el-tag :type="getStatusType(scope.row.status)">
              {{ scope.row.status }}
            </el-tag>
          </template>
        </el-table-column>
        <el-table-column prop="publishTime" label="Publish Time" width="150" sortable />
        <el-table-column prop="updateTime" label="Update Time" width="150" sortable />
        <el-table-column fixed="right" label="Operations" width="180">
          <template #default="scope">
            <el-button type="primary" size="small" link @click="handleEdit(scope.row)">Edit</el-button>
            <el-button v-if="scope.row.status === 'published'" type="success" size="small" link @click="handlePreview(scope.row)">Preview</el-button>
            <el-button type="danger" size="small" link @click="handleDelete(scope.row)">Delete</el-button>
          </template>
        </el-table-column>
      </el-table>

      <!-- Pagination -->
      <el-pagination
        class="cms-pagination"
        :current-page="pagination.current"
        :page-size="pagination.pageSize"
        :total="pagination.total"
        :page-sizes="[10, 20, 50, 100]"
        layout="total, sizes, prev, pager, next, jumper"
        @size-change="handleSizeChange"
        @current-change="handleCurrentChange"
      />
    </el-card>
  </div>
</template>

<script>
import { ref, reactive, computed, onMounted } from 'vue'
import { useRouter } from 'vue-router'
import { Plus } from '@element-plus/icons-vue'
import { ElMessage, ElMessageBox } from 'element-plus'
import { getArticles, updateArticleStatus, deleteArticle } from '@/api/content'

export default {
  name: 'ArticleList',
  components: {
    Plus
  },
  setup() {
    const router = useRouter()
    const loading = ref(false)
    const tableData = ref([])
    const categories = ref([])
    const searchFormRef = ref(null)
    const selectedRows = ref([])
    
    // Search form
    const searchForm = reactive({
      title: '',
      categoryId: '',
      status: '',
      featured: ''
    })
    
    // Pagination
    const pagination = reactive({
      current: 1,
      pageSize: 10,
      total: 0
    })

    const hasSelected = computed(() => {
      return selectedRows.value.length > 0
    })
    
    // Get status type for el-tag
    const getStatusType = (status) => {
      const types = {
        published: 'success',
        draft: 'info',
        pending: 'warning',
        archived: 'danger'
      }
      return types[status] || 'info'
    }
    
    // Methods
    const fetchArticles = async () => {
      loading.value = true
      try {
        // Prepare query params
        const params = {
          page: pagination.current,
          pageSize: pagination.pageSize,
          ...searchForm
        }
        
        // In a real app, we would fetch data from API
        // const response = await getArticles(params)
        
        // For now, use mock data
        setTimeout(() => {
          tableData.value = [
            {
              id: 1,
              title: 'Introduction to Content Management',
              categoryName: 'Products',
              author: 'John Doe',
              viewCount: 1250,
              featured: true,
              status: 'published',
              publishTime: '2023-11-15 10:30:00',
              updateTime: '2023-11-15 14:20:00'
            },
            {
              id: 2,
              title: 'Best Practices for SEO',
              categoryName: 'Solutions',
              author: 'Jane Smith',
              viewCount: 980,
              featured: false,
              status: 'published',
              publishTime: '2023-11-14 09:15:00',
              updateTime: '2023-11-14 16:45:00'
            },
            {
              id: 3,
              title: 'Upcoming Features in CMS 2.0',
              categoryName: 'News',
              author: 'Admin User',
              viewCount: 540,
              featured: true,
              status: 'draft',
              publishTime: null,
              updateTime: '2023-11-13 11:20:00'
            }
          ]
          
          // Set pagination total
          pagination.total = 3
          
          // Mock categories
          categories.value = [
            { id: 1, name: 'Products' },
            { id: 2, name: 'Solutions' },
            { id: 3, name: 'News' },
            { id: 4, name: 'Case Studies' },
            { id: 5, name: 'About Us' }
          ]
          
          loading.value = false
        }, 800)
      } catch (error) {
        console.error('Error loading articles:', error)
        loading.value = false
      }
    }
    
    const handleSearch = () => {
      pagination.current = 1
      fetchArticles()
    }
    
    const resetSearch = () => {
      searchFormRef.value.resetFields()
      pagination.current = 1
      fetchArticles()
    }
    
    const handleSelectionChange = (rows) => {
      selectedRows.value = rows
    }
    
    const handleSizeChange = (size) => {
      pagination.pageSize = size
      pagination.current = 1
      fetchArticles()
    }
    
    const handleCurrentChange = (current) => {
      pagination.current = current
      fetchArticles()
    }
    
    const handleCreate = () => {
      router.push('/content/article/create')
    }
    
    const handleEdit = (row) => {
      router.push(`/content/article/edit/${row.id}`)
    }
    
    const handlePreview = (row) => {
      // In a real app, we would open the article in a new tab
      console.log('Preview article:', row)
      ElMessage({
        message: `Preview article: ${row.title}`,
        type: 'info'
      })
    }
    
    const handleDelete = (row) => {
      ElMessageBox.confirm(
        `Are you sure you want to delete the article "${row.title}"?`,
        'Delete Confirmation',
        {
          confirmButtonText: 'Delete',
          cancelButtonText: 'Cancel',
          type: 'warning'
        }
      ).then(async () => {
        try {
          // In a real app, we would call API
          // await deleteArticle(row.id)
          
          ElMessage({
            message: 'Article deleted successfully',
            type: 'success'
          })
          
          // Refresh the list
          fetchArticles()
        } catch (error) {
          console.error('Error deleting article:', error)
          ElMessage({
            message: 'Failed to delete article',
            type: 'error'
          })
        }
      }).catch(() => {
        // User cancelled
      })
    }
    
    const handleBatchDelete = () => {
      const count = selectedRows.value.length
      ElMessageBox.confirm(
        `Are you sure you want to delete ${count} selected articles?`,
        'Delete Confirmation',
        {
          confirmButtonText: 'Delete',
          cancelButtonText: 'Cancel',
          type: 'warning'
        }
      ).then(async () => {
        try {
          // In a real app, we would call API
          // await Promise.all(selectedRows.value.map(row => deleteArticle(row.id)))
          
          ElMessage({
            message: `${count} articles deleted successfully`,
            type: 'success'
          })
          
          // Refresh the list
          fetchArticles()
        } catch (error) {
          console.error('Error batch deleting articles:', error)
          ElMessage({
            message: 'Failed to delete articles',
            type: 'error'
          })
        }
      }).catch(() => {
        // User cancelled
      })
    }
    
    const handlePublish = () => {
      const count = selectedRows.value.length
      ElMessageBox.confirm(
        `Are you sure you want to publish ${count} selected articles?`,
        'Publish Confirmation',
        {
          confirmButtonText: 'Publish',
          cancelButtonText: 'Cancel',
          type: 'warning'
        }
      ).then(async () => {
        try {
          // In a real app, we would call API
          // await Promise.all(selectedRows.value.map(row => updateArticleStatus(row.id, 'published')))
          
          ElMessage({
            message: `${count} articles published successfully`,
            type: 'success'
          })
          
          // Refresh the list
          fetchArticles()
        } catch (error) {
          console.error('Error publishing articles:', error)
          ElMessage({
            message: 'Failed to publish articles',
            type: 'error'
          })
        }
      }).catch(() => {
        // User cancelled
      })
    }
    
    const handleArchive = () => {
      const count = selectedRows.value.length
      ElMessageBox.confirm(
        `Are you sure you want to archive ${count} selected articles?`,
        'Archive Confirmation',
        {
          confirmButtonText: 'Archive',
          cancelButtonText: 'Cancel',
          type: 'warning'
        }
      ).then(async () => {
        try {
          // In a real app, we would call API
          // await Promise.all(selectedRows.value.map(row => updateArticleStatus(row.id, 'archived')))
          
          ElMessage({
            message: `${count} articles archived successfully`,
            type: 'success'
          })
          
          // Refresh the list
          fetchArticles()
        } catch (error) {
          console.error('Error archiving articles:', error)
          ElMessage({
            message: 'Failed to archive articles',
            type: 'error'
          })
        }
      }).catch(() => {
        // User cancelled
      })
    }
    
    const handleFeature = () => {
      const count = selectedRows.value.length
      ElMessageBox.confirm(
        `Are you sure you want to toggle featured status for ${count} selected articles?`,
        'Feature Confirmation',
        {
          confirmButtonText: 'Confirm',
          cancelButtonText: 'Cancel',
          type: 'warning'
        }
      ).then(async () => {
        try {
          // In a real app, we would call API
          // await Promise.all(selectedRows.value.map(row => updateArticle(row.id, { featured: !row.featured })))
          
          ElMessage({
            message: `Feature status updated for ${count} articles`,
            type: 'success'
          })
          
          // Refresh the list
          fetchArticles()
        } catch (error) {
          console.error('Error updating feature status:', error)
          ElMessage({
            message: 'Failed to update feature status',
            type: 'error'
          })
        }
      }).catch(() => {
        // User cancelled
      })
    }
    
    // Load articles on component mount
    onMounted(() => {
      fetchArticles()
    })

    return {
      loading,
      tableData,
      categories,
      searchForm,
      searchFormRef,
      pagination,
      selectedRows,
      hasSelected,
      getStatusType,
      handleSearch,
      resetSearch,
      handleSelectionChange,
      handleSizeChange,
      handleCurrentChange,
      handleCreate,
      handleEdit,
      handlePreview,
      handleDelete,
      handleBatchDelete,
      handlePublish,
      handleArchive,
      handleFeature
    }
  }
}
</script>

<style scoped>
.article-list {
  padding: 20px;
}

.search-card,
.table-card {
  margin-bottom: 20px;
}

.form-buttons {
  display: flex;
  justify-content: center;
  margin-top: 10px;
}

.table-operations {
  margin-bottom: 16px;
  display: flex;
  justify-content: space-between;
}

.article-title-link {
  color: var(--primary-color);
  text-decoration: none;
}

.article-title-link:hover {
  text-decoration: underline;
}
</style>