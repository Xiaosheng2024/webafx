<!-- src/views/content/CategoryManagement.vue -->
<template>
  <div class="category-management">
    <div class="page-header flex-between">
      <h2>Category Management</h2>
      <el-button type="primary" @click="handleAdd">
        <el-icon><Plus /></el-icon>
        New Category
      </el-button>
    </div>

    <el-card>
      <el-table :data="categories" v-loading="loading" row-key="id">
        <el-table-column prop="id" label="ID" width="80" />
        <el-table-column prop="name" label="Name" min-width="150" />
        <el-table-column prop="description" label="Description" min-width="200" />
        <el-table-column prop="articleCount" label="Articles" width="100" sortable />
        <el-table-column prop="sortOrder" label="Sort Order" width="120" sortable />
        <el-table-column label="Icon" width="100">
          <template #default="scope">
            <el-icon v-if="scope.row.icon">
              <component :is="scope.row.icon" />
            </el-icon>
            <span v-else>-</span>
          </template>
        </el-table-column>
        <el-table-column prop="status" label="Status" width="100">
          <template #default="scope">
            <el-tag :type="scope.row.status === 'active' ? 'success' : 'danger'">
              {{ scope.row.status }}
            </el-tag>
          </template>
        </el-table-column>
        <el-table-column fixed="right" label="Operations" width="200">
          <template #default="scope">
            <el-button type="primary" size="small" link @click="handleEdit(scope.row)">Edit</el-button>
            <el-button 
              type="warning" 
              size="small" 
              link 
              @click="handleToggleStatus(scope.row)"
            >
              {{ scope.row.status === 'active' ? 'Disable' : 'Enable' }}
            </el-button>
            <el-button 
              type="danger" 
              size="small" 
              link 
              @click="handleDelete(scope.row)"
              :disabled="scope.row.articleCount > 0"
            >
              Delete
            </el-button>
          </template>
        </el-table-column>
      </el-table>
    </el-card>

    <!-- Category Form Dialog -->
    <el-dialog
      :title="dialogTitle"
      v-model="dialogVisible"
      width="500px"
    >
      <el-form
        ref="formRef"
        :model="form"
        :rules="rules"
        label-width="100px"
      >
        <el-form-item label="Name" prop="name">
          <el-input v-model="form.name" placeholder="Enter category name" />
        </el-form-item>
        <el-form-item label="Description" prop="description">
          <el-input 
            v-model="form.description" 
            type="textarea" 
            :rows="3" 
            placeholder="Enter category description"
          />
        </el-form-item>
        <el-form-item label="Parent">
          <el-select v-model="form.parentId" placeholder="Select parent category" clearable class="w-100">
            <el-option 
              v-for="cat in parentCategories" 
              :key="cat.id" 
              :label="cat.name" 
              :value="cat.id" 
            />
          </el-select>
        </el-form-item>
        <el-form-item label="Icon">
          <el-select v-model="form.icon" placeholder="Select icon" clearable class="w-100">
            <el-option value="el-icon-document" label="Document">
              <div class="icon-option">
                <el-icon class="el-icon-document" />
                <span>Document</span>
              </div>
            </el-option>
            <el-option value="el-icon-goods" label="Products">
              <div class="icon-option">
                <el-icon class="el-icon-goods" />
                <span>Products</span>
              </div>
            </el-option>
            <el-option value="el-icon-news" label="News">
              <div class="icon-option">
                <el-icon class="el-icon-news" />
                <span>News</span>
              </div>
            </el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="Sort Order" prop="sortOrder">
          <el-input-number v-model="form.sortOrder" :min="0" class="w-100" />
        </el-form-item>
        <el-form-item label="Status">
          <el-switch
            v-model="form.status"
            :active-value="'active'"
            :inactive-value="'inactive'"
          />
        </el-form-item>
      </el-form>
      <template #footer>
        <div class="dialog-footer">
          <el-button @click="dialogVisible = false">Cancel</el-button>
          <el-button type="primary" @click="submitForm">Confirm</el-button>
        </div>
      </template>
    </el-dialog>
  </div>
</template>

<script>
import { ref, reactive, computed, onMounted } from 'vue'
import { Plus } from '@element-plus/icons-vue'
import { ElMessage, ElMessageBox } from 'element-plus'

export default {
  name: 'CategoryManagement',
  components: {
    Plus
  },
  setup() {
    const loading = ref(false)
    const categories = ref([])
    const dialogVisible = ref(false)
    const formRef = ref(null)
    const isEdit = ref(false)
    
    // Form data
    const form = reactive({
      id: null,
      name: '',
      description: '',
      parentId: null,
      icon: '',
      sortOrder: 0,
      status: 'active'
    })
    
    // Form validation rules
    const rules = {
      name: [{ required: true, message: 'Please enter category name', trigger: 'blur' }]
    }
    
    const dialogTitle = computed(() => isEdit.value ? 'Edit Category' : 'Add Category')
    
    // Filter out current category (when editing) and its children from parent options
    const parentCategories = computed(() => {
      return categories.value.filter(cat => {
        if (!isEdit.value) return true
        return cat.id !== form.id && !isChildCategory(cat.id, form.id)
      })
    })
    
    // Check if potentialChild is a child of parentId
    const isChildCategory = (potentialChild, parentId) => {
      const category = categories.value.find(c => c.id === potentialChild)
      if (!category) return false
      if (category.parentId === parentId) return true
      if (category.parentId) return isChildCategory(category.parentId, parentId)
      return false
    }

    // Fetch categories
    const fetchCategories = async () => {
      loading.value = true
      try {
        // In a real app, we would fetch from API
        // const response = await getCategories()
        // categories.value = response.data.items
        
        // For now, use mock data
        setTimeout(() => {
          categories.value = [
            { id: 1, name: 'Products', description: 'Product information', parentId: 0, icon: 'el-icon-goods', articleCount: 3, sortOrder: 1, status: 'active' },
            { id: 2, name: 'Solutions', description: 'Solutions we offer', parentId: 0, icon: 'el-icon-magic-stick', articleCount: 2, sortOrder: 2, status: 'active' },
            { id: 3, name: 'News', description: 'Latest news and updates', parentId: 0, icon: 'el-icon-news', articleCount: 5, sortOrder: 3, status: 'active' },
            { id: 4, name: 'Case Studies', description: 'Customer case studies', parentId: 0, icon: 'el-icon-s-management', articleCount: 1, sortOrder: 4, status: 'active' },
            { id: 5, name: 'About Us', description: 'Company information', parentId: 0, icon: 'el-icon-office-building', articleCount: 1, sortOrder: 5, status: 'inactive' }
          ]
          
          loading.value = false
        }, 800)
      } catch (error) {
        console.error('Error loading categories:', error)
        ElMessage({ message: 'Failed to load categories', type: 'error' })
        loading.value = false
      }
    }
    
    // Reset form fields
    const resetForm = () => {
      form.id = null
      form.name = ''
      form.description = ''
      form.parentId = null
      form.icon = ''
      form.sortOrder = 0
      form.status = 'active'
      
      if (formRef.value) {
        formRef.value.resetFields()
      }
    }
    
    // Open add category dialog
    const handleAdd = () => {
      resetForm()
      isEdit.value = false
      dialogVisible.value = true
    }
    
    // Open edit category dialog
    const handleEdit = (row) => {
      resetForm()
      isEdit.value = true
      
      // Populate form with category data
      form.id = row.id
      form.name = row.name
      form.description = row.description
      form.parentId = row.parentId
      form.icon = row.icon
      form.sortOrder = row.sortOrder
      form.status = row.status
      
      dialogVisible.value = true
    }
    
    // Toggle category status
    const handleToggleStatus = (row) => {
      const newStatus = row.status === 'active' ? 'inactive' : 'active'
      const action = newStatus === 'active' ? 'enable' : 'disable'
      
      ElMessageBox.confirm(
        `Are you sure you want to ${action} the category "${row.name}"?`,
        `${action.charAt(0).toUpperCase() + action.slice(1)} Category`,
        {
          confirmButtonText: 'Confirm',
          cancelButtonText: 'Cancel',
          type: 'warning'
        }
      ).then(async () => {
        try {
          // In a real app, we would call API
          // await updateCategoryStatus(row.id, newStatus)
          
          // For now, update locally
          const index = categories.value.findIndex(c => c.id === row.id)
          categories.value[index].status = newStatus
          
          ElMessage({ message: `Category ${action}d successfully`, type: 'success' })
        } catch (error) {
          console.error(`Error ${action}ing category:`, error)
          ElMessage({ message: `Failed to ${action} category`, type: 'error' })
        }
      }).catch(() => {
        // User cancelled
      })
    }
    
    // Delete category
    const handleDelete = (row) => {
      if (row.articleCount > 0) {
        ElMessage({
          message: 'Cannot delete category with articles. Remove articles first or move them to another category.',
          type: 'warning'
        })
        return
      }
      
      ElMessageBox.confirm(
        `Are you sure you want to delete the category "${row.name}"?`,
        'Delete Category',
        {
          confirmButtonText: 'Delete',
          cancelButtonText: 'Cancel',
          type: 'warning'
        }
      ).then(async () => {
        try {
          // In a real app, we would call API
          // await deleteCategory(row.id)
          
          // For now, update locally
          categories.value = categories.value.filter(c => c.id !== row.id)
          
          ElMessage({ message: 'Category deleted successfully', type: 'success' })
        } catch (error) {
          console.error('Error deleting category:', error)
          ElMessage({ message: 'Failed to delete category', type: 'error' })
        }
      }).catch(() => {
        // User cancelled
      })
    }
    
    // Submit form
    const submitForm = () => {
      formRef.value.validate(async (valid) => {
        if (valid) {
          try {
            // In a real app, we would call API
            // if (isEdit.value) {
            //   await updateCategory(form.id, form)
            // } else {
            //   await createCategory(form)
            // }
            
            // For now, update locally
            if (isEdit.value) {
              const index = categories.value.findIndex(c => c.id === form.id)
              categories.value[index] = { ...categories.value[index], ...form }
            } else {
              // Generate new ID
              const newId = Math.max(...categories.value.map(c => c.id)) + 1
              categories.value.push({
                id: newId,
                articleCount: 0,
                ...form
              })
            }
            
            ElMessage({
              message: isEdit.value ? 'Category updated successfully' : 'Category created successfully',
              type: 'success'
            })
            
            dialogVisible.value = false
          } catch (error) {
            console.error('Error saving category:', error)
            ElMessage({ message: 'Failed to save category', type: 'error' })
          }
        }
      })
    }
    
    // Load categories on component mount
    onMounted(() => {
      fetchCategories()
    })
    
    return {
      loading,
      categories,
      dialogVisible,
      dialogTitle,
      formRef,
      form,
      rules,
      parentCategories,
      handleAdd,
      handleEdit,
      handleToggleStatus,
      handleDelete,
      submitForm
    }
  }
}
</script>

<style scoped>
.category-management {
  padding: 20px;
}

.w-100 {
  width: 100%;
}

.icon-option {
  display: flex;
  align-items: center;
}

.icon-option span {
  margin-left: 8px;
}

.dialog-footer {
  text-align: right;
}
</style>