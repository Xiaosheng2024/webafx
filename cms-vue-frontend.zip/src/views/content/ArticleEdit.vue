<!-- src/views/content/ArticleEdit.vue -->
<template>
  <div class="article-edit">
    <div class="page-header flex-between">
      <h2>{{ isEdit ? 'Edit Article' : 'Create Article' }}</h2>
      <el-button @click="goBack">
        <el-icon><Back /></el-icon>
        Back to List
      </el-button>
    </div>

    <el-card>
      <el-form
        ref="formRef"
        :model="form"
        :rules="rules"
        label-position="top"
        v-loading="loading"
      >
        <el-row :gutter="20">
          <el-col :xs="24" :md="16">
            <!-- Basic Information -->
            <el-form-item label="Title" prop="title">
              <el-input v-model="form.title" placeholder="Enter article title" />
            </el-form-item>

            <el-form-item label="Content" prop="content">
              <div class="editor-container">
                <div class="editor-toolbar">
                  <el-button-group>
                    <el-button size="small">Bold</el-button>
                    <el-button size="small">Italic</el-button>
                    <el-button size="small">List</el-button>
                    <el-button size="small">Link</el-button>
                    <el-button size="small">Image</el-button>
                  </el-button-group>
                </div>
                <el-input 
                  v-model="form.content" 
                  type="textarea" 
                  :rows="15" 
                  placeholder="Enter article content"
                  class="content-editor"
                />
              </div>
            </el-form-item>

            <el-form-item label="Summary" prop="summary">
              <el-input 
                v-model="form.summary" 
                type="textarea" 
                :rows="4" 
                placeholder="Enter article summary" 
                maxlength="500" 
                show-word-limit
              />
            </el-form-item>
          </el-col>

          <el-col :xs="24" :md="8">
            <!-- Sidebar Settings -->
            <el-form-item label="Category" prop="categoryId">
              <el-select v-model="form.categoryId" placeholder="Select category" class="w-100">
                <el-option 
                  v-for="category in categories" 
                  :key="category.id" 
                  :label="category.name" 
                  :value="category.id" 
                />
              </el-select>
            </el-form-item>

            <el-form-item label="Status" prop="status">
              <el-select v-model="form.status" placeholder="Select status" class="w-100">
                <el-option label="Published" value="published" />
                <el-option label="Draft" value="draft" />
                <el-option label="Archived" value="archived" />
              </el-select>
            </el-form-item>

            <el-form-item label="URL Alias" prop="urlAlias">
              <el-input v-model="form.urlAlias" placeholder="Enter URL alias" />
            </el-form-item>

            <el-form-item label="Tags">
              <el-select 
                v-model="form.tags" 
                multiple 
                filterable 
                allow-create 
                default-first-option 
                placeholder="Enter or select tags" 
                class="w-100"
              >
                <el-option 
                  v-for="tag in tags" 
                  :key="tag.id" 
                  :label="tag.name" 
                  :value="tag.id" 
                />
              </el-select>
            </el-form-item>

            <el-form-item label="Featured">
              <el-switch v-model="form.featured" />
            </el-form-item>

            <el-form-item label="Publication Date" prop="publishTime">
              <el-date-picker
                v-model="form.publishTime"
                type="datetime"
                placeholder="Select date and time"
                class="w-100"
              />
            </el-form-item>

            <el-form-item label="Cover Image">
              <el-upload
                class="cover-upload"
                :show-file-list="false"
                :before-upload="beforeUpload"
                :http-request="handleUpload"
              >
                <el-image 
                  v-if="form.coverImage" 
                  :src="form.coverImage" 
                  fit="cover" 
                  class="cover-preview" 
                />
                <div v-else class="upload-placeholder">
                  <el-icon><Plus /></el-icon>
                  <div>Upload Cover Image</div>
                </div>
              </el-upload>
            </el-form-item>

            <el-collapse>
              <el-collapse-item title="SEO Settings">
                <el-form-item label="Keywords">
                  <el-input v-model="form.keywords" placeholder="Enter SEO keywords, comma separated" />
                </el-form-item>

                <el-form-item label="SEO Description">
                  <el-input 
                    v-model="form.seoDescription" 
                    type="textarea" 
                    :rows="3" 
                    placeholder="Enter SEO description"
                    maxlength="255" 
                    show-word-limit
                  />
                </el-form-item>
              </el-collapse-item>
            </el-collapse>
          </el-col>
        </el-row>

        <div class="form-actions">
          <el-button @click="goBack">Cancel</el-button>
          <el-button type="primary" @click="handleSaveAsDraft">Save as Draft</el-button>
          <el-button type="success" @click="handlePublish">Publish</el-button>
        </div>
      </el-form>
    </el-card>
  </div>
</template>

<script>
import { ref, reactive, computed, onMounted } from 'vue'
import { useRouter, useRoute } from 'vue-router'
import { Back, Plus } from '@element-plus/icons-vue'
import { ElMessage, ElMessageBox } from 'element-plus'
import { getArticleById, createArticle, updateArticle, uploadImage } from '@/api/content'

export default {
  name: 'ArticleEdit',
  components: {
    Back,
    Plus
  },
  setup() {
    const router = useRouter()
    const route = useRoute()
    const formRef = ref(null)
    const loading = ref(false)
    const articleId = computed(() => route.params.id)
    const isEdit = computed(() => Boolean(articleId.value))
    
    // Form data
    const form = reactive({
      title: '',
      content: '',
      summary: '',
      categoryId: '',
      status: 'draft',
      urlAlias: '',
      tags: [],
      featured: false,
      publishTime: '',
      coverImage: '',
      keywords: '',
      seoDescription: ''
    })
    
    // Form validation rules
    const rules = {
      title: [{ required: true, message: 'Please enter title', trigger: 'blur' }],
      content: [{ required: true, message: 'Please enter content', trigger: 'blur' }],
      categoryId: [{ required: true, message: 'Please select category', trigger: 'change' }]
    }
    
    // Mock data for categories and tags
    const categories = ref([])
    const tags = ref([])
    
    // Load article data if in edit mode
    const loadArticle = async () => {
      if (!isEdit.value) return
      
      loading.value = true
      try {
        // In a real app, we would fetch from API
        // const response = await getArticleById(articleId.value)
        
        // For now, use mock data
        setTimeout(() => {
          Object.assign(form, {
            title: 'Introduction to Content Management',
            content: `<p>Content management systems (CMS) help organizations create, manage, and publish digital content.</p>
                      <p>Key benefits include:</p>
                      <ul>
                        <li>Centralized content storage</li>
                        <li>Workflow management</li>
                        <li>Version control</li>
                        <li>User role management</li>
                      </ul>
                      <p>This article explores modern CMS solutions and best practices.</p>`,
            summary: 'An overview of content management systems, their benefits, and implementation strategies.',
            categoryId: 1,
            status: 'published',
            urlAlias: 'intro-to-cms',
            tags: [2, 3],
            featured: true,
            publishTime: new Date('2023-11-15 10:30:00'),
            coverImage: 'https://placehold.co/600x400',
            keywords: 'CMS, content management, digital content, workflow',
            seoDescription: 'Learn about content management systems, their benefits, and implementation strategies in this comprehensive guide.'
          })
          
          loading.value = false
        }, 800)
      } catch (error) {
        console.error('Error loading article:', error)
        ElMessage({ message: 'Failed to load article', type: 'error' })
        loading.value = false
      }
    }
    
    // Load categories and tags
    const loadFormData = async () => {
      try {
        // In a real app, we would fetch from API
        // const [categoriesResponse, tagsResponse] = await Promise.all([
        //   getCategories(),
        //   getTags()
        // ])
        
        // For now, use mock data
        categories.value = [
          { id: 1, name: 'Products' },
          { id: 2, name: 'Solutions' },
          { id: 3, name: 'News' },
          { id: 4, name: 'Case Studies' },
          { id: 5, name: 'About Us' }
        ]
        
        tags.value = [
          { id: 1, name: 'New' },
          { id: 2, name: 'Featured' },
          { id: 3, name: 'Technology' },
          { id: 4, name: 'Business' },
          { id: 5, name: 'Updates' }
        ]
      } catch (error) {
        console.error('Error loading form data:', error)
        ElMessage({ message: 'Failed to load form data', type: 'error' })
      }
    }
    
    // Navigate back to article list
    const goBack = () => {
      router.push('/content/article')
    }
    
    // Before upload hook
    const beforeUpload = (file) => {
      const isImage = file.type.startsWith('image/')
      const isLt2M = file.size / 1024 / 1024 < 2
      
      if (!isImage) {
        ElMessage({ message: 'Please upload an image file', type: 'error' })
        return false
      }
      
      if (!isLt2M) {
        ElMessage({ message: 'Image size cannot exceed 2MB', type: 'error' })
        return false
      }
      
      return true
    }
    
    // Custom upload handler
    const handleUpload = async (options) => {
      try {
        const file = options.file
        
        // In a real app, we would upload to the server
        // const response = await uploadImage(file)
        // form.coverImage = response.data.url
        
        // For now, use a placeholder
        const reader = new FileReader()
        reader.readAsDataURL(file)
        reader.onload = (e) => {
          form.coverImage = e.target.result
          ElMessage({ message: 'Image uploaded successfully', type: 'success' })
        }
      } catch (error) {
        console.error('Error uploading image:', error)
        ElMessage({ message: 'Failed to upload image', type: 'error' })
      }
    }
    
    // Save article as draft
    const handleSaveAsDraft = () => {
      saveArticle('draft')
    }
    
    // Publish article
    const handlePublish = () => {
      saveArticle('published')
    }
    
    // Save article with specified status
    const saveArticle = async (status) => {
      if (status) {
        form.status = status
      }
      
      formRef.value.validate(async (valid) => {
        if (valid) {
          loading.value = true
          try {
            // In a real app, we would call API
            // if (isEdit.value) {
            //   await updateArticle(articleId.value, form)
            // } else {
            //   await createArticle(form)
            // }
            
            // For now, just simulate success
            setTimeout(() => {
              ElMessage({
                message: isEdit.value
                  ? 'Article updated successfully'
                  : 'Article created successfully',
                type: 'success'
              })
              
              loading.value = false
              goBack()
            }, 800)
          } catch (error) {
            console.error('Error saving article:', error)
            ElMessage({ message: 'Failed to save article', type: 'error' })
            loading.value = false
          }
        } else {
          ElMessage({ message: 'Please correct the errors in the form', type: 'warning' })
        }
      })
    }
    
    // Initialize
    onMounted(async () => {
      await loadFormData()
      await loadArticle()
    })
    
    return {
      formRef,
      form,
      rules,
      loading,
      categories,
      tags,
      isEdit,
      goBack,
      beforeUpload,
      handleUpload,
      handleSaveAsDraft,
      handlePublish
    }
  }
}
</script>

<style scoped>
.article-edit {
  padding: 20px;
}

.w-100 {
  width: 100%;
}

.editor-container {
  border: 1px solid #dcdfe6;
  border-radius: 4px;
}

.editor-toolbar {
  padding: 8px;
  border-bottom: 1px solid #dcdfe6;
  background-color: #f5f7fa;
}

.content-editor {
  border: none;
}

.cover-upload {
  display: block;
}

.cover-preview {
  width: 100%;
  height: 180px;
  object-fit: cover;
  border-radius: 4px;
}

.upload-placeholder {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  width: 100%;
  height: 180px;
  border: 1px dashed #dcdfe6;
  border-radius: 4px;
  color: #909399;
  cursor: pointer;
}

.upload-placeholder:hover {
  border-color: var(--primary-color);
  color: var(--primary-color);
}

.form-actions {
  margin-top: 30px;
  text-align: center;
}

:deep(.el-collapse-item__header) {
  font-size: 14px;
  color: #606266;
}
</style>