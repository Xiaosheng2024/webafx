<template>
  <div class="case-edit container">
    <div class="action-header">
      <div class="page-title">
        <h1>{{ isEdit ? 'Edit Case Study' : 'Create Case Study' }}</h1>
      </div>
      <div class="action-buttons">
        <el-button @click="goBack">
          <el-icon><Back /></el-icon> Back
        </el-button>
      </div>
    </div>

    <el-form
      ref="caseFormRef"
      :model="caseForm"
      :rules="rules"
      label-width="120px"
      class="case-form"
      v-loading="loading"
    >
      <el-card class="form-card">
        <template #header>
          <div class="card-header">
            <span>Basic Information</span>
          </div>
        </template>
        
        <el-form-item label="Title" prop="title">
          <el-input v-model="caseForm.title" placeholder="Enter case title" />
        </el-form-item>
        
        <el-form-item label="Category" prop="categoryId">
          <el-tree-select
            v-model="caseForm.categoryId"
            :data="categoryOptions"
            check-strictly
            node-key="id"
            :props="{
              children: 'children',
              label: 'name'
            }"
            placeholder="Select case category"
          />
        </el-form-item>
        
        <el-form-item label="Client Name" prop="clientName">
          <el-input v-model="caseForm.clientName" placeholder="Enter client name" />
        </el-form-item>
        
        <el-form-item label="Industry" prop="industry">
          <el-input v-model="caseForm.industry" placeholder="Enter industry" />
        </el-form-item>
        
        <el-form-item label="Status" prop="status">
          <el-radio-group v-model="caseForm.status">
            <el-radio label="DRAFT">Draft</el-radio>
            <el-radio label="PUBLISHED">Published</el-radio>
          </el-radio-group>
        </el-form-item>
        
        <el-form-item label="Short Description">
          <el-input
            v-model="caseForm.shortDescription"
            type="textarea"
            :rows="3"
            placeholder="Enter short description"
          />
        </el-form-item>
      </el-card>

      <el-card class="form-card">
        <template #header>
          <div class="card-header">
            <span>Cover Image</span>
          </div>
        </template>
        
        <el-form-item label="Cover Image" prop="coverImage">
          <el-upload
            class="cover-image-uploader"
            :action="uploadUrl"
            :headers="headers"
            :show-file-list="false"
            :on-success="handleCoverImageSuccess"
            :before-upload="beforeImageUpload"
          >
            <img v-if="caseForm.coverImage" :src="caseForm.coverImage" class="cover-image" />
            <el-icon v-else class="cover-image-uploader-icon"><Plus /></el-icon>
          </el-upload>
          <div class="upload-tip">Recommended size: 1200x600px</div>
        </el-form-item>
      </el-card>

      <el-card class="form-card">
        <template #header>
          <div class="card-header">
            <span>Gallery Images</span>
          </div>
        </template>
        
        <el-form-item label="Gallery">
          <el-upload
            class="gallery-uploader"
            :action="uploadUrl"
            :headers="headers"
            list-type="picture-card"
            :file-list="galleryFileList"
            :on-preview="handlePicturePreview"
            :on-success="handleGallerySuccess"
            :on-remove="handleGalleryRemove"
          >
            <el-icon><Plus /></el-icon>
          </el-upload>
          <el-dialog v-model="dialogVisible">
            <img w-full :src="dialogImageUrl" alt="Preview Image" />
          </el-dialog>
        </el-form-item>
      </el-card>

      <el-card class="form-card">
        <template #header>
          <div class="card-header">
            <span>Case Details</span>
          </div>
        </template>
        
        <el-form-item label="Challenge" prop="challenge">
          <div class="editor-container">
            <el-editor v-model="caseForm.challenge" height="300px" />
          </div>
        </el-form-item>
        
        <el-form-item label="Solution" prop="solution">
          <div class="editor-container">
            <el-editor v-model="caseForm.solution" height="300px" />
          </div>
        </el-form-item>
        
        <el-form-item label="Results" prop="results">
          <div class="editor-container">
            <el-editor v-model="caseForm.results" height="300px" />
          </div>
        </el-form-item>
      </el-card>

      <el-card class="form-card">
        <template #header>
          <div class="card-header">
            <span>Key Results</span>
          </div>
        </template>
        
        <div class="results-list">
          <div v-for="(result, index) in caseForm.keyResults" :key="index" class="result-item">
            <el-row :gutter="10">
              <el-col :span="21">
                <el-input v-model="result.text" placeholder="Enter key result or achievement" />
              </el-col>
              <el-col :span="3">
                <el-button type="danger" circle @click="removeResult(index)">
                  <el-icon><Delete /></el-icon>
                </el-button>
              </el-col>
            </el-row>
          </div>
          <div class="add-result-button">
            <el-button type="primary" @click="addResult">
              <el-icon><Plus /></el-icon> Add Key Result
            </el-button>
          </div>
        </div>
      </el-card>

      <el-card class="form-card">
        <template #header>
          <div class="card-header">
            <span>SEO Information</span>
          </div>
        </template>
        
        <el-form-item label="Meta Title">
          <el-input v-model="caseForm.metaTitle" placeholder="Enter meta title" />
        </el-form-item>
        
        <el-form-item label="Meta Description">
          <el-input
            v-model="caseForm.metaDescription"
            type="textarea"
            :rows="3"
            placeholder="Enter meta description"
          />
        </el-form-item>
        
        <el-form-item label="Meta Keywords">
          <el-input v-model="caseForm.metaKeywords" placeholder="Enter meta keywords" />
        </el-form-item>
      </el-card>

      <div class="form-actions">
        <el-button @click="goBack">Cancel</el-button>
        <el-button type="primary" @click="submitForm" :loading="submitting">Save</el-button>
        <el-button
          v-if="isEdit && caseForm.status === 'DRAFT'"
          type="success"
          @click="saveAndPublish"
          :loading="submitting"
        >
          Save & Publish
        </el-button>
      </div>
    </el-form>
  </div>
</template>

<script>
import { ref, reactive, computed, onMounted, nextTick } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { ElMessage } from 'element-plus'
import { Plus, Back, Delete } from '@element-plus/icons-vue'
import axios from 'axios'
import { getToken } from '@/utils/auth'

export default {
  name: 'CaseEdit',
  setup() {
    const route = useRoute()
    const router = useRouter()
    const caseId = computed(() => route.params.id)
    const isEdit = computed(() => !!caseId.value)
    const caseFormRef = ref(null)
    const loading = ref(false)
    const submitting = ref(false)
    const categoryOptions = ref([])
    const galleryFileList = ref([])
    const dialogImageUrl = ref('')
    const dialogVisible = ref(false)
    
    // Upload related
    const uploadUrl = '/api/media'
    const headers = {
      Authorization: `Bearer ${getToken()}`
    }

    const caseForm = reactive({
      id: undefined,
      title: '',
      categoryId: undefined,
      clientName: '',
      industry: '',
      shortDescription: '',
      coverImage: '',
      gallery: [],
      challenge: '',
      solution: '',
      results: '',
      keyResults: [],
      status: 'DRAFT',
      metaTitle: '',
      metaDescription: '',
      metaKeywords: ''
    })

    const rules = {
      title: [{ required: true, message: 'Please enter case title', trigger: 'blur' }],
      categoryId: [{ required: true, message: 'Please select a category', trigger: 'change' }],
      clientName: [{ required: true, message: 'Please enter client name', trigger: 'blur' }],
      industry: [{ required: true, message: 'Please enter industry', trigger: 'blur' }],
      status: [{ required: true, message: 'Please select case status', trigger: 'change' }],
      challenge: [{ required: true, message: 'Please enter case challenge', trigger: 'blur' }],
      solution: [{ required: true, message: 'Please enter case solution', trigger: 'blur' }]
    }

    // Initialize component
    onMounted(() => {
      fetchCategories()
      if (isEdit.value) {
        fetchCaseDetail()
      } else {
        // Initialize with at least one key result for new cases
        addResult()
      }
    })

    // Fetch case categories
    const fetchCategories = async () => {
      try {
        const response = await axios.get('/api/case-categories/tree')
        categoryOptions.value = response.data.data || []
      } catch (error) {
        console.error('Failed to fetch categories:', error)
        ElMessage.error('Failed to load case categories')
      }
    }

    // Fetch case details if in edit mode
    const fetchCaseDetail = async () => {
      loading.value = true
      try {
        const response = await axios.get(`/api/cases/${caseId.value}`)
        const caseData = response.data.data
        
        // Update case form with fetched data
        Object.keys(caseForm).forEach(key => {
          if (caseData[key] !== undefined) {
            caseForm[key] = caseData[key]
          }
        })
        
        // Handle gallery images
        if (Array.isArray(caseData.gallery) && caseData.gallery.length > 0) {
          galleryFileList.value = caseData.gallery.map((url, index) => ({
            name: `image-${index}`,
            url,
            uid: `existing-${index}`
          }))
        }
        
        // Handle key results
        if (!Array.isArray(caseForm.keyResults) || caseForm.keyResults.length === 0) {
          caseForm.keyResults = []
          addResult() // Add at least one result field
        }
        
      } catch (error) {
        console.error('Failed to fetch case details:', error)
        ElMessage.error('Failed to load case study details')
      } finally {
        loading.value = false
      }
    }

    // Cover image upload handlers
    const handleCoverImageSuccess = (response, uploadFile) => {
      if (response.code === 200) {
        caseForm.coverImage = response.data.url
        ElMessage.success('Cover image uploaded successfully')
      } else {
        ElMessage.error('Failed to upload cover image')
      }
    }

    const beforeImageUpload = (file) => {
      const isImage = file.type.startsWith('image/')
      const isLt5M = file.size / 1024 / 1024 < 5

      if (!isImage) {
        ElMessage.error('You can only upload image files!')
        return false
      }
      if (!isLt5M) {
        ElMessage.error('Image size cannot exceed 5MB!')
        return false
      }
      return true
    }

    // Gallery upload handlers
    const handleGallerySuccess = (response, uploadFile) => {
      if (response.code === 200) {
        caseForm.gallery.push(response.data.url)
        galleryFileList.value.push({
          name: uploadFile.name,
          url: response.data.url,
          uid: uploadFile.uid
        })
        ElMessage.success('Gallery image uploaded successfully')
      } else {
        ElMessage.error('Failed to upload gallery image')
      }
    }

    const handleGalleryRemove = (file) => {
      const index = galleryFileList.value.findIndex(item => item.uid === file.uid)
      if (index !== -1) {
        galleryFileList.value.splice(index, 1)
        caseForm.gallery.splice(index, 1)
      }
    }

    const handlePicturePreview = (file) => {
      dialogImageUrl.value = file.url
      dialogVisible.value = true
    }

    // Key results list handlers
    const addResult = () => {
      caseForm.keyResults.push({ text: '' })
    }

    const removeResult = (index) => {
      caseForm.keyResults.splice(index, 1)
    }

    // Form submission
    const submitForm = async () => {
      if (!caseFormRef.value) return
      
      await caseFormRef.value.validate(async (valid) => {
        if (!valid) return

        submitting.value = true
        try {
          // Filter out empty key results
          caseForm.keyResults = caseForm.keyResults.filter(
            result => result.text.trim() !== ''
          )
          
          let response
          if (isEdit.value) {
            response = await axios.put(`/api/cases/${caseId.value}`, caseForm)
          } else {
            response = await axios.post('/api/cases', caseForm)
          }
          
          ElMessage.success(`Case study ${isEdit.value ? 'updated' : 'created'} successfully`)
          router.push('/cases/list')
        } catch (error) {
          console.error('Failed to save case study:', error)
          ElMessage.error(`Failed to ${isEdit.value ? 'update' : 'create'} case study`)
        } finally {
          submitting.value = false
        }
      })
    }

    // Save and publish
    const saveAndPublish = async () => {
      if (!caseFormRef.value) return
      
      await caseFormRef.value.validate(async (valid) => {
        if (!valid) return
        
        submitting.value = true
        try {
          caseForm.status = 'PUBLISHED'
          
          let response
          if (isEdit.value) {
            response = await axios.put(`/api/cases/${caseId.value}`, caseForm)
          } else {
            response = await axios.post('/api/cases', caseForm)
          }
          
          ElMessage.success('Case study saved and published successfully')
          router.push('/cases/list')
        } catch (error) {
          console.error('Failed to save and publish case study:', error)
          ElMessage.error('Failed to save and publish case study')
        } finally {
          submitting.value = false
        }
      })
    }

    // Navigation
    const goBack = () => {
      router.back()
    }

    return {
      caseFormRef,
      caseForm,
      rules,
      isEdit,
      loading,
      submitting,
      categoryOptions,
      uploadUrl,
      headers,
      galleryFileList,
      dialogImageUrl,
      dialogVisible,
      handleCoverImageSuccess,
      beforeImageUpload,
      handleGallerySuccess,
      handleGalleryRemove,
      handlePicturePreview,
      addResult,
      removeResult,
      submitForm,
      saveAndPublish,
      goBack,
      Plus,
      Back,
      Delete
    }
  }
}
</script>

<style scoped>
.case-edit {
  padding: 20px;
}

.action-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 20px;
}

.form-card {
  margin-bottom: 20px;
}

.card-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
}

.case-form {
  max-width: 1200px;
}

.cover-image-uploader {
  width: 300px;
  height: 150px;
}

.cover-image-uploader-icon {
  font-size: 28px;
  color: #8c939d;
  width: 300px;
  height: 150px;
  line-height: 150px;
  text-align: center;
  border: 1px dashed #d9d9d9;
  border-radius: 6px;
  cursor: pointer;
}

.cover-image {
  width: 300px;
  height: 150px;
  display: block;
  object-fit: cover;
}

.upload-tip {
  font-size: 12px;
  color: #909399;
  margin-top: 5px;
}

.editor-container {
  border: 1px solid #dcdfe6;
  border-radius: 4px;
}

.results-list {
  margin-bottom: 10px;
}

.result-item {
  margin-bottom: 10px;
}

.add-result-button {
  margin-top: 10px;
}

.form-actions {
  display: flex;
  justify-content: flex-start;
  margin-top: 30px;
  margin-bottom: 50px;
  gap: 10px;
}
</style>