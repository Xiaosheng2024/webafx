<!-- src/views/dashboard/Dashboard.vue -->
<template>
  <div class="dashboard">
    <div class="page-header flex-between">
      <h2>Dashboard</h2>
      <el-button type="primary" @click="refreshData">
        <el-icon><Refresh /></el-icon>
        Refresh
      </el-button>
    </div>

    <el-row :gutter="20">
      <el-col :xs="24" :sm="12" :md="6">
        <el-card class="stat-card" shadow="hover">
          <div class="stat-value">{{ stats.articles }}</div>
          <div class="stat-label">Total Articles</div>
          <el-progress :percentage="calculatePercentage(stats.articles, stats.maxArticles)" />
        </el-card>
      </el-col>
      <el-col :xs="24" :sm="12" :md="6">
        <el-card class="stat-card" shadow="hover">
          <div class="stat-value">{{ stats.categories }}</div>
          <div class="stat-label">Categories</div>
          <el-progress :percentage="calculatePercentage(stats.categories, stats.maxCategories)" :color="'#67C23A'" />
        </el-card>
      </el-col>
      <el-col :xs="24" :sm="12" :md="6">
        <el-card class="stat-card" shadow="hover">
          <div class="stat-value">{{ stats.users }}</div>
          <div class="stat-label">Users</div>
          <el-progress :percentage="calculatePercentage(stats.users, stats.maxUsers)" :color="'#E6A23C'" />
        </el-card>
      </el-col>
      <el-col :xs="24" :sm="12" :md="6">
        <el-card class="stat-card" shadow="hover">
          <div class="stat-value">{{ stats.views }}</div>
          <div class="stat-label">Total Views</div>
          <el-progress :percentage="calculatePercentage(stats.views, stats.maxViews)" :color="'#409EFF'" />
        </el-card>
      </el-col>
    </el-row>

    <el-row :gutter="20" class="chart-row">
      <el-col :xs="24" :lg="12">
        <el-card class="chart-card" shadow="hover">
          <template #header>
            <div class="card-header">
              <h3>Article Statistics</h3>
              <el-radio-group v-model="chartTimeRange" size="small">
                <el-radio-button label="week">Week</el-radio-button>
                <el-radio-button label="month">Month</el-radio-button>
                <el-radio-button label="year">Year</el-radio-button>
              </el-radio-group>
            </div>
          </template>
          <div class="chart-placeholder">
            <div class="chart-message">Chart component will be rendered here</div>
          </div>
        </el-card>
      </el-col>
      <el-col :xs="24" :lg="12">
        <el-card class="chart-card" shadow="hover">
          <template #header>
            <div class="card-header">
              <h3>Category Distribution</h3>
            </div>
          </template>
          <div class="chart-placeholder">
            <div class="chart-message">Pie chart will be rendered here</div>
          </div>
        </el-card>
      </el-col>
    </el-row>

    <el-row :gutter="20">
      <el-col :xs="24" :lg="12">
        <el-card class="table-card" shadow="hover">
          <template #header>
            <div class="card-header">
              <h3>Recent Articles</h3>
              <router-link to="/content/article">
                <el-button type="text">View All</el-button>
              </router-link>
            </div>
          </template>
          <el-table :data="recentArticles" style="width: 100%" v-loading="loading">
            <el-table-column prop="title" label="Title" min-width="180" />
            <el-table-column prop="author" label="Author" width="120" />
            <el-table-column prop="date" label="Date" width="120" />
            <el-table-column prop="status" label="Status" width="100">
              <template #default="scope">
                <el-tag :type="getStatusType(scope.row.status)">
                  {{ scope.row.status }}
                </el-tag>
              </template>
            </el-table-column>
          </el-table>
        </el-card>
      </el-col>
      <el-col :xs="24" :lg="12">
        <el-card class="table-card" shadow="hover">
          <template #header>
            <div class="card-header">
              <h3>Popular Categories</h3>
              <router-link to="/content/category">
                <el-button type="text">View All</el-button>
              </router-link>
            </div>
          </template>
          <el-table :data="popularCategories" style="width: 100%" v-loading="loading">
            <el-table-column prop="name" label="Name" min-width="120" />
            <el-table-column prop="articles" label="Articles" width="100" />
            <el-table-column prop="views" label="Views" width="100" />
            <el-table-column label="Trend" width="120">
              <template #default="scope">
                <el-progress :percentage="scope.row.trend" :format="formatTrend" />
              </template>
            </el-table-column>
          </el-table>
        </el-card>
      </el-col>
    </el-row>
  </div>
</template>

<script>
import { ref, reactive, onMounted } from 'vue'
import { Refresh } from '@element-plus/icons-vue'

export default {
  name: 'Dashboard',
  components: {
    Refresh
  },
  setup() {
    const loading = ref(false)
    const chartTimeRange = ref('week')

    // Statistics reactive data
    const stats = reactive({
      articles: 0,
      categories: 0,
      users: 0,
      views: 0,
      maxArticles: 100,
      maxCategories: 20,
      maxUsers: 50,
      maxViews: 10000
    })

    // Tables data
    const recentArticles = ref([])
    const popularCategories = ref([])

    // Method to calculate percentage for progress bars
    const calculatePercentage = (value, max) => {
      return Math.min(Math.round((value / max) * 100), 100)
    }

    // Format trend percentage
    const formatTrend = (percentage) => {
      return percentage > 0 ? `+${percentage}%` : `${percentage}%`
    }

    // Get status type for el-tag
    const getStatusType = (status) => {
      const types = {
        published: 'success',
        draft: 'info',
        pending: 'warning',
        archived: 'danger'
      }
      return types[status] || 'info'
    }

    // Method to load dashboard data
    const loadDashboardData = async () => {
      loading.value = true
      try {
        // In a real app, we would fetch data from API
        // const response = await fetchDashboardData()
        
        // For now, use mock data
        setTimeout(() => {
          stats.articles = 42
          stats.categories = 8
          stats.users = 12
          stats.views = 2750

          recentArticles.value = [
            { title: 'Introduction to Content Management', author: 'John Doe', date: '2023-11-15', status: 'published' },
            { title: 'Best Practices for SEO', author: 'Jane Smith', date: '2023-11-14', status: 'published' },
            { title: 'Upcoming Features in CMS 2.0', author: 'Admin User', date: '2023-11-13', status: 'draft' },
            { title: 'How to Optimize Your Content', author: 'John Doe', date: '2023-11-10', status: 'published' },
            { title: 'Content Strategy for 2024', author: 'Jane Smith', date: '2023-11-08', status: 'pending' }
          ]

          popularCategories.value = [
            { name: 'Products', articles: 15, views: 1250, trend: 12 },
            { name: 'News', articles: 9, views: 850, trend: 8 },
            { name: 'Solutions', articles: 6, views: 450, trend: -3 },
            { name: 'Case Studies', articles: 5, views: 320, trend: 15 },
            { name: 'About Us', articles: 3, views: 180, trend: 2 }
          ]

          loading.value = false
        }, 800)
      } catch (error) {
        console.error('Error loading dashboard data:', error)
        loading.value = false
      }
    }

    // Refresh data
    const refreshData = () => {
      loadDashboardData()
    }

    // Load data on component mount
    onMounted(() => {
      loadDashboardData()
    })

    return {
      loading,
      stats,
      recentArticles,
      popularCategories,
      chartTimeRange,
      calculatePercentage,
      formatTrend,
      getStatusType,
      refreshData
    }
  }
}
</script>

<style scoped>
.dashboard {
  padding: 20px;
}

.stat-card {
  margin-bottom: 20px;
  text-align: center;
}

.stat-value {
  font-size: 28px;
  font-weight: bold;
  margin-bottom: 5px;
}

.stat-label {
  margin-bottom: 10px;
  font-size: 14px;
  color: #606266;
}

.chart-row {
  margin-bottom: 20px;
}

.chart-card, .table-card {
  margin-bottom: 20px;
  height: 350px;
}

.chart-placeholder {
  height: 280px;
  display: flex;
  align-items: center;
  justify-content: center;
  background-color: #f5f7fa;
  border-radius: 4px;
}

.chart-message {
  color: #909399;
  font-size: 14px;
}

.card-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.card-header h3 {
  margin: 0;
  font-size: 16px;
  font-weight: 500;
}
</style>