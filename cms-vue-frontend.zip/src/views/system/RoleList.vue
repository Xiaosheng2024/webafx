<template>
  <div class="role-list container">
    <div class="action-header">
      <div class="page-title">
        <h1>Role Management</h1>
      </div>
      <div class="action-buttons">
        <el-button type="primary" @click="showAddRoleDialog">
          <el-icon><Plus /></el-icon> Add Role
        </el-button>
      </div>
    </div>

    <el-card class="table-container" v-loading="loading">
      <el-table
        :data="roleList"
        border
        style="width: 100%"
        row-key="id"
      >
        <el-table-column label="ID" prop="id" width="80" />
        <el-table-column label="Role Name" prop="name" min-width="150" />
        <el-table-column label="Description" prop="description" min-width="250" show-overflow-tooltip />
        <el-table-column label="Users" width="100" align="center">
          <template #default="{ row }">
            <el-tag type="info">{{ row.userCount || 0 }}</el-tag>
          </template>
        </el-table-column>
        <el-table-column label="System Role" width="120" align="center">
          <template #default="{ row }">
            <el-tag v-if="row.systemRole" type="danger">Yes</el-tag>
            <el-tag v-else type="info">No</el-tag>
          </template>
        </el-table-column>
        <el-table-column label="Created At" width="180">
          <template #default="{ row }">
            {{ formatDateTime(row.createdAt) }}
          </template>
        </el-table-column>
        <el-table-column label="Operations" width="250" fixed="right">
          <template #default="{ row }">
            <el-button size="small" @click="handleEditRole(row)">Edit</el-button>
            <el-button size="small" type="primary" @click="handleManagePermissions(row)">Permissions</el-button>
            <el-popconfirm
              title="Are you sure to delete this role? All users with this role will be affected."
              @confirm="handleDeleteRole(row)"
              :disabled="row.systemRole"
            >
              <template #reference>
                <el-button size="small" type="danger" :disabled="row.systemRole">Delete</el-button>
              </template>
            </el-popconfirm>
          </template>
        </el-table-column>
      </el-table>
    </el-card>

    <!-- Role Dialog -->
    <el-dialog
      v-model="roleDialog.visible"
      :title="roleDialog.type === 'create' ? 'Add Role' : 'Edit Role'"
      width="500px"
      @close="resetRoleForm"
    >
      <el-form
        ref="roleFormRef"
        :model="roleForm"
        :rules="roleRules"
        label-width="100px"
      >
        <el-form-item label="Role Name" prop="name">
          <el-input 
            v-model="roleForm.name" 
            placeholder="Enter role name"
            :disabled="roleForm.systemRole"
          />
        </el-form-item>
        <el-form-item label="Description" prop="description">
          <el-input 
            v-model="roleForm.description" 
            type="textarea"
            :rows="3"
            placeholder="Enter role description"
          />
        </el-form-item>
      </el-form>
      <template #footer>
        <div class="dialog-footer">
          <el-button @click="roleDialog.visible = false">Cancel</el-button>
          <el-button type="primary" @click="submitRoleForm" :loading="roleDialog.submitting">
            {{ roleDialog.type === 'create' ? 'Create' : 'Update' }}
          </el-button>
        </div>
      </template>
    </el-dialog>

    <!-- Permissions Dialog -->
    <el-dialog
      v-model="permissionsDialog.visible"
      :title="'Manage Permissions for ' + permissionsDialog.roleName"
      width="800px"
      destroy-on-close
    >
      <div v-loading="permissionsDialog.loading">
        <div class="permissions-header">
          <div class="role-info">
            <h3>{{ permissionsDialog.roleName }}</h3>
            <p>{{ permissionsDialog.roleDescription }}</p>
          </div>
          <div class="quick-actions">
            <el-button size="small" @click="selectAllPermissions">Select All</el-button>
            <el-button size="small" @click="deselectAllPermissions">Deselect All</el-button>
          </div>
        </div>

        <el-divider />

        <el-tabs v-model="permissionsDialog.activeTab" type="card">
          <el-tab-pane 
            v-for="category in permissionCategories" 
            :key="category.key" 
            :label="category.name" 
            :name="category.key"
          >
            <div class="permission-category">
              <div class="category-header">
                <h4>{{ category.name }}</h4>
                <div class="category-actions">
                  <el-checkbox 
                    v-model="categoryCheckedAll[category.key]"
                    :indeterminate="categoryIndeterminate[category.key]"
                    @change="(val) => handleCategoryCheckAllChange(val, category.key)"
                  >
                    Check all
                  </el-checkbox>
                </div>
              </div>
              
              <el-divider />
              
              <el-checkbox-group 
                v-model="checkedPermissions" 
                @change="handleCheckedPermissionsChange"
              >
                <div class="permission-list">
                  <el-row>
                    <el-col :span="12" v-for="permission in getPermissionsByCategory(category.key)" :key="permission.id">
                      <div class="permission-item">
                        <el-checkbox 
                          :label="permission.id" 
                          :disabled="permissionsDialog.isSystemRole && permission.systemPermission"
                        >
                          <div class="permission-info">
                            <span class="permission-name">{{ permission.name }}</span>
                            <span class="permission-code">{{ permission.code }}</span>
                          </div>
                        </el-checkbox>
                      </div>
                    </el-col>
                  </el-row>
                </div>
              </el-checkbox-group>
            </div>
          </el-tab-pane>
        </el-tabs>
      </div>
      <template #footer>
        <div class="dialog-footer">
          <el-button @click="permissionsDialog.visible = false">Cancel</el-button>
          <el-button type="primary" @click="savePermissions" :loading="permissionsDialog.submitting">
            Save Permissions
          </el-button>
        </div>
      </template>
    </el-dialog>
  </div>
</template>

<script>
import { ref, reactive, onMounted, computed, watch } from 'vue'
import { Plus } from '@element-plus/icons-vue'
import { ElMessage } from 'element-plus'
import axios from 'axios'

export default {
  name: 'RoleList',
  setup() {
    const loading = ref(false)
    const roleList = ref([])
    const roleFormRef = ref(null)

    // Role form
    const roleForm = reactive({
      id: undefined,
      name: '',
      description: '',
      systemRole: false
    })

    const roleDialog = reactive({
      visible: false,
      type: 'create',
      submitting: false
    })

    const roleRules = {
      name: [
        { required: true, message: 'Please enter role name', trigger: 'blur' },
        { min: 3, max: 50, message: 'Length should be 3 to 50 characters', trigger: 'blur' }
      ],
      description: [
        { required: true, message: 'Please enter role description', trigger: 'blur' }
      ]
    }

    // Permissions management
    const permissionList = ref([])
    const checkedPermissions = ref([])
    const permissionsDialog = reactive({
      visible: false,
      roleId: null,
      roleName: '',
      roleDescription: '',
      isSystemRole: false,
      loading: false,
      submitting: false,
      activeTab: 'content'
    })

    // Categories for organizing permissions
    const permissionCategories = [
      { key: 'content', name: 'Content Management' },
      { key: 'user', name: 'User Management' },
      { key: 'system', name: 'System Settings' },
      { key: 'marketing', name: 'Marketing' },
      { key: 'ecommerce', name: 'E-commerce' }
    ]

    // For handling select all and partial selection in categories
    const categoryCheckedAll = reactive({})
    const categoryIndeterminate = reactive({})

    // Initialize category checked states
    permissionCategories.forEach(category => {
      categoryCheckedAll[category.key] = false
      categoryIndeterminate[category.key] = false
    })

    // Get permissions by category
    const getPermissionsByCategory = (categoryKey) => {
      return permissionList.value.filter(p => p.category === categoryKey)
    }

    // Format date time
    const formatDateTime = (dateTimeStr) => {
      if (!dateTimeStr) return ''
      const date = new Date(dateTimeStr)
      return date.toLocaleString()
    }

    // Fetch roles list
    const fetchRoleList = async () => {
      loading.value = true
      try {
        const response = await axios.get('/api/roles')
        roleList.value = response.data.data.content || []
      } catch (error) {
        console.error('Failed to fetch roles:', error)
        ElMessage.error('Failed to load roles')
      } finally {
        loading.value = false
      }
    }

    // Fetch all available permissions
    const fetchPermissions = async () => {
      try {
        const response = await axios.get('/api/permissions')
        permissionList.value = response.data.data || []
      } catch (error) {
        console.error('Failed to fetch permissions:', error)
        ElMessage.error('Failed to load permissions')
      }
    }

    // Show add role dialog
    const showAddRoleDialog = () => {
      roleDialog.type = 'create'
      roleDialog.visible = true
      resetRoleForm()
    }

    // Handle edit role
    const handleEditRole = (row) => {
      roleDialog.type = 'edit'
      roleDialog.visible = true
      
      Object.assign(roleForm, {
        id: row.id,
        name: row.name,
        description: row.description,
        systemRole: row.systemRole
      })
    }

    // Reset role form
    const resetRoleForm = () => {
      if (roleFormRef.value) {
        roleFormRef.value.resetFields()
      }
      
      Object.assign(roleForm, {
        id: undefined,
        name: '',
        description: '',
        systemRole: false
      })
    }

    // Submit role form
    const submitRoleForm = async () => {
      if (!roleFormRef.value) return
      
      await roleFormRef.value.validate(async (valid) => {
        if (!valid) return
        
        roleDialog.submitting = true
        try {
          const formData = { ...roleForm }
          
          let response
          if (roleDialog.type === 'create') {
            response = await axios.post('/api/roles', formData)
          } else {
            response = await axios.put(`/api/roles/${formData.id}`, formData)
          }
          
          ElMessage.success(`Role ${roleDialog.type === 'create' ? 'created' : 'updated'} successfully`)
          roleDialog.visible = false
          fetchRoleList()
        } catch (error) {
          console.error('Failed to save role:', error)
          if (error.response && error.response.data && error.response.data.message) {
            ElMessage.error(error.response.data.message)
          } else {
            ElMessage.error(`Failed to ${roleDialog.type === 'create' ? 'create' : 'update'} role`)
          }
        } finally {
          roleDialog.submitting = false
        }
      })
    }

    // Handle delete role
    const handleDeleteRole = async (row) => {
      if (row.systemRole) {
        ElMessage.warning('System roles cannot be deleted')
        return
      }
      
      try {
        await axios.delete(`/api/roles/${row.id}`)
        ElMessage.success('Role deleted successfully')
        fetchRoleList()
      } catch (error) {
        console.error('Failed to delete role:', error)
        if (error.response && error.response.data && error.response.data.message) {
          ElMessage.error(error.response.data.message)
        } else {
          ElMessage.error('Failed to delete role')
        }
      }
    }

    // Handle manage permissions
    const handleManagePermissions = async (row) => {
      permissionsDialog.visible = true
      permissionsDialog.loading = true
      permissionsDialog.roleId = row.id
      permissionsDialog.roleName = row.name
      permissionsDialog.roleDescription = row.description
      permissionsDialog.isSystemRole = row.systemRole
      
      try {
        // Load role permissions
        const response = await axios.get(`/api/roles/${row.id}/permissions`)
        const rolePermissions = response.data.data || []
        checkedPermissions.value = rolePermissions.map(p => p.id)
        
        // Update category selection states
        updateCategoryCheckStates()
        
        permissionsDialog.loading = false
      } catch (error) {
        console.error('Failed to fetch role permissions:', error)
        ElMessage.error('Failed to load role permissions')
        permissionsDialog.visible = false
        permissionsDialog.loading = false
      }
    }
    
    // Handle category check all change
    const handleCategoryCheckAllChange = (val, categoryKey) => {
      const categoryPermissions = getPermissionsByCategory(categoryKey)
      
      if (val) {
        // When selecting all, only add permissions that aren't disabled
        const permissionsToAdd = categoryPermissions
          .filter(p => !(permissionsDialog.isSystemRole && p.systemPermission))
          .map(p => p.id)
          
        // Merge with existing permissions, avoiding duplicates
        const newCheckedPermissions = [...new Set([...checkedPermissions.value, ...permissionsToAdd])]
        checkedPermissions.value = newCheckedPermissions
      } else {
        // When deselecting, remove all permissions from this category that aren't disabled system permissions
        checkedPermissions.value = checkedPermissions.value.filter(id => {
          const permission = categoryPermissions.find(p => p.id === id)
          return !permission || (permissionsDialog.isSystemRole && permission.systemPermission)
        })
      }
      
      categoryIndeterminate[categoryKey] = false
    }
    
    // Handle checked permissions change
    const handleCheckedPermissionsChange = () => {
      updateCategoryCheckStates()
    }
    
    // Update category check states based on selected permissions
    const updateCategoryCheckStates = () => {
      permissionCategories.forEach(category => {
        const categoryPermissions = getPermissionsByCategory(category.key)
        const availablePermissions = categoryPermissions.filter(
          p => !(permissionsDialog.isSystemRole && p.systemPermission)
        )
        
        if (availablePermissions.length === 0) {
          categoryCheckedAll[category.key] = false
          categoryIndeterminate[category.key] = false
          return
        }
        
        // Check how many permissions are selected in this category
        const checkedCount = categoryPermissions.filter(
          p => checkedPermissions.value.includes(p.id)
        ).length
        
        categoryCheckedAll[category.key] = checkedCount === availablePermissions.length
        categoryIndeterminate[category.key] = checkedCount > 0 && checkedCount < availablePermissions.length
      })
    }
    
    // Select all permissions
    const selectAllPermissions = () => {
      // Only select permissions that aren't disabled for system roles
      const availablePermissionIds = permissionList.value
        .filter(p => !(permissionsDialog.isSystemRole && p.systemPermission))
        .map(p => p.id)
        
      checkedPermissions.value = [...availablePermissionIds]
      updateCategoryCheckStates()
    }
    
    // Deselect all permissions
    const deselectAllPermissions = () => {
      // Keep only system permissions for system roles, otherwise clear all
      if (permissionsDialog.isSystemRole) {
        const systemPermissionIds = permissionList.value
          .filter(p => p.systemPermission)
          .map(p => p.id)
        checkedPermissions.value = [...systemPermissionIds]
      } else {
        checkedPermissions.value = []
      }
      updateCategoryCheckStates()
    }
    
    // Save permissions for a role
    const savePermissions = async () => {
      permissionsDialog.submitting = true
      try {
        await axios.put(`/api/roles/${permissionsDialog.roleId}/permissions`, {
          permissionIds: checkedPermissions.value
        })
        
        ElMessage.success('Role permissions updated successfully')
        permissionsDialog.visible = false
      } catch (error) {
        console.error('Failed to update role permissions:', error)
        ElMessage.error('Failed to update role permissions')
      } finally {
        permissionsDialog.submitting = false
      }
    }

    onMounted(() => {
      fetchRoleList()
      fetchPermissions()
    })

    // Watch for changes to the permission list to update category check states
    watch(permissionList, () => {
      if (permissionsDialog.visible) {
        updateCategoryCheckStates()
      }
    })

    return {
      loading,
      roleList,
      roleForm,
      roleFormRef,
      roleDialog,
      roleRules,
      permissionList,
      checkedPermissions,
      permissionsDialog,
      permissionCategories,
      categoryCheckedAll,
      categoryIndeterminate,
      getPermissionsByCategory,
      formatDateTime,
      showAddRoleDialog,
      handleEditRole,
      handleDeleteRole,
      resetRoleForm,
      submitRoleForm,
      handleManagePermissions,
      selectAllPermissions,
      deselectAllPermissions,
      handleCategoryCheckAllChange,
      handleCheckedPermissionsChange,
      savePermissions,
      Plus
    }
  }
}
</script>

<style scoped>
.role-list {
  padding: 20px;
}

.action-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 20px;
}

.table-container {
  margin-bottom: 20px;
}

.dialog-footer {
  display: flex;
  justify-content: flex-end;
}

.permissions-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 15px;
}

.role-info h3 {
  margin: 0 0 5px 0;
}

.role-info p {
  margin: 0;
  color: #606266;
  font-size: 14px;
}

.permission-category {
  margin-bottom: 20px;
}

.category-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.category-header h4 {
  margin: 0;
}

.permission-list {
  margin-top: 15px;
}

.permission-item {
  padding: 8px 0;
}

.permission-info {
  display: flex;
  flex-direction: column;
}

.permission-name {
  font-size: 14px;
}

.permission-code {
  font-size: 12px;
  color: #909399;
}
</style>