<template>
  <div class="system-settings container">
    <div class="action-header">
      <div class="page-title">
        <h1>System Settings</h1>
      </div>
      <div class="action-buttons">
        <el-button type="primary" @click="saveSettings" :loading="saving">
          <el-icon><Check /></el-icon> Save Settings
        </el-button>
      </div>
    </div>

    <el-tabs v-model="activeTab" tab-position="left" class="content-tabs">
      <el-tab-pane label="General Settings" name="general">
        <el-card class="tab-card">
          <template #header>
            <div class="card-header">
              <span>Site Information</span>
            </div>
          </template>

          <el-form label-width="180px" :model="settingsData.general">
            <el-form-item label="Website Title">
              <el-input v-model="settingsData.general.siteTitle" placeholder="Enter website title" />
            </el-form-item>
            
            <el-form-item label="Site Description">
              <el-input 
                v-model="settingsData.general.siteDescription" 
                type="textarea"
                :rows="2"
                placeholder="Enter site description for SEO"
              />
            </el-form-item>
            
            <el-form-item label="Company Name">
              <el-input v-model="settingsData.general.companyName" placeholder="Enter company name" />
            </el-form-item>

            <el-form-item label="Copyright Text">
              <el-input v-model="settingsData.general.copyrightText" placeholder="Enter copyright text" />
            </el-form-item>
            
            <el-form-item label="Website Logo">
              <el-upload
                class="logo-uploader"
                :action="uploadUrl"
                :headers="headers"
                :show-file-list="false"
                :on-success="handleLogoSuccess"
                :before-upload="beforeLogoUpload"
              >
                <img v-if="settingsData.general.logo" :src="settingsData.general.logo" class="logo-image" />
                <div v-else class="logo-uploader-placeholder">
                  <el-icon><Plus /></el-icon>
                  <div>Upload Logo</div>
                </div>
              </el-upload>
              <div class="upload-tip">Recommended size: 200x60px, transparent PNG</div>
            </el-form-item>
            
            <el-form-item label="Favicon">
              <el-upload
                class="favicon-uploader"
                :action="uploadUrl"
                :headers="headers"
                :show-file-list="false"
                :on-success="handleFaviconSuccess"
                :before-upload="beforeImageUpload"
              >
                <img v-if="settingsData.general.favicon" :src="settingsData.general.favicon" class="favicon-image" />
                <div v-else class="favicon-uploader-placeholder">
                  <el-icon><Plus /></el-icon>
                  <div>Upload Favicon</div>
                </div>
              </el-upload>
              <div class="upload-tip">Square image, at least 32x32px, will be converted to ico/png</div>
            </el-form-item>

            <el-form-item label="Default Language">
              <el-select v-model="settingsData.general.defaultLanguage" placeholder="Select default language">
                <el-option label="English" value="en" />
                <el-option label="Spanish" value="es" />
                <el-option label="French" value="fr" />
                <el-option label="German" value="de" />
                <el-option label="Chinese" value="zh" />
              </el-select>
            </el-form-item>

            <el-form-item label="Time Zone">
              <el-select v-model="settingsData.general.timezone" placeholder="Select time zone" filterable>
                <el-option
                  v-for="tz in timezones"
                  :key="tz.value"
                  :label="tz.label"
                  :value="tz.value"
                />
              </el-select>
            </el-form-item>
          </el-form>
        </el-card>
      </el-tab-pane>
      
      <el-tab-pane label="SEO & Meta" name="seo">
        <el-card class="tab-card">
          <template #header>
            <div class="card-header">
              <span>SEO Settings</span>
            </div>
          </template>

          <el-form label-width="180px" :model="settingsData.seo">
            <el-form-item label="Meta Title Template">
              <el-input 
                v-model="settingsData.seo.metaTitleTemplate" 
                placeholder="E.g., {page} | {site_name}" 
              />
              <div class="input-help">Use {page} for page title, {site_name} for website name</div>
            </el-form-item>
            
            <el-form-item label="Meta Description">
              <el-input 
                v-model="settingsData.seo.metaDescription" 
                type="textarea"
                :rows="3"
                placeholder="Default meta description for pages"
              />
            </el-form-item>
            
            <el-form-item label="Meta Keywords">
              <el-select
                v-model="settingsData.seo.metaKeywords"
                multiple
                filterable
                allow-create
                default-first-option
                placeholder="Enter keywords and press Enter"
              ></el-select>
            </el-form-item>
            
            <el-form-item label="Google Analytics ID">
              <el-input 
                v-model="settingsData.seo.googleAnalyticsId" 
                placeholder="E.g., G-XXXXXXXXXX or UA-XXXXXXXX-X" 
              />
            </el-form-item>
            
            <el-form-item label="Google Site Verification">
              <el-input 
                v-model="settingsData.seo.googleSiteVerification" 
                placeholder="Google site verification code" 
              />
            </el-form-item>
            
            <el-form-item label="Robots.txt Content">
              <el-input 
                v-model="settingsData.seo.robotsTxt" 
                type="textarea"
                :rows="5"
                placeholder="Content for robots.txt file"
              />
            </el-form-item>
            
            <el-form-item label="Enable Sitemap">
              <el-switch v-model="settingsData.seo.enableSitemap" />
            </el-form-item>
            
            <el-form-item label="Sitemap Update Frequency" v-if="settingsData.seo.enableSitemap">
              <el-select v-model="settingsData.seo.sitemapFrequency" placeholder="Select frequency">
                <el-option label="Always" value="always" />
                <el-option label="Hourly" value="hourly" />
                <el-option label="Daily" value="daily" />
                <el-option label="Weekly" value="weekly" />
                <el-option label="Monthly" value="monthly" />
                <el-option label="Yearly" value="yearly" />
                <el-option label="Never" value="never" />
              </el-select>
            </el-form-item>
          </el-form>
        </el-card>
      </el-tab-pane>
