<!-- src/views/system/UserManagement.vue -->
<template>
  <div class="user-management">
    <div class="page-header flex-between">
      <h2>User Management</h2>
      <el-button type="primary" @click="handleAdd">
        <el-icon><Plus /></el-icon>
        New User
      </el-button>
    </div>

    <!-- Search Form -->
    <el-card class="search-card">
      <el-form :model="searchForm" ref="searchFormRef" label-width="100px" class="search-form" @submit.prevent>
        <el-row :gutter="20">
          <el-col :xs="24" :sm="12" :md="8">
            <el-form-item label="Username:">
              <el-input v-model="searchForm.username" placeholder="Search by username" clearable />
            </el-form-item>
          </el-col>
          <el-col :xs="24" :sm="12" :md="8">
            <el-form-item label="Name:">
              <el-input v-model="searchForm.name" placeholder="Search by name" clearable />
            </el-form-item>
          </el-col>
          <el-col :xs="24" :sm="12" :md="8">
            <el-form-item label="Role:">
              <el-select v-model="searchForm.roleId" placeholder="Select role" clearable>
                <el-option v-for="role in roles" :key="role.id" :label="role.name" :value="role.id" />
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :xs="24" class="form-buttons">
            <el-button type="primary" @click="handleSearch">Search</el-button>
            <el-button @click="resetSearch">Reset</el-button>
          </el-col>
        </el-row>
      </el-form>
    </el-card>

    <!-- Table -->
    <el-card class="table-card">
      <el-table 
        :data="tableData" 
        v-loading="loading"
        style="width: 100%"
        @selection-change="handleSelectionChange"
      >
        <el-table-column type="selection" width="55" />
        <el-table-column prop="id" label="ID" width="80" />
        <el-table-column prop="username" label="Username" width="120" />
        <el-table-column prop="name" label="Name" width="140" />
        <el-table-column prop="email" label="Email" min-width="180" />
        <el-table-column label="Avatar" width="80">
          <template #default="scope">
            <el-avatar :size="40" :src="scope.row.avatar || defaultAvatar" />
          </template>
        </el-table-column>
        <el-table-column prop="roles" label="Roles" width="200">
          <template #default="scope">
            <el-tag 
              v-for="role in scope.row.roles" 
              :key="role.id" 
              class="role-tag"
              :type="getRoleType(role.name)"
            >
              {{ role.name }}
            </el-tag>
          </template>
        </el-table-column>
        <el-table-column prop="lastLoginTime" label="Last Login" width="170" sortable />
        <el-table-column prop="status" label="Status" width="100">
          <template #default="scope">
            <el-tag :type="scope.row.status === 'active' ? 'success' : 'danger'">
              {{ scope.row.status }}
            </el-tag>
          </template>
        </el-table-column>
        <el-table-column fixed="right" label="Operations" width="250">
          <template #default="scope">
            <el-button type="primary" size="small" link @click="handleEdit(scope.row)">Edit</el-button>
            <el-button 
              type="success" 
              size="small" 
              link 
              @click="handleResetPassword(scope.row)"
            >
              Reset Password
            </el-button>
            <el-button 
              type="warning" 
              size="small" 
              link 
              @click="handleToggleStatus(scope.row)"
            >
              {{ scope.row.status === 'active' ? 'Disable' : 'Enable' }}
            </el-button>
            <el-button 
              type="danger" 
              size="small" 
              link 
              @click="handleDelete(scope.row)"
              :disabled="scope.row.username === 'admin'"
            >
              Delete
            </el-button>
          </template>
        </el-table-column>
      </el-table>

      <!-- Pagination -->
      <el-pagination
        class="cms-pagination"
        :current-page="pagination.current"
        :page-size="pagination.pageSize"
        :total="pagination.total"
        :page-sizes="[10, 20, 50, 100]"
        layout="total, sizes, prev, pager, next, jumper"
        @size-change="handleSizeChange"
        @current-change="handleCurrentChange"
      />
    </el-card>

    <!-- User Form Dialog -->
    <el-dialog
      :title="dialogTitle"
      v-model="dialogVisible"
      width="500px"
    >
      <el-form
        ref="formRef"
        :model="form"
        :rules="rules"
        label-width="100px"
      >
        <el-form-item label="Username" prop="username" :disabled="isEdit">
          <el-input v-model="form.username" placeholder="Enter username" :disabled="isEdit" />
        </el-form-item>
        <el-form-item label="Name" prop="name">
          <el-input v-model="form.name" placeholder="Enter name" />
        </el-form-item>
        <el-form-item label="Email" prop="email">
          <el-input v-model="form.email" placeholder="Enter email" />
        </el-form-item>
        <el-form-item label="Password" prop="password" v-if="!isEdit">
          <el-input v-model="form.password" placeholder="Enter password" type="password" />
        </el-form-item>
        <el-form-item label="Confirm" prop="confirmPassword" v-if="!isEdit">
          <el-input v-model="form.confirmPassword" placeholder="Confirm password" type="password" />
        </el-form-item>
        <el-form-item label="Roles" prop="roleIds">
          <el-select v-model="form.roleIds" multiple placeholder="Select roles" class="w-100">
            <el-option
              v-for="role in roles"
              :key="role.id"
              :label="role.name"
              :value="role.id"
            />
          </el-select>
        </el-form-item>
        <el-form-item label="Status">
          <el-switch
            v-model="form.status"
            :active-value="'active'"
            :inactive-value="'inactive'"
          />
        </el-form-item>
        <el-form-item label="Avatar">
          <el-upload
            class="avatar-upload"
            :show-file-list="false"
            :before-upload="beforeAvatarUpload"
            :http-request="handleAvatarUpload"
          >
            <el-avatar 
              v-if="form.avatar" 
              :src="form.avatar" 
              :size="100"
              class="avatar-preview" 
            />
            <el-button v-else type="primary">Upload Avatar</el-button>
          </el-upload>
        </el-form-item>
      </el-form>
      <template #footer>
        <div class="dialog-footer">
          <el-button @click="dialogVisible = false">Cancel</el-button>
          <el-button type="primary" @click="submitForm">Confirm</el-button>
        </div>
      </template>
    </el-dialog>

    <!-- Role Assignment Dialog -->
    <el-dialog
      title="Role Assignment"
      v-model="roleDialogVisible"
      width="500px"
    >
      <div v-if="currentUser">
        <p class="mb-20">Assign roles to user: <strong>{{ currentUser.username }}</strong></p>
        <el-checkbox-group v-model="selectedRoles">
          <el-checkbox 
            v-for="role in roles" 
            :key="role.id" 
            :label="role.id"
            border
            class="role-checkbox"
          >
            <div class="role-checkbox-content">
              <div class="role-name">{{ role.name }}</div>
              <div class="role-description">{{ role.description }}</div>
            </div>
          </el-checkbox>
        </el-checkbox-group>
      </div>
      <template #footer>
        <div class="dialog-footer">
          <el-button @click="roleDialogVisible = false">Cancel</el-button>
          <el-button type="primary" @click="updateUserRoles">Confirm</el-button>
        </div>
      </template>
    </el-dialog>
  </div>
</template>

<script>
import { ref, reactive, computed, onMounted } from 'vue'
import { Plus } from '@element-plus/icons-vue'
import { ElMessage, ElMessageBox } from 'element-plus'
import { getUsers, getUserDetails, createUser, updateUser, deleteUser, resetPassword, updateUserStatus } from '@/api/user'

export default {
  name: 'UserManagement',
  components: {
    Plus
  },
  setup() {
    const loading = ref(false)
    const tableData = ref([])
    const roles = ref([])
    const searchFormRef = ref(null)
    const formRef = ref(null)
    const selectedRows = ref([])
    const dialogVisible = ref(false)
    const roleDialogVisible = ref(false)
    const isEdit = ref(false)
    const currentUser = ref(null)
    const selectedRoles = ref([])
    const defaultAvatar = 'https://cube.elemecdn.com/3/7c/3ea6beec64369c2642b92c6726f1epng.png'
    
    // Search form
    const searchForm = reactive({
      username: '',
      name: '',
      roleId: ''
    })
    
    // Pagination
    const pagination = reactive({
      current: 1,
      pageSize: 10,
      total: 0
    })
    
    // Form data
    const form = reactive({
      id: null,
      username: '',
      name: '',
      email: '',
      password: '',
      confirmPassword: '',
      roleIds: [],
      status: 'active',
      avatar: ''
    })
    
    // Form validation rules
    const rules = {
      username: [
        { required: true, message: 'Please enter username', trigger: 'blur' },
        { min: 4, max: 20, message: 'Length should be 4 to 20 characters', trigger: 'blur' }
      ],
      name: [
        { required: true, message: 'Please enter name', trigger: 'blur' }
      ],
      email: [
        { required: true, message: 'Please enter email', trigger: 'blur' },
        { type: 'email', message: 'Please enter a valid email address', trigger: 'blur' }
      ],
      password: [
        { required: true, message: 'Please enter password', trigger: 'blur', validator: (rule, value, callback) => {
          if (!isEdit.value && !value) {
            callback(new Error('Please enter password'))
          } else {
            callback()
          }
        }},
        { min: 6, message: 'Password length should be at least 6 characters', trigger: 'blur' }
      ],
      confirmPassword: [
        { required: true, message: 'Please confirm password', trigger: 'blur', validator: (rule, value, callback) => {
          if (!isEdit.value && !value) {
            callback(new Error('Please confirm password'))
          } else if (value !== form.password) {
            callback(new Error('Passwords do not match'))
          } else {
            callback()
          }
        }}
      ],
      roleIds: [
        { type: 'array', required: true, message: 'Please select at least one role', trigger: 'change' }
      ]
    }
    
    const dialogTitle = computed(() => isEdit.value ? 'Edit User' : 'Add User')
    
    const getRoleType = (roleName) => {
      const types = {
        'Administrator': 'danger',
        'Editor': 'primary',
        'Author': 'success',
        'Viewer': 'info'
      }
      return types[roleName] || 'info'
    }
    
    // Fetch users
    const fetchUsers = async () => {
      loading.value = true
      try {
        // In a real app, we would fetch from API
        // const response = await getUsers({
        //   page: pagination.current,
        //   pageSize: pagination.pageSize,
        //   ...searchForm
        // })
        
        // For now, use mock data
        setTimeout(() => {
          tableData.value = [
            {
              id: 1,
              username: 'admin',
              name: 'Admin User',
              email: 'admin@example.com',
              avatar: '',
              roles: [{ id: 1, name: 'Administrator' }],
              lastLoginTime: '2023-11-20 09:15:32',
              status: 'active'
            },
            {
              id: 2,
              username: 'editor',
              name: 'John Editor',
              email: 'editor@example.com',
              avatar: '',
              roles: [{ id: 2, name: 'Editor' }],
              lastLoginTime: '2023-11-19 14:30:47',
              status: 'active'
            },
            {
              id: 3,
              username: 'author',
              name: 'Jane Author',
              email: 'author@example.com',
              avatar: '',
              roles: [{ id: 3, name: 'Author' }],
              lastLoginTime: '2023-11-18 11:22:05',
              status: 'active'
            },
            {
              id: 4,
              username: 'user',
              name: 'Regular User',
              email: 'user@example.com',
              avatar: '',
              roles: [{ id: 4, name: 'Viewer' }],
              lastLoginTime: '2023-11-15 16:45:30',
              status: 'inactive'
            }
          ]
          
          // Set pagination total
          pagination.total = 4
          
          // Mock roles
          roles.value = [
            { id: 1, name: 'Administrator', description: 'Full access to all features' },
            { id: 2, name: 'Editor', description: 'Can edit and publish content' },
            { id: 3, name: 'Author', description: 'Can create and edit own content' },
            { id: 4, name: 'Viewer', description: 'Read-only access to content' }
          ]
          
          loading.value = false
        }, 800)
      } catch (error) {
        console.error('Error loading users:', error)
        ElMessage({ message: 'Failed to load users', type: 'error' })
        loading.value = false
      }
    }
    
    // Handle search form submission
    const handleSearch = () => {
      pagination.current = 1
      fetchUsers()
    }
    
    // Reset search form
    const resetSearch = () => {
      searchFormRef.value.resetFields()
      pagination.current = 1
      fetchUsers()
    }
    
    // Handle table selection change
    const handleSelectionChange = (rows) => {
      selectedRows.value = rows
    }
    
    // Handle pagination size change
    const handleSizeChange = (size) => {
      pagination.pageSize = size
      pagination.current = 1
      fetchUsers()
    }
    
    // Handle pagination current page change
    const handleCurrentChange = (current) => {
      pagination.current = current
      fetchUsers()
    }
    
    // Reset form fields
    const resetForm = () => {
      form.id = null
      form.username = ''
      form.name = ''
      form.email = ''
      form.password = ''
      form.confirmPassword = ''
      form.roleIds = []
      form.status = 'active'
      form.avatar = ''
      
      if (formRef.value) {
        formRef.value.resetFields()
      }
    }
    
    // Open add user dialog
    const handleAdd = () => {
      resetForm()
      isEdit.value = false
      dialogVisible.value = true
    }
    
    // Open edit user dialog
    const handleEdit = (row) => {
      resetForm()
      isEdit.value = true
      
      // Populate form with user data
      form.id = row.id
      form.username = row.username
      form.name = row.name
      form.email = row.email
      form.roleIds = row.roles.map(r => r.id)
      form.status = row.status
      form.avatar = row.avatar
      
      dialogVisible.value = true
    }
    
    // Handle reset password
    const handleResetPassword = (row) => {
      ElMessageBox.confirm(
        `Are you sure you want to reset the password for user "${row.username}"?`,
        'Reset Password',
        {
          confirmButtonText: 'Reset',
          cancelButtonText: 'Cancel',
          type: 'warning'
        }
      ).then(async () => {
        try {
          // In a real app, we would call API
          // await resetPassword(row.id)
          
          ElMessage({ message: 'Password reset successfully', type: 'success' })
        } catch (error) {
          console.error('Error resetting password:', error)
          ElMessage({ message: 'Failed to reset password', type: 'error' })
        }
      }).catch(() => {
        // User cancelled
      })
    }
    
    // Toggle user status
    const handleToggleStatus = (row) => {
      const newStatus = row.status === 'active' ? 'inactive' : 'active'
      const action = newStatus === 'active' ? 'enable' : 'disable'
      
      ElMessageBox.confirm(
        `Are you sure you want to ${action} the user "${row.username}"?`,
        `${action.charAt(0).toUpperCase() + action.slice(1)} User`,
        {
          confirmButtonText: 'Confirm',
          cancelButtonText: 'Cancel',
          type: 'warning'
        }
      ).then(async () => {
        try {
          // In a real app, we would call API
          // await updateUserStatus(row.id, newStatus)
          
          // For now, update locally
          const index = tableData.value.findIndex(u => u.id === row.id)
          tableData.value[index].status = newStatus
          
          ElMessage({ message: `User ${action}d successfully`, type: 'success' })
        } catch (error) {
          console.error(`Error ${action}ing user:`, error)
          ElMessage({ message: `Failed to ${action} user`, type: 'error' })
        }
      }).catch(() => {
        // User cancelled
      })
    }
    
    // Delete user
    const handleDelete = (row) => {
      if (row.username === 'admin') {
        ElMessage({
          message: 'Cannot delete admin user',
          type: 'warning'
        })
        return
      }
      
      ElMessageBox.confirm(
        `Are you sure you want to delete the user "${row.username}"?`,
        'Delete User',
        {
          confirmButtonText: 'Delete',
          cancelButtonText: 'Cancel',
          type: 'warning'
        }
      ).then(async () => {
        try {
          // In a real app, we would call API
          // await deleteUser(row.id)
          
          // For now, update locally
          tableData.value = tableData.value.filter(u => u.id !== row.id)
          
          ElMessage({ message: 'User deleted successfully', type: 'success' })
        } catch (error) {
          console.error('Error deleting user:', error)
          ElMessage({ message: 'Failed to delete user', type: 'error' })
        }
      }).catch(() => {
        // User cancelled
      })
    }
    
    // Before avatar upload hook
    const beforeAvatarUpload = (file) => {
      const isImage = file.type.startsWith('image/')
      const isLt2M = file.size / 1024 / 1024 < 2
      
      if (!isImage) {
        ElMessage({ message: 'Avatar must be an image file', type: 'error' })
        return false
      }
      
      if (!isLt2M) {
        ElMessage({ message: 'Avatar size cannot exceed 2MB', type: 'error' })
        return false
      }
      
      return true
    }
    
    // Custom avatar upload handler
    const handleAvatarUpload = async (options) => {
      try {
        const file = options.file
        
        // In a real app, we would upload to the server
        // const response = await uploadImage(file)
        // form.avatar = response.data.url
        
        // For now, use a placeholder
        const reader = new FileReader()
        reader.readAsDataURL(file)
        reader.onload = (e) => {
          form.avatar = e.target.result
          ElMessage({ message: 'Avatar uploaded successfully', type: 'success' })
        }
      } catch (error) {
        console.error('Error uploading avatar:', error)
        ElMessage({ message: 'Failed to upload avatar', type: 'error' })
      }
    }
    
    // Submit form
    const submitForm = () => {
      formRef.value.validate(async (valid) => {
        if (valid) {
          try {
            // In a real app, we would call API
            // if (isEdit.value) {
            //   await updateUser(form.id, form)
            // } else {
            //   await createUser(form)
            // }
            
            // For now, update locally
            if (isEdit.value) {
              const index = tableData.value.findIndex(u => u.id === form.id)
              
              // Map role IDs to role objects
              const userRoles = form.roleIds.map(id => {
                const role = roles.value.find(r => r.id === id)
                return { id: role.id, name: role.name }
              })
              
              tableData.value[index] = { 
                ...tableData.value[index], 
                name: form.name,
                email: form.email,
                roles: userRoles,
                status: form.status,
                avatar: form.avatar
              }
            } else {
              // Generate new ID
              const newId = Math.max(...tableData.value.map(u => u.id)) + 1
              
              // Map role IDs to role objects
              const userRoles = form.roleIds.map(id => {
                const role = roles.value.find(r => r.id === id)
                return { id: role.id, name: role.name }
              })
              
              tableData.value.push({
                id: newId,
                username: form.username,
                name: form.name,
                email: form.email,
                roles: userRoles,
                status: form.status,
                avatar: form.avatar,
                lastLoginTime: '-'
              })
            }
            
            ElMessage({
              message: isEdit.value ? 'User updated successfully' : 'User created successfully',
              type: 'success'
            })
            
            dialogVisible.value = false
          } catch (error) {
            console.error('Error saving user:', error)
            ElMessage({ message: 'Failed to save user', type: 'error' })
          }
        }
      })
    }
    
    // Update user roles
    const updateUserRoles = async () => {
      if (!currentUser.value) return
      
      try {
        // In a real app, we would call API
        // await updateUserRoles(currentUser.value.id, selectedRoles.value)
        
        // For now, update locally
        const index = tableData.value.findIndex(u => u.id === currentUser.value.id)
        
        // Map role IDs to role objects
        const userRoles = selectedRoles.value.map(id => {
          const role = roles.value.find(r => r.id === id)
          return { id: role.id, name: role.name }
        })
        
        tableData.value[index].roles = userRoles
        
        ElMessage({ message: 'User roles updated successfully', type: 'success' })
        roleDialogVisible.value = false
      } catch (error) {
        console.error('Error updating user roles:', error)
        ElMessage({ message: 'Failed to update user roles', type: 'error' })
      }
    }
    
    // Load users on component mount
    onMounted(() => {
      fetchUsers()
    })
    
    return {
      loading,
      tableData,
      roles,
      searchForm,
      searchFormRef,
      pagination,
      defaultAvatar,
      selectedRows,
      dialogVisible,
      roleDialogVisible,
      dialogTitle,
      isEdit,
      formRef,
      form,
      rules,
      currentUser,
      selectedRoles,
      getRoleType,
      handleSearch,
      resetSearch,
      handleSelectionChange,
      handleSizeChange,
      handleCurrentChange,
      handleAdd,
      handleEdit,
      handleResetPassword,
      handleToggleStatus,
      handleDelete,
      beforeAvatarUpload,
      handleAvatarUpload,
      submitForm,
      updateUserRoles
    }
  }
}
</script>

<style scoped>
.user-management {
  padding: 20px;
}

.search-card,
.table-card {
  margin-bottom: 20px;
}

.form-buttons {
  display: flex;
  justify-content: center;
  margin-top: 10px;
}

.role-tag {
  margin-right: 5px;
}

.w-100 {
  width: 100%;
}

.avatar-upload {
  display: flex;
  justify-content: center;
}

.avatar-preview {
  cursor: pointer;
}

.dialog-footer {
  text-align: right;
}

.mb-20 {
  margin-bottom: 20px;
}

.role-checkbox {
  display: block;
  margin-bottom: 10px;
  width: 100%;
}

.role-checkbox-content {
  padding: 5px 0;
}

.role-name {
  font-weight: bold;
  margin-bottom: 3px;
}

.role-description {
  font-size: 12px;
  color: #606266;
}
</style>