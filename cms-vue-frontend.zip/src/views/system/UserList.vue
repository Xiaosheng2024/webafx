<template>
  <div class="user-list container">
    <div class="action-header">
      <div class="page-title">
        <h1>User Management</h1>
      </div>
      <div class="action-buttons">
        <el-button type="primary" @click="showAddUserDialog">
          <el-icon><Plus /></el-icon> Add User
        </el-button>
      </div>
    </div>

    <el-card class="filter-container">
      <div class="filter-items">
        <el-form :inline="true" :model="queryParams" class="search-form">
          <el-form-item label="Username/Email">
            <el-input
              v-model="queryParams.keyword"
              placeholder="Search by username or email"
              clearable
              @keyup.enter="handleSearch"
            />
          </el-form-item>
          <el-form-item label="Role">
            <el-select v-model="queryParams.roleId" placeholder="All Roles" clearable>
              <el-option
                v-for="role in roles"
                :key="role.id"
                :label="role.name"
                :value="role.id"
              />
            </el-select>
          </el-form-item>
          <el-form-item label="Status">
            <el-select v-model="queryParams.enabled" placeholder="All Status" clearable>
              <el-option label="Enabled" :value="true" />
              <el-option label="Disabled" :value="false" />
            </el-select>
          </el-form-item>
          <el-form-item>
            <el-button type="primary" @click="handleSearch">
              <el-icon><Search /></el-icon> Search
            </el-button>
            <el-button @click="resetQuery">
              <el-icon><Refresh /></el-icon> Reset
            </el-button>
          </el-form-item>
        </el-form>
      </div>
    </el-card>

    <el-card class="table-container" v-loading="loading">
      <el-table
        :data="userList"
        border
        style="width: 100%"
        row-key="id"
      >
        <el-table-column label="ID" prop="id" width="80" />
        <el-table-column label="Avatar" width="80">
          <template #default="{ row }">
            <el-avatar 
              :size="40" 
              :src="row.avatar || defaultAvatar" 
              :icon="UserFilled" 
            />
          </template>
        </el-table-column>
        <el-table-column label="Username" prop="username" min-width="120" show-overflow-tooltip />
        <el-table-column label="Full Name" prop="fullName" min-width="120" show-overflow-tooltip />
        <el-table-column label="Email" prop="email" min-width="180" show-overflow-tooltip />
        <el-table-column label="Role" min-width="120">
          <template #default="{ row }">
            <el-tag 
              v-for="role in row.roles" 
              :key="role.id" 
              :type="getRoleTagType(role.name)" 
              class="role-tag"
            >
              {{ role.name }}
            </el-tag>
          </template>
        </el-table-column>
        <el-table-column label="Status" width="100">
          <template #default="{ row }">
            <el-tag :type="row.enabled ? 'success' : 'info'">
              {{ row.enabled ? 'Enabled' : 'Disabled' }}
            </el-tag>
          </template>
        </el-table-column>
        <el-table-column label="Last Login" width="180">
          <template #default="{ row }">
            {{ formatDateTime(row.lastLoginTime) || 'Never' }}
          </template>
        </el-table-column>
        <el-table-column label="Operations" width="220" fixed="right">
          <template #default="{ row }">
            <el-button size="small" @click="handleEditUser(row)">Edit</el-button>
            <el-button
              size="small"
              :type="row.enabled ? 'warning' : 'success'"
              @click="handleToggleStatus(row)"
            >
              {{ row.enabled ? 'Disable' : 'Enable' }}
            </el-button>
            <el-popconfirm
              title="Are you sure to delete this user?"
              @confirm="handleDeleteUser(row)"
              :disabled="row.id === currentUser.id"
            >
              <template #reference>
                <el-button size="small" type="danger" :disabled="row.id === currentUser.id">Delete</el-button>
              </template>
            </el-popconfirm>
          </template>
        </el-table-column>
      </el-table>

      <div class="pagination-container">
        <el-pagination
          v-model:current-page="queryParams.page"
          v-model:page-size="queryParams.size"
          :page-sizes="[10, 20, 50, 100]"
          :total="total"
          layout="total, sizes, prev, pager, next, jumper"
          @size-change="handleSizeChange"
          @current-change="handleCurrentChange"
        />
      </div>
    </el-card>

    <!-- User Dialog -->
    <el-dialog
      v-model="userDialog.visible"
      :title="userDialog.type === 'create' ? 'Add User' : 'Edit User'"
      width="600px"
      @close="resetUserForm"
    >
      <el-form
        ref="userFormRef"
        :model="userForm"
        :rules="userRules"
        label-width="120px"
        v-loading="userDialog.loading"
      >
        <el-form-item label="Avatar">
          <el-upload
            class="avatar-uploader"
            :action="uploadUrl"
            :headers="headers"
            :show-file-list="false"
            :on-success="handleAvatarSuccess"
            :before-upload="beforeAvatarUpload"
          >
            <img v-if="userForm.avatar" :src="userForm.avatar" class="avatar" />
            <el-icon v-else class="avatar-uploader-icon">
              <Plus />
            </el-icon>
          </el-upload>
        </el-form-item>
        <el-form-item label="Username" prop="username">
          <el-input 
            v-model="userForm.username" 
            placeholder="Enter username"
            :disabled="userDialog.type === 'edit'"
          />
        </el-form-item>
        <el-form-item label="Full Name" prop="fullName">
          <el-input v-model="userForm.fullName" placeholder="Enter full name" />
        </el-form-item>
        <el-form-item label="Email" prop="email">
          <el-input v-model="userForm.email" placeholder="Enter email address" />
        </el-form-item>
        <el-form-item 
          label="Password" 
          prop="password" 
          v-if="userDialog.type === 'create' || userForm.changePassword"
        >
          <el-input v-model="userForm.password" placeholder="Enter password" type="password" />
        </el-form-item>
        <el-form-item 
          label="Confirm Password" 
          prop="confirmPassword" 
          v-if="userDialog.type === 'create' || userForm.changePassword"
        >
          <el-input v-model="userForm.confirmPassword" placeholder="Confirm password" type="password" />
        </el-form-item>
        <el-form-item v-if="userDialog.type === 'edit'">
          <el-checkbox v-model="userForm.changePassword">Change Password</el-checkbox>
        </el-form-item>
        <el-form-item label="Roles" prop="roleIds">
          <el-select v-model="userForm.roleIds" multiple placeholder="Select roles">
            <el-option
              v-for="role in roles"
              :key="role.id"
              :label="role.name"
              :value="role.id"
            />
          </el-select>
        </el-form-item>
        <el-form-item label="Status" prop="enabled">
          <el-radio-group v-model="userForm.enabled">
            <el-radio :label="true">Enabled</el-radio>
            <el-radio :label="false">Disabled</el-radio>
          </el-radio-group>
        </el-form-item>
      </el-form>
      <template #footer>
        <div class="dialog-footer">
          <el-button @click="userDialog.visible = false">Cancel</el-button>
          <el-button type="primary" @click="submitUserForm" :loading="userDialog.submitting">
            {{ userDialog.type === 'create' ? 'Create' : 'Update' }}
          </el-button>
        </div>
      </template>
    </el-dialog>
  </div>
</template>

<script>
import { ref, reactive, onMounted, computed } from 'vue'
import { Plus, Search, Refresh, UserFilled } from '@element-plus/icons-vue'
import { ElMessage } from 'element-plus'
import axios from 'axios'
import { getToken } from '@/utils/auth'
import { useStore } from 'vuex'

export default {
  name: 'UserList',
  setup() {
    const store = useStore()
    const loading = ref(false)
    const userList = ref([])
    const total = ref(0)
    const roles = ref([])
    const userFormRef = ref(null)
    
    const currentUser = computed(() => store.state.user)
    const defaultAvatar = '/assets/avatar-placeholder.png'

    // Upload related
    const uploadUrl = '/api/media'
    const headers = {
      Authorization: `Bearer ${getToken()}`
    }

    const queryParams = reactive({
      page: 1,
      size: 10,
      keyword: '',
      roleId: '',
      enabled: null
    })

    const userForm = reactive({
      id: undefined,
      username: '',
      fullName: '',
      email: '',
      password: '',
      confirmPassword: '',
      changePassword: false,
      avatar: '',
      roleIds: [],
      enabled: true
    })

    const userDialog = reactive({
      visible: false,
      type: 'create',
      loading: false,
      submitting: false
    })

    // Validation rules
    const validatePassword = (rule, value, callback) => {
      if (userDialog.type === 'edit' && !userForm.changePassword) {
        callback()
      } else if (!value) {
        callback(new Error('Please enter password'))
      } else if (value.length < 6) {
        callback(new Error('Password must be at least 6 characters'))
      } else {
        callback()
      }
    }

    const validateConfirmPassword = (rule, value, callback) => {
      if (userDialog.type === 'edit' && !userForm.changePassword) {
        callback()
      } else if (!value) {
        callback(new Error('Please confirm password'))
      } else if (value !== userForm.password) {
        callback(new Error('Passwords do not match'))
      } else {
        callback()
      }
    }

    const userRules = {
      username: [{ required: true, message: 'Please enter username', trigger: 'blur' }],
      fullName: [{ required: true, message: 'Please enter full name', trigger: 'blur' }],
      email: [
        { required: true, message: 'Please enter email', trigger: 'blur' },
        { type: 'email', message: 'Please enter a valid email address', trigger: 'blur' }
      ],
      password: [{ validator: validatePassword, trigger: 'blur' }],
      confirmPassword: [{ validator: validateConfirmPassword, trigger: 'blur' }],
      roleIds: [{ required: true, type: 'array', message: 'Please select at least one role', trigger: 'change' }]
    }

    // Format date time
    const formatDateTime = (dateTimeStr) => {
      if (!dateTimeStr) return ''
      const date = new Date(dateTimeStr)
      return date.toLocaleString()
    }

    // Get role tag type
    const getRoleTagType = (roleName) => {
      const roleTypes = {
        'Admin': 'danger',
        'Editor': 'warning',
        'User': 'success',
        'Guest': 'info'
      }
      return roleTypes[roleName] || 'primary'
    }

    // Fetch user list
    const fetchUserList = async () => {
      loading.value = true
      try {
        const response = await axios.get('/api/users', { params: queryParams })
        const data = response.data.data
        userList.value = data.content || []
        total.value = data.totalElements || 0
      } catch (error) {
        console.error('Failed to fetch users:', error)
        ElMessage.error('Failed to load user list')
      } finally {
        loading.value = false
      }
    }

    // Fetch all roles
    const fetchRoles = async () => {
      try {
        const response = await axios.get('/api/roles', { params: { size: 100 } })
        roles.value = response.data.data.content || []
      } catch (error) {
        console.error('Failed to fetch roles:', error)
        ElMessage.error('Failed to load roles')
      }
    }

    // Handle search
    const handleSearch = () => {
      queryParams.page = 1
      fetchUserList()
    }

    // Reset query params
    const resetQuery = () => {
      queryParams.keyword = ''
      queryParams.roleId = ''
      queryParams.enabled = null
      queryParams.page = 1
      fetchUserList()
    }

    // Avatar upload handlers
    const handleAvatarSuccess = (response, uploadFile) => {
      if (response.code === 200) {
        userForm.avatar = response.data.url
        ElMessage.success('Avatar uploaded successfully')
      } else {
        ElMessage.error('Failed to upload avatar')
      }
    }

    const beforeAvatarUpload = (file) => {
      const isImage = file.type.startsWith('image/')
      const isLt2M = file.size / 1024 / 1024 < 2

      if (!isImage) {
        ElMessage.error('You can only upload image files!')
        return false
      }
      if (!isLt2M) {
        ElMessage.error('Image size cannot exceed 2MB!')
        return false
      }
      return true
    }

    // Show add user dialog
    const showAddUserDialog = () => {
      userDialog.type = 'create'
      userDialog.visible = true
      resetUserForm()
    }

    // Handle edit user
    const handleEditUser = (row) => {
      userDialog.type = 'edit'
      userDialog.visible = true
      userDialog.loading = true
      
      // Fetch full user details
      axios.get(`/api/users/${row.id}`).then(response => {
        const userData = response.data.data
        userForm.id = userData.id
        userForm.username = userData.username
        userForm.fullName = userData.fullName
        userForm.email = userData.email
        userForm.avatar = userData.avatar
        userForm.enabled = userData.enabled
        userForm.changePassword = false
        userForm.password = ''
        userForm.confirmPassword = ''
        
        // Map roles to role IDs
        userForm.roleIds = userData.roles?.map(role => role.id) || []
        
        userDialog.loading = false
      }).catch(error => {
        console.error('Failed to fetch user details:', error)
        ElMessage.error('Failed to load user details')
        userDialog.visible = false
        userDialog.loading = false
      })
    }

    // Reset user form
    const resetUserForm = () => {
      if (userFormRef.value) {
        userFormRef.value.resetFields()
      }
      
      Object.assign(userForm, {
        id: undefined,
        username: '',
        fullName: '',
        email: '',
        password: '',
        confirmPassword: '',
        changePassword: false,
        avatar: '',
        roleIds: [],
        enabled: true
      })
    }

    // Submit user form
    const submitUserForm = async () => {
      if (!userFormRef.value) return
      
      await userFormRef.value.validate(async (valid) => {
        if (!valid) return
        
        userDialog.submitting = true
        try {
          const formData = { ...userForm }
          
          // Remove unnecessary fields
          if (userDialog.type === 'edit' && !formData.changePassword) {
            delete formData.password
            delete formData.confirmPassword
          }
          delete formData.changePassword
          delete formData.confirmPassword
          
          let response
          if (userDialog.type === 'create') {
            response = await axios.post('/api/users', formData)
          } else {
            response = await axios.put(`/api/users/${formData.id}`, formData)
          }
          
          ElMessage.success(`User ${userDialog.type === 'create' ? 'created' : 'updated'} successfully`)
          userDialog.visible = false
          fetchUserList()
        } catch (error) {
          console.error('Failed to save user:', error)
          if (error.response && error.response.data && error.response.data.message) {
            ElMessage.error(error.response.data.message)
          } else {
            ElMessage.error(`Failed to ${userDialog.type === 'create' ? 'create' : 'update'} user`)
          }
        } finally {
          userDialog.submitting = false
        }
      })
    }

    // Handle toggle user status
    const handleToggleStatus = async (row) => {
      try {
        await axios.patch(`/api/users/${row.id}/status`, { enabled: !row.enabled })
        ElMessage.success(`User ${row.enabled ? 'disabled' : 'enabled'} successfully`)
        fetchUserList()
      } catch (error) {
        console.error('Failed to update user status:', error)
        ElMessage.error('Failed to update user status')
      }
    }

    // Handle delete user
    const handleDeleteUser = async (row) => {
      // Prevent deleting current logged-in user
      if (row.id === currentUser.value.id) {
        ElMessage.warning('You cannot delete your own account')
        return
      }
      
      try {
        await axios.delete(`/api/users/${row.id}`)
        ElMessage.success('User deleted successfully')
        fetchUserList()
      } catch (error) {
        console.error('Failed to delete user:', error)
        ElMessage.error('Failed to delete user')
      }
    }

    // Pagination handlers
    const handleSizeChange = (size) => {
      queryParams.size = size
      fetchUserList()
    }

    const handleCurrentChange = (page) => {
      queryParams.page = page
      fetchUserList()
    }

    onMounted(() => {
      fetchRoles()
      fetchUserList()
    })

    return {
      loading,
      userList,
      total,
      roles,
      queryParams,
      userForm,
      userFormRef,
      userDialog,
      userRules,
      currentUser,
      defaultAvatar,
      uploadUrl,
      headers,
      formatDateTime,
      getRoleTagType,
      handleSearch,
      resetQuery,
      showAddUserDialog,
      handleEditUser,
      handleToggleStatus,
      handleDeleteUser,
      resetUserForm,
      submitUserForm,
      handleAvatarSuccess,
      beforeAvatarUpload,
      handleSizeChange,
      handleCurrentChange,
      Plus,
      Search,
      Refresh,
      UserFilled
    }
  }
}
</script>

<style scoped>
.user-list {
  padding: 20px;
}

.action-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 20px;
}

.filter-container {
  margin-bottom: 20px;
}

.table-container {
  margin-bottom: 20px;
}

.pagination-container {
  margin-top: 20px;
  display: flex;
  justify-content: flex-end;
}

.avatar-uploader {
  width: 100px;
  height: 100px;
  border: 1px dashed #d9d9d9;
  border-radius: 50%;
  cursor: pointer;
  position: relative;
  overflow: hidden;
  display: flex;
  justify-content: center;
  align-items: center;
}

.avatar-uploader-icon {
  font-size: 28px;
  color: #8c939d;
  width: 100px;
  height: 100px;
  line-height: 100px;
  text-align: center;
}

.avatar {
  width: 100px;
  height: 100px;
  display: block;
  object-fit: cover;
  border-radius: 50%;
}

.dialog-footer {
  display: flex;
  justify-content: flex-end;
}

.role-tag {
  margin-right: 5px;
  margin-bottom: 5px;
}
</style>