<!-- src/views/system/RoleManagement.vue -->
<template>
  <div class="role-management">
    <div class="page-header flex-between">
      <h2>Role Management</h2>
      <el-button type="primary" @click="handleAdd">
        <el-icon><Plus /></el-icon>
        New Role
      </el-button>
    </div>

    <el-card>
      <el-table :data="roles" v-loading="loading" row-key="id">
        <el-table-column prop="id" label="ID" width="80" />
        <el-table-column prop="name" label="Name" min-width="150" />
        <el-table-column prop="description" label="Description" min-width="200" />
        <el-table-column prop="userCount" label="Users" width="100" sortable />
        <el-table-column label="Status" width="100">
          <template #default="scope">
            <el-tag :type="scope.row.status === 'active' ? 'success' : 'danger'">
              {{ scope.row.status }}
            </el-tag>
          </template>
        </el-table-column>
        <el-table-column fixed="right" label="Operations" width="320">
          <template #default="scope">
            <el-button type="primary" size="small" link @click="handleEdit(scope.row)">Edit</el-button>
            <el-button type="success" size="small" link @click="handleManagePermissions(scope.row)">
              Permissions
            </el-button>
            <el-button 
              type="warning" 
              size="small" 
              link 
              @click="handleToggleStatus(scope.row)"
            >
              {{ scope.row.status === 'active' ? 'Disable' : 'Enable' }}
            </el-button>
            <el-button 
              type="danger" 
              size="small" 
              link 
              @click="handleDelete(scope.row)"
              :disabled="scope.row.isSystem || scope.row.userCount > 0"
            >
              Delete
            </el-button>
          </template>
        </el-table-column>
      </el-table>
    </el-card>

    <!-- Role Form Dialog -->
    <el-dialog
      :title="dialogTitle"
      v-model="dialogVisible"
      width="500px"
    >
      <el-form
        ref="formRef"
        :model="form"
        :rules="rules"
        label-width="100px"
      >
        <el-form-item label="Name" prop="name">
          <el-input v-model="form.name" placeholder="Enter role name" />
        </el-form-item>
        <el-form-item label="Code" prop="code" :disabled="isEdit">
          <el-input v-model="form.code" placeholder="Enter role code" :disabled="isEdit" />
        </el-form-item>
        <el-form-item label="Description" prop="description">
          <el-input 
            v-model="form.description" 
            type="textarea" 
            :rows="3" 
            placeholder="Enter role description"
          />
        </el-form-item>
        <el-form-item label="Status">
          <el-switch
            v-model="form.status"
            :active-value="'active'"
            :inactive-value="'inactive'"
          />
        </el-form-item>
      </el-form>
      <template #footer>
        <div class="dialog-footer">
          <el-button @click="dialogVisible = false">Cancel</el-button>
          <el-button type="primary" @click="submitForm">Confirm</el-button>
        </div>
      </template>
    </el-dialog>

    <!-- Permission Dialog -->
    <el-dialog
      title="Role Permissions"
      v-model="permissionDialogVisible"
      width="600px"
    >
      <div v-if="currentRole">
        <p class="mb-20">Manage permissions for role: <strong>{{ currentRole.name }}</strong></p>
        
        <el-tree
          ref="permissionTree"
          :data="permissionTree"
          show-checkbox
          node-key="id"
          :default-checked-keys="selectedPermissions"
          :props="{ label: 'name', children: 'children' }"
        />
      </div>
      <template #footer>
        <div class="dialog-footer">
          <el-button @click="permissionDialogVisible = false">Cancel</el-button>
          <el-button type="primary" @click="updateRolePermissions">Save Permissions</el-button>
        </div>
      </template>
    </el-dialog>
  </div>
</template>

<script>
import { ref, reactive, computed, onMounted } from 'vue'
import { Plus } from '@element-plus/icons-vue'
import { ElMessage, ElMessageBox } from 'element-plus'
import { getRoles, getPermissions, createRole, updateRole, deleteRole, 
         updateRoleStatus, getRolePermissions, updateRolePermissions } from '@/api/system'

export default {
  name: 'RoleManagement',
  components: {
    Plus
  },
  setup() {
    const loading = ref(false)
    const roles = ref([])
    const dialogVisible = ref(false)
    const permissionDialogVisible = ref(false)
    const formRef = ref(null)
    const permissionTree = ref([])
    const permissionTreeRef = ref(null)
    const isEdit = ref(false)
    const currentRole = ref(null)
    const selectedPermissions = ref([])
    
    // Form data
    const form = reactive({
      id: null,
      name: '',
      code: '',
      description: '',
      status: 'active'
    })
    
    // Form validation rules
    const rules = {
      name: [{ required: true, message: 'Please enter role name', trigger: 'blur' }],
      code: [{ required: true, message: 'Please enter role code', trigger: 'blur' }]
    }
    
    const dialogTitle = computed(() => isEdit.value ? 'Edit Role' : 'Add Role')

    // Fetch roles
    const fetchRoles = async () => {
      loading.value = true
      try {
        // In a real app, we would fetch from API
        // const response = await getRoles()
        
        // For now, use mock data
        setTimeout(() => {
          roles.value = [
            { id: 1, name: 'Administrator', code: 'admin', description: 'Full access to all features', userCount: 1, status: 'active', isSystem: true },
            { id: 2, name: 'Editor', code: 'editor', description: 'Can edit and publish content', userCount: 2, status: 'active', isSystem: false },
            { id: 3, name: 'Author', code: 'author', description: 'Can create and edit own content', userCount: 5, status: 'active', isSystem: false },
            { id: 4, name: 'Viewer', code: 'viewer', description: 'Read-only access to content', userCount: 10, status: 'active', isSystem: false }
          ]
          
          loading.value = false
        }, 800)
      } catch (error) {
        console.error('Error loading roles:', error)
        ElMessage({ message: 'Failed to load roles', type: 'error' })
        loading.value = false
      }
    }
    
    // Reset form fields
    const resetForm = () => {
      form.id = null
      form.name = ''
      form.code = ''
      form.description = ''
      form.status = 'active'
      
      if (formRef.value) {
        formRef.value.resetFields()
      }
    }
    
    // Open add role dialog
    const handleAdd = () => {
      resetForm()
      isEdit.value = false
      dialogVisible.value = true
    }
    
    // Open edit role dialog
    const handleEdit = (row) => {
      resetForm()
      isEdit.value = true
      
      // Populate form with role data
      form.id = row.id
      form.name = row.name
      form.code = row.code
      form.description = row.description
      form.status = row.status
      
      dialogVisible.value = true
    }
    
    // Toggle role status
    const handleToggleStatus = (row) => {
      if (row.isSystem && row.status === 'active') {
        ElMessage({
          message: 'Cannot disable system role',
          type: 'warning'
        })
        return
      }
      
      const newStatus = row.status === 'active' ? 'inactive' : 'active'
      const action = newStatus === 'active' ? 'enable' : 'disable'
      
      ElMessageBox.confirm(
        `Are you sure you want to ${action} the role "${row.name}"?`,
        `${action.charAt(0).toUpperCase() + action.slice(1)} Role`,
        {
          confirmButtonText: 'Confirm',
          cancelButtonText: 'Cancel',
          type: 'warning'
        }
      ).then(async () => {
        try {
          // In a real app, we would call API
          // await updateRoleStatus(row.id, newStatus)
          
          // For now, update locally
          const index = roles.value.findIndex(r => r.id === row.id)
          roles.value[index].status = newStatus
          
          ElMessage({ message: `Role ${action}d successfully`, type: 'success' })
        } catch (error) {
          console.error(`Error ${action}ing role:`, error)
          ElMessage({ message: `Failed to ${action} role`, type: 'error' })
        }
      }).catch(() => {
        // User cancelled
      })
    }
    
    // Delete role
    const handleDelete = (row) => {
      if (row.isSystem) {
        ElMessage({
          message: 'Cannot delete system role',
          type: 'warning'
        })
        return
      }
      
      if (row.userCount > 0) {
        ElMessage({
          message: 'Cannot delete role with users. Remove users from this role first.',
          type: 'warning'
        })
        return
      }
      
      ElMessageBox.confirm(
        `Are you sure you want to delete the role "${row.name}"?`,
        'Delete Role',
        {
          confirmButtonText: 'Delete',
          cancelButtonText: 'Cancel',
          type: 'warning'
        }
      ).then(async () => {
        try {
          // In a real app, we would call API
          // await deleteRole(row.id)
          
          // For now, update locally
          roles.value = roles.value.filter(r => r.id !== row.id)
          
          ElMessage({ message: 'Role deleted successfully', type: 'success' })
        } catch (error) {
          console.error('Error deleting role:', error)
          ElMessage({ message: 'Failed to delete role', type: 'error' })
        }
      }).catch(() => {
        // User cancelled
      })
    }
    
    // Submit form
    const submitForm = () => {
      formRef.value.validate(async (valid) => {
        if (valid) {
          try {
            // In a real app, we would call API
            // if (isEdit.value) {
            //   await updateRole(form.id, form)
            // } else {
            //   await createRole(form)
            // }
            
            // For now, update locally
            if (isEdit.value) {
              const index = roles.value.findIndex(r => r.id === form.id)
              roles.value[index] = { ...roles.value[index], ...form }
            } else {
              // Generate new ID
              const newId = Math.max(...roles.value.map(r => r.id)) + 1
              roles.value.push({
                id: newId,
                userCount: 0,
                isSystem: false,
                ...form
              })
            }
            
            ElMessage({
              message: isEdit.value ? 'Role updated successfully' : 'Role created successfully',
              type: 'success'
            })
            
            dialogVisible.value = false
          } catch (error) {
            console.error('Error saving role:', error)
            ElMessage({ message: 'Failed to save role', type: 'error' })
          }
        }
      })
    }

    // Manage permissions dialog
    const handleManagePermissions = async (row) => {
      currentRole.value = row
      permissionDialogVisible.value = true
      
      try {
        // In a real app, we would fetch from API
        // const [permissionsResponse, rolePermissionsResponse] = await Promise.all([
        //   getPermissions(),
        //   getRolePermissions(row.id)
        // ])
        
        // Generate mock permission tree
        permissionTree.value = [
          {
            id: 'content',
            name: 'Content Management',
            children: [
              { id: 'content:view', name: 'View Content' },
              { id: 'content:create', name: 'Create Content' },
              { id: 'content:edit', name: 'Edit Content' },
              { id: 'content:delete', name: 'Delete Content' },
              { id: 'content:publish', name: 'Publish Content' }
            ]
          },
          {
            id: 'category',
            name: 'Category Management',
            children: [
              { id: 'category:view', name: 'View Categories' },
              { id: 'category:create', name: 'Create Categories' },
              { id: 'category:edit', name: 'Edit Categories' },
              { id: 'category:delete', name: 'Delete Categories' }
            ]
          },
          {
            id: 'user',
            name: 'User Management',
            children: [
              { id: 'user:view', name: 'View Users' },
              { id: 'user:create', name: 'Create Users' },
              { id: 'user:edit', name: 'Edit Users' },
              { id: 'user:delete', name: 'Delete Users' }
            ]
          },
          {
            id: 'role',
            name: 'Role Management',
            children: [
              { id: 'role:view', name: 'View Roles' },
              { id: 'role:create', name: 'Create Roles' },
              { id: 'role:edit', name: 'Edit Roles' },
              { id: 'role:delete', name: 'Delete Roles' }
            ]
          },
          {
            id: 'system',
            name: 'System Settings',
            children: [
              { id: 'system:view', name: 'View Settings' },
              { id: 'system:edit', name: 'Edit Settings' }
            ]
          }
        ]
        
        // Set selected permissions based on role
        if (row.code === 'admin') {
          // Admin has all permissions
          selectedPermissions.value = [
            'content:view', 'content:create', 'content:edit', 'content:delete', 'content:publish',
            'category:view', 'category:create', 'category:edit', 'category:delete',
            'user:view', 'user:create', 'user:edit', 'user:delete',
            'role:view', 'role:create', 'role:edit', 'role:delete',
            'system:view', 'system:edit'
          ]
        } else if (row.code === 'editor') {
          selectedPermissions.value = [
            'content:view', 'content:create', 'content:edit', 'content:publish',
            'category:view',
            'user:view'
          ]
        } else if (row.code === 'author') {
          selectedPermissions.value = [
            'content:view', 'content:create', 'content:edit',
            'category:view'
          ]
        } else if (row.code === 'viewer') {
          selectedPermissions.value = [
            'content:view',
            'category:view'
          ]
        } else {
          selectedPermissions.value = []
        }
      } catch (error) {
        console.error('Error loading permissions:', error)
        ElMessage({ message: 'Failed to load permissions', type: 'error' })
      }
    }
    
    // Update role permissions
    const updateRolePermissions = async () => {
      if (!currentRole.value) return
      
      try {
        // Get checked nodes from tree
        const checkedKeys = permissionTreeRef.value?.getCheckedKeys() || []
        const halfCheckedKeys = permissionTreeRef.value?.getHalfCheckedKeys() || []
        const allCheckedKeys = [...checkedKeys, ...halfCheckedKeys]
        
        // In a real app, we would call API
        // await updateRolePermissions(currentRole.value.id, allCheckedKeys)
        
        ElMessage({ message: 'Role permissions updated successfully', type: 'success' })
        permissionDialogVisible.value = false
      } catch (error) {
        console.error('Error updating role permissions:', error)
        ElMessage({ message: 'Failed to update role permissions', type: 'error' })
      }
    }
    
    // Load roles on component mount
    onMounted(() => {
      fetchRoles()
    })
    
    return {
      loading,
      roles,
      dialogVisible,
      permissionDialogVisible,
      dialogTitle,
      isEdit,
      formRef,
      form,
      rules,
      currentRole,
      permissionTree,
      permissionTreeRef,
      selectedPermissions,
      handleAdd,
      handleEdit,
      handleToggleStatus,
      handleDelete,
      submitForm,
      handleManagePermissions,
      updateRolePermissions
    }
  }
}
</script>

<style scoped>
.role-management {
  padding: 20px;
}

.dialog-footer {
  text-align: right;
}

.mb-20 {
  margin-bottom: 20px;
}
</style>