<template>
  <div class="contact-info container">
    <div class="action-header">
      <div class="page-title">
        <h1>Contact Information</h1>
      </div>
      <div class="action-buttons">
        <el-button type="primary" @click="saveSettings" :loading="saving">
          <el-icon><Check /></el-icon> Save Settings
        </el-button>
      </div>
    </div>

    <el-tabs v-model="activeTab" tab-position="left" class="content-tabs">
      <el-tab-pane label="Company Contact Info" name="contact">
        <el-card class="tab-card">
          <template #header>
            <div class="card-header">
              <span>Primary Contact Information</span>
            </div>
          </template>

          <el-form label-width="180px" :model="contactData.primary">
            <el-form-item label="Email Address">
              <el-input v-model="contactData.primary.email" placeholder="Enter email address" />
            </el-form-item>
            
            <el-form-item label="Phone Number">
              <el-input v-model="contactData.primary.phone" placeholder="Enter phone number" />
            </el-form-item>
            
            <el-form-item label="Fax Number">
              <el-input v-model="contactData.primary.fax" placeholder="Enter fax number (optional)" />
            </el-form-item>
            
            <el-form-item label="Contact Hours">
              <el-input v-model="contactData.primary.hours" placeholder="e.g., Monday-Friday: 9am-5pm" />
            </el-form-item>
          </el-form>
        </el-card>
      </el-tab-pane>
      
      <el-tab-pane label="Office Locations" name="locations">
        <el-card class="tab-card">
          <template #header>
            <div class="card-header">
              <span>Office Locations</span>
              <el-button type="primary" size="small" @click="addOfficeLocation">
                <el-icon><Plus /></el-icon> Add Office
              </el-button>
            </div>
          </template>

          <div v-if="contactData.locations.length === 0" class="no-data-message">
            No office locations added. Click "Add Office" to create one.
          </div>

          <el-collapse v-else v-model="activeOfficePanel">
            <el-collapse-item 
              v-for="(office, index) in contactData.locations" 
              :key="index"
              :name="index.toString()"
            >
              <template #title>
                <div class="collapse-title">
                  <span>{{ office.name || 'Unnamed Office' }}</span>
                  <span class="office-type">{{ office.type }}</span>
                </div>
              </template>
              
              <el-form label-width="120px" :model="office">
                <el-form-item label="Office Name">
                  <el-input v-model="office.name" placeholder="e.g., Headquarters, Branch Office" />
                </el-form-item>
                
                <el-form-item label="Office Type">
                  <el-select v-model="office.type" placeholder="Select office type">
                    <el-option label="Headquarters" value="Headquarters" />
                    <el-option label="Branch Office" value="Branch Office" />
                    <el-option label="Regional Office" value="Regional Office" />
                    <el-option label="Sales Office" value="Sales Office" />
                    <el-option label="Customer Support" value="Customer Support" />
                  </el-select>
                </el-form-item>
                
                <el-form-item label="Address">
                  <el-input 
                    v-model="office.address" 
                    type="textarea" 
                    :rows="2" 
                    placeholder="Enter complete address"
                  />
                </el-form-item>
                
                <el-form-item label="City">
                  <el-input v-model="office.city" placeholder="Enter city" />
                </el-form-item>
                
                <el-form-item label="State/Province">
                  <el-input v-model="office.state" placeholder="Enter state or province" />
                </el-form-item>
                
                <el-form-item label="Postal Code">
                  <el-input v-model="office.postalCode" placeholder="Enter postal code" />
                </el-form-item>
                
                <el-form-item label="Country">
                  <el-input v-model="office.country" placeholder="Enter country" />
                </el-form-item>
                
                <el-form-item label="Phone">
                  <el-input v-model="office.phone" placeholder="Enter phone number" />
                </el-form-item>
                
                <el-form-item label="Email">
                  <el-input v-model="office.email" placeholder="Enter email address" />
                </el-form-item>
                
                <el-form-item label="Is Main Office">
                  <el-switch v-model="office.isMainOffice" />
                </el-form-item>
                
                <el-form-item label="Show on Map">
                  <el-switch v-model="office.showOnMap" />
                </el-form-item>
                
                <el-form-item v-if="office.showOnMap" label="Map Coordinates">
                  <el-row :gutter="10">
                    <el-col :span="12">
                      <el-input v-model="office.latitude" placeholder="Latitude" />
                    </el-col>
                    <el-col :span="12">
                      <el-input v-model="office.longitude" placeholder="Longitude" />
                    </el-col>
                  </el-row>
                </el-form-item>
                
                <el-form-item>
                  <el-button type="danger" @click="removeOfficeLocation(index)">
                    <el-icon><Delete /></el-icon> Remove Office
                  </el-button>
                </el-form-item>
              </el-form>
            </el-collapse-item>
          </el-collapse>
        </el-card>
      </el-tab-pane>
      
      <el-tab-pane label="Social Media" name="social">
        <el-card class="tab-card">
          <template #header>
            <div class="card-header">
              <span>Social Media Links</span>
            </div>
          </template>

          <el-form label-width="120px" :model="contactData.social">
            <el-form-item label="LinkedIn">
              <el-input v-model="contactData.social.linkedin" placeholder="Enter LinkedIn URL" prefix="https://" />
            </el-form-item>
            
            <el-form-item label="Facebook">
              <el-input v-model="contactData.social.facebook" placeholder="Enter Facebook URL" prefix="https://" />
            </el-form-item>
            
            <el-form-item label="Twitter/X">
              <el-input v-model="contactData.social.twitter" placeholder="Enter Twitter/X URL" prefix="https://" />
            </el-form-item>
            
            <el-form-item label="Instagram">
              <el-input v-model="contactData.social.instagram" placeholder="Enter Instagram URL" prefix="https://" />
            </el-form-item>
            
            <el-form-item label="YouTube">
              <el-input v-model="contactData.social.youtube" placeholder="Enter YouTube URL" prefix="https://" />
            </el-form-item>
          </el-form>
        </el-card>
      </el-tab-pane>
      
      <el-tab-pane label="Map Settings" name="map">
        <el-card class="tab-card">
          <template #header>
            <div class="card-header">
              <span>Map Settings</span>
            </div>
          </template>

          <el-form label-width="180px" :model="contactData.map">
            <el-form-item label="Show Map on Contact Page">
              <el-switch v-model="contactData.map.show" />
            </el-form-item>
            
            <template v-if="contactData.map.show">
              <el-form-item label="Map Provider">
                <el-radio-group v-model="contactData.map.provider">
                  <el-radio label="google">Google Maps</el-radio>
                  <el-radio label="openstreet">OpenStreetMap</el-radio>
                </el-radio-group>
              </el-form-item>
              
              <el-form-item label="API Key" v-if="contactData.map.provider === 'google'">
                <el-input v-model="contactData.map.apiKey" placeholder="Enter Google Maps API key" show-password />
              </el-form-item>
              
              <el-form-item label="Default Zoom Level">
                <el-slider v-model="contactData.map.zoom" :min="1" :max="20" />
              </el-form-item>
              
              <el-form-item label="Map Height (px)">
                <el-input-number v-model="contactData.map.height" :min="200" :max="800" />
              </el-form-item>
            </template>
          </el-form>
        </el-card>
      </el-tab-pane>
    </el-tabs>
  </div>
</template>

<script>
import { ref, reactive, onMounted, nextTick } from 'vue'
import { ElMessage } from 'element-plus'
import { Check, Plus, Delete } from '@element-plus/icons-vue'
import axios from 'axios'

export default {
  name: 'ContactInfo',
  setup() {
    const activeTab = ref('contact')
    const activeOfficePanel = ref(['0'])
    const saving = ref(false)
    
    // Available email options for recipients dropdown
    const emailOptions = ref([])
    
    // Contact settings data structure
    const contactData = reactive({
      id: null,
      primary: {
        email: '',
        phone: '',
        fax: '',
        hours: ''
      },
      locations: [],
      form: {
        title: 'Contact Us',
        description: 'Fill out the form below to get in touch with us.',
        recipients: [],
        successMessage: 'Thank you for your message. We will get back to you shortly.',
        requiredFields: ['name', 'email', 'message'],
        enableCaptcha: true,
        enableAutoReply: false,
        autoReplySubject: 'Thank you for contacting us',
        autoReplyMessage: ''
      },
      social: {
        linkedin: '',
        facebook: '',
        twitter: '',
        instagram: '',
        youtube: ''
      },
      map: {
        show: true,
        provider: 'google',
        apiKey: '',
        zoom: 15,
        height: 400
      }
    })

    // Fetch contact settings
    const fetchContactSettings = async () => {
      try {
        const response = await axios.get('/api/contact-settings')
        const data = response.data.data
        
        if (data) {
          contactData.id = data.id
          
          // Populate primary contact data if available
          if (data.primary) {
            Object.assign(contactData.primary, data.primary)
          }
          
          // Populate office locations if available
          if (Array.isArray(data.locations) && data.locations.length > 0) {
            contactData.locations = data.locations
          }
          
          // Populate form settings if available
          if (data.form) {
            Object.assign(contactData.form, data.form)
          }
          
          // Populate social media links if available
          if (data.social) {
            Object.assign(contactData.social, data.social)
          }
          
          // Populate map settings if available
          if (data.map) {
            Object.assign(contactData.map, data.map)
          }
        } else {
          // If no data exists, add a default office location
          addOfficeLocation()
        }
      } catch (error) {
        console.error('Failed to fetch contact settings:', error)
        ElMessage.error('Failed to load contact settings')
        // Add a default office location if there's an error
        if (contactData.locations.length === 0) {
          addOfficeLocation()
        }
      }
    }
    
    // Fetch company email addresses for recipients dropdown
    const fetchCompanyEmails = async () => {
      try {
        const response = await axios.get('/api/users/emails')
        emailOptions.value = response.data.data || []
        
        // Add the primary email to options if it exists and isn't already included
        if (contactData.primary.email && !emailOptions.value.includes(contactData.primary.email)) {
          emailOptions.value.push(contactData.primary.email)
        }
      } catch (error) {
        console.error('Failed to fetch email options:', error)
      }
    }

    // Save contact settings
    const saveSettings = async () => {
      saving.value = true
      try {
        const payload = {
          primary: contactData.primary,
          locations: contactData.locations,
          form: contactData.form,
          social: contactData.social,
          map: contactData.map
        }
        
        let response
        if (contactData.id) {
          response = await axios.put(`/api/contact-settings/${contactData.id}`, payload)
        } else {
          response = await axios.post('/api/contact-settings', payload)
          contactData.id = response.data.data.id
        }
        
        ElMessage.success('Contact settings saved successfully')
      } catch (error) {
        console.error('Failed to save contact settings:', error)
        ElMessage.error('Failed to save contact settings')
      } finally {
        saving.value = false
      }
    }

    // Add office location
    const addOfficeLocation = () => {
      contactData.locations.push({
        name: '',
        type: 'Branch Office',
        address: '',
        city: '',
        state: '',
        postalCode: '',
        country: '',
        phone: '',
        email: '',
        isMainOffice: contactData.locations.length === 0,
        showOnMap: true,
        latitude: '',
        longitude: ''
      })
      
      // Open the newly added office panel
      nextTick(() => {
        activeOfficePanel.value = [(contactData.locations.length - 1).toString()]
      })
    }

    // Remove office location
    const removeOfficeLocation = (index) => {
      contactData.locations.splice(index, 1)
      
      // If we removed the main office, set the first location as main (if any exist)
      if (contactData.locations.length > 0) {
        const hasMainOffice = contactData.locations.some(office => office.isMainOffice)
        if (!hasMainOffice) {
          contactData.locations[0].isMainOffice = true
        }
      }
    }

    onMounted(() => {
      fetchContactSettings()
      fetchCompanyEmails()
    })

    return {
      activeTab,
      activeOfficePanel,
      contactData,
      emailOptions,
      saving,
      saveSettings,
      addOfficeLocation,
      removeOfficeLocation,
      Check,
      Plus,
      Delete
    }
  }
}
</script>

<style scoped>
.contact-info {
  padding: 20px;
}

.action-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 20px;
}

.content-tabs {
  min-height: 500px;
}

.tab-card {
  margin-bottom: 20px;
}

.card-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
}

.collapse-title {
  display: flex;
  align-items: center;
  gap: 10px;
}

.office-type {
  font-size: 12px;
  color: #909399;
}

.no-data-message {
  color: #909399;
  font-style: italic;
  text-align: center;
  padding: 20px;
}

.input-help {
  font-size: 12px;
  color: #909399;
  margin-top: 5px;
}
</style>