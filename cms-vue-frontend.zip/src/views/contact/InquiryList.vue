<template>
  <div class="inquiry-list container">
    <div class="action-header">
      <div class="page-title">
        <h1>Contact Form Submissions</h1>
      </div>
      <div class="action-buttons">
        <el-button-group>
          <el-button type="primary" :disabled="!selectedInquiries.length" @click="markAsRead(true)" plain>
            <el-icon><View /></el-icon> Mark as Read
          </el-button>
          <el-button type="warning" :disabled="!selectedInquiries.length" @click="markAsRead(false)" plain>
            <el-icon><Bell /></el-icon> Mark as Unread
          </el-button>
        </el-button-group>
        <el-popconfirm
          title="Are you sure to delete all selected inquiries?"
          @confirm="deleteSelected"
          :disabled="!selectedInquiries.length"
        >
          <template #reference>
            <el-button type="danger" :disabled="!selectedInquiries.length" plain>
              <el-icon><Delete /></el-icon> Delete Selected
            </el-button>
          </template>
        </el-popconfirm>
      </div>
    </div>

    <el-card class="filter-container">
      <div class="filter-items">
        <el-form :inline="true" :model="queryParams" class="search-form">
          <el-form-item label="Search">
            <el-input
              v-model="queryParams.keyword"
              placeholder="Search name, email, subject"
              clearable
              @keyup.enter="handleSearch"
            />
          </el-form-item>
          <el-form-item label="Status">
            <el-select v-model="queryParams.read" placeholder="All Status" clearable>
              <el-option label="Read" :value="true" />
              <el-option label="Unread" :value="false" />
            </el-select>
          </el-form-item>
          <el-form-item label="Date Range">
            <el-date-picker
              v-model="dateRange"
              type="daterange"
              range-separator="To"
              start-placeholder="Start date"
              end-placeholder="End date"
              :shortcuts="dateRangeShortcuts"
              value-format="YYYY-MM-DD"
              @change="handleDateRangeChange"
            />
          </el-form-item>
          <el-form-item>
            <el-button type="primary" @click="handleSearch">
              <el-icon><Search /></el-icon> Search
            </el-button>
            <el-button @click="resetQuery">
              <el-icon><Refresh /></el-icon> Reset
            </el-button>
          </el-form-item>
        </el-form>
      </div>
    </el-card>

    <el-card class="table-container" v-loading="loading">
      <el-table
        :data="inquiryList"
        border
        style="width: 100%"
        row-key="id"
        @selection-change="handleSelectionChange"
        :row-class-name="rowClassName"
      >
        <el-table-column type="selection" width="55" />
        <el-table-column label="Status" width="80">
          <template #default="{ row }">
            <el-tag v-if="row.read" type="info">Read</el-tag>
            <el-tag v-else type="warning">Unread</el-tag>
          </template>
        </el-table-column>
        <el-table-column label="Name" prop="name" min-width="130" show-overflow-tooltip />
        <el-table-column label="Email" prop="email" min-width="180" show-overflow-tooltip />
        <el-table-column label="Subject" prop="subject" min-width="180" show-overflow-tooltip />
        <el-table-column label="Date" width="180">
          <template #default="{ row }">
            {{ formatDateTime(row.createdAt) }}
          </template>
        </el-table-column>
        <el-table-column label="Operations" width="150" fixed="right">
          <template #default="{ row }">
            <el-button type="primary" size="small" @click="handleViewInquiry(row)">
              View
            </el-button>
            <el-popconfirm
              title="Are you sure to delete this inquiry?"
              @confirm="handleDeleteInquiry(row)"
            >
              <template #reference>
                <el-button size="small" type="danger">Delete</el-button>
              </template>
            </el-popconfirm>
          </template>
        </el-table-column>
      </el-table>

      <div class="pagination-container">
        <el-pagination
          v-model:current-page="queryParams.page"
          v-model:page-size="queryParams.size"
          :page-sizes="[10, 20, 50, 100]"
          :total="total"
          layout="total, sizes, prev, pager, next, jumper"
          @size-change="handleSizeChange"
          @current-change="handleCurrentChange"
        />
      </div>
    </el-card>

    <!-- Inquiry Detail Dialog -->
    <el-dialog
      v-model="inquiryDialog.visible"
      title="Inquiry Details"
      width="600px"
      destroy-on-close
    >
      <div class="inquiry-detail" v-loading="inquiryDialog.loading">
        <div class="inquiry-header">
          <div class="inquiry-subject">{{ inquiryDialog.data.subject || 'No Subject' }}</div>
          <div class="inquiry-meta">
            <el-tag v-if="inquiryDialog.data.read" type="info">Read</el-tag>
            <el-tag v-else type="warning">Unread</el-tag>
            <span class="inquiry-date">{{ formatDateTime(inquiryDialog.data.createdAt) }}</span>
          </div>
        </div>
        
        <div class="inquiry-sender">
          <div class="info-group">
            <div class="info-label">From:</div>
            <div class="info-value">{{ inquiryDialog.data.name }}</div>
          </div>
          <div class="info-group">
            <div class="info-label">Email:</div>
            <div class="info-value">
              <a :href="`mailto:${inquiryDialog.data.email}`">{{ inquiryDialog.data.email }}</a>
            </div>
          </div>
          <div class="info-group" v-if="inquiryDialog.data.phone">
            <div class="info-label">Phone:</div>
            <div class="info-value">{{ inquiryDialog.data.phone }}</div>
          </div>
          <div class="info-group" v-if="inquiryDialog.data.company">
            <div class="info-label">Company:</div>
            <div class="info-value">{{ inquiryDialog.data.company }}</div>
          </div>
        </div>
        
        <div class="inquiry-message">
          <div class="message-label">Message:</div>
          <div class="message-content">{{ inquiryDialog.data.message }}</div>
        </div>
        
        <div class="inquiry-footer">
          <el-button type="primary" @click="handleReplyEmail">
            <el-icon><Message /></el-icon> Reply by Email
          </el-button>
        </div>
      </div>
    </el-dialog>
  </div>
</template>

<script>
import { ref, reactive, onMounted } from 'vue'
import { Search, Refresh, Delete, View, Bell, Message } from '@element-plus/icons-vue'
import { ElMessage } from 'element-plus'
import axios from 'axios'

export default {
  name: 'InquiryList',
  setup() {
    const loading = ref(false)
    const inquiryList = ref([])
    const total = ref(0)
    const selectedInquiries = ref([])
    const dateRange = ref(null)

    const queryParams = reactive({
      page: 1,
      size: 10,
      keyword: '',
      read: null,
      startDate: null,
      endDate: null,
      sortBy: 'createdAt',
      sortDir: 'desc'
    })

    const inquiryDialog = reactive({
      visible: false,
      loading: false,
      data: {}
    })

    const dateRangeShortcuts = [
      {
        text: 'Last week',
        value: () => {
          const end = new Date()
          const start = new Date()
          start.setTime(start.getTime() - 3600 * 1000 * 24 * 7)
          return [start, end]
        }
      },
      {
        text: 'Last month',
        value: () => {
          const end = new Date()
          const start = new Date()
          start.setMonth(start.getMonth() - 1)
          return [start, end]
        }
      },
      {
        text: 'Last 3 months',
        value: () => {
          const end = new Date()
          const start = new Date()
          start.setMonth(start.getMonth() - 3)
          return [start, end]
        }
      }
    ]

    // Format date time
    const formatDateTime = (dateTimeStr) => {
      if (!dateTimeStr) return ''
      const date = new Date(dateTimeStr)
      return date.toLocaleString()
    }

    // Handle date range change
    const handleDateRangeChange = (value) => {
      if (value && value.length === 2) {
        queryParams.startDate = value[0]
        queryParams.endDate = value[1]
      } else {
        queryParams.startDate = null
        queryParams.endDate = null
      }
    }

    // Handle table row selection change
    const handleSelectionChange = (selection) => {
      selectedInquiries.value = selection
    }

    // Apply row class based on read status
    const rowClassName = ({ row }) => {
      return row.read ? '' : 'unread-row'
    }

    // Fetch inquiries list
    const fetchInquiries = async () => {
      loading.value = true
      try {
        const response = await axios.get('/api/inquiries', { params: queryParams })
        const data = response.data.data
        inquiryList.value = data.content || []
        total.value = data.totalElements || 0
      } catch (error) {
        console.error('Failed to fetch inquiries:', error)
        ElMessage.error('Failed to load inquiries')
      } finally {
        loading.value = false
      }
    }

    // Handle search
    const handleSearch = () => {
      queryParams.page = 1
      fetchInquiries()
    }

    // Reset query params
    const resetQuery = () => {
      queryParams.keyword = ''
      queryParams.read = null
      queryParams.startDate = null
      queryParams.endDate = null
      queryParams.page = 1
      dateRange.value = null
      fetchInquiries()
    }

    // View inquiry details
    const handleViewInquiry = async (row) => {
      inquiryDialog.visible = true
      inquiryDialog.loading = true
      inquiryDialog.data = { ...row }
      
      try {
        // If the inquiry was unread, mark it as read
        if (!row.read) {
          await axios.patch(`/api/inquiries/${row.id}/read`, { read: true })
          // Update the local data
          row.read = true
          // Find the item in the inquiry list and update it
          const index = inquiryList.value.findIndex(item => item.id === row.id)
          if (index !== -1) {
            inquiryList.value[index].read = true
          }
        }
      } catch (error) {
        console.error('Failed to mark inquiry as read:', error)
      } finally {
        inquiryDialog.loading = false
      }
    }

    // Handle reply by email
    const handleReplyEmail = () => {
      const email = inquiryDialog.data.email
      if (email) {
        const subject = `Re: ${inquiryDialog.data.subject || 'Your Inquiry'}`
        const mailtoLink = `mailto:${email}?subject=${encodeURIComponent(subject)}`
        window.open(mailtoLink, '_blank')
      }
    }

    // Handle delete inquiry
    const handleDeleteInquiry = async (row) => {
      try {
        await axios.delete(`/api/inquiries/${row.id}`)
        ElMessage.success('Inquiry deleted successfully')
        fetchInquiries()
      } catch (error) {
        console.error('Failed to delete inquiry:', error)
        ElMessage.error('Failed to delete inquiry')
      }
    }

    // Mark selected inquiries as read/unread
    const markAsRead = async (read) => {
      if (selectedInquiries.value.length === 0) return
      
      const ids = selectedInquiries.value.map(item => item.id)
      try {
        await axios.post('/api/inquiries/batch-update', {
          ids: ids,
          read: read
        })
        
        ElMessage.success(`${selectedInquiries.value.length} inquiries marked as ${read ? 'read' : 'unread'}`)
        fetchInquiries()
      } catch (error) {
        console.error(`Failed to mark inquiries as ${read ? 'read' : 'unread'}:`, error)
        ElMessage.error(`Failed to mark inquiries as ${read ? 'read' : 'unread'}`)
      }
    }

    // Delete selected inquiries
    const deleteSelected = async () => {
      if (selectedInquiries.value.length === 0) return
      
      const ids = selectedInquiries.value.map(item => item.id)
      try {
        await axios.post('/api/inquiries/batch-delete', { ids: ids })
        ElMessage.success(`${selectedInquiries.value.length} inquiries deleted successfully`)
        selectedInquiries.value = []
        fetchInquiries()
      } catch (error) {
        console.error('Failed to delete inquiries:', error)
        ElMessage.error('Failed to delete inquiries')
      }
    }

    // Pagination handlers
    const handleSizeChange = (size) => {
      queryParams.size = size
      fetchInquiries()
    }

    const handleCurrentChange = (page) => {
      queryParams.page = page
      fetchInquiries()
    }

    onMounted(() => {
      fetchInquiries()
    })

    return {
      loading,
      inquiryList,
      total,
      selectedInquiries,
      queryParams,
      dateRange,
      dateRangeShortcuts,
      inquiryDialog,
      formatDateTime,
      handleDateRangeChange,
      handleSelectionChange,
      rowClassName,
      handleSearch,
      resetQuery,
      handleViewInquiry,
      handleReplyEmail,
      handleDeleteInquiry,
      markAsRead,
      deleteSelected,
      handleSizeChange,
      handleCurrentChange,
      Search,
      Refresh,
      Delete,
      View,
      Bell,
      Message
    }
  }
}
</script>

<style scoped>
.inquiry-list {
  padding: 20px;
}

.action-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 20px;
}

.filter-container {
  margin-bottom: 20px;
}

.table-container {
  margin-bottom: 20px;
}

.pagination-container {
  margin-top: 20px;
  display: flex;
  justify-content: flex-end;
}

.unread-row {
  font-weight: bold;
  background-color: #fafafa;
}

.inquiry-detail {
  padding: 10px;
}

.inquiry-header {
  display: flex;
  justify-content: space-between;
  align-items: flex-start;
  margin-bottom: 20px;
  padding-bottom: 15px;
  border-bottom: 1px solid #ebeef5;
}

.inquiry-subject {
  font-size: 18px;
  font-weight: bold;
}

.inquiry-meta {
  display: flex;
  flex-direction: column;
  align-items: flex-end;
  gap: 5px;
}

.inquiry-date {
  color: #909399;
  font-size: 12px;
}

.inquiry-sender {
  margin-bottom: 20px;
  padding-bottom: 15px;
  border-bottom: 1px solid #ebeef5;
}

.info-group {
  display: flex;
  margin-bottom: 8px;
}

.info-label {
  width: 70px;
  font-weight: bold;
  color: #606266;
}

.info-value {
  color: #303133;
}

.message-label {
  font-weight: bold;
  color: #606266;
  margin-bottom: 10px;
}

.message-content {
  white-space: pre-wrap;
  line-height: 1.6;
  color: #303133;
  background-color: #f5f7fa;
  padding: 15px;
  border-radius: 4px;
  min-height: 100px;
}

.inquiry-footer {
  margin-top: 20px;
  display: flex;
  justify-content: flex-end;
}
</style>