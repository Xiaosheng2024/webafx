<template>
  <div class="product-edit container">
    <div class="action-header">
      <div class="page-title">
        <h1>{{ isEdit ? 'Edit Product' : 'Create Product' }}</h1>
      </div>
      <div class="action-buttons">
        <el-button @click="goBack">
          <el-icon><Back /></el-icon> Back
        </el-button>
      </div>
    </div>

    <el-form
      ref="productFormRef"
      :model="productForm"
      :rules="rules"
      label-width="120px"
      class="product-form"
      v-loading="loading"
    >
      <el-card class="form-card">
        <template #header>
          <div class="card-header">
            <span>Basic Information</span>
          </div>
        </template>
        
        <el-form-item label="Product Name" prop="name">
          <el-input v-model="productForm.name" placeholder="Enter product name" />
        </el-form-item>
        
        <el-form-item label="Category" prop="categoryId">
          <el-tree-select
            v-model="productForm.categoryId"
            :data="categoryOptions"
            check-strictly
            node-key="id"
            :props="{
              children: 'children',
              label: 'name'
            }"
            placeholder="Select product category"
          />
        </el-form-item>
        
        <el-form-item label="Product Code" prop="code">
          <el-input v-model="productForm.code" placeholder="Enter product code" />
        </el-form-item>
        
        <el-form-item label="Price" prop="price">
          <el-input-number 
            v-model="productForm.price" 
            :min="0" 
            :precision="2" 
            :step="0.01" 
            style="width: 200px;" 
          />
        </el-form-item>
        
        <el-form-item label="Status" prop="status">
          <el-radio-group v-model="productForm.status">
            <el-radio label="DRAFT">Draft</el-radio>
            <el-radio label="PUBLISHED">Published</el-radio>
          </el-radio-group>
        </el-form-item>
        
        <el-form-item label="Short Description">
          <el-input
            v-model="productForm.shortDescription"
            type="textarea"
            :rows="3"
            placeholder="Enter short description"
          />
        </el-form-item>
      </el-card>

      <el-card class="form-card">
        <template #header>
          <div class="card-header">
            <span>Product Media</span>
          </div>
        </template>
        
        <el-form-item label="Thumbnail" prop="thumbnail">
          <el-upload
            class="avatar-uploader"
            :action="uploadUrl"
            :headers="headers"
            :show-file-list="false"
            :on-success="handleThumbnailSuccess"
            :before-upload="beforeThumbnailUpload"
          >
            <img v-if="productForm.thumbnail" :src="productForm.thumbnail" class="avatar" />
            <el-icon v-else class="avatar-uploader-icon"><Plus /></el-icon>
          </el-upload>
          <div class="upload-tip">Recommended size: 300x300px</div>
        </el-form-item>
        
        <el-form-item label="Gallery Images">
          <el-upload
            class="gallery-uploader"
            :action="uploadUrl"
            :headers="headers"
            list-type="picture-card"
            :file-list="galleryFileList"
            :on-preview="handlePicturePreview"
            :on-success="handleGallerySuccess"
            :on-remove="handleGalleryRemove"
          >
            <el-icon><Plus /></el-icon>
          </el-upload>
          <el-dialog v-model="dialogVisible">
            <img w-full :src="dialogImageUrl" alt="Preview Image" />
          </el-dialog>
        </el-form-item>
      </el-card>

      <el-card class="form-card">
        <template #header>
          <div class="card-header">
            <span>Product Details</span>
          </div>
        </template>
        
        <el-form-item label="Description" prop="description">
          <div class="editor-container">
            <el-editor v-model="productForm.description" height="300px" />
          </div>
        </el-form-item>
        
        <el-form-item label="Specifications">
          <div class="spec-list">
            <div v-for="(spec, index) in productForm.specifications" :key="index" class="spec-item">
              <el-row :gutter="10">
                <el-col :span="10">
                  <el-input v-model="spec.name" placeholder="Specification name" />
                </el-col>
                <el-col :span="11">
                  <el-input v-model="spec.value" placeholder="Specification value" />
                </el-col>
                <el-col :span="3">
                  <el-button type="danger" circle @click="removeSpec(index)">
                    <el-icon><Delete /></el-icon>
                  </el-button>
                </el-col>
              </el-row>
            </div>
            <div class="add-spec-button">
              <el-button type="primary" @click="addSpec">
                <el-icon><Plus /></el-icon> Add Specification
              </el-button>
            </div>
          </div>
        </el-form-item>
      </el-card>

      <el-card class="form-card">
        <template #header>
          <div class="card-header">
            <span>SEO Information</span>
          </div>
        </template>
        
        <el-form-item label="Meta Title">
          <el-input v-model="productForm.metaTitle" placeholder="Enter meta title" />
        </el-form-item>
        
        <el-form-item label="Meta Description">
          <el-input
            v-model="productForm.metaDescription"
            type="textarea"
            :rows="3"
            placeholder="Enter meta description"
          />
        </el-form-item>
        
        <el-form-item label="Meta Keywords">
          <el-input v-model="productForm.metaKeywords" placeholder="Enter meta keywords" />
        </el-form-item>
      </el-card>

      <div class="form-actions">
        <el-button @click="goBack">Cancel</el-button>
        <el-button type="primary" @click="submitForm" :loading="submitting">Save</el-button>
        <el-button
          v-if="isEdit && productForm.status === 'DRAFT'"
          type="success"
          @click="saveAndPublish"
          :loading="submitting"
        >
          Save & Publish
        </el-button>
      </div>
    </el-form>
  </div>
</template>

<script>
import { ref, reactive, computed, onMounted, nextTick } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { ElMessage, ElMessageBox } from 'element-plus'
import { Plus, Back, Delete } from '@element-plus/icons-vue'
import axios from 'axios'
import { getToken } from '@/utils/auth'

export default {
  name: 'ProductEdit',
  components: {},
  setup() {
    const route = useRoute()
    const router = useRouter()
    const productId = computed(() => route.params.id)
    const isEdit = computed(() => !!productId.value)
    const productFormRef = ref(null)
    const loading = ref(false)
    const submitting = ref(false)
    const categoryOptions = ref([])
    const galleryFileList = ref([])
    const dialogImageUrl = ref('')
    const dialogVisible = ref(false)
    
    // Upload related
    const uploadUrl = '/api/media'
    const headers = {
      Authorization: `Bearer ${getToken()}`
    }

    const productForm = reactive({
      id: undefined,
      name: '',
      code: '',
      categoryId: undefined,
      price: 0,
      status: 'DRAFT',
      thumbnail: '',
      gallery: [],
      shortDescription: '',
      description: '',
      specifications: [],
      metaTitle: '',
      metaDescription: '',
      metaKeywords: ''
    })

    const rules = {
      name: [{ required: true, message: 'Please enter product name', trigger: 'blur' }],
      categoryId: [{ required: true, message: 'Please select a category', trigger: 'change' }],
      price: [{ required: true, message: 'Please enter product price', trigger: 'blur' }],
      status: [{ required: true, message: 'Please select product status', trigger: 'change' }]
    }

    // Initialize component
    onMounted(() => {
      fetchCategories()
      if (isEdit.value) {
        fetchProductDetail()
      }
    })

    // Fetch product categories
    const fetchCategories = async () => {
      try {
        const response = await axios.get('/api/product-categories/tree')
        categoryOptions.value = response.data.data || []
      } catch (error) {
        console.error('Failed to fetch categories:', error)
        ElMessage.error('Failed to load product categories')
      }
    }

    // Fetch product details if in edit mode
    const fetchProductDetail = async () => {
      loading.value = true
      try {
        const response = await axios.get(`/api/products/${productId.value}`)
        const productData = response.data.data
        
        // Update product form with fetched data
        Object.keys(productForm).forEach(key => {
          if (productData[key] !== undefined) {
            productForm[key] = productData[key]
          }
        })
        
        // Handle gallery images
        if (Array.isArray(productData.gallery) && productData.gallery.length > 0) {
          galleryFileList.value = productData.gallery.map((url, index) => ({
            name: `image-${index}`,
            url,
            uid: `existing-${index}`
          }))
        }
        
        // Handle specifications
        if (!Array.isArray(productForm.specifications) || productForm.specifications.length === 0) {
          productForm.specifications = []
        }
        
      } catch (error) {
        console.error('Failed to fetch product details:', error)
        ElMessage.error('Failed to load product details')
      } finally {
        loading.value = false
      }
    }

    // Thumbnail upload handlers
    const handleThumbnailSuccess = (response, uploadFile) => {
      if (response.code === 200) {
        productForm.thumbnail = response.data.url
        ElMessage.success('Thumbnail uploaded successfully')
      } else {
        ElMessage.error('Failed to upload thumbnail')
      }
    }

    const beforeThumbnailUpload = (file) => {
      const isImage = file.type.startsWith('image/')
      const isLt2M = file.size / 1024 / 1024 < 2

      if (!isImage) {
        ElMessage.error('You can only upload image files!')
        return false
      }
      if (!isLt2M) {
        ElMessage.error('Image size can not exceed 2MB!')
        return false
      }
      return true
    }

    // Gallery upload handlers
    const handleGallerySuccess = (response, uploadFile) => {
      if (response.code === 200) {
        productForm.gallery.push(response.data.url)
        galleryFileList.value.push({
          name: uploadFile.name,
          url: response.data.url,
          uid: uploadFile.uid
        })
        ElMessage.success('Gallery image uploaded successfully')
      } else {
        ElMessage.error('Failed to upload gallery image')
      }
    }

    const handleGalleryRemove = (file) => {
      const index = galleryFileList.value.findIndex(item => item.uid === file.uid)
      if (index !== -1) {
        galleryFileList.value.splice(index, 1)
        productForm.gallery.splice(index, 1)
      }
    }

    const handlePicturePreview = (file) => {
      dialogImageUrl.value = file.url
      dialogVisible.value = true
    }

    // Specification list handlers
    const addSpec = () => {
      productForm.specifications.push({ name: '', value: '' })
    }

    const removeSpec = (index) => {
      productForm.specifications.splice(index, 1)
    }

    // Form submission
    const submitForm = async () => {
      if (!productFormRef.value) return
      
      await productFormRef.value.validate(async (valid) => {
        if (!valid) return

        submitting.value = true
        try {
          // Filter out empty specifications
          productForm.specifications = productForm.specifications.filter(
            spec => spec.name.trim() !== '' || spec.value.trim() !== ''
          )
          
          let response
          if (isEdit.value) {
            response = await axios.put(`/api/products/${productId.value}`, productForm)
          } else {
            response = await axios.post('/api/products', productForm)
          }
          
          ElMessage.success(`Product ${isEdit.value ? 'updated' : 'created'} successfully`)
          router.push('/products/list')
        } catch (error) {
          console.error('Failed to save product:', error)
          ElMessage.error(`Failed to ${isEdit.value ? 'update' : 'create'} product`)
        } finally {
          submitting.value = false
        }
      })
    }

    // Save and publish
    const saveAndPublish = async () => {
      if (!productFormRef.value) return
      
      await productFormRef.value.validate(async (valid) => {
        if (!valid) return
        
        submitting.value = true
        try {
          productForm.status = 'PUBLISHED'
          
          let response
          if (isEdit.value) {
            response = await axios.put(`/api/products/${productId.value}`, productForm)
          } else {
            response = await axios.post('/api/products', productForm)
          }
          
          ElMessage.success('Product saved and published successfully')
          router.push('/products/list')
        } catch (error) {
          console.error('Failed to save and publish product:', error)
          ElMessage.error('Failed to save and publish product')
        } finally {
          submitting.value = false
        }
      })
    }

    // Navigation
    const goBack = () => {
      router.back()
    }

    return {
      productFormRef,
      productForm,
      rules,
      isEdit,
      loading,
      submitting,
      categoryOptions,
      uploadUrl,
      headers,
      galleryFileList,
      dialogImageUrl,
      dialogVisible,
      handleThumbnailSuccess,
      beforeThumbnailUpload,
      handleGallerySuccess,
      handleGalleryRemove,
      handlePicturePreview,
      addSpec,
      removeSpec,
      submitForm,
      saveAndPublish,
      goBack,
      Plus,
      Back,
      Delete
    }
  }
}
</script>

<style scoped>
.product-edit {
  padding: 20px;
}

.action-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 20px;
}

.form-card {
  margin-bottom: 20px;
}

.card-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
}

.product-form {
  max-width: 1200px;
}

.avatar-uploader {
  width: 150px;
  height: 150px;
}

.avatar-uploader-icon {
  font-size: 28px;
  color: #8c939d;
  width: 150px;
  height: 150px;
  line-height: 150px;
  text-align: center;
  border: 1px dashed #d9d9d9;
  border-radius: 6px;
  cursor: pointer;
}

.avatar {
  width: 150px;
  height: 150px;
  display: block;
  object-fit: cover;
}

.upload-tip {
  font-size: 12px;
  color: #909399;
  margin-top: 5px;
}

.editor-container {
  border: 1px solid #dcdfe6;
  border-radius: 4px;
}

.spec-list {
  margin-bottom: 10px;
}

.spec-item {
  margin-bottom: 10px;
}

.add-spec-button {
  margin-top: 10px;
}

.form-actions {
  display: flex;
  justify-content: flex-start;
  margin-top: 30px;
  margin-bottom: 50px;
  gap: 10px;
}
</style>