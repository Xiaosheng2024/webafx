<template>
  <div class="product-categories container">
    <div class="action-header">
      <div class="page-title">
        <h1>Product Categories Management</h1>
      </div>
      <div class="action-buttons">
        <el-button type="primary" @click="handleCreateCategory">
          <el-icon><Plus /></el-icon> Add Category
        </el-button>
      </div>
    </div>

    <el-row :gutter="20">
      <el-col :span="24">
        <el-card class="table-container">
          <el-table
            v-loading="loading"
            :data="categoryList"
            border
            row-key="id"
            default-expand-all
            :tree-props="{ children: 'children' }"
          >
            <el-table-column label="ID" prop="id" width="80" />
            <el-table-column label="Category Name" prop="name" min-width="200" />
            <el-table-column label="Sort Order" prop="sortOrder" width="120" />
            <el-table-column label="Status" width="120">
              <template #default="{ row }">
                <el-tag :type="row.status === 'ENABLED' ? 'success' : 'info'">
                  {{ row.status === 'ENABLED' ? 'Enabled' : 'Disabled' }}
                </el-tag>
              </template>
            </el-table-column>
            <el-table-column label="Created At" width="180">
              <template #default="{ row }">
                {{ formatDateTime(row.createdAt) }}
              </template>
            </el-table-column>
            <el-table-column label="Operations" width="230" fixed="right">
              <template #default="{ row }">
                <el-button size="small" @click="handleEditCategory(row)">Edit</el-button>
                <el-button
                  size="small"
                  :type="row.status === 'ENABLED' ? 'warning' : 'success'"
                  @click="handleToggleStatus(row)"
                >
                  {{ row.status === 'ENABLED' ? 'Disable' : 'Enable' }}
                </el-button>
                <el-popconfirm
                  title="Are you sure to delete this category? All subcategories will also be deleted."
                  @confirm="handleDeleteCategory(row)"
                >
                  <template #reference>
                    <el-button size="small" type="danger">Delete</el-button>
                  </template>
                </el-popconfirm>
              </template>
            </el-table-column>
          </el-table>
        </el-card>
      </el-col>
    </el-row>

    <!-- Category Dialog -->
    <el-dialog
      v-model="categoryDialog.visible"
      :title="categoryDialog.type === 'create' ? 'Create Category' : 'Edit Category'"
      width="500px"
      @close="resetCategoryForm"
    >
      <el-form
        ref="categoryFormRef"
        :model="categoryForm"
        :rules="categoryRules"
        label-width="120px"
      >
        <el-form-item label="Parent Category" prop="parentId">
          <el-tree-select
            v-model="categoryForm.parentId"
            :data="categoryOptions"
            check-strictly
            node-key="id"
            :props="{
              children: 'children',
              label: 'name'
            }"
            placeholder="Select parent category"
            clearable
          />
        </el-form-item>
        <el-form-item label="Category Name" prop="name">
          <el-input v-model="categoryForm.name" placeholder="Enter category name" />
        </el-form-item>
        <el-form-item label="Sort Order" prop="sortOrder">
          <el-input-number v-model="categoryForm.sortOrder" :min="0" :max="999" />
        </el-form-item>
        <el-form-item label="Status" prop="status">
          <el-radio-group v-model="categoryForm.status">
            <el-radio label="ENABLED">Enabled</el-radio>
            <el-radio label="DISABLED">Disabled</el-radio>
          </el-radio-group>
        </el-form-item>
        <el-form-item label="Description">
          <el-input
            v-model="categoryForm.description"
            type="textarea"
            rows="3"
            placeholder="Enter category description"
          />
        </el-form-item>
      </el-form>
      <template #footer>
        <div class="dialog-footer">
          <el-button @click="categoryDialog.visible = false">Cancel</el-button>
          <el-button type="primary" @click="submitCategoryForm" :loading="categoryDialog.loading">
            {{ categoryDialog.type === 'create' ? 'Create' : 'Update' }}
          </el-button>
        </div>
      </template>
    </el-dialog>
  </div>
</template>

<script>
import { ref, reactive, onMounted, nextTick } from 'vue'
import { Plus } from '@element-plus/icons-vue'
import { ElMessage } from 'element-plus'
import axios from 'axios'

export default {
  name: 'ProductCategories',
  setup() {
    const loading = ref(false)
    const categoryList = ref([])
    const categoryOptions = ref([])
    const categoryFormRef = ref(null)

    const categoryForm = reactive({
      id: undefined,
      name: '',
      parentId: null,
      sortOrder: 0,
      status: 'ENABLED',
      description: ''
    })

    const categoryDialog = reactive({
      visible: false,
      type: 'create',
      loading: false
    })

    const categoryRules = {
      name: [{ required: true, message: 'Please input category name', trigger: 'blur' }],
      status: [{ required: true, message: 'Please select status', trigger: 'change' }]
    }

    // Format date time
    const formatDateTime = (dateTimeStr) => {
      if (!dateTimeStr) return ''
      const date = new Date(dateTimeStr)
      return date.toLocaleString()
    }

    // Fetch category list
    const fetchCategoryList = async () => {
      loading.value = true
      try {
        const response = await axios.get('/api/product-categories/tree')
        categoryList.value = response.data.data || []
        prepareCategoryOptions()
      } catch (error) {
        console.error('Failed to fetch categories:', error)
        ElMessage.error('Failed to load product categories')
      } finally {
        loading.value = false
      }
    }

    // Prepare category options for selection (exclude current category for editing)
    const prepareCategoryOptions = () => {
      const cloneData = JSON.parse(JSON.stringify(categoryList.value))
      const excludeId = categoryForm.id
      
      if (excludeId) {
        const filterOut = (list) => {
          return list.filter(item => {
            if (item.id === excludeId) return false
            if (item.children) {
              item.children = filterOut(item.children)
            }
            return true
          })
        }
        categoryOptions.value = filterOut(cloneData)
      } else {
        categoryOptions.value = cloneData
      }
    }

    // Handle create category
    const handleCreateCategory = () => {
      categoryDialog.type = 'create'
      categoryDialog.visible = true
      resetCategoryForm()
    }

    // Handle edit category
    const handleEditCategory = (row) => {
      categoryDialog.type = 'edit'
      categoryDialog.visible = true
      
      nextTick(() => {
        Object.assign(categoryForm, {
          id: row.id,
          name: row.name,
          parentId: row.parentId,
          sortOrder: row.sortOrder,
          status: row.status,
          description: row.description
        })
        prepareCategoryOptions()
      })
    }

    // Reset category form
    const resetCategoryForm = () => {
      if (categoryFormRef.value) {
        categoryFormRef.value.resetFields()
      }
      
      Object.assign(categoryForm, {
        id: undefined,
        name: '',
        parentId: null,
        sortOrder: 0,
        status: 'ENABLED',
        description: ''
      })
    }

    // Submit category form
    const submitCategoryForm = async () => {
      if (!categoryFormRef.value) return
      
      await categoryFormRef.value.validate(async (valid) => {
        if (!valid) return
        
        categoryDialog.loading = true
        try {
          const formData = { ...categoryForm }
          
          if (categoryDialog.type === 'create') {
            await axios.post('/api/product-categories', formData)
            ElMessage.success('Category created successfully')
          } else {
            await axios.put(`/api/product-categories/${formData.id}`, formData)
            ElMessage.success('Category updated successfully')
          }
          
          categoryDialog.visible = false
          fetchCategoryList()
        } catch (error) {
          console.error('Failed to save category:', error)
          ElMessage.error('Failed to save category')
        } finally {
          categoryDialog.loading = false
        }
      })
    }

    // Handle toggle category status
    const handleToggleStatus = async (row) => {
      const newStatus = row.status === 'ENABLED' ? 'DISABLED' : 'ENABLED'
      try {
        await axios.put(`/api/product-categories/${row.id}/status`, { status: newStatus })
        ElMessage.success('Category status updated successfully')
        fetchCategoryList()
      } catch (error) {
        console.error('Failed to update category status:', error)
        ElMessage.error('Failed to update category status')
      }
    }

    // Handle delete category
    const handleDeleteCategory = async (row) => {
      try {
        await axios.delete(`/api/product-categories/${row.id}`)
        ElMessage.success('Category deleted successfully')
        fetchCategoryList()
      } catch (error) {
        console.error('Failed to delete category:', error)
        ElMessage.error('Failed to delete category')
      }
    }

    onMounted(() => {
      fetchCategoryList()
    })

    return {
      loading,
      categoryList,
      categoryOptions,
      categoryForm,
      categoryFormRef,
      categoryDialog,
      categoryRules,
      formatDateTime,
      handleCreateCategory,
      handleEditCategory,
      handleToggleStatus,
      handleDeleteCategory,
      resetCategoryForm,
      submitCategoryForm,
      Plus
    }
  }
}
</script>

<style scoped>
.product-categories {
  padding: 20px;
}

.action-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 20px;
}

.table-container {
  margin-bottom: 20px;
}

.dialog-footer {
  display: flex;
  justify-content: flex-end;
}
</style>