<!-- src/views/login/Login.vue -->
<template>
  <div class="login-container">
    <div class="login-card">
      <div class="login-header">
        <h2>CMS System</h2>
      </div>
      <el-form ref="loginForm" :model="loginForm" :rules="loginRules" class="login-form" autocomplete="on" label-position="top">
        <el-form-item prop="username">
          <el-input
            v-model="loginForm.username"
            placeholder="Username"
            type="text"
            tabindex="1"
            autocomplete="username"
            prefix-icon="el-icon-user"
          />
        </el-form-item>
        
        <el-form-item prop="password">
          <el-input
            v-model="loginForm.password"
            placeholder="Password"
            type="password"
            tabindex="2"
            autocomplete="current-password"
            prefix-icon="el-icon-lock"
            show-password
            @keyup.enter="handleLogin"
          />
        </el-form-item>
        
        <el-form-item>
          <el-checkbox v-model="loginForm.rememberMe">Remember me</el-checkbox>
        </el-form-item>
        
        <el-form-item>
          <el-button
            :loading="loading"
            type="primary"
            class="login-button"
            @click.prevent="handleLogin"
          >
            Sign in
          </el-button>
        </el-form-item>
      </el-form>
    </div>
  </div>
</template>

<script>
import { reactive, ref, onMounted } from 'vue'
import { useRouter, useRoute } from 'vue-router'
import { ElMessage } from 'element-plus'
import { login } from '@/api/user'
import { setToken } from '@/utils/auth'

export default {
  name: 'Login',
  setup() {
    const router = useRouter()
    const route = useRoute()
    const loginForm = reactive({
      username: 'admin',
      password: 'admin123',
      rememberMe: false
    })
    
    const loginRules = {
      username: [{ required: true, message: 'Please enter username', trigger: 'blur' }],
      password: [{ required: true, message: 'Please enter password', trigger: 'blur' }]
    }
    
    const loginFormRef = ref(null)
    const loading = ref(false)
    
    const handleLogin = () => {
      loginFormRef.value.validate(valid => {
        if (valid) {
          loading.value = true
          login(loginForm.username, loginForm.password)
            .then(response => {
              const { token } = response.data
              setToken(token, loginForm.rememberMe)
              
              // Redirect to the requested page or dashboard
              const redirect = route.query.redirect || '/'
              router.push(redirect)
              
              ElMessage({
                message: 'Login successful',
                type: 'success'
              })
            })
            .catch(error => {
              console.error('Login failed:', error)
              ElMessage({
                message: 'Login failed. Please check your username and password.',
                type: 'error'
              })
            })
            .finally(() => {
              loading.value = false
            })
        }
      })
    }
    
    onMounted(() => {
      // Reset form when mounted
      if (loginFormRef.value) {
        loginFormRef.value.resetFields()
      }
    })
    
    return {
      loginForm,
      loginRules,
      loginFormRef,
      loading,
      handleLogin
    }
  }
}
</script>

<style scoped>
.login-container {
  display: flex;
  justify-content: center;
  align-items: center;
  height: 100vh;
  background-color: #f3f4f6;
}

.login-card {
  width: 400px;
  padding: 30px;
  background: #ffffff;
  border-radius: 8px;
  box-shadow: 0 2px 12px 0 rgba(0, 0, 0, 0.1);
}

.login-header {
  text-align: center;
  margin-bottom: 30px;
}

.login-header h2 {
  font-size: 24px;
  color: #303133;
}

.login-form {
  margin-top: 20px;
}

.login-button {
  width: 100%;
}

@media (max-width: 576px) {
  .login-card {
    width: 90%;
    padding: 20px;
  }
}
</style>