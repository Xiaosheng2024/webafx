<template>
  <div class="solution-edit container">
    <div class="action-header">
      <div class="page-title">
        <h1>{{ isEdit ? 'Edit Solution' : 'Create Solution' }}</h1>
      </div>
      <div class="action-buttons">
        <el-button @click="goBack">
          <el-icon><Back /></el-icon> Back
        </el-button>
      </div>
    </div>

    <el-form
      ref="solutionFormRef"
      :model="solutionForm"
      :rules="rules"
      label-width="120px"
      class="solution-form"
      v-loading="loading"
    >
      <el-card class="form-card">
        <template #header>
          <div class="card-header">
            <span>Basic Information</span>
          </div>
        </template>
        
        <el-form-item label="Title" prop="title">
          <el-input v-model="solutionForm.title" placeholder="Enter solution title" />
        </el-form-item>
        
        <el-form-item label="Status" prop="status">
          <el-radio-group v-model="solutionForm.status">
            <el-radio label="DRAFT">Draft</el-radio>
            <el-radio label="PUBLISHED">Published</el-radio>
          </el-radio-group>
        </el-form-item>
        
        <el-form-item label="Short Description">
          <el-input
            v-model="solutionForm.shortDescription"
            type="textarea"
            :rows="3"
            placeholder="Enter short description"
          />
        </el-form-item>
      </el-card>

      <el-card class="form-card">
        <template #header>
          <div class="card-header">
            <span>Featured Image</span>
          </div>
        </template>
        
        <el-form-item label="Featured Image" prop="featuredImage">
          <el-upload
            class="feature-image-uploader"
            :action="uploadUrl"
            :headers="headers"
            :show-file-list="false"
            :on-success="handleFeaturedImageSuccess"
            :before-upload="beforeImageUpload"
          >
            <img v-if="solutionForm.featuredImage" :src="solutionForm.featuredImage" class="featured-image" />
            <el-icon v-else class="feature-image-uploader-icon"><Plus /></el-icon>
          </el-upload>
          <div class="upload-tip">Recommended size: 1200x600px</div>
        </el-form-item>
      </el-card>

      <el-card class="form-card">
        <template #header>
          <div class="card-header">
            <span>Solution Details</span>
          </div>
        </template>
        
        <el-form-item label="Content" prop="content">
          <div class="editor-container">
            <el-editor v-model="solutionForm.content" height="400px" />
          </div>
        </el-form-item>
      </el-card>

      <el-card class="form-card">
        <template #header>
          <div class="card-header">
            <span>Key Benefits</span>
          </div>
        </template>
        
        <div class="benefits-list">
          <div v-for="(benefit, index) in solutionForm.keyBenefits" :key="index" class="benefit-item">
            <el-row :gutter="10">
              <el-col :span="21">
                <el-input v-model="benefit.text" placeholder="Enter benefit" />
              </el-col>
              <el-col :span="3">
                <el-button type="danger" circle @click="removeBenefit(index)">
                  <el-icon><Delete /></el-icon>
                </el-button>
              </el-col>
            </el-row>
          </div>
          <div class="add-benefit-button">
            <el-button type="primary" @click="addBenefit">
              <el-icon><Plus /></el-icon> Add Benefit
            </el-button>
          </div>
        </div>
      </el-card>

      <el-card class="form-card">
        <template #header>
          <div class="card-header">
            <span>SEO Information</span>
          </div>
        </template>
        
        <el-form-item label="Meta Title">
          <el-input v-model="solutionForm.metaTitle" placeholder="Enter meta title" />
        </el-form-item>
        
        <el-form-item label="Meta Description">
          <el-input
            v-model="solutionForm.metaDescription"
            type="textarea"
            :rows="3"
            placeholder="Enter meta description"
          />
        </el-form-item>
        
        <el-form-item label="Meta Keywords">
          <el-input v-model="solutionForm.metaKeywords" placeholder="Enter meta keywords" />
        </el-form-item>
      </el-card>

      <div class="form-actions">
        <el-button @click="goBack">Cancel</el-button>
        <el-button type="primary" @click="submitForm" :loading="submitting">Save</el-button>
        <el-button
          v-if="isEdit && solutionForm.status === 'DRAFT'"
          type="success"
          @click="saveAndPublish"
          :loading="submitting"
        >
          Save & Publish
        </el-button>
      </div>
    </el-form>
  </div>
</template>

<script>
import { ref, reactive, computed, onMounted, nextTick } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { ElMessage } from 'element-plus'
import { Plus, Back, Delete } from '@element-plus/icons-vue'
import axios from 'axios'
import { getToken } from '@/utils/auth'

export default {
  name: 'SolutionEdit',
  setup() {
    const route = useRoute()
    const router = useRouter()
    const solutionId = computed(() => route.params.id)
    const isEdit = computed(() => !!solutionId.value)
    const solutionFormRef = ref(null)
    const loading = ref(false)
    const submitting = ref(false)
    
    // Upload related
    const uploadUrl = '/api/media'
    const headers = {
      Authorization: `Bearer ${getToken()}`
    }

    const solutionForm = reactive({
      id: undefined,
      title: '',
      shortDescription: '',
      content: '',
      featuredImage: '',
      status: 'DRAFT',
      keyBenefits: [],
      metaTitle: '',
      metaDescription: '',
      metaKeywords: ''
    })

    const rules = {
      title: [{ required: true, message: 'Please enter solution title', trigger: 'blur' }],
      content: [{ required: true, message: 'Please enter solution content', trigger: 'blur' }],
      status: [{ required: true, message: 'Please select solution status', trigger: 'change' }]
    }

    // Initialize component
    onMounted(() => {
      if (isEdit.value) {
        fetchSolutionDetail()
      } else {
        // Initialize with at least one benefit for new solutions
        addBenefit()
      }
    })

    // Fetch solution details if in edit mode
    const fetchSolutionDetail = async () => {
      loading.value = true
      try {
        const response = await axios.get(`/api/solutions/${solutionId.value}`)
        const solutionData = response.data.data
        
        // Update solution form with fetched data
        Object.keys(solutionForm).forEach(key => {
          if (solutionData[key] !== undefined) {
            solutionForm[key] = solutionData[key]
          }
        })
        
        // Handle key benefits
        if (!Array.isArray(solutionForm.keyBenefits) || solutionForm.keyBenefits.length === 0) {
          solutionForm.keyBenefits = []
          addBenefit() // Add at least one benefit field
        }
        
      } catch (error) {
        console.error('Failed to fetch solution details:', error)
        ElMessage.error('Failed to load solution details')
      } finally {
        loading.value = false
      }
    }

    // Featured image upload handlers
    const handleFeaturedImageSuccess = (response, uploadFile) => {
      if (response.code === 200) {
        solutionForm.featuredImage = response.data.url
        ElMessage.success('Featured image uploaded successfully')
      } else {
        ElMessage.error('Failed to upload featured image')
      }
    }

    const beforeImageUpload = (file) => {
      const isImage = file.type.startsWith('image/')
      const isLt2M = file.size / 1024 / 1024 < 5

      if (!isImage) {
        ElMessage.error('You can only upload image files!')
        return false
      }
      if (!isLt2M) {
        ElMessage.error('Image size cannot exceed 5MB!')
        return false
      }
      return true
    }

    // Key benefits list handlers
    const addBenefit = () => {
      solutionForm.keyBenefits.push({ text: '' })
    }

    const removeBenefit = (index) => {
      solutionForm.keyBenefits.splice(index, 1)
    }

    // Form submission
    const submitForm = async () => {
      if (!solutionFormRef.value) return
      
      await solutionFormRef.value.validate(async (valid) => {
        if (!valid) return

        submitting.value = true
        try {
          // Filter out empty benefits
          solutionForm.keyBenefits = solutionForm.keyBenefits.filter(
            benefit => benefit.text.trim() !== ''
          )
          
          let response
          if (isEdit.value) {
            response = await axios.put(`/api/solutions/${solutionId.value}`, solutionForm)
          } else {
            response = await axios.post('/api/solutions', solutionForm)
          }
          
          ElMessage.success(`Solution ${isEdit.value ? 'updated' : 'created'} successfully`)
          router.push('/solutions/list')
        } catch (error) {
          console.error('Failed to save solution:', error)
          ElMessage.error(`Failed to ${isEdit.value ? 'update' : 'create'} solution`)
        } finally {
          submitting.value = false
        }
      })
    }

    // Save and publish
    const saveAndPublish = async () => {
      if (!solutionFormRef.value) return
      
      await solutionFormRef.value.validate(async (valid) => {
        if (!valid) return
        
        submitting.value = true
        try {
          solutionForm.status = 'PUBLISHED'
          
          let response
          if (isEdit.value) {
            response = await axios.put(`/api/solutions/${solutionId.value}`, solutionForm)
          } else {
            response = await axios.post('/api/solutions', solutionForm)
          }
          
          ElMessage.success('Solution saved and published successfully')
          router.push('/solutions/list')
        } catch (error) {
          console.error('Failed to save and publish solution:', error)
          ElMessage.error('Failed to save and publish solution')
        } finally {
          submitting.value = false
        }
      })
    }

    // Navigation
    const goBack = () => {
      router.back()
    }

    return {
      solutionFormRef,
      solutionForm,
      rules,
      isEdit,
      loading,
      submitting,
      uploadUrl,
      headers,
      handleFeaturedImageSuccess,
      beforeImageUpload,
      addBenefit,
      removeBenefit,
      submitForm,
      saveAndPublish,
      goBack,
      Plus,
      Back,
      Delete
    }
  }
}
</script>

<style scoped>
.solution-edit {
  padding: 20px;
}

.action-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 20px;
}

.form-card {
  margin-bottom: 20px;
}

.card-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
}

.solution-form {
  max-width: 1200px;
}

.feature-image-uploader {
  width: 300px;
  height: 150px;
}

.feature-image-uploader-icon {
  font-size: 28px;
  color: #8c939d;
  width: 300px;
  height: 150px;
  line-height: 150px;
  text-align: center;
  border: 1px dashed #d9d9d9;
  border-radius: 6px;
  cursor: pointer;
}

.featured-image {
  width: 300px;
  height: 150px;
  display: block;
  object-fit: cover;
}

.upload-tip {
  font-size: 12px;
  color: #909399;
  margin-top: 5px;
}

.editor-container {
  border: 1px solid #dcdfe6;
  border-radius: 4px;
}

.benefits-list {
  margin-bottom: 10px;
}

.benefit-item {
  margin-bottom: 10px;
}

.add-benefit-button {
  margin-top: 10px;
}

.form-actions {
  display: flex;
  justify-content: flex-start;
  margin-top: 30px;
  margin-bottom: 50px;
  gap: 10px;
}
</style>