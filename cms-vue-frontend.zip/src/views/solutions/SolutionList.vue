<template>
  <div class="solution-list container">
    <div class="action-header">
      <div class="page-title">
        <h1>Solution Management</h1>
      </div>
      <div class="action-buttons">
        <el-button type="primary" @click="handleCreate">
          <el-icon><Plus /></el-icon> Add Solution
        </el-button>
      </div>
    </div>

    <el-card class="filter-container">
      <div class="filter-items">
        <el-form :inline="true" :model="queryParams" class="search-form">
          <el-form-item label="Title">
            <el-input
              v-model="queryParams.title"
              placeholder="Search solution title"
              clearable
              @keyup.enter="handleSearch"
            />
          </el-form-item>
          <el-form-item label="Status">
            <el-select v-model="queryParams.status" placeholder="All Status" clearable>
              <el-option label="Published" value="PUBLISHED" />
              <el-option label="Draft" value="DRAFT" />
            </el-select>
          </el-form-item>
          <el-form-item>
            <el-button type="primary" @click="handleSearch">
              <el-icon><Search /></el-icon> Search
            </el-button>
            <el-button @click="resetQuery">
              <el-icon><Refresh /></el-icon> Reset
            </el-button>
          </el-form-item>
        </el-form>
      </div>
    </el-card>

    <el-card class="table-container">
      <el-table
        v-loading="loading"
        :data="solutionList"
        border
        style="width: 100%"
        row-key="id"
      >
        <el-table-column label="ID" prop="id" width="80" />
        <el-table-column label="Featured Image" width="120">
          <template #default="{ row }">
            <el-image
              v-if="row.featuredImage"
              :src="row.featuredImage"
              fit="cover"
              style="width: 80px; height: 80px"
              :preview-src-list="[row.featuredImage]"
            >
              <template #error>
                <div class="image-placeholder">No image</div>
              </template>
            </el-image>
            <div v-else class="image-placeholder">No image</div>
          </template>
        </el-table-column>
        <el-table-column label="Title" prop="title" min-width="200" show-overflow-tooltip />
        <el-table-column label="Status" width="120">
          <template #default="{ row }">
            <el-tag :type="row.status === 'PUBLISHED' ? 'success' : 'info'">
              {{ row.status === 'PUBLISHED' ? 'Published' : 'Draft' }}
            </el-tag>
          </template>
        </el-table-column>
        <el-table-column label="Created At" width="180">
          <template #default="{ row }">
            {{ formatDateTime(row.createdAt) }}
          </template>
        </el-table-column>
        <el-table-column label="Updated At" width="180">
          <template #default="{ row }">
            {{ formatDateTime(row.updatedAt) }}
          </template>
        </el-table-column>
        <el-table-column label="Operations" width="220" fixed="right">
          <template #default="{ row }">
            <el-button size="small" @click="handleEdit(row)">Edit</el-button>
            <el-button
              size="small"
              :type="row.status === 'PUBLISHED' ? 'warning' : 'success'"
              @click="handleToggleStatus(row)"
            >
              {{ row.status === 'PUBLISHED' ? 'Unpublish' : 'Publish' }}
            </el-button>
            <el-popconfirm
              title="Are you sure to delete this solution?"
              @confirm="handleDelete(row)"
            >
              <template #reference>
                <el-button size="small" type="danger">Delete</el-button>
              </template>
            </el-popconfirm>
          </template>
        </el-table-column>
      </el-table>

      <div class="pagination-container">
        <el-pagination
          v-model:current-page="queryParams.page"
          v-model:page-size="queryParams.size"
          :page-sizes="[10, 20, 50, 100]"
          :total="total"
          layout="total, sizes, prev, pager, next, jumper"
          @size-change="handleSizeChange"
          @current-change="handleCurrentChange"
        />
      </div>
    </el-card>
  </div>
</template>

<script>
import { ref, reactive, onMounted } from 'vue'
import { useRouter } from 'vue-router'
import { Plus, Search, Refresh } from '@element-plus/icons-vue'
import { ElMessage } from 'element-plus'
import axios from 'axios'

export default {
  name: 'SolutionList',
  setup() {
    const router = useRouter()
    const loading = ref(false)
    const solutionList = ref([])
    const total = ref(0)

    const queryParams = reactive({
      page: 1,
      size: 10,
      title: '',
      status: ''
    })

    // Format date time
    const formatDateTime = (dateTimeStr) => {
      if (!dateTimeStr) return ''
      const date = new Date(dateTimeStr)
      return date.toLocaleString()
    }

    // Fetch solution list
    const fetchSolutionList = async () => {
      loading.value = true
      try {
        const response = await axios.get('/api/solutions', { params: queryParams })
        const data = response.data.data
        solutionList.value = data.content || []
        total.value = data.totalElements || 0
      } catch (error) {
        console.error('Failed to fetch solutions:', error)
        ElMessage.error('Failed to load solution list')
      } finally {
        loading.value = false
      }
    }

    // Handle search
    const handleSearch = () => {
      queryParams.page = 1
      fetchSolutionList()
    }

    // Reset query params
    const resetQuery = () => {
      queryParams.title = ''
      queryParams.status = ''
      queryParams.page = 1
      fetchSolutionList()
    }

    // Handle create new solution
    const handleCreate = () => {
      router.push('/solutions/create')
    }

    // Handle edit solution
    const handleEdit = (row) => {
      router.push(`/solutions/edit/${row.id}`)
    }

    // Handle toggle solution status (publish/unpublish)
    const handleToggleStatus = async (row) => {
      const action = row.status === 'PUBLISHED' ? 'unpublish' : 'publish'
      const endpoint = `/api/solutions/${row.id}/${action}`
      
      try {
        await axios.patch(endpoint)
        ElMessage.success(`${action === 'publish' ? 'Published' : 'Unpublished'} successfully`)
        fetchSolutionList()
      } catch (error) {
        console.error(`Failed to ${action} solution:`, error)
        ElMessage.error(`Failed to ${action} solution`)
      }
    }

    // Handle delete solution
    const handleDelete = async (row) => {
      try {
        await axios.delete(`/api/solutions/${row.id}`)
        ElMessage.success('Solution deleted successfully')
        fetchSolutionList()
      } catch (error) {
        console.error('Failed to delete solution:', error)
        ElMessage.error('Failed to delete solution')
      }
    }

    // Pagination handlers
    const handleSizeChange = (size) => {
      queryParams.size = size
      fetchSolutionList()
    }

    const handleCurrentChange = (page) => {
      queryParams.page = page
      fetchSolutionList()
    }

    onMounted(() => {
      fetchSolutionList()
    })

    return {
      loading,
      solutionList,
      total,
      queryParams,
      formatDateTime,
      handleSearch,
      resetQuery,
      handleCreate,
      handleEdit,
      handleToggleStatus,
      handleDelete,
      handleSizeChange,
      handleCurrentChange,
      Plus,
      Search,
      Refresh
    }
  }
}
</script>

<style scoped>
.solution-list {
  padding: 20px;
}

.action-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 20px;
}

.filter-container {
  margin-bottom: 20px;
}

.table-container {
  margin-bottom: 20px;
}

.pagination-container {
  margin-top: 20px;
  display: flex;
  justify-content: flex-end;
}

.image-placeholder {
  width: 80px;
  height: 80px;
  display: flex;
  justify-content: center;
  align-items: center;
  background-color: #f5f7fa;
  color: #909399;
  font-size: 12px;
  border-radius: 4px;
}
</style>