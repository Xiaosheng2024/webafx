// src/router/index.js
import { createRouter, createWebHistory } from 'vue-router'
import NProgress from 'nprogress'
import 'nprogress/nprogress.css'
import { getToken } from '@/utils/auth'

// Configure NProgress
NProgress.configure({ showSpinner: false })

// Import layout components
const Layout = () => import('@/components/layout/Layout.vue')

// Routes configuration
const routes = [
  {
    path: '/login',
    name: 'Login',
    component: () => import('@/views/login/Login.vue'),
    meta: { title: 'Login', public: true }
  },
  {
    path: '/',
    component: Layout,
    redirect: '/dashboard',
    children: [
      {
        path: 'dashboard',
        name: 'Dashboard',
        component: () => import('@/views/dashboard/Dashboard.vue'),
        meta: { title: 'Dashboard', icon: 'el-icon-s-home' }
      }
    ]
  },
  {
    path: '/content',
    component: Layout,
    name: 'Content',
    meta: { title: 'Content Management', icon: 'el-icon-document' },
    children: [
      {
        path: 'article',
        name: 'ArticleList',
        component: () => import('@/views/content/ArticleList.vue'),
        meta: { title: 'Article List', icon: 'el-icon-tickets' }
      },
      {
        path: 'article/create',
        name: 'ArticleCreate',
        component: () => import('@/views/content/ArticleEdit.vue'),
        meta: { title: 'Create Article', activeMenu: '/content/article' },
        hidden: true
      },
      {
        path: 'article/edit/:id',
        name: 'ArticleEdit',
        component: () => import('@/views/content/ArticleEdit.vue'),
        meta: { title: 'Edit Article', activeMenu: '/content/article' },
        hidden: true
      },
      {
        path: 'category',
        name: 'CategoryManagement',
        component: () => import('@/views/content/CategoryManagement.vue'),
        meta: { title: 'Category Management', icon: 'el-icon-collection' }
      }
    ]
  },
  {
    path: '/products',
    component: Layout,
    name: 'Products',
    meta: { title: 'Product Center', icon: 'el-icon-s-goods' },
    children: [
      {
        path: 'list',
        name: 'ProductList',
        component: () => import('@/views/products/ProductList.vue'),
        meta: { title: 'Product List', icon: 'el-icon-s-grid' }
      },
      {
        path: 'create',
        name: 'ProductCreate',
        component: () => import('@/views/products/ProductEdit.vue'),
        meta: { title: 'Create Product', activeMenu: '/products/list' },
        hidden: true
      },
      {
        path: 'edit/:id',
        name: 'ProductEdit',
        component: () => import('@/views/products/ProductEdit.vue'),
        meta: { title: 'Edit Product', activeMenu: '/products/list' },
        hidden: true
      },
      {
        path: 'categories',
        name: 'ProductCategories',
        component: () => import('@/views/products/ProductCategories.vue'),
        meta: { title: 'Product Categories', icon: 'el-icon-menu' }
      }
    ]
  },
  {
    path: '/solutions',
    component: Layout,
    name: 'Solutions',
    meta: { title: 'Solutions', icon: 'el-icon-s-opportunity' },
    children: [
      {
        path: 'list',
        name: 'SolutionList',
        component: () => import('@/views/solutions/SolutionList.vue'),
        meta: { title: 'Solution List', icon: 'el-icon-s-management' }
      },
      {
        path: 'create',
        name: 'SolutionCreate',
        component: () => import('@/views/solutions/SolutionEdit.vue'),
        meta: { title: 'Create Solution', activeMenu: '/solutions/list' },
        hidden: true
      },
      {
        path: 'edit/:id',
        name: 'SolutionEdit',
        component: () => import('@/views/solutions/SolutionEdit.vue'),
        meta: { title: 'Edit Solution', activeMenu: '/solutions/list' },
        hidden: true
      }
    ]
  },
  {
    path: '/cases',
    component: Layout,
    name: 'Cases',
    meta: { title: 'Case Showcase', icon: 'el-icon-picture-outline' },
    children: [
      {
        path: 'list',
        name: 'CaseList',
        component: () => import('@/views/cases/CaseList.vue'),
        meta: { title: 'Case List', icon: 'el-icon-picture' }
      },
      {
        path: 'create',
        name: 'CaseCreate',
        component: () => import('@/views/cases/CaseEdit.vue'),
        meta: { title: 'Create Case', activeMenu: '/cases/list' },
        hidden: true
      },
      {
        path: 'edit/:id',
        name: 'CaseEdit',
        component: () => import('@/views/cases/CaseEdit.vue'),
        meta: { title: 'Edit Case', activeMenu: '/cases/list' },
        hidden: true
      },
      {
        path: 'categories',
        name: 'CaseCategories',
        component: () => import('@/views/cases/CaseCategories.vue'),
        meta: { title: 'Case Categories', icon: 'el-icon-files' }
      }
    ]
  },
  {
    path: '/about',
    component: Layout,
    name: 'About',
    meta: { title: 'About Us', icon: 'el-icon-office-building' },
    children: [
      {
        path: 'content',
        name: 'AboutContent',
        component: () => import('@/views/about/AboutContent.vue'),
        meta: { title: 'Company Info', icon: 'el-icon-info' }
      },
      {
        path: 'team',
        name: 'TeamManagement',
        component: () => import('@/views/about/TeamManagement.vue'),
        meta: { title: 'Team Members', icon: 'el-icon-user-solid' }
      }
    ]
  },
  {
    path: '/contact',
    component: Layout,
    name: 'Contact',
    meta: { title: 'Contact Us', icon: 'el-icon-phone-outline' },
    children: [
      {
        path: 'info',
        name: 'ContactInfo',
        component: () => import('@/views/contact/ContactInfo.vue'),
        meta: { title: 'Contact Information', icon: 'el-icon-phone' }
      },
      {
        path: 'messages',
        name: 'ContactMessages',
        component: () => import('@/views/contact/ContactMessages.vue'),
        meta: { title: 'Customer Messages', icon: 'el-icon-message' }
      }
    ]
  },
  {
    path: '/system',
    component: Layout,
    name: 'System',
    meta: { title: 'System Management', icon: 'el-icon-setting' },
    children: [
      {
        path: 'user',
        name: 'UserManagement',
        component: () => import('@/views/system/UserManagement.vue'),
        meta: { title: 'User Management', icon: 'el-icon-user' }
      },
      {
        path: 'role',
        name: 'RoleManagement',
        component: () => import('@/views/system/RoleManagement.vue'),
        meta: { title: 'Role Management', icon: 'el-icon-s-custom' }
      }
    ]
  },
  {
    path: '/404',
    component: () => import('@/views/404.vue'),
    hidden: true
  },
  {
    path: '/:pathMatch(.*)*',
    redirect: '/404',
    hidden: true
  }
]

const router = createRouter({
  history: createWebHistory(),
  routes
})

// Navigation guards
router.beforeEach((to, from, next) => {
  // Start progress bar
  NProgress.start()

  // Set page title
  document.title = to.meta.title ? `${to.meta.title} - CMS System` : 'CMS System'

  // Check if the user is logged in
  const token = getToken()
  
  if (to.meta.public) {
    // Public page, allow access
    if (token && to.path === '/login') {
      // If already logged in and trying to access login page, redirect to dashboard
      next({ path: '/' })
    } else {
      next()
    }
  } else {
    // Protected page, check authentication
    if (token) {
      next()
    } else {
      // Not logged in, redirect to login page
      next(`/login?redirect=${to.path}`)
    }
  }
})

router.afterEach(() => {
  // Stop progress bar
  NProgress.done()
})

export default router