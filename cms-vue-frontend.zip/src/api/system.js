// src/api/system.js
import request from '@/utils/request'

// Role APIs
export function getRoles() {
  return request({
    url: '/system/roles',
    method: 'get'
  })
}

export function getRoleById(id) {
  return request({
    url: `/system/roles/${id}`,
    method: 'get'
  })
}

export function createRole(data) {
  return request({
    url: '/system/roles',
    method: 'post',
    data
  })
}

export function updateRole(id, data) {
  return request({
    url: `/system/roles/${id}`,
    method: 'put',
    data
  })
}

export function deleteRole(id) {
  return request({
    url: `/system/roles/${id}`,
    method: 'delete'
  })
}

export function updateRoleStatus(id, status) {
  return request({
    url: `/system/roles/${id}/status`,
    method: 'patch',
    data: {
      status
    }
  })
}

// Permission APIs
export function getPermissions() {
  return request({
    url: '/system/permissions',
    method: 'get'
  })
}

export function getRolePermissions(roleId) {
  return request({
    url: `/system/roles/${roleId}/permissions`,
    method: 'get'
  })
}

export function updateRolePermissions(roleId, permissionIds) {
  return request({
    url: `/system/roles/${roleId}/permissions`,
    method: 'put',
    data: {
      permissionIds
    }
  })
}

// System Settings APIs
export function getSystemSettings() {
  return request({
    url: '/system/settings',
    method: 'get'
  })
}

export function updateSystemSettings(data) {
  return request({
    url: '/system/settings',
    method: 'put',
    data
  })
}

// Logs APIs
export function getOperationLogs(params) {
  return request({
    url: '/system/logs/operation',
    method: 'get',
    params
  })
}

export function getLoginLogs(params) {
  return request({
    url: '/system/logs/login',
    method: 'get',
    params
  })
}

// Dashboard APIs
export function getDashboardStats() {
  return request({
    url: '/system/dashboard/stats',
    method: 'get'
  })
}

export function getDashboardChartData(type, timeRange) {
  return request({
    url: '/system/dashboard/chart',
    method: 'get',
    params: {
      type,
      timeRange
    }
  })
}