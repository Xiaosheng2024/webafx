// src/api/user.js
import request from '@/utils/request'

// User login
export function login(username, password) {
  return request({
    url: '/auth/login',
    method: 'post',
    data: {
      username,
      password
    }
  })
}

// User logout
export function logout() {
  return request({
    url: '/auth/logout',
    method: 'post'
  })
}

// Get user info
export function getUserInfo() {
  return request({
    url: '/user/info',
    method: 'get'
  })
}

// Get user list
export function getUsers(params) {
  return request({
    url: '/system/users',
    method: 'get',
    params
  })
}

// Get user details
export function getUserDetails(id) {
  return request({
    url: `/system/users/${id}`,
    method: 'get'
  })
}

// Create new user
export function createUser(data) {
  return request({
    url: '/system/users',
    method: 'post',
    data
  })
}

// Update user
export function updateUser(id, data) {
  return request({
    url: `/system/users/${id}`,
    method: 'put',
    data
  })
}

// Delete user
export function deleteUser(id) {
  return request({
    url: `/system/users/${id}`,
    method: 'delete'
  })
}

// Update user status
export function updateUserStatus(id, status) {
  return request({
    url: `/system/users/${id}/status`,
    method: 'patch',
    data: {
      status
    }
  })
}

// Change user password
export function changePassword(data) {
  return request({
    url: '/user/password',
    method: 'put',
    data
  })
}

// Reset user password
export function resetPassword(id) {
  return request({
    url: `/system/users/${id}/password/reset`,
    method: 'post'
  })
}

// Get roles
export function getRoles() {
  return request({
    url: '/system/roles',
    method: 'get'
  })
}

// Update user roles
export function updateUserRoles(id, roleIds) {
  return request({
    url: `/system/users/${id}/roles`,
    method: 'put',
    data: {
      roleIds
    }
  })
}