// src/api/content.js
import request from '@/utils/request'

// Article APIs
export function getArticles(params) {
  return request({
    url: '/content/articles',
    method: 'get',
    params
  })
}

export function getArticleById(id) {
  return request({
    url: `/content/articles/${id}`,
    method: 'get'
  })
}

export function createArticle(data) {
  return request({
    url: '/content/articles',
    method: 'post',
    data
  })
}

export function updateArticle(id, data) {
  return request({
    url: `/content/articles/${id}`,
    method: 'put',
    data
  })
}

export function deleteArticle(id) {
  return request({
    url: `/content/articles/${id}`,
    method: 'delete'
  })
}

export function updateArticleStatus(id, status) {
  return request({
    url: `/content/articles/${id}/status`,
    method: 'patch',
    data: {
      status
    }
  })
}

export function uploadImage(file) {
  const formData = new FormData()
  formData.append('file', file)
  
  return request({
    url: '/content/upload',
    method: 'post',
    data: formData,
    headers: {
      'Content-Type': 'multipart/form-data'
    }
  })
}

// Category APIs
export function getCategories(params) {
  return request({
    url: '/content/categories',
    method: 'get',
    params
  })
}

export function getCategoryById(id) {
  return request({
    url: `/content/categories/${id}`,
    method: 'get'
  })
}

export function createCategory(data) {
  return request({
    url: '/content/categories',
    method: 'post',
    data
  })
}

export function updateCategory(id, data) {
  return request({
    url: `/content/categories/${id}`,
    method: 'put',
    data
  })
}

export function deleteCategory(id) {
  return request({
    url: `/content/categories/${id}`,
    method: 'delete'
  })
}

// Tag APIs
export function getTags(params) {
  return request({
    url: '/content/tags',
    method: 'get',
    params
  })
}

export function getTagById(id) {
  return request({
    url: `/content/tags/${id}`,
    method: 'get'
  })
}

export function createTag(data) {
  return request({
    url: '/content/tags',
    method: 'post',
    data
  })
}

export function updateTag(id, data) {
  return request({
    url: `/content/tags/${id}`,
    method: 'put',
    data
  })
}

export function deleteTag(id) {
  return request({
    url: `/content/tags/${id}`,
    method: 'delete'
  })
}