<!-- src/components/layout/Sidebar.vue -->
<template>
  <div class="sidebar-container" :class="{ 'is-collapsed': isCollapsed }">
    <div class="logo-container">
      <router-link to="/">
        <h1 class="logo-text" v-if="!isCollapsed">CMS</h1>
        <h1 class="logo-icon" v-else>C</h1>
      </router-link>
    </div>
    <el-scrollbar>
      <el-menu
        :default-active="activeMenu"
        :collapse="isCollapsed"
        :unique-opened="true"
        background-color="#304156"
        text-color="#bfcbd9"
        active-text-color="#409EFF"
        :collapse-transition="false"
        mode="vertical"
      >
        <sidebar-item 
          v-for="route in routes" 
          :key="route.path" 
          :item="route" 
          :base-path="route.path" 
          :is-collapsed="isCollapsed" 
        />
      </el-menu>
    </el-scrollbar>
  </div>
</template>

<script>
import { computed } from 'vue'
import { useRoute } from 'vue-router'

// Sidebar Item Component
const SidebarItem = {
  name: 'SidebarItem',
  props: {
    item: {
      type: Object,
      required: true
    },
    basePath: {
      type: String,
      default: ''
    },
    isCollapsed: {
      type: Boolean,
      default: false
    }
  },
  setup(props) {
    const route = useRoute()
    
    const showingChildNumber = computed(() => {
      const children = props.item.children || []
      return children.filter(item => !item.hidden).length
    })

    const isActive = (routePath) => {
      return route.path === routePath || route.meta?.activeMenu === routePath
    }

    return {
      isActive,
      showingChildNumber
    }
  },
  render() {
    // If the item has children and they're not all hidden
    if (this.item.children && this.showingChildNumber > 0) {
      // Don't show submenu if there's only one visible child
      if (this.showingChildNumber === 1 && !this.item.alwaysShow) {
        const onlyChild = this.item.children.find(child => !child.hidden)
        return (
          <el-menu-item 
            index={onlyChild.path}
            class={{ 'is-active': this.isActive(onlyChild.path) }}
          >
            {onlyChild.meta?.icon && <el-icon><i class={onlyChild.meta.icon}></i></el-icon>}
            <span>{onlyChild.meta?.title}</span>
          </el-menu-item>
        )
      }
      
      // Show submenu with multiple children
      return (
        <el-sub-menu 
          index={this.item.path}
          popper-append-to-body
        >
          <template slot="title">
            {this.item.meta?.icon && <el-icon><i class={this.item.meta.icon}></i></el-icon>}
            <span>{this.item.meta?.title}</span>
          </template>
          {this.item.children
            .filter(child => !child.hidden)
            .map(child => (
              <sidebar-item
                key={child.path}
                item={child}
                base-path={child.path}
                is-collapsed={this.isCollapsed}
              />
            ))
          }
        </el-sub-menu>
      )
    }
    
    // Item has no children or all children are hidden
    return (
      <el-menu-item 
        index={this.item.path}
        class={{ 'is-active': this.isActive(this.item.path) }}
      >
        {this.item.meta?.icon && <el-icon><i class={this.item.meta.icon}></i></el-icon>}
        <span>{this.item.meta?.title}</span>
      </el-menu-item>
    )
  }
}

export default {
  name: 'Sidebar',
  components: {
    SidebarItem
  },
  props: {
    isCollapsed: {
      type: Boolean,
      default: false
    }
  },
  setup() {
    const route = useRoute()
    
    // Get routes from router configuration
    const routes = computed(() => {
      const router = route.matched[0]?.meta?.router || []
      return router.routes.filter(route => !route.hidden)
    })
    
    // Determine active menu based on current route
    const activeMenu = computed(() => {
      const { meta, path } = route
      if (meta.activeMenu) {
        return meta.activeMenu
      }
      return path
    })
    
    return {
      routes,
      activeMenu
    }
  }
}
</script>

<style scoped>
.sidebar-container {
  width: var(--sidebar-width);
  height: 100%;
  background-color: #304156;
  overflow: hidden;
  transition: width 0.3s;
}

.sidebar-container.is-collapsed {
  width: 64px;
}

.logo-container {
  height: var(--header-height);
  display: flex;
  align-items: center;
  justify-content: center;
  background-color: #263445;
  overflow: hidden;
}

.logo-text {
  font-size: 20px;
  color: #ffffff;
  margin: 0;
}

.logo-icon {
  font-size: 24px;
  color: #ffffff;
  margin: 0;
}

a {
  text-decoration: none;
}

:deep(.el-menu) {
  border-right: none;
}

:deep(.el-sub-menu__title) {
  &:hover {
    background-color: #263445 !important;
  }
}

:deep(.el-menu-item) {
  &.is-active {
    background-color: #263445 !important;
  }
  
  &:hover {
    background-color: #263445 !important;
  }
}
</style>