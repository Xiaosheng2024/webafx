<!-- src/components/layout/Header.vue -->
<template>
  <div class="header-container">
    <div class="left-section">
      <div class="hamburger" @click="toggleSidebar">
        <i class="el-icon-menu"></i>
      </div>
      <breadcrumb class="breadcrumb" />
    </div>
    <div class="right-section">
      <el-dropdown trigger="click" @command="handleCommand">
        <div class="user-info">
          <el-avatar :size="30" :src="userInfo.avatar || defaultAvatar" />
          <span class="username">{{ userInfo.name }}</span>
          <i class="el-icon-arrow-down"></i>
        </div>
        <template #dropdown>
          <el-dropdown-menu>
            <el-dropdown-item command="profile">Profile</el-dropdown-item>
            <el-dropdown-item command="settings">Settings</el-dropdown-item>
            <el-dropdown-item divided command="logout">Logout</el-dropdown-item>
          </el-dropdown-menu>
        </template>
      </el-dropdown>
    </div>
  </div>
</template>

<script>
import { computed } from 'vue'
import { useRouter } from 'vue-router'
import { ElMessageBox, ElMessage } from 'element-plus'
import { logout } from '@/api/user'
import { removeToken } from '@/utils/auth'

// Breadcrumb Component
const Breadcrumb = {
  name: 'Breadcrumb',
  setup() {
    const route = useRoute()
    
    const breadcrumbs = computed(() => {
      const matched = route.matched.filter(item => item.meta && item.meta.title)
      return matched
    })
    
    return {
      breadcrumbs
    }
  },
  render() {
    return (
      <el-breadcrumb separator="/">
        {this.breadcrumbs.map((item, index) => (
          <el-breadcrumb-item key={item.path}>
            {index < this.breadcrumbs.length - 1 ? (
              <router-link to={item.path}>{item.meta.title}</router-link>
            ) : (
              <span>{item.meta.title}</span>
            )}
          </el-breadcrumb-item>
        ))}
      </el-breadcrumb>
    )
  }
}

export default {
  name: 'Header',
  components: {
    Breadcrumb
  },
  emits: ['toggle-sidebar'],
  setup(props, { emit }) {
    const router = useRouter()
    
    // Mock user information - in real app, this would come from a store or API
    const userInfo = computed(() => ({
      name: 'Admin User',
      avatar: ''
    }))
    
    const defaultAvatar = 'https://cube.elemecdn.com/3/7c/3ea6beec64369c2642b92c6726f1epng.png'
    
    const toggleSidebar = () => {
      emit('toggle-sidebar')
    }
    
    const handleCommand = (command) => {
      switch (command) {
        case 'profile':
          router.push('/profile')
          break
        case 'settings':
          router.push('/settings')
          break
        case 'logout':
          ElMessageBox.confirm(
            'Are you sure you want to logout?',
            'Logout Confirmation',
            {
              confirmButtonText: 'Confirm',
              cancelButtonText: 'Cancel',
              type: 'warning'
            }
          ).then(() => {
            logout().then(() => {
              removeToken()
              router.push('/login')
              ElMessage({
                message: 'Logout successful',
                type: 'success'
              })
            }).catch((error) => {
              console.error('Logout error:', error)
              // Force logout if API fails
              removeToken()
              router.push('/login')
            })
          }).catch(() => {
            // User cancelled logout
          })
          break
      }
    }
    
    return {
      userInfo,
      defaultAvatar,
      toggleSidebar,
      handleCommand
    }
  }
}
</script>

<style scoped>
.header-container {
  height: var(--header-height);
  padding: 0 20px;
  display: flex;
  justify-content: space-between;
  align-items: center;
  background-color: #ffffff;
  box-shadow: 0 1px 4px rgba(0, 21, 41, 0.08);
}

.left-section {
  display: flex;
  align-items: center;
}

.hamburger {
  padding: 0 15px;
  cursor: pointer;
  font-size: 20px;
}

.hamburger:hover {
  color: var(--primary-color);
}

.breadcrumb {
  margin-left: 10px;
}

.right-section {
  display: flex;
  align-items: center;
}

.user-info {
  display: flex;
  align-items: center;
  cursor: pointer;
  padding: 5px 10px;
  border-radius: 4px;
}

.user-info:hover {
  background-color: #f6f6f6;
}

.username {
  margin: 0 10px;
  font-size: 14px;
}
</style>