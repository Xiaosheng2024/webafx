<!-- src/components/layout/Layout.vue -->
<template>
  <div class="app-container">
    <Sidebar class="sidebar" :is-collapsed="isCollapsed" />
    <div class="main-container">
      <Header @toggle-sidebar="toggleSidebar" />
      <div class="content-container">
        <router-view />
      </div>
    </div>
  </div>
</template>

<script>
import { ref } from 'vue'
import Sidebar from './Sidebar.vue'
import Header from './Header.vue'

export default {
  name: 'Layout',
  components: {
    Sidebar,
    Header
  },
  setup() {
    const isCollapsed = ref(false)
    
    const toggleSidebar = () => {
      isCollapsed.value = !isCollapsed.value
    }
    
    return {
      isCollapsed,
      toggleSidebar
    }
  }
}
</script>

<style scoped>
.app-container {
  height: 100vh;
  display: flex;
}

.sidebar {
  height: 100%;
  position: fixed;
  z-index: 1001;
}

.main-container {
  flex: 1;
  display: flex;
  flex-direction: column;
  min-height: 100%;
  margin-left: var(--sidebar-width);
  transition: margin-left 0.3s;
  overflow-x: hidden;
}

.main-container:has(.sidebar.is-collapsed) {
  margin-left: 64px;
}

.content-container {
  padding: 20px;
  flex: 1;
  overflow-y: auto;
  background-color: #f0f2f5;
}

@media (max-width: 768px) {
  .sidebar {
    transform: translateX(-100%);
    transition: transform 0.3s;
  }

  .sidebar.is-visible {
    transform: translateX(0);
  }

  .main-container {
    margin-left: 0;
  }
}
</style>